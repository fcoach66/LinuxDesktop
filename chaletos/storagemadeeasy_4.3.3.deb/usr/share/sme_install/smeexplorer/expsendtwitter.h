#ifndef EXPSENDTWITTER_H
#define EXPSENDTWITTER_H

#include <QtGui/QWidget>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QWidget>
#include <Qt3Support/Q3MimeSourceFactory>
#include <QtGui/QMessageBox>
#include <QtGui/QTextEdit>
#include <QtGui/QKeyEvent>


class ExpSendTwitter : public QWidget
{
    Q_OBJECT

public:
	ExpSendTwitter(QWidget *parent = 0);
	~ExpSendTwitter();
	void clear();
	void clear2();
	void initWnd();

	QString name, message;

	QWidget *widget1;
	QTextEdit *textEdit1;
	QLabel *textLabel1, *textLabel2;
	QPushButton *pushButton1, *pushButton2;
	QLineEdit *lineEdit1;

public
  slots:
	void hideWindow();
	void bshare();

  signals:
    void sendToTwitter();

private:
	virtual void keyPressEvent(QKeyEvent * event);
	virtual void resizeEvent(QResizeEvent * e);

};

#endif // EXPSENDTWITTER_H
