#include "stdio.h"
#include "expsendemail.h"

ExpSendEmail::ExpSendEmail(QWidget *parent) : QWidget(parent){
	widget1 = new QWidget(this);
	widget1->setGeometry(QRect(0, 0, 430, 333));
	this->setWindowTitle("Share File via Email");
	this->setWindowIcon(QIcon("/usr/share/pixmaps/sme_explorer_icon_42.png"));
   widget1->setObjectName(QString::fromUtf8("widget1"));

	int x1=20, y1=18, y2=25;
	int dy=20, dx1=75, dx2=295;
	int x2=x1+dx1+20;
	int y=30;

	textLabel1 = new QLabel(widget1);
	textLabel1->setObjectName(QString::fromUtf8("textLabel1"));
	textLabel1->setGeometry(QRect(x1, y, dx1, y1));
	textLabel1->setText("User Email:");
	lineEdit1 = new QLineEdit(widget1);
	lineEdit1->setObjectName(QString::fromUtf8("lineEdit1"));
	lineEdit1->setGeometry(QRect(x2, y-3, dx2, y2));
	y+=y1+dy-5;

	textLabel2 = new QLabel(widget1);
	textLabel2->setObjectName(QString::fromUtf8("textLabel2"));
	textLabel2->setGeometry(QRect(x1, y, dx1, y1));
	textLabel2->setText("Your Name:");
	lineEdit2 = new QLineEdit(widget1);
	lineEdit2->setObjectName(QString::fromUtf8("lineEdit2"));
	lineEdit2->setGeometry(QRect(x2, y-3, dx2, y2));
	y+=y1+dy-5;

	textLabel3 = new QLabel(widget1);
	textLabel3->setObjectName(QString::fromUtf8("textLabel3"));
	textLabel3->setGeometry(QRect(x1, y, dx1, y1));
	textLabel3->setText("Files Links:");
	lineEdit3 = new QLineEdit(widget1);
	lineEdit3->setObjectName(QString::fromUtf8("lineEdit3"));
	lineEdit3->setGeometry(QRect(x2, y-3, dx2, y2));
	lineEdit3->setReadOnly(true);
	y+=y1+dy-5;

	checkBox1=new QCheckBox("Expire in", widget1);
	checkBox1->setObjectName(QString::fromUtf8("checkBox1"));
	checkBox1->setGeometry(QRect(x1, y, 90, y1));
	checkBox1->setCheckState(Qt::Unchecked);

	lineEdit4 = new QLineEdit(widget1);
	lineEdit4->setObjectName(QString::fromUtf8("lineEdit2"));
	lineEdit4->setGeometry(QRect(x1+95, y-1, 50, y2-4));

	textLabel4 = new QLabel(widget1);
	textLabel4->setObjectName(QString::fromUtf8("textLabel4"));
	textLabel4->setGeometry(QRect(x1+150, y, 80, y1));
	textLabel4->setText("days");
	y+=y1+dy-5;

	textLabel5 = new QLabel(widget1);
	textLabel5->setObjectName(QString::fromUtf8("textLabel5"));
	textLabel5->setGeometry(QRect(x1, y-1, dx1, y1+4));
	textLabel5->setText("Message:");
	textEdit1 = new QTextEdit(widget1);
	textEdit1->setObjectName(QString::fromUtf8("textEdit1"));
	textEdit1->setGeometry(QRect(x2, y-3, dx2, y2*6+3));
	y+=y2*6+dy-12;


	pushButton1 = new QPushButton(widget1);
	pushButton1->setObjectName(QString::fromUtf8("pushButton1"));
	pushButton1->setGeometry(QRect(122, y+5, 85, 29));
	pushButton1->setText("Send");

	pushButton2 = new QPushButton(widget1);
	pushButton2->setObjectName(QString::fromUtf8("pushButton2"));
	pushButton2->setGeometry(QRect(242, y+5, 85, 29));
	pushButton2->setText("Cancel");

// Buttons
	QObject::connect(pushButton1, SIGNAL(clicked()), this, SLOT(bOK()));
	QObject::connect(pushButton2, SIGNAL(clicked()), this, SLOT(hideWindow()));
	QObject::connect(checkBox1, SIGNAL(stateChanged(int)), this, SLOT(checkBox1StateChanged(int)));
}
//////////////////////////////////////////////////////////////////////
ExpSendEmail::~ExpSendEmail(){
}
//////////////////////////////////////////////////////////////////////
void ExpSendEmail::hideWindow(){
  this->hide();
}
//////////////////////////////////////////////////////////////////////
void ExpSendEmail::clear(){
	name="";
	message="";
	type=0;
	countDays=0;
	lineEdit1->setText("");
	lineEdit2->setText("");
	lineEdit3->setText("");
	lineEdit4->setText("0");
	lineEdit4->setEnabled(false);
	textEdit1->setPlainText("");
	checkBox1->setCheckState(Qt::Unchecked);
}
//////////////////////////////////////////////////////////////////////
void ExpSendEmail::initWnd(){
	lineEdit3->setText(name);

	if(expiredEnable){
		checkBox1->setCheckState(Qt::Checked);
	}

}
//////////////////////////////////////////////////////////////////////
void ExpSendEmail::checkBox1StateChanged(int n){
	n++;
	if(checkBox1->checkState()==Qt::Checked){
		lineEdit4->setEnabled(true);
	}else{
		lineEdit4->setEnabled(false);
	}

}
//////////////////////////////////////////////////////////////////////
void ExpSendEmail::bOK(){
	QString text1=lineEdit2->text();
	countDays=text1.toInt();
	if(checkBox1->checkState()==Qt::Checked){
		expiredEnable=true;
	}else{
		expiredEnable=false;
	}

	email=lineEdit1->text();
	username=lineEdit2->text();
	countDays=lineEdit4->text().toInt();

	if(email.length()<1){
		QMessageBox::critical(this, "Error", "    Enter Email    ");
		return ;
	}

	if(username.length()<1){
		QMessageBox::critical(this, "Error", "    Enter your name    ");
		return ;
	}

	message=textEdit1->toPlainText();

	emit sendToEmail();
	this->hide();
}
//////////////////////////////////////////////////////////////////////
void ExpSendEmail::keyPressEvent(QKeyEvent *event){
	int key=event->key();
	if(key==Qt::Key_Escape){
		hideWindow();
	}else if(key==Qt::Key_Enter || key==Qt::Key_Return){
		bOK();
	}

}
//////////////////////////////////////////////////////////////////////
void ExpSendEmail::resizeEvent(QResizeEvent *e){
	int w=width();
	int h=height();
	widget1->setGeometry(QRect(0, 0, w, h));
	if(e){}

	int x1=3, y1=18, y2=25;
	int dy=20, dx1=(int) (w/2.6+x1-5), dx2=w-dx1-x1-6;
	int x2=x1+dx1+4;
	int y=6;

	textLabel1->setGeometry(QRect(x1, y, dx1, y1));
	lineEdit1->setGeometry(QRect(x2, y-3, dx2, y2));
	y+=y1+dy-5;

	textLabel2->setGeometry(QRect(x1, y, dx1, y1));
	lineEdit2->setGeometry(QRect(x2, y-3, dx2, y2));
	y+=y1+dy-5;

	textLabel3->setGeometry(QRect(x1, y, dx1, y1));
	lineEdit3->setGeometry(QRect(x2, y-3, dx2, y2));
	y+=y1+dy-5;

	int rx=x1, ddx=(int) (w-2*x1-50)/3;
	checkBox1->setGeometry(QRect(rx, y, (int) (ddx/1.1), y1));
	rx+=(int) (ddx/1.1);
	lineEdit4->setGeometry(QRect(rx, y-1, 50, y2-4));
	rx+=50+2;
	textLabel4->setGeometry(QRect(rx, y, (int) (ddx/1.5), y1));
	y+=y1+dy-5;

	textLabel5->setGeometry(QRect(x1, y-1, dx1, y1+4));
	textEdit1->setGeometry(QRect(x2, y-3, dx2, y2*6+3));
	y+=y2*6+dy-7;

	pushButton1->setGeometry(QRect(x1+5, y, 100, 29));
	pushButton2->setGeometry(QRect(x1+130, y, 100, 29));

}


