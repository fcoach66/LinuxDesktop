#ifndef EXPSHARE_H
#define EXPSHARE_H

#include <QtGui/QWidget>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QWidget>
#include <Qt3Support/Q3MimeSourceFactory>
#include <QtGui/QMessageBox>
#include <QtGui/QCheckBox>
#include <QtGui/QTextEdit>
#include <QDateTime>
#include <QTreeWidget>
#include <QTreeWidgetItem>
#include <QtGui/QKeyEvent>


typedef struct {
	QString id;
	QString pid;
	QString name;
	int type;			// 2-user, 3-group
	QTreeWidgetItem *node;
} TshareGU;

class ExpShare : public QWidget
{
    Q_OBJECT

public:
	ExpShare(QWidget *parent = 0);
	~ExpShare();
	void clear();
	void clear2();
	void initWnd();

	QString id;
	QString name;
	int type;				// 0 - file, 1 - folder

	QString comment;
	int countDays;
	bool expiredEnable, sharewithsubfolders;

	TshareGU *grouplist;
	int countGU;
	int sx, sy;

	QWidget *widget1;
	QTextEdit *textEdit1;
	QLabel *textLabel1, *textLabel2, *textLabel3, *textLabel4, *textLabel5;
	QPushButton *pushButton1, *pushButton2;
	QLineEdit *lineEdit1, *lineEdit2;
	QCheckBox *checkBox1, *checkBox2;
	QTreeWidget *tree;
	bool addToTree(QString id, QString name, int type, QString pid="0");

public
  slots:
	void hideWindow();
	void checkBox1StateChanged(int n);
	void bshare();

  signals:
    void shareWithGroupOrUser();

private:
	virtual void keyPressEvent(QKeyEvent * event);
	virtual void resizeEvent(QResizeEvent * e);


};

#endif // EXPSHARE_H
