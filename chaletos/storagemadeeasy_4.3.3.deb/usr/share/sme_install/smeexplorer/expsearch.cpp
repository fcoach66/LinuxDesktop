#include "expsearch.h"

ExpSearch::ExpSearch(QWidget *parent) : QWidget(parent){
	widget1 = new QWidget(this);
	widget1->setGeometry(QRect(0, 0, 430, 200));
	this->setWindowTitle("Search");
	this->setWindowIcon(QIcon("/usr/share/pixmaps/sme_explorer_icon_42.png"));
   widget1->setObjectName(QString::fromUtf8("widget1"));

	int x1=20, y1=18, y2=25;
	int dy=15, dx1=100, dx2=270;
	int x2=x1+dx1+20;
	int y=19;

	textLabel1 = new QLabel(widget1);
	textLabel1->setObjectName(QString::fromUtf8("textLabel1"));
	textLabel1->setGeometry(QRect(x1, y, dx1, y1));
	textLabel1->setText("Search for:");
	lineEdit1 = new QLineEdit(widget1);
	lineEdit1->setObjectName(QString::fromUtf8("lineEdit1"));
	lineEdit1->setGeometry(QRect(x2, y-3, dx2, y2));
	y+=y1+dy;


	comboBox1 = new QComboBox(widget1);
	comboBox1->setObjectName(QString::fromUtf8("comboBox1"));
	comboBox1->setGeometry(QRect(x1, y, dx1+20, y2));
	comboBox2 = new QComboBox(widget1);
	comboBox2->setObjectName(QString::fromUtf8("comboBox2"));
	comboBox2->setGeometry(QRect(x2+20, y, dx2-20, y2));
	y+=y1+dy;

	comboBox1->insertItem(0, "Any word");
	comboBox1->insertItem(1, "All words");
	comboBox1->insertItem(2, "Exact phrase");

	comboBox2->insertItem(0, "My files only");
	comboBox2->insertItem(1, "My & shared files");
	comboBox2->insertItem(2, "Public files");

	checkBox1=new QCheckBox("Name", widget1);
	checkBox1->setObjectName(QString::fromUtf8("checkBox1"));
	checkBox1->setGeometry(QRect(x1+15, y, 150, y2));
	checkBox1->setCheckState(Qt::Unchecked);
	checkBox4=new QCheckBox("Extension", widget1);
	checkBox4->setObjectName(QString::fromUtf8("checkBox4"));
	checkBox4->setGeometry(QRect(x2+70, y, 150, y2));
	checkBox4->setCheckState(Qt::Unchecked);
	y+=y1+dy-5;
	checkBox2=new QCheckBox("Description", widget1);
	checkBox2->setObjectName(QString::fromUtf8("checkBox2"));
	checkBox2->setGeometry(QRect(x1+15, y, 150, y2));
	checkBox2->setCheckState(Qt::Unchecked);
	checkBox5=new QCheckBox("Extension exactly", widget1);
	checkBox5->setObjectName(QString::fromUtf8("checkBox5"));
	checkBox5->setGeometry(QRect(x2+70, y, 150, y2));
	checkBox5->setCheckState(Qt::Unchecked);
	y+=y1+dy-5;
	checkBox3=new QCheckBox("Tags", widget1);
	checkBox3->setObjectName(QString::fromUtf8("checkBox3"));
	checkBox3->setGeometry(QRect(x1+15, y, 150, y2));
	checkBox3->setCheckState(Qt::Unchecked);
	y+=y1+dy+10;

	pushButton1 = new QPushButton(widget1);
	pushButton1->setObjectName(QString::fromUtf8("pushButton1"));
	pushButton1->setGeometry(QRect(200, y, 85, 29));
	pushButton1->setText("Search");
	pushButton2 = new QPushButton(widget1);
	pushButton2->setObjectName(QString::fromUtf8("pushButton2"));
	pushButton2->setGeometry(QRect(306, y, 85, 29));
	pushButton2->setText("Cancel");

// Buttons
	QObject::connect(pushButton1, SIGNAL(clicked()), this, SLOT(bOK()));
	QObject::connect(pushButton2, SIGNAL(clicked()), this, SLOT(hideWindow()));
}
//////////////////////////////////////////////////////////////////////
ExpSearch::~ExpSearch(){
}
//////////////////////////////////////////////////////////////////////
void ExpSearch::bOK(){
	stext=lineEdit1->text();

	if(checkBox1->checkState()==Qt::Checked){
		byName=true;
	}else{
		byName=false;
	}

	if(checkBox4->checkState()==Qt::Checked){
		byExtension=true;
	}else{
		byExtension=false;
	}

	if(checkBox5->checkState()==Qt::Checked){
		byExtensionExactly=true;
	}else{
		byExtensionExactly=false;
	}

	if(checkBox2->checkState()==Qt::Checked){
		byDescription=true;
	}else{
		byDescription=false;
	}

	if(checkBox3->checkState()==Qt::Checked){
		byTags=true;
	}else{
		byTags=false;
	}

	if(stext.length()<1){
		QMessageBox::critical(this, "Error", "Enter text for search");
		return ;
	}

	typeSearch=comboBox2->currentIndex();
	typeOfSearch="";
	int i=comboBox1->currentIndex();
	if(i==0){
		typeOfSearch="o";
	}else if(i==1){
		typeOfSearch="a";
	}else if(i==2){
		typeOfSearch="e";
	}

	emit startSearch();
	this->hide();
}
//////////////////////////////////////////////////////////////////////
void ExpSearch::hideWindow(){
  this->hide();
}
//////////////////////////////////////////////////////////////////////
void ExpSearch::clear(){
	stext="";
	checkBox1->setCheckState(Qt::Unchecked);
	checkBox2->setCheckState(Qt::Unchecked);
	checkBox3->setCheckState(Qt::Unchecked);
	checkBox4->setCheckState(Qt::Unchecked);
	checkBox5->setCheckState(Qt::Unchecked);

}
//////////////////////////////////////////////////////////////////////
void ExpSearch::initWnd(){
	lineEdit1->setText(stext);

}
//////////////////////////////////////////////////////////////////////
void ExpSearch::keyPressEvent(QKeyEvent *event){
	int key=event->key();
	if(key==Qt::Key_Escape){
		hideWindow();
	}else if(key==Qt::Key_Enter || key==Qt::Key_Return){
		bOK();
	}

}
//////////////////////////////////////////////////////////////////////
void ExpSearch::resizeEvent(QResizeEvent *e){
	int w=width();
	int h=height();
	widget1->setGeometry(QRect(0, 0, w, h));
	if(e){}

	int x1=3, y1=18, y2=25;
	int dy=15, dx1=(int) (w/2.7-x1), dx2=w-dx1-2*x1-10;
	int x2=x1+dx1+5;
	int y=10;

	textLabel1->setGeometry(QRect(x1, y, dx1, y1));
	lineEdit1->setGeometry(QRect(x2, y-3, dx2, y2));
	y+=y1+dy;

	comboBox1->setGeometry(QRect(x1, y, dx1+20, y2));
	comboBox2->setGeometry(QRect(x2+20, y, dx2-20, y2));
	y+=y1+dy;

	checkBox1->setGeometry(QRect(x1, y, 220, y2));
	checkBox4->setGeometry(QRect(x2+50, y, 220, y2));
	y+=y1+dy-5;
	checkBox2->setGeometry(QRect(x1, y, 220, y2));
	checkBox5->setGeometry(QRect(x2+50, y, 220, y2));
	y+=y1+dy-5;
	checkBox3->setGeometry(QRect(x1, y, 220, y2));
	y+=y1+dy+3;

	pushButton1->setGeometry(QRect(x1+5, y, 100, 29));
	pushButton2->setGeometry(QRect(x1+125, y, 100, 29));

}

