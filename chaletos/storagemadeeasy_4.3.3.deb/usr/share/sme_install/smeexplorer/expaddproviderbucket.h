#ifndef EXPADDPROVIDERBUCKET_H
#define EXPADDPROVIDERBUCKET_H

#include <QtGui/QWidget>
#include <QtGui/QLabel>
#include <QtGui/QCheckBox>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QWidget>
#include <Qt3Support/Q3MimeSourceFactory>
#include <QtGui/QMessageBox>
#include <QtGui/QCheckBox>
#include <QtGui/QKeyEvent>


class ExpAddProviderBucket : public QWidget
{
    Q_OBJECT

public:
	ExpAddProviderBucket(QWidget *parent = 0);
	~ExpAddProviderBucket();
	void initWnd();
	QString bucketname;
	bool EULocation;

	QWidget *widget1;
	QLabel *textLabel1;
	QPushButton *pushButton1, *pushButton2;
	QLineEdit *lineEdit1;
	QCheckBox *checkBox1;

public
  slots:
    void bOK();
    void hideWindow();

  signals:
    void addBucket();

private:
	virtual void keyPressEvent(QKeyEvent * event);
	virtual void resizeEvent(QResizeEvent * e);

};

#endif // EXPADDPROVIDERBUCKET_H
