#ifndef UI_SMESTORAGEEXPLORER_H
#define UI_SMESTORAGEEXPLORER_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QLabel>
//#include <QtGui/QCheckBox>
#include <QtGui/QPushButton>
#include <QtGui/QWidget>
#include <QtGui/QProgressBar>

#include <QtGui/QFileDialog>

#include <Qt3Support/Q3MimeSourceFactory>
#include <QtGui/QMenu>
#include <QtGui/QMenuBar>
#include <QtGui/QMessageBox>
#include <QtGui/QLineEdit>
#include <QtGui/QComboBox>

#include <QTreeWidget>
#include <QTreeWidgetItem>
#include <QString>
//#include <QDate>

#include <QListWidget>
#include <QListWidgetItem>
#include <QModelIndex>


class Ui_SMEStorageExplorer
{
public:
	QWidget *widget;
	QPushButton *pushButton0, *pushButton1, *pushButton2, *pushButton3, *pushButton4, *pushButton5, *pushButton6, *pushButton7, *pushButton8,
		*pushButton9, *pushButton10, *pushButton11, *pushButton12, *pushButton13, *pushButton14, *pushButton15, *pushButton16, *pushButton17,
		*pushButton18, *pushButton19, *pushButton20;
	QLabel *textLabel1;
	QProgressBar *progressBar1;
	QMenuBar *MenuBar;
	QMenu *fileMenu, *viewMenu, *shareMenu, *helpMenu;
	QTreeWidget *tree;
	QListWidget *listWidget;
	QLineEdit *lineEdit1;
	QComboBox *comboBox1;

	void setupUi(QWidget *SMEStorageExplorer)
	{
		QString pathToIcon="/usr/share/smeclient/exp/";
		QString pathToWIcon="/usr/share/pixmaps/";

      if(SMEStorageExplorer->objectName().isEmpty())
          SMEStorageExplorer->setObjectName(QString::fromUtf8("StorageMadeEasyExplorer"));
		SMEStorageExplorer->resize(840, 391);
		SMEStorageExplorer->setMinimumSize(150, 50);
		SMEStorageExplorer->setWindowIcon(QIcon(pathToWIcon +"sme_explorer_icon_42.png"));

      widget = new QWidget(SMEStorageExplorer);
      widget->setObjectName(QString::fromUtf8("widget"));
      widget->setGeometry(QRect(0, 0, 840, 391));

		int sw=1, w=37, h=40, p=3, p_big=14, y=0;
		MenuBar = new QMenuBar(widget);
		MenuBar->setObjectName(QString::fromUtf8("MenuBar"));
		MenuBar->setGeometry(QRect(0, y, 840, 15));
		fileMenu = new QMenu(MenuBar);
		fileMenu->setObjectName(QString::fromUtf8("fileMenu"));
      fileMenu->setTitle("&File");
		MenuBar->addAction(fileMenu->menuAction());
		shareMenu = new QMenu(MenuBar);
		shareMenu->setObjectName(QString::fromUtf8("shareMenu"));
      shareMenu->setTitle("&Share");
		MenuBar->addAction(shareMenu->menuAction());
		helpMenu = new QMenu(MenuBar);
		helpMenu->setObjectName(QString::fromUtf8("helpMenu"));
      helpMenu->setTitle("&Help");
		MenuBar->addAction(helpMenu->menuAction());
		y+=26;

//		lineEdit1=new QLineEdit(widget);
//		lineEdit1->setObjectName(QString::fromUtf8("lineEdit1"));
//		lineEdit1->setGeometry(QRect(sw, y, 400, 24));
//		lineEdit1->setReadOnly(true);
		comboBox1=new QComboBox(widget);
		comboBox1->setGeometry(QRect(sw, y, 400, 24));
		comboBox1->setEditable(false);
//		QLineEdit *edit=new QLineEdit();
//		comboBox1->setLineEdit(lineEdit1);
		y+=25;

		pushButton0 = new QPushButton(QIcon(pathToIcon +"back.gif"), "", widget);
		pushButton0->setObjectName(QString::fromUtf8("pushButton0"));
		pushButton0->setGeometry(QRect(sw, y, w, h));
		pushButton0->setToolTip("Back");

		sw+=w+p;
		pushButton1 = new QPushButton(QIcon(pathToIcon +"next.gif"), "", widget);
		pushButton1->setObjectName(QString::fromUtf8("pushButton1"));
		pushButton1->setGeometry(QRect(sw, y, w, h));
		pushButton1->setToolTip("Next");

		sw+=w+p_big;
		pushButton2 = new QPushButton(QIcon(pathToIcon +"refresh.gif"), "", widget);
		pushButton2->setObjectName(QString::fromUtf8("pushButton2"));
		pushButton2->setGeometry(QRect(sw, y, w, h));
		pushButton2->setToolTip("Refresh");

		sw+=w+p_big;
		pushButton3 = new QPushButton(QIcon(pathToIcon +"download.gif"), "", widget);
		pushButton3->setObjectName(QString::fromUtf8("pushButton3"));
		pushButton3->setGeometry(QRect(sw, y, w, h));
		pushButton3->setToolTip("Download");

		sw+=w+p;
		pushButton4 = new QPushButton(QIcon(pathToIcon +"upload.gif"), "", widget);
		pushButton4->setObjectName(QString::fromUtf8("pushButton4"));
		pushButton4->setGeometry(QRect(sw, y, w, h));
		pushButton4->setToolTip("Upload");

		sw+=w+p_big;
		pushButton5 = new QPushButton(QIcon(pathToIcon +"share.gif"), "", widget);
		pushButton5->setObjectName(QString::fromUtf8("pushButton5"));
		pushButton5->setGeometry(QRect(sw, y, w, h));
		pushButton5->setToolTip("Sharing");

		sw+=w+p;
		pushButton10 = new QPushButton(QIcon(pathToIcon +"copy.gif"), "", widget);
		pushButton10->setObjectName(QString::fromUtf8("pushButton10"));
		pushButton10->setGeometry(QRect(sw, y, w, h));
		pushButton10->setToolTip("Copy");

		sw+=w+p;
		pushButton11 = new QPushButton(QIcon(pathToIcon +"paste.gif"), "", widget);
		pushButton11->setObjectName(QString::fromUtf8("pushButton11"));
		pushButton11->setGeometry(QRect(sw, y, w, h));
		pushButton11->setToolTip("Paste");

		sw+=w+p;
		pushButton6 = new QPushButton(QIcon(pathToIcon +"import_export.gif"), "", widget);
		pushButton6->setObjectName(QString::fromUtf8("pushButton6"));
		pushButton6->setGeometry(QRect(sw, y, w, h));
		pushButton6->setToolTip("Import/Export");

		sw+=w+p;
		pushButton7 = new QPushButton(QIcon(pathToIcon +"favourite.gif"), "", widget);
		pushButton7->setObjectName(QString::fromUtf8("pushButton7"));
		pushButton7->setGeometry(QRect(sw, y, w, h));
		pushButton7->setToolTip("Add/Remove File(s) to/from Favourites");

		sw+=w+p_big;
		pushButton8 = new QPushButton(QIcon(pathToIcon +"createfolder.gif"), "", widget);
		pushButton8->setObjectName(QString::fromUtf8("pushButton8"));
		pushButton8->setGeometry(QRect(sw, y, w, h));
		pushButton8->setToolTip("New Folder/Group");

		sw+=w+p;
		pushButton13 = new QPushButton("abc", widget);
		pushButton13->setObjectName(QString::fromUtf8("pushButton13"));
		pushButton13->setGeometry(QRect(sw, y, w, h));
		pushButton13->setToolTip("Rename Folder/File/Group/Share");

		sw+=w+p;
		pushButton14 = new QPushButton(QIcon(pathToIcon +"delete.gif"), "", widget);
		pushButton14->setObjectName(QString::fromUtf8("pushButton14"));
		pushButton14->setGeometry(QRect(sw, y, w, h));
		pushButton14->setToolTip("Delete Folder/File/Group");

		sw+=w+p;
		pushButton15 = new QPushButton(QIcon(pathToIcon +"search.gif"), "", widget);
		pushButton15->setObjectName(QString::fromUtf8("pushButton15"));
		pushButton15->setGeometry(QRect(sw, y, w, h));
		pushButton15->setToolTip("Search for Files");

		sw+=w+p;
		pushButton16 = new QPushButton(QIcon(pathToIcon +"cloudproviders.gif"), "", widget);
		pushButton16->setObjectName(QString::fromUtf8("pushButton16"));
		pushButton16->setGeometry(QRect(sw, y, w, h));
		pushButton16->setToolTip("Cloud Providers");

		sw+=w+p_big;
		pushButton17 = new QPushButton(QIcon(pathToIcon +"view.gif"), "", widget);
		pushButton17->setObjectName(QString::fromUtf8("pushButton17"));
		pushButton17->setGeometry(QRect(sw, y, w, h));
		pushButton17->setToolTip("View");
		sw+=w+p;
		pushButton18 = new QPushButton(QIcon(pathToIcon +"about.gif"), "", widget);
		pushButton18->setObjectName(QString::fromUtf8("pushButton18"));
		pushButton18->setGeometry(QRect(sw, y, w, h));
		pushButton18->setToolTip("About");
		sw+=w+p;

		y+=74;

listWidget=new QListWidget(widget);
listWidget->setGeometry(QRect(3, y, 800, 278));
QFont font1;
font1=listWidget->font();
font1.setPointSize(9);
listWidget->setFont(font1);

//listWidget->setSelectionMode(QAbstractItemView::MultiSelection);
//listWidget->setSelectionMode(QAbstractItemView::ContiguousSelection);
listWidget->setSelectionMode(QAbstractItemView::ExtendedSelection);




		textLabel1 = new QLabel(widget);
		textLabel1->setObjectName(QString::fromUtf8("textLabel1"));
		textLabel1->setGeometry(QRect(3, 368, 700, 22));
		textLabel1->setWordWrap(true);

		progressBar1 = new QProgressBar(widget);
		progressBar1->setObjectName(QString::fromUtf8("progressBar1"));
		progressBar1->setGeometry(QRect(503, 368, 200, 20));

		pushButton9 = new QPushButton(widget);
		pushButton9->setObjectName(QString::fromUtf8("pushButton9"));
		pushButton9->setGeometry(QRect(710, 368, 80, 23));

		retranslateUi(SMEStorageExplorer);

		QMetaObject::connectSlotsByName(SMEStorageExplorer);
    } // setupUi

    void retranslateUi(QWidget *SMEStorageExplorer)
    {
      SMEStorageExplorer->setWindowTitle("Storage Made Easy Explorer");

		textLabel1->setText("");
		textLabel1->hide();
		pushButton9->setText("Cancel");
		pushButton9->hide();
		progressBar1->hide();

      Q_UNUSED(SMEStorageExplorer);
    }// retranslateUi

};

namespace Ui {
	class SMEStorageExplorer: public Ui_SMEStorageExplorer {};
} // namespace Ui

#endif // UI_SMESTORAGEEXPLORER_H
