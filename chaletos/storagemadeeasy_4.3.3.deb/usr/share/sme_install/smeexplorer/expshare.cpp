#include "stdio.h"
#include "expshare.h"

ExpShare::ExpShare(QWidget *parent) : QWidget(parent){
	widget1 = new QWidget(this);
	widget1->setGeometry(QRect(0, 0, 430, 470));
	this->setWindowTitle("Share File with Business Group or User");
	this->setWindowIcon(QIcon("/usr/share/pixmaps/sme_explorer_icon_42.png"));
   widget1->setObjectName(QString::fromUtf8("widget1"));

	int x1=3, y1=18, y2=25;
	int dy=2, dy2=15, dx1=424;
	int y=6;
	countGU=0;

	textLabel1 = new QLabel(widget1);
	textLabel1->setObjectName(QString::fromUtf8("textLabel1"));
	textLabel1->setGeometry(QRect(x1, y, dx1, y1));
	textLabel1->setText("Share File:");
	y+=y1+dy;
	lineEdit1 = new QLineEdit(widget1);
	lineEdit1->setObjectName(QString::fromUtf8("lineEdit1"));
	lineEdit1->setGeometry(QRect(x1, y-3, dx1, y2));
	lineEdit1->setReadOnly(true);
	y+=y1+dy+dy2;

	textLabel2 = new QLabel(widget1);
	textLabel2->setObjectName(QString::fromUtf8("textLabel2"));
	textLabel2->setGeometry(QRect(x1, y, dx1, y1));
	textLabel2->setText("With Business Group or User:");
	y+=y1+dy;
	tree = new QTreeWidget(widget1);
	tree->setObjectName(QString::fromUtf8("tree"));
	tree->setGeometry(QRect(x1, y, dx1, 170));
	tree->setUpdatesEnabled(true);
	tree->setColumnCount(1);
	tree->headerItem()->setHidden(true);
	y+=170+dy+dy2;

	textLabel3 = new QLabel(widget1);
	textLabel3->setObjectName(QString::fromUtf8("textLabel3"));
	textLabel3->setGeometry(QRect(x1, y, dx1, y1));
	textLabel3->setText("Comment:");
	y+=y1+dy;
	textEdit1 = new QTextEdit(widget1);
	textEdit1->setObjectName(QString::fromUtf8("textEdit1"));
	textEdit1->setGeometry(QRect(x1, y, dx1, y1*5));
	y+=y1*5+dy+dy2;

	checkBox1=new QCheckBox("Expire in", widget1);
	checkBox1->setObjectName(QString::fromUtf8("checkBox1"));
	checkBox1->setGeometry(QRect(x1, y, 102, y1));
	checkBox1->setCheckState(Qt::Unchecked);

	lineEdit2 = new QLineEdit(widget1);
	lineEdit2->setObjectName(QString::fromUtf8("lineEdit2"));
	lineEdit2->setGeometry(QRect(x1+103, y-1, 50, y2-4));

	textLabel4 = new QLabel(widget1);
	textLabel4->setObjectName(QString::fromUtf8("textLabel4"));
	textLabel4->setGeometry(QRect(x1+153, y, 78, y1));
	textLabel4->setText("days");

	checkBox2=new QCheckBox("Include subfolders", widget1);
	checkBox2->setObjectName(QString::fromUtf8("checkBox2"));
	checkBox2->setGeometry(QRect(x1+242, y, 179+10, y1));
	checkBox2->setCheckState(Qt::Unchecked);
	y+=y1+dy+dy2;




	pushButton1 = new QPushButton(widget1);
	pushButton1->setObjectName(QString::fromUtf8("pushButton1"));
	pushButton1->setGeometry(QRect(110, y, 100, 29));
	pushButton1->setText("Share");

	pushButton2 = new QPushButton(widget1);
	pushButton2->setObjectName(QString::fromUtf8("pushButton2"));
	pushButton2->setGeometry(QRect(220, y, 100, 29));
	pushButton2->setText("Cancel");

// Buttons
	QObject::connect(pushButton1, SIGNAL(clicked()), this, SLOT(bshare()));
	QObject::connect(pushButton2, SIGNAL(clicked()), this, SLOT(hideWindow()));
	QObject::connect(checkBox1, SIGNAL(stateChanged(int)), this, SLOT(checkBox1StateChanged(int)));
}
//////////////////////////////////////////////////////////////////////
ExpShare::~ExpShare(){
}
//////////////////////////////////////////////////////////////////////
void ExpShare::hideWindow(){
  this->hide();
}
//////////////////////////////////////////////////////////////////////
void ExpShare::clear(){
	clear2();
	id="";
	name="";
	comment="";
	type=0;
	countDays=0;
	sharewithsubfolders=false;
	expiredEnable=false;
	lineEdit2->setText("0");
	lineEdit2->setEnabled(false);

	int maxCount=10000;
	countGU=0;
	grouplist=new TshareGU[maxCount];
	for(int i=0; i<maxCount; i++){
		grouplist[i].id="";
		grouplist[i].pid="";
		grouplist[i].name="";
	}

}
//////////////////////////////////////////////////////////////////////
void ExpShare::clear2(){
	if(countGU>0){
		for(int i=countGU-1; i>=0; i--){
			if(grouplist[i].name!=""){
				grouplist[i].name="";
				delete grouplist[i].node;
			}
		}

		delete []grouplist;
		countGU=0;
	}
}
//////////////////////////////////////////////////////////////////////
void ExpShare::initWnd(){
	lineEdit1->setText(name);

	if(expiredEnable)	checkBox1->setCheckState(Qt::Checked);
	if(type!=1)	checkBox2->setVisible(false);

	if(sx<0) sx=0;
	if(sy<0) sy=0;
	move(QPoint(sx, sy));

}
//////////////////////////////////////////////////////////////////////
bool ExpShare::addToTree(QString id, QString name, int type, QString pid){
	TshareGU elem;
	elem.id=id;
	elem.pid=pid;
	elem.name=name;
	elem.type=type;

	grouplist[countGU]=elem;
	countGU++;

	if(pid=="" || pid=="0"){
		grouplist[countGU-1].node=new QTreeWidgetItem(tree);
//		grouplist[countGU-1].node=new QTreeWidgetItem(tree->invisibleRootItem());
	}else{
		int n=-1;
		for(int i=0; grouplist[i].name!=""; i++){
			if(grouplist[i].id==pid){
				n=i;
				break;
			}
		}
		if(n==-1) return false;
		grouplist[countGU-1].node=new QTreeWidgetItem(grouplist[n].node);
	}

	QString ipath="/usr/share/smeclient/exp/files/small/";
	if(type==2){
		ipath+="user.gif";
	}else if(type==3){
		ipath+="group.gif";
	}
	grouplist[countGU-1].node->setText(0, elem.name);
	grouplist[countGU-1].node->setIcon(0, QIcon(ipath));
	
//	tree->insertTopLevelItem(tree->topLevelItemCount(), grouplist[countGU-1].node);

	return true;
}
//////////////////////////////////////////////////////////////////////
void ExpShare::checkBox1StateChanged(int n){
	n++;
	if(checkBox1->checkState()==Qt::Checked){
		lineEdit2->setEnabled(true);
	}else{
		lineEdit2->setEnabled(false);
	}

}
//////////////////////////////////////////////////////////////////////
void ExpShare::bshare(){
	bool L=false;
	for(int i=0; i<countGU; i++){
		if(grouplist[i].node->isSelected()){
			L=true;
			break;
		}
	}

	if(!L){
		QMessageBox::critical(this, "Error", "Select group or user");
		return ;
	}

	QString text1=lineEdit2->text();
	countDays=text1.toInt();
	if(checkBox1->checkState()==Qt::Checked){
		expiredEnable=true;
	}else{
		expiredEnable=false;
	}

	if(checkBox2->checkState()==Qt::Checked){
		sharewithsubfolders=true;
	}else{
		sharewithsubfolders=false;
	}


	comment=textEdit1->toPlainText();

	emit shareWithGroupOrUser();
	this->hide();
}
//////////////////////////////////////////////////////////////////////
void ExpShare::keyPressEvent(QKeyEvent *event){
	int key=event->key();
	if(key==Qt::Key_Escape){
		hideWindow();
	}else if(key==Qt::Key_Enter || key==Qt::Key_Return){
		bshare();
	}

}
//////////////////////////////////////////////////////////////////////
void ExpShare::resizeEvent(QResizeEvent *e){
	int w=width();
	int h=height();
	widget1->setGeometry(QRect(0, 0, w, h));
	if(e){}

	int x1=3, y1=19, y2=25;
	int dy=2, dy2=15, dx1=w-2*x1;
	int y=6;

	textLabel1->setGeometry(QRect(x1, y, dx1, y1));
	y+=y1+dy;
	lineEdit1->setGeometry(QRect(x1, y-3, dx1, y2));
	y+=y1+dy+dy2;

	textLabel2->setGeometry(QRect(x1, y, dx1, y1));
	y+=y1+dy;
	tree->setGeometry(QRect(x1, y, dx1, 170));
	y+=170+dy+dy2;

	textLabel3->setGeometry(QRect(x1, y, dx1, y1));
	y+=y1+dy;
	textEdit1->setGeometry(QRect(x1, y, dx1, y1*5));
	y+=y1*5+dy+dy2;

	int rx=x1, ddx=(int) (w-2*x1-50)/3;
	checkBox1->setGeometry(QRect(x1, y, (int) (ddx/1.1), y1));
	rx+=(int) (ddx/1.1);
	lineEdit2->setGeometry(QRect(rx, y-1, 50, y2-4));
	rx+=50+2;
	textLabel4->setGeometry(QRect(rx, y, (int) (ddx/1.5), y1));
	rx+=(int) (ddx/1.5+15);
	checkBox2->setGeometry(QRect(rx, y, (int) (ddx*1.5), y1));
	y+=y1+dy+dy2;

	pushButton1->setGeometry(QRect(110, y, 100, 29));
	pushButton2->setGeometry(QRect(220, y, 100, 29));

}
