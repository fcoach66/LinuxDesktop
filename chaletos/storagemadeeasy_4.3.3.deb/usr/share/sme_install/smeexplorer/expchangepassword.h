#ifndef EXPCHANGEPASSWORD_H
#define EXPCHANGEPASSWORD_H

#include <QtGui/QWidget>
#include <QtGui/QLabel>
#include <QtGui/QCheckBox>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QWidget>
#include <Qt3Support/Q3MimeSourceFactory>
#include <QtGui/QMessageBox>
#include <QtGui/QCheckBox>
#include <QtGui/QKeyEvent>


class ExpChangePassword : public QWidget
{
    Q_OBJECT

public:
	ExpChangePassword(QWidget *parent = 0);
	~ExpChangePassword();
	void initWnd();
	QString password;

	QWidget *widget1;
	QLabel *textLabel1;
	QPushButton *pushButton1, *pushButton2;
	QLineEdit *lineEdit1;

public
  slots:
    void bOK();
    void hideWindow();

  signals:
    void wchangePassword();

private:
	virtual void keyPressEvent(QKeyEvent * event);


};

#endif // EXPCHANGEPASSWORD_H
