#ifndef EXPUPLOAD_H
#define EXPUPLOAD_H

#include <QtGui/QWidget>
#include <QtGui/QLabel>
#include <QtGui/QCheckBox>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QWidget>
#include <Qt3Support/Q3MimeSourceFactory>
#include <QtGui/QMessageBox>
#include <QtGui/QCheckBox>
#include <QtGui/QKeyEvent>


class ExpUpload : public QWidget
{
    Q_OBJECT

public:
	ExpUpload(QWidget *parent = 0);
	~ExpUpload();
	void clear();
	void initWnd();
	QString name, desc, tags, path, encrypt;

	QWidget *widget1;
	QLabel *textLabel01, *textLabel1, *textLabel2, *textLabel3, *textLabel4, *textLabel5, *textLabel6;
	QPushButton *pushButton1, *pushButton2;
	QLineEdit *lineEdit1, *lineEdit2, *lineEdit3, *lineEdit4, *lineEdit5, *lineEdit6;
	QCheckBox *checkBox1;

public
  slots:
    void bupload();
    void hideWindow();

  signals:
    void uploadFile();
    void hideUploadWindow();

private:
	virtual void keyPressEvent(QKeyEvent * event);
	virtual void resizeEvent(QResizeEvent * e);


};

#endif // EXPUPLOAD_H
