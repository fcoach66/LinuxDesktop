#ifndef EXPREQUESTSHARE_H
#define EXPREQUESTSHARE_H

#include <QtGui/QWidget>
#include <QtGui/QLabel>
#include <QtGui/QPushButton>
#include <QtGui/QWidget>
#include <Qt3Support/Q3MimeSourceFactory>
#include <QtGui/QMessageBox>
#include <QtGui/QTextEdit>
#include <QDateTime>
#include <QComboBox>
#include <QtGui/QKeyEvent>


typedef struct {
	QString id;
	QString name;
} Tsgroup;

typedef struct {
	QString id;
	QString name;
} Tsuser;

class ExpRequestShare : public QWidget
{
    Q_OBJECT

public:
	ExpRequestShare(QWidget *parent = 0);
	~ExpRequestShare();
	void clear();
	void clear2();
	void initWnd();
	void add(bool group, QString id, QString name);
	void debug(QString s);

	QString gid, uid, comment;

//	Tsgroup *groupslist;
//	Tsuser *userslist;
	QString *groupslist, *userslist;
	int countG;
	int countU;

	QWidget *widget1;
	QTextEdit *textEdit1;
	QLabel *textLabel1, *textLabel2, *textLabel3;
	QPushButton *pushButton1, *pushButton2;
	QComboBox *comboBox1, *comboBox2;

public
  slots:
	void hideWindow();
	void bshare();

  signals:
    void requestShare();

private:
	virtual void keyPressEvent(QKeyEvent * event);
	virtual void resizeEvent(QResizeEvent * e);

};

#endif // EXPREQUESTSHARE_H
