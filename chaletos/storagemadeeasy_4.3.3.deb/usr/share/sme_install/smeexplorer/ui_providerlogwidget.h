#ifndef UI_PROVIDERLOGWIDGET_H
#define UI_PROVIDERLOGWIDGET_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
// #include <QtGui/QButtonGroup>
#include <QtGui/QLabel>
#include <QtGui/QCheckBox>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QWidget>

#include <QtGui/QFileDialog>
// #include <QFile>

#include <Qt3Support/Q3MimeSourceFactory>
// #include <QtGui/QDialog>
// #include <QtGui/QMenu>
// #include <QtGui/QMenuBar>
#include <QtGui/QMessageBox>

class Ui_ProviderlogWidget
{
public:
    QWidget *widget;
    QLabel *textLabel1;
    QLabel *textLabel2;
    QPushButton *pushButton1;
    QPushButton *pushButton2;
    QLineEdit *lineEdit1;
    QLineEdit *lineEdit2;

    void setupUi(QWidget *ProviderlogWidget)
    {
      if (ProviderlogWidget->objectName().isEmpty())
          ProviderlogWidget->setObjectName(QString::fromUtf8("ProviderlogWidget"));
      ProviderlogWidget->resize(450, 130);
      ProviderlogWidget->setWindowIcon(QIcon("/usr/share/pixmaps/sme_explorer_icon_42.png"));

      widget = new QWidget(ProviderlogWidget);
      widget->setObjectName(QString::fromUtf8("widget"));
      widget->setGeometry(QRect(0, 0, 450, 200));

      textLabel1 = new QLabel(widget);
      textLabel1->setObjectName(QString::fromUtf8("textLabel1"));
      textLabel1->setGeometry(QRect(30, 39, 120, 18));
      textLabel2 = new QLabel(widget);
      textLabel2->setObjectName(QString::fromUtf8("textLabel2"));
      textLabel2->setGeometry(QRect(30, 90, 120, 18));

		lineEdit1 = new QLineEdit(widget);
      lineEdit1->setObjectName(QString::fromUtf8("lineEdit1"));
      lineEdit1->setGeometry(QRect(165, 33, 240, 31));
      lineEdit2 = new QLineEdit(widget);
      lineEdit2->setObjectName(QString::fromUtf8("lineEdit2"));
      lineEdit2->setGeometry(QRect(165, 83, 240, 31));
		lineEdit2->setEchoMode(QLineEdit::Password);

      pushButton1 = new QPushButton(widget);
      pushButton1->setObjectName(QString::fromUtf8("pushButton1"));
      pushButton1->setGeometry(QRect(255, 160, 75, 27));
      pushButton2 = new QPushButton(widget);
      pushButton2->setObjectName(QString::fromUtf8("pushButton2"));
      pushButton2->setGeometry(QRect(350, 160, 75, 27));

      retranslateUi(ProviderlogWidget);

      QMetaObject::connectSlotsByName(ProviderlogWidget);
    } // setupUi

    void retranslateUi(QWidget *ProviderlogWidget)
    {

      ProviderlogWidget->setWindowTitle(QApplication::translate("ProviderlogWidget", "Provider Advanced", 0, QApplication::UnicodeUTF8));

      textLabel1->setText("Provider Login");
      textLabel2->setText("Provider Password");

      pushButton1->setText(QApplication::translate("Dialog", "OK", 0, QApplication::UnicodeUTF8));
      pushButton2->setText(QApplication::translate("Dialog", "Cancel", 0, QApplication::UnicodeUTF8));

      Q_UNUSED(ProviderlogWidget);
    }// retranslateUi

};

namespace Ui {
    class ProviderlogWidget: public Ui_ProviderlogWidget {};
} // namespace Ui

#endif // UI_PROVIDERLOGWIDGET_H
