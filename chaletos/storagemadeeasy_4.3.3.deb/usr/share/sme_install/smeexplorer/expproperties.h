#ifndef EXPPROPERTIES_H
#define EXPPROPERTIES_H

#include <QtGui/QWidget>
#include <QtGui/QLabel>
#include <QtGui/QCheckBox>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QWidget>
#include <Qt3Support/Q3MimeSourceFactory>
#include <QtGui/QMessageBox>
#include <QtGui/QCheckBox>
#include <QDateTime>
#include <QtGui/QKeyEvent>


class ExpProperties : public QWidget
{
    Q_OBJECT

public:
	ExpProperties(QWidget *parent = 0);
	~ExpProperties();
	void clear();
	void initWnd();

	QString name, description, tags, created, lastmodify, lastaccess, id, pid, size, provider, orgid, orgfolderid, uid, extension;
	int type;					// 0 - file, 1 - folder, 2 - user, 3 - group
	bool encrypted, isPublic, isFavorite, isOrg, isLocked;
//	bool isProcessed;

	int sx, sy;

	QWidget *widget1;
	QLabel *textLabel1, *textLabel2, *textLabel3, *textLabel4, *textLabel5, *textLabel6, *textLabel7, *textLabel8, *textLabel9, *textLabel10, *textLabel11;
	QPushButton *pushButton1;
	QLineEdit *lineEdit1, *lineEdit2, *lineEdit3, *lineEdit4, *lineEdit5, *lineEdit6, *lineEdit7, *lineEdit8, *lineEdit9, *lineEdit10, *lineEdit11;
	QString readableSize(QString size);

public
  slots:
    void hideWindow();

  signals:

private:
	virtual void keyPressEvent(QKeyEvent * event);
	virtual void resizeEvent(QResizeEvent * e);

};

#endif // EXPPROPERTIES_H
