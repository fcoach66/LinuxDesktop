#ifndef EXPSELECTBUCKETS_H
#define EXPSELECTBUCKETS_H

#include <QtGui/QWidget>
#include <QtGui/QPushButton>
#include <QtGui/QWidget>
#include <Qt3Support/Q3MimeSourceFactory>
#include <QtGui/QMessageBox>
#include <QListWidget>
#include <QListWidgetItem>
#include <QModelIndex>
#include <QtGui/QKeyEvent>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QComboBox>

typedef struct {
	QString id, name;
	QListWidgetItem *node;
} TSBucket;

class ExpSelectBuckets : public QWidget
{
    Q_OBJECT

public:
	ExpSelectBuckets(QWidget *parent = 0);
	~ExpSelectBuckets();
	void clear();
	void clear2();
	void initWnd();
	bool addToTree(QString id, QString name);
	QString prid;

	int countB;
	TSBucket *buckets;

	QWidget *widget1;
	QPushButton *pushButton1;
	QLabel *textLabel0, *textLabel1, *textLabel2;
	QLineEdit *lineEdit1;
	QComboBox *comboBox1;
	QListWidget *prList;

private:
	virtual void resizeEvent(QResizeEvent * e);

public
  slots:
	void bOK();

  signals:
	void setBuckets();

private:
	virtual void keyPressEvent(QKeyEvent * event);


};

#endif // EXPSELECTBUCKETS_H
