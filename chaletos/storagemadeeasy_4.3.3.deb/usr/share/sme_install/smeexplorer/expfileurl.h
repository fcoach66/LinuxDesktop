#ifndef EXPFILEURL_H
#define EXPFILEURL_H

#include <QtGui/QWidget>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QWidget>
#include <Qt3Support/Q3MimeSourceFactory>
#include <QtGui/QMessageBox>
#include <QtGui/QKeyEvent>
#include <QtGui/QCheckBox>
#include <QtGui/QRadioButton>

class ExpFileurl : public QWidget
{
    Q_OBJECT

public:
	ExpFileurl(QWidget *parent = 0);
	~ExpFileurl();
	void clear();
	void clear2();
	void initWnd();

	QString name, password;
	int urltype;	// 0-SME url, 1-short URL
	bool useExpire, usePassword;
	int expireDays, expireHours, expireMinutes;

	QWidget *widget1;
	QLabel *textLabel1, *textLabel2, *textLabel3, *textLabel4, *textLabel5;
	QLineEdit *lineEdit1, *lineEdit2, *lineEdit3, *lineEdit4, *lineEdit5;
	QCheckBox *checkBox1, *checkBox2;
	QRadioButton *radioButton1, *radioButton2;
	QPushButton *pushButton1, *pushButton3;

public
  slots:
	void OK();
	void hideWindow();
	void checkBoxStateChanged(int par);

  signals:
    void OKpressed();

private:
	virtual void keyPressEvent(QKeyEvent *event);
	virtual void resizeEvent(QResizeEvent * e);


};

#endif // EXPFILEURL_H
