#include "providerlogwidget.h"
#include "ui_providerlogwidget.h"

ProviderlogWidget::ProviderlogWidget(QWidget *parent) : QWidget(parent), ui(new Ui::ProviderlogWidget){
	ui->setupUi(this);
	plogin="";
	ppass="";

// Buttons
	QObject::connect(ui->pushButton1, SIGNAL(clicked()), this, SLOT(saveProviderlog()));
	QObject::connect(ui->pushButton2, SIGNAL(clicked()), this, SLOT(hideWindow()));
}
//////////////////////////////////////////////////////////////////////
ProviderlogWidget::~ProviderlogWidget(){
	delete ui;
}
//////////////////////////////////////////////////////////////////////
void ProviderlogWidget::saveProviderlog(){
  QString login = ui->lineEdit1->text();
  QString pass  = ui->lineEdit2->text();
  if(login.length()<1){
    QMessageBox::critical(this, tr("Error"), "     Enter login     ");
    return ;
  }

  if(pass.length()<1){
    QMessageBox::critical(this, tr("Error"), "   Enter password   ");
    return ;
  }

	plogin=login;
	ppass=pass;

  emit saveProviderLog();
  this->hide();
}
//////////////////////////////////////////////////////////////////////
void ProviderlogWidget::hideWindow(){
  this->hide();
}
//////////////////////////////////////////////////////////////////////
void ProviderlogWidget::initWnd(){
	ui->lineEdit1->setText(plogin);
	ui->lineEdit2->setText(ppass);

}
//////////////////////////////////////////////////////////////////////
void ProviderlogWidget::resizeEvent(QResizeEvent *e){
	int w=width();
	int h=height();
	int x1=3, x=x1;
	ui->widget->setGeometry(QRect(0, 0, w, h));
	if(e){}
	ui->textLabel1->setGeometry(QRect(x, 19, (int) (w/2-x1-2), 18));
	ui->textLabel2->setGeometry(QRect(x, 60, (int) (w/2-x1-2), 18));
	x=x1+(int) (w/2-x1);

	ui->lineEdit1->setGeometry(QRect(x, 13, (int) (w/2-x1-2), 31));
	ui->lineEdit2->setGeometry(QRect(x, 53, (int) (w/2-x1-2), 31));

	ui->pushButton1->setGeometry(QRect(x1+ 5, 95, 120, 28));
	ui->pushButton2->setGeometry(QRect(x1+140, 95, 120, 28));

}
