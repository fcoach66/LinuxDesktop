#ifndef EXPAUTOSHARERULE_H
#define EXPAUTOSHARERULE_H

#include <QtGui/QWidget>
#include <QtGui/QLabel>
#include <QtGui/QPushButton>
#include <QtGui/QWidget>
#include <Qt3Support/Q3MimeSourceFactory>
#include <QtGui/QMessageBox>
#include <QTreeWidget>
#include <QTreeWidgetItem>
#include <QtGui/QKeyEvent>

typedef struct {
	QString id, folderId;
	QTreeWidgetItem *node;
} TshareR;

class ExpAutoShareRule : public QWidget
{
    Q_OBJECT

public:
	ExpAutoShareRule(QWidget *parent = 0);
	~ExpAutoShareRule();
	void clear();
	void clear2();
	void initWnd();

	QString selectedid;
	TshareR *ruleslist;
	int countR;
	bool isWaiting;

	QWidget *widget1;
	QPushButton *pushButton1, *pushButton2, *pushButton3;
	QTreeWidget *tree;
	bool addToTree(QString id, QString group, QString rule, QString fromFolder, QString folderId);
	bool addFolder(QString id, QString name);
	bool deleteFromTree(QString id);
private:
	virtual void resizeEvent(QResizeEvent * e);

public
  slots:
	void hideWindow();
	void bAddAutoShare();
	void bDeleteAutoShare();

  signals:
    void addAutoShare();
    void deleteAutoShare();

private:
	virtual void keyPressEvent(QKeyEvent * event);


};

#endif // EXPAUTOSHARERULE_H
