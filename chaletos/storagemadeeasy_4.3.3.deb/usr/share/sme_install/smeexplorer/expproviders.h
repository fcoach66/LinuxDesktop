#ifndef EXPPROVIDERS_H
#define EXPPROVIDERS_H

#include <QtGui/QWidget>
#include <QtGui/QLabel>
#include <QtGui/QCheckBox>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QWidget>
#include <Qt3Support/Q3MimeSourceFactory>
#include <QtGui/QMessageBox>
#include <QtGui/QCheckBox>
#include <QtGui/QTextEdit>
#include <QDateTime>
#include <QTreeWidget>
#include <QTreeWidgetItem>
#include <QtGui/QKeyEvent>
#include "expchangepassword.h"
#include "expaddprovider.h"

typedef struct {
//	QString prid, prname, classname, paids, practive, prisprovider, prforimport, prforexport, prdescription, prcode, prsupportedbackup, pr_fileslisttype;
	QString pi_login, defaultfolder, pi_id, prid, defaultfolderid, pr_name, cf;  // cf - count files
	bool pi_master, isBackup, isDefault;
	QTreeWidgetItem *node;
} TNProvider;


class ExpProviders : public QWidget
{
    Q_OBJECT

public:
	ExpProviders(QWidget *parent = 0);
	~ExpProviders();
	void clear();
	void clear2();
	void initWnd();

	QString newPassword, newProviderId, providerId;
	int providerType;				// 1 - Amazon S3, 2 - Mosso (RacksSpace)
	ExpChangePassword changePasswordWnd;
	ExpAddProvider addProviderWnd;

	TNProvider *providerslist, *aproviderslist;
	int countP, countA;

	QWidget *widget1;
	QPushButton *pushButton1, *pushButton2, *pushButton3, *pushButton4, *pushButton5, *pushButton6;
	QTreeWidget *tree;
//	bool addToTree(QString id, QString name, int type, QString pid="0");
	bool addToTree(TNProvider elem);
	bool addAllowedPr(TNProvider elem);
	void upateNode(int n);

public
  slots:
	void baddProvider();
	void bgetProviderMetaFields();
	void bsetDefault();
	void bchangePassword();
	void bchangePassword2();
	void bsyncNow();
	void bsyncTask();
	void updateState();
	void bmanageBuckets();

  signals:
	void setDefaultProvider();
	void changePassword();
	void syncNow();
	void syncTask();
	void getProviderMetaFields();
	void manageBuckets();

private:
	virtual void resizeEvent(QResizeEvent * e);
	virtual void keyPressEvent(QKeyEvent * event);


};

#endif // EXPPROVIDERS_H
