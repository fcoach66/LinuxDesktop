#include "expinformationwindow.h"

ExpInformationWindow::ExpInformationWindow(QWidget *parent) : QWidget(parent){
	widget1 = new QWidget(this);
	widget1->setGeometry(QRect(0, 0, 460, 345));
	this->setWindowTitle("Warning! Detected old version");
	this->setWindowIcon(QIcon("/usr/share/pixmaps/sme_explorer_icon_42.png"));
   widget1->setObjectName(QString::fromUtf8("widget1"));

	textEdit1 = new QTextEdit(widget1);
	textEdit1->setObjectName(QString::fromUtf8("textEdit1"));
	textEdit1->setGeometry(QRect(1, 1, 100, 100));
	textEdit1->setReadOnly(true);
	textEdit1->setText("Name of the package have been <b>changed</b>.<br><br>You have <b>installed two versions: old and new</b>.<br>It will be <b>conflicts</b> between old and new version!<br>You must <b>remove old</b> version.<br><br>You can remove old version via <b>package manager</b> (Synaptic Package Manager, YaST, etc.) or via <b>terminal</b>.<br>Name of old package is <b>smestorage</b> (if you installed it by using RMP) and <b>libfusesme-perl</b> (if you installed it by using DEB)<br><br>If you use Ubuntu/KUbuntu/Debian or have installed old package by using DEB then you can remove old package via <b>terminal</b> by using command:<br><b>sudo dpkg --remove libfusesme-perl</b><br><br>If you use CentOS/OpenSUSE/Fedora/Mandriva or have installed old package by using RPM then you can remove old package via <b>terminal</b> by using command:<br><b>sudo rpm -e smestorage</b><br>");

	pushButton1 = new QPushButton(widget1);
	pushButton1->setObjectName(QString::fromUtf8("pushButton1"));
	pushButton1->setGeometry(QRect(100, 321, 100, 27));
	pushButton1->setText("Close");


	QObject::connect(pushButton1, SIGNAL(clicked()), this, SLOT(hideWindow()));
}
//////////////////////////////////////////////////////////////////////
ExpInformationWindow::~ExpInformationWindow(){
}
//////////////////////////////////////////////////////////////////////
void ExpInformationWindow::closeEvent(QCloseEvent *event){
	event->accept();
	emit closed();
}
//////////////////////////////////////////////////////////////////////
void ExpInformationWindow::hideWindow(){
  this->close();
}
//////////////////////////////////////////////////////////////////////
void ExpInformationWindow::keyPressEvent(QKeyEvent *event){
	int key=event->key();
	if(key==Qt::Key_Escape || key==Qt::Key_Enter || key==Qt::Key_Return){
		hideWindow();
	}

}
//////////////////////////////////////////////////////////////////////
void ExpInformationWindow::resizeEvent(QResizeEvent *e){
	int w=width(), h=height();
	int y=3;
	widget1->setGeometry(QRect(0, 0, w, h));
	if(e){}

	textEdit1->setGeometry(QRect(1, 1, w-2, h-29));
	y=h-29+4;

	pushButton1->setGeometry(QRect((int) ((w-120)/2), y, 120, 24));
}

