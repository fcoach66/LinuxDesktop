#include "stdio.h"
#include "expchangepassword.h"

ExpChangePassword::ExpChangePassword(QWidget *parent) : QWidget(parent){
	widget1 = new QWidget(this);
	widget1->setGeometry(QRect(0, 0, 230, 120));
	this->setWindowTitle("Change Password");
	this->setWindowIcon(QIcon("/usr/share/pixmaps/sme_explorer_icon_42.png"));
   widget1->setObjectName(QString::fromUtf8("widget1"));

	int x1=10, y1=18, y2=25, dy=10, dx1=210;
	int y=20;
	textLabel1 = new QLabel(widget1);
	textLabel1->setObjectName(QString::fromUtf8("textLabel1"));
	textLabel1->setGeometry(QRect(x1, y, dx1, y1));
	textLabel1->setText("New Password:");
	y+=y1+dy;
	lineEdit1 = new QLineEdit(widget1);
	lineEdit1->setObjectName(QString::fromUtf8("lineEdit1"));
	lineEdit1->setGeometry(QRect(x1, y-3, dx1, y2));
	y+=y1+dy+3;

	x1+=25;
	pushButton1 = new QPushButton(widget1);
	pushButton1->setObjectName(QString::fromUtf8("pushButton1"));
	pushButton1->setGeometry(QRect(x1, y, 80, 28));
	pushButton1->setText("OK");
	pushButton2 = new QPushButton(widget1);
	pushButton2->setObjectName(QString::fromUtf8("pushButton2"));
	pushButton2->setGeometry(QRect(x1+90, y, 80, 28));
	pushButton2->setText("Cancel");

// Buttons
	QObject::connect(pushButton1, SIGNAL(clicked()), this, SLOT(bOK()));
	QObject::connect(pushButton2, SIGNAL(clicked()), this, SLOT(hideWindow()));
}
//////////////////////////////////////////////////////////////////////
ExpChangePassword::~ExpChangePassword(){
}
//////////////////////////////////////////////////////////////////////
void ExpChangePassword::bOK(){
	password=lineEdit1->text();
	if(password.length()<1){
		QMessageBox::critical(this, "Error", "Enter New Password");
		return ;
	}

	emit wchangePassword();
	this->hide();
}
//////////////////////////////////////////////////////////////////////
void ExpChangePassword::hideWindow(){
  this->hide();
}
//////////////////////////////////////////////////////////////////////
void ExpChangePassword::initWnd(){
	password="";
	lineEdit1->setText("");
}
//////////////////////////////////////////////////////////////////////
void ExpChangePassword::keyPressEvent(QKeyEvent *event){
	int key=event->key();
	if(key==Qt::Key_Escape){
		hideWindow();
	}else if(key==Qt::Key_Enter || key==Qt::Key_Return){
		bOK();
	}

}
//////////////////////////////////////////////////////////////////////


