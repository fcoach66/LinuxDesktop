#include "stdio.h"
#include "expautoshare.h"

ExpAutoShare::ExpAutoShare(QWidget *parent) : QWidget(parent){
	widget1 = new QWidget(this);
	widget1->setGeometry(QRect(0, 0, 525, 334));
	this->setWindowTitle("Auto Share File(s) with Business Group or User");
	this->setWindowIcon(QIcon("/usr/share/pixmaps/sme_explorer_icon_42.png"));
   widget1->setObjectName(QString::fromUtf8("widget1"));

	int x1=3, y1=18, y2=25;
	int dy=2, dy2=15, dx1=485;
	int y=6;
	countGU=0;

	textLabel1 = new QLabel(widget1);
	textLabel1->setObjectName(QString::fromUtf8("textLabel1"));
	textLabel1->setGeometry(QRect(x1, y, dx1, y1+1));
	textLabel1->setText("Files containing:");
	y+=y1+dy;
	lineEdit1 = new QLineEdit(widget1);
	lineEdit1->setObjectName(QString::fromUtf8("lineEdit1"));
	lineEdit1->setGeometry(QRect(x1, y, 200, y2));
	checkBox1=new QCheckBox("name", widget1);
	checkBox1->setObjectName(QString::fromUtf8("checkBox1"));
	checkBox1->setGeometry(QRect(x1+205, y, 70, y1));
	checkBox1->setCheckState(Qt::Unchecked);
	checkBox2=new QCheckBox("extension", widget1);
	checkBox2->setObjectName(QString::fromUtf8("checkBox2"));
	checkBox2->setGeometry(QRect(x1+280, y, 93, y1));
	checkBox2->setCheckState(Qt::Unchecked);
	checkBox3=new QCheckBox("description", widget1);
	checkBox3->setObjectName(QString::fromUtf8("checkBox3"));
	checkBox3->setGeometry(QRect(x1+378, y, 103, y1));
	checkBox3->setCheckState(Qt::Unchecked);
	y+=y1+dy+dy2;

	checkBox4=new QCheckBox("From Folder", widget1);
	checkBox4->setObjectName(QString::fromUtf8("checkBox4"));
	checkBox4->setGeometry(QRect(x1, y, dx1, y1));
	checkBox4->setCheckState(Qt::Unchecked);
	y+=y1+dy+dy2;
/*
	checkBox5=new QCheckBox("Include subfolders", widget1);
	checkBox5->setObjectName(QString::fromUtf8("checkBox5"));
	checkBox5->setGeometry(QRect(x1+200, y, 160, y1));
	checkBox5->setCheckState(Qt::Unchecked);
	y+=y1+dy+dy2;
*/
	textLabel2 = new QLabel(widget1);
	textLabel2->setObjectName(QString::fromUtf8("textLabel2"));
	textLabel2->setGeometry(QRect(x1, y, dx1, y1));
	textLabel2->setText("With Business Group or User:");
	y+=y1+dy;
	tree = new QTreeWidget(widget1);
	tree->setObjectName(QString::fromUtf8("tree"));
	tree->setGeometry(QRect(x1, y, dx1, 170));
	tree->setUpdatesEnabled(true);
	tree->setColumnCount(1);
	tree->headerItem()->setHidden(true);
	y+=170+dy+dy2-7;

	pushButton1 = new QPushButton(widget1);
	pushButton1->setObjectName(QString::fromUtf8("pushButton1"));
	pushButton1->setGeometry(QRect(x1, y+5, 125, 29));
	pushButton1->setText("Auto Share");
	pushButton2 = new QPushButton(widget1);
	pushButton2->setObjectName(QString::fromUtf8("pushButton2"));
	pushButton2->setGeometry(QRect(x1+130, y+5, 125, 29));
	pushButton2->setText("Cancel");

// Buttons
	QObject::connect(pushButton1, SIGNAL(clicked()), this, SLOT(bshare()));
	QObject::connect(pushButton2, SIGNAL(clicked()), this, SLOT(hideWindow()));
}
//////////////////////////////////////////////////////////////////////
ExpAutoShare::~ExpAutoShare(){
}
//////////////////////////////////////////////////////////////////////
void ExpAutoShare::hideWindow(){
  this->hide();
}
//////////////////////////////////////////////////////////////////////
void ExpAutoShare::clear(){
	clear2();
	rule="";
	shareInPfolder=false;
	sharewithsubfolders=false;
	rfname=false;
	rext=false;
	rdescription=false;
	int maxCount=10000;
	countGU=0;
	grouplist=new TashareGU[maxCount];
	for(int i=0; i<maxCount; i++){
		grouplist[i].id="";
		grouplist[i].pid="";
		grouplist[i].name="";
	}

}
//////////////////////////////////////////////////////////////////////
void ExpAutoShare::clear2(){
	if(countGU>0){
		for(int i=countGU-1; i>=0; i--){
			if(grouplist[i].name!=""){
				grouplist[i].name="";
				delete grouplist[i].node;
			}
		}

		delete []grouplist;
		countGU=0;
	}
}
//////////////////////////////////////////////////////////////////////
void ExpAutoShare::initWnd(){
	lineEdit1->setText(rule);
	checkBox4->setText("From Folder \""+ pname +"\"");
	checkBox1->setCheckState(Qt::Checked);
	checkBox2->setCheckState(Qt::Unchecked);
	checkBox3->setCheckState(Qt::Unchecked);
	checkBox4->setCheckState(Qt::Unchecked);

}
//////////////////////////////////////////////////////////////////////
bool ExpAutoShare::addToTree(QString id, QString name, int type, QString pid){
	TashareGU elem;
	elem.id=id;
	elem.pid=pid;
	elem.name=name;
	elem.type=type;

	grouplist[countGU]=elem;
	countGU++;

	if(pid=="" || pid=="0"){
		grouplist[countGU-1].node=new QTreeWidgetItem(tree);
//		grouplist[countGU-1].node=new QTreeWidgetItem(tree->invisibleRootItem());
	}else{
		int n=-1;
		for(int i=0; grouplist[i].name!=""; i++){
			if(grouplist[i].id==pid){
				n=i;
				break;
			}
		}
		if(n==-1) return false;
		grouplist[countGU-1].node=new QTreeWidgetItem(grouplist[n].node);
	}

	QString ipath="/usr/share/smeclient/exp/files/small/";
	if(type==2){
		ipath+="user.gif";
	}else if(type==3){
		ipath+="group.gif";
	}
	grouplist[countGU-1].node->setText(0, elem.name);
	grouplist[countGU-1].node->setIcon(0, QIcon(ipath));
	
//	tree->insertTopLevelItem(tree->topLevelItemCount(), grouplist[countGU-1].node);

	return true;
}
//////////////////////////////////////////////////////////////////////
void ExpAutoShare::bshare(){
/*
	bool L=false;
	for(int i=0; i<countGU; i++){
		if(grouplist[i].node->isSelected()){
			L=true;
			break;
		}
	}

	if(!L){
		QMessageBox::critical(this, "Error", "Select group or user");
		return ;
	}
*/
	rule=lineEdit1->text();
	if(checkBox1->checkState()==Qt::Checked){
		rfname=true;
	}else{
		sharewithsubfolders=false;
	}

	if(checkBox2->checkState()==Qt::Checked){
		rext=true;
	}else{
		rext=false;
	}

	if(checkBox3->checkState()==Qt::Checked){
		rdescription=true;
	}else{
		rdescription=false;
	}

	if(checkBox4->checkState()==Qt::Checked){
		shareInPfolder=true;
	}else{
		shareInPfolder=false;
	}

	emit addAutoShare();
	this->hide();
}
//////////////////////////////////////////////////////////////////////
void ExpAutoShare::keyPressEvent(QKeyEvent *event){
	int key=event->key();
	if(key==Qt::Key_Escape){
		hideWindow();
	}else if(key==Qt::Key_Enter || key==Qt::Key_Return){
		bshare();
	}

}
//////////////////////////////////////////////////////////////////////
void ExpAutoShare::resizeEvent(QResizeEvent *e){
	int w=width();
	int h=height();
	widget1->setGeometry(QRect(0, 0, w, h));
	if(e){}

	int x1=3, x=x1+205;
	int y=26, y1=18;
	int d1=(int) (w-x-x1)/3+4;
	checkBox1->setGeometry(QRect(x, y, d1-15, y1));	// 70
	x+=d1-17;
	checkBox2->setGeometry(QRect(x, y, d1, y1));	// 93
	x+=d1-4;
	checkBox3->setGeometry(QRect(x, y, d1+6, y1)); // 103

	tree->setGeometry(QRect(x1, 117, w-x1*2, 177));
}


