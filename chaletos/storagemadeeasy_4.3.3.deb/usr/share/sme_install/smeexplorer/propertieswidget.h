#ifndef PROPERTIESWIDGET_H
#define PROPERTIESWIDGET_H

#include <QtGui/QWidget>
#include <QtGui/QKeyEvent>

namespace Ui
{
    class propertiesWidget;
}

class propertiesWidget : public QWidget
{
    Q_OBJECT

	public:
		propertiesWidget(QWidget *parent=0);
		~propertiesWidget();

		QString login, password, apihost, proxyhost, proxylogin, proxypass;
		int proxyport;
		bool useProxy;
//		QString defaultFolder, logFileName;

		int DEBUG;

		bool cronTaskExists;
		void debug(QString s, int level=5);
		void initWnd();
		QString floatToQstring(double n);
		QString intToQstring(int n);

	public
  slots:
		void saveProperties();
		void hideWindow();
		void checkBox1StateChanged(int par);

  signals:
		void propertiesWidgetClickOKButton();

	private:
		Ui::propertiesWidget *ui;
		virtual void keyPressEvent(QKeyEvent * event);

};

#endif // PROPERTIESWIDGET_H
