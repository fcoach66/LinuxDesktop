#ifndef EXPAUTOSHARE_H
#define EXPAUTOSHARE_H

#include <QtGui/QWidget>
#include <QtGui/QLabel>
#include <QtGui/QCheckBox>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QWidget>
#include <Qt3Support/Q3MimeSourceFactory>
#include <QtGui/QMessageBox>
#include <QtGui/QCheckBox>
#include <QDateTime>
#include <QTreeWidget>
#include <QTreeWidgetItem>
#include <QtGui/QKeyEvent>


typedef struct {
	QString id;
	QString pid;
	QString name;
	int type;			// 2-user, 3-group
	QTreeWidgetItem *node;
} TashareGU;

class ExpAutoShare : public QWidget
{
    Q_OBJECT

public:
	ExpAutoShare(QWidget *parent = 0);
	~ExpAutoShare();
	void clear();
	void clear2();
	void initWnd();

	QString rule, pname;
	bool shareInPfolder, sharewithsubfolders, rfname, rext, rdescription;

	TashareGU *grouplist;
	int countGU;

	QWidget *widget1;
	QLabel *textLabel1, *textLabel2, *textLabel3, *textLabel4, *textLabel5;
	QPushButton *pushButton1, *pushButton2;
	QLineEdit *lineEdit1, *lineEdit2;
	QCheckBox *checkBox1, *checkBox2, *checkBox3, *checkBox4;
	QTreeWidget *tree;
	bool addToTree(QString id, QString name, int type, QString pid="0");

public
  slots:
	void hideWindow();
	void bshare();

  signals:
    void addAutoShare();

private:
	virtual void keyPressEvent(QKeyEvent * event);
	virtual void resizeEvent(QResizeEvent * e=NULL);


};

#endif // EXPAUTOSHARE_H
