#ifndef EXPTINYURL_H
#define EXPTINYURL_H

#include <QtGui/QWidget>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QWidget>
#include <Qt3Support/Q3MimeSourceFactory>
#include <QtGui/QMessageBox>
#include <QtGui/QKeyEvent>

class ExpTinyurl : public QWidget
{
    Q_OBJECT

public:
	ExpTinyurl(QWidget *parent = 0);
	~ExpTinyurl();
	void clear();
	void clear2();
	void initWnd();

	QString name, url, smeurl;

	QWidget *widget1;
	QLabel *textLabel1, *textLabel2, *textLabel3;
	QLineEdit *lineEdit1, *lineEdit2, *lineEdit3;
	QPushButton *pushButton1, *pushButton2;

public
  slots:
	void hideWindow();

  signals:

private:
	virtual void keyPressEvent(QKeyEvent *event);
	virtual void resizeEvent(QResizeEvent * e);


};

#endif // EXPTINYURL_H
