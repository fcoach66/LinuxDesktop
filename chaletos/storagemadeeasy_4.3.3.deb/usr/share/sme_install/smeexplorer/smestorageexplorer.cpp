//#include <QNetworkAccessManager>
//#include "request.h"
#include <QtNetwork/QHttp>
#include <QtNetwork/QHttpRequestHeader>
#include <QUrl>
#include <QtXml>
#include <QMenu>
#include <QContextMenuEvent>
#include <QNetworkProxy>

#include <QSslCipher>
#include <QSslSocket>
#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QSslConfiguration>
#include <QDebug>

#include <fcntl.h>
#include <unistd.h>

#include <sys/types.h>				// this is need for utime
#include <utime.h>

#include "smestorageexplorer.h"
#include "ui_smestorageexplorer.h"
#include "propertieswidget.h"
#include "expshare.h"
#include "cqthread.h"



SMEStorageExplorer::SMEStorageExplorer(QWidget *parent) : QWidget(parent), ui(new Ui::SMEStorageExplorer){
	ui->setupUi(this);
	nResize=0;

	userId="";
	tmptoken="";

	fCnfName=QDir::homePath() + "/.StorageMadeEasy.cnf";
	QString fCnfNameOld=QDir::homePath() + "/.SMEStorage.cnf";
	if(!QFile::exists(fCnfName) && QFile::exists(fCnfNameOld)) QFile::rename(fCnfNameOld, fCnfName);

	pathToIcons="/usr/share/smeclient/exp/";
	isActionCanceled=false;
	SgetToken.uri="";
	smehost="storagemadeeasy.com";

	SrunFunction.attempt=0;
	isGetFilesList=false;
	isOrganizationAdmin=false;
	isGetUserInfo=false;
	lastDir=QDir::homePath();

	isRunning=false;
	viewType=0;
	explorerType=0;
	isRunningInKDE=isKDE();

	DEBUG=100;

	emptyFile.id="";
	emptyFile.pid="";
	emptyFile.type=0;					// 0 - file, 1 - folder, 2 - user, 3 - group
	emptyFile.name="";
	emptyFile.description="";
	emptyFile.tags="";
	emptyFile.size="0";
	emptyFile.created="";
	emptyFile.lastmodify="";
	emptyFile.lastaccess="";
	emptyFile.encrypted=false;
//	emptyFile.isProcessed=false;
	emptyFile.uid="";
	emptyFile.extension="";
	emptyFile.isPublic=false;
	emptyFile.isFavorite=false;
	emptyFile.orgid="";
	emptyFile.orgfolderid="";
	emptyFile.provider="";
	emptyFile.us_name="";
	emptyFile.shareGrId="";
	emptyFile.shareUsId="";
	emptyFile.shareFolderId="";
	emptyFile.gpermissions="";
	emptyFile.gprivate="";
	emptyFile.link="";
	emptyFile.path="";
	emptyFile.lpath="";
	emptyFile.lockedby="";

	currentFolder=emptyFile;
	
	gmt_offset=runCommand("smemount --server= get_gmt_offset --sync").toInt();
	localeEncoding=runCommand("locale charmap");
	if(localeEncoding.indexOf("utf8", 0, Qt::CaseInsensitive)>-1 || localeEncoding.indexOf("utf-8", 0, Qt::CaseInsensitive)>-1){
		localeEncoding="";
	}else if(localeEncoding!=""){
		localeEncoding.replace(QRegExp("[ \t\r\n]+"), "");
	}else{
		localeEncoding="";
	}
	if(localeEncoding!="")	debug("localeEncoding="+localeEncoding +";");

	SbUpload.http_created=false;
	SbDownload.http_created=false;

	useProxy=false;
	proxyport=80;
	proxyhost="";
	proxylogin="";
	proxypass="";

	canPasswordBeEncrypted = true;
	encryptionKeyForPassword = getEncryptionKeyForPassword();
	if(decryptSMEPassword(encryptSMEPassword("12345678901234567890123456789012345678901234567890"))!="12345678901234567890123456789012345678901234567890"){
		canPasswordBeEncrypted = false;
	}

	maxCount=100000;
	filelist=new Tfile[maxCount];			// initialize filelist
	for(int i=0; i<maxCount; i++){
		filelist[i] = emptyFile;
	}

	maxCountClipboard=2000;
	clipboardfilelist=new Tfile[maxCountClipboard];	// initialize clipboardfilelist
	for(int i=0; i<maxCountClipboard; i++){
		clipboardfilelist[i]=emptyFile;
	}

	SLocation=new Tfile [1000];
	for(int i=0; i<1000; i++){
		SLocation[i]=emptyFile;
	}

	SbAutoSharingRules.countG=0;
	Shistory.current=0;
	Tfile historyEl=emptyFile;
	historyEl.id="";
	historyEl.name="";
	Shistory.history=new Tfile	[256];
	for(int i=0; i<256; i++){
		Shistory.history[i]=historyEl;
	}
//	addToHistory(currentFolderId, currentFolderName, currentFolderType);
	addToHistory(currentFolder);

	contextMenu=new QMenu(tr("&Context Menu"));								// Create context menu
	aDownload=contextMenu->addAction(tr("Download"));
	aRename=contextMenu->addAction(tr("Rename"));
	contextMenu->addSeparator();
	aPublic=contextMenu->addAction(tr("Set/Unset as Public File(s)"));
	aLock=contextMenu->addAction(tr("Lock File(s)"));
	aUnlock=contextMenu->addAction(tr("Unlock File(s)"));
	aShare=contextMenu->addAction(tr("Share With Group/User"));
	aEmail=contextMenu->addAction(tr("Send To E-mail"));
	aTwitter=contextMenu->addAction(tr("Send To Twitter"));
	aFileUrl=contextMenu->addAction(tr("Get URL"));
	contextMenu->addSeparator();
	aRestore=contextMenu->addAction(tr("Restore"));
	aRestore->setVisible(false);		// it need show only in trash
	aDelete=contextMenu->addAction(tr("Delete"));
	contextMenu->addSeparator();
	aProperties=contextMenu->addAction(tr("Properties"));
	contextMenu->addSeparator();


	viewMenu=new QMenu(tr("View"));			// Menu for button View
	avIcons=viewMenu->addAction(tr("Icons"));
	avList=viewMenu->addAction(tr("List"));

	uploadMenu=new QMenu(tr("Upload"));			// Menu for button Upload
	uplFiles=uploadMenu->addAction(tr("Upload File(s)"));
	uplFolder=uploadMenu->addAction(tr("Upload Folder"));

	importExportMenu=new QMenu(tr("Import/Export"));			// Menu for button importExport
	aieImport=importExportMenu->addAction(tr("Import"));
	aieExport=importExportMenu->addAction(tr("Export"));

	sharingMenu=new QMenu(tr("Sharing"));			// Menu for button Sharing
	asPublic							=sharingMenu->addAction(tr("Set/Unset as Public File(s)"));
	asShareWithGroupUser			=sharingMenu->addAction(tr("Share With Group/User"));
	asSendToEmail					=sharingMenu->addAction(tr("Send To E-mail"));
	asSendToTwitter				=sharingMenu->addAction(tr("Send To Twitter"));
	asGetFileUrl					=sharingMenu->addAction(tr("Get URL"));
	sharingMenu->addSeparator();
	asAutoShareWithGroupUser	=sharingMenu->addAction(tr("Auto Share With Group/User"));
	asAutoSharingRules			=sharingMenu->addAction(tr("Auto Sharing Rules"));
	sharingMenu->addSeparator();
	asRequestShare					=sharingMenu->addAction(tr("Request A Share"));

	amsPublic						=ui->shareMenu->addAction(tr("Set/Unset as Public File(s)"));
	amsShareWithGroupUser		=ui->shareMenu->addAction(tr("Share With Group/User"));
	amsSendToEmail					=ui->shareMenu->addAction(tr("Send To E-mail"));
	amsSendToTwitter				=ui->shareMenu->addAction(tr("Send To Twitter"));
	amsGetFileUrl					=ui->shareMenu->addAction(tr("Get URL"));
	ui->shareMenu->addSeparator();
	amsAutoShareWithGroupUser	=ui->shareMenu->addAction(tr("Auto Share With Group/User"));
	amsAutoSharingRules			=ui->shareMenu->addAction(tr("Auto Sharing Rules"));
	ui->shareMenu->addSeparator();
	amsRequestShare				=ui->shareMenu->addAction(tr("Request A Share"));

	amfCloudExp			=ui->fileMenu->addAction(tr("Cloud Files"));
	amfPublicExp		=ui->fileMenu->addAction(tr("Public Files"));
	amfPublicExp->setVisible(false);
	amfFavouriteExp	=ui->fileMenu->addAction(tr("Favourite Files"));
	amfSearchExp		=ui->fileMenu->addAction(tr("Search Files"));
	amfSearchExp->setVisible(false);
	amfClipboardExp	=ui->fileMenu->addAction(tr("Clipboard Files"));
	amfGroupsExp		=ui->fileMenu->addAction(tr("Business Groups"));
	amfTrashExp			=ui->fileMenu->addAction(tr("Trash"));
	ui->fileMenu->addSeparator();
	amfProperties		=ui->fileMenu->addAction(tr("Properties"));
	ui->fileMenu->addSeparator();
	aLogout=ui->fileMenu->addAction(tr("Logout"));

	ahAbout	=ui->helpMenu->addAction(tr("About"));

	QObject::connect(ahAbout, SIGNAL(triggered()), this, SLOT(bAbout()));

	QObject::connect(ui->pushButton0, SIGNAL(clicked()), this, SLOT(bPrevious()));			// Back
	QObject::connect(ui->pushButton1, SIGNAL(clicked()), this, SLOT(bNext()));					// Next
	QObject::connect(ui->pushButton2, SIGNAL(clicked()), this, SLOT(bRefresh()));				// Refresh
	QObject::connect(ui->pushButton3, SIGNAL(clicked()), this, SLOT(downloadFile()));		// Download
	QObject::connect(ui->pushButton4, SIGNAL(clicked()), this, SLOT(bUpload()));				// Upload
	QObject::connect(ui->pushButton5, SIGNAL(clicked()), this, SLOT(bSharing()));				// Sharing
	QObject::connect(ui->pushButton6, SIGNAL(clicked()), this, SLOT(bImportExport()));		// Import/Export
	QObject::connect(ui->pushButton7, SIGNAL(clicked()), this, SLOT(bFavourite()));			// Add/Remove File(s) to/from Favourites
	QObject::connect(ui->pushButton8, SIGNAL(clicked()), this, SLOT(bCreate()));				// New Folder/Group
	QObject::connect(ui->pushButton10, SIGNAL(clicked()), this, SLOT(bCopy()));				// Copy
	QObject::connect(ui->pushButton11, SIGNAL(clicked()), this, SLOT(bPaste()));				// Paste
	QObject::connect(ui->pushButton13, SIGNAL(clicked()), this, SLOT(bRename()));				// Rename Folder/File/Group/Share
	QObject::connect(ui->pushButton14, SIGNAL(clicked()), this, SLOT(bDelete()));				// Delete
	QObject::connect(ui->pushButton15, SIGNAL(clicked()), this, SLOT(bSearch()));				// Search
	QObject::connect(ui->pushButton16, SIGNAL(clicked()), this, SLOT(bCloudProviders()));	// Cloud Providers
	QObject::connect(ui->pushButton17, SIGNAL(clicked()), this, SLOT(bView()));				// View
	QObject::connect(ui->pushButton18, SIGNAL(clicked()), this, SLOT(bAbout()));				// About
	QObject::connect(ui->pushButton9, SIGNAL(clicked()), this, SLOT(cancelCurrentAction()));// Cancel

							// View menu
	QObject::connect(avIcons, SIGNAL(triggered()), this, SLOT(bViewIcons()));
	QObject::connect(avList, SIGNAL(triggered()), this, SLOT(bViewList()));

							// Upload menu
	QObject::connect(uplFiles, SIGNAL(triggered()), this, SLOT(bUploadFiles()));
	QObject::connect(uplFolder, SIGNAL(triggered()), this, SLOT(bUploadFolder()));

						// Sharing menu
	QObject::connect(asPublic, SIGNAL(triggered()), this, SLOT(bPublic()));
	QObject::connect(asShareWithGroupUser, SIGNAL(triggered()), this, SLOT(bShareWithGroupUser()));
	QObject::connect(asSendToEmail, SIGNAL(triggered()), this, SLOT(bSendToEmail()));
	QObject::connect(asSendToTwitter, SIGNAL(triggered()), this, SLOT(bSendToTwitter()));
	QObject::connect(asGetFileUrl, SIGNAL(triggered()), this, SLOT(bFileUrl()));
	QObject::connect(asAutoShareWithGroupUser, SIGNAL(triggered()), this, SLOT(bAutoShareWithGroupUser()));
	QObject::connect(asAutoSharingRules, SIGNAL(triggered()), this, SLOT(bAutoSharingRules()));
	QObject::connect(asRequestShare, SIGNAL(triggered()), this, SLOT(bRequestShare()));

						// Share menu
	QObject::connect(amsPublic, SIGNAL(triggered()), this, SLOT(bPublic()));
	QObject::connect(amsShareWithGroupUser, SIGNAL(triggered()), this, SLOT(bShareWithGroupUser()));
	QObject::connect(amsSendToEmail, SIGNAL(triggered()), this, SLOT(bSendToEmail()));
	QObject::connect(amsSendToTwitter, SIGNAL(triggered()), this, SLOT(bSendToTwitter()));
	QObject::connect(amsGetFileUrl, SIGNAL(triggered()), this, SLOT(bFileUrl()));
	QObject::connect(amsAutoShareWithGroupUser, SIGNAL(triggered()), this, SLOT(bAutoShareWithGroupUser()));
	QObject::connect(amsAutoSharingRules, SIGNAL(triggered()), this, SLOT(bAutoSharingRules()));
	QObject::connect(amsRequestShare, SIGNAL(triggered()), this, SLOT(bRequestShare()));

						// File menu
	QObject::connect(amfProperties, SIGNAL(triggered()), this, SLOT(bPropertiesGlobal()));
	QObject::connect(amfCloudExp, SIGNAL(triggered()), this, SLOT(changeExplorerTypeToCloud()));
	QObject::connect(amfPublicExp, SIGNAL(triggered()), this, SLOT(changeExplorerTypeToPublic()));
	QObject::connect(amfFavouriteExp, SIGNAL(triggered()), this, SLOT(changeExplorerTypeToFavourite()));
	QObject::connect(amfSearchExp, SIGNAL(triggered()), this, SLOT(changeExplorerTypeToSearch()));
	QObject::connect(amfClipboardExp, SIGNAL(triggered()), this, SLOT(changeExplorerTypeToClipboard()));
	QObject::connect(amfGroupsExp, SIGNAL(triggered()), this, SLOT(changeExplorerTypeToGroups()));
	QObject::connect(amfTrashExp, SIGNAL(triggered()), this, SLOT(changeExplorerTypeToTrash()));

						// Context menu
	QObject::connect(aDownload, SIGNAL(triggered()), this, SLOT(downloadFile()));
	QObject::connect(aRename, SIGNAL(triggered()), this, SLOT(bRename()));
	QObject::connect(aDelete, SIGNAL(triggered()), this, SLOT(bDelete()));
	QObject::connect(aRestore, SIGNAL(triggered()), this, SLOT(bRestore()));
	QObject::connect(aPublic, SIGNAL(triggered()), this, SLOT(bPublic()));
	QObject::connect(aLock, SIGNAL(triggered()), this, SLOT(bLock()));
	QObject::connect(aUnlock, SIGNAL(triggered()), this, SLOT(bUnlock()));
	QObject::connect(aShare, SIGNAL(triggered()), this, SLOT(bShareWithGroupUser()));
	QObject::connect(aEmail, SIGNAL(triggered()), this, SLOT(bSendToEmail()));
	QObject::connect(aTwitter, SIGNAL(triggered()), this, SLOT(bSendToTwitter()));
	QObject::connect(aFileUrl, SIGNAL(triggered()), this, SLOT(bFileUrl()));
	QObject::connect(aProperties, SIGNAL(triggered()), this, SLOT(bProperties()));
	QObject::connect(aLogout, SIGNAL(triggered()), this, SLOT(logOut()));


						// ImportExport menu
	QObject::connect(aieImport, SIGNAL(triggered()), this, SLOT(bImport()));
	QObject::connect(aieExport, SIGNAL(triggered()), this, SLOT(bExport()));

	QObject::connect(ui->listWidget, SIGNAL(itemDoubleClicked(QListWidgetItem *)), this, SLOT(bDoubleClicked(QListWidgetItem *)));
	QObject::connect(ui->listWidget, SIGNAL(itemSelectionChanged()), this, SLOT(updateMenus()));

	QObject::connect(&propertiesWnd, SIGNAL(propertiesWidgetClickOKButton()), this, SLOT(saveProperties()));
	QObject::connect(&providerlog, SIGNAL(saveProviderLog()), this, SLOT(saveProviderLoginAndPassword()));

	QObject::connect(&createFolderWnd, SIGNAL(createFolder()), this, SLOT(createFolder2()));
	QObject::connect(&createFolderWnd, SIGNAL(renameFolder()), this, SLOT(renameFolder2()));
	QObject::connect(&createFolderWnd, SIGNAL(renameFile()), this, SLOT(renameFile2()));
	QObject::connect(&createFolderWnd, SIGNAL(renameGroup()), this, SLOT(renameGroup2()));
	QObject::connect(&createFolderWnd, SIGNAL(createGroup()), this, SLOT(createGroup()));
	QObject::connect(&shareWithGroupUserWnd, SIGNAL(shareWithGroupOrUser()), this, SLOT(bshareWithGroupOrUser()));
	QObject::connect(&uploadFileWnd, SIGNAL(uploadFile()), this, SLOT(bUpload1()));
	QObject::connect(&uploadFileWnd, SIGNAL(hideUploadWindow()), this, SLOT(hideMessage()));
//	QObject::connect(&downloadFileWnd, SIGNAL(downloadFile()), this, SLOT(downloadFileToDisk()));
	QObject::connect(&sendEmailWnd, SIGNAL(sendToEmail()), this, SLOT(bSendToEmailResp()));
	QObject::connect(&sendToTwitterWnd, SIGNAL(sendToTwitter()), this, SLOT(bSendToTwitterResp()));
	QObject::connect(&requestShareWnd, SIGNAL(requestShare()), this, SLOT(bRequestShare2()));
	QObject::connect(&autoShareWithGroupUserWnd, SIGNAL(addAutoShare()), this, SLOT(bAutoShareWithGroupUser2()));
	QObject::connect(&autoShareRuleWnd, SIGNAL(deleteAutoShare()), this, SLOT(bDeleteAutoShare()));
	QObject::connect(&autoShareRuleWnd, SIGNAL(addAutoShare()), this, SLOT(bAutoShareWithGroupUser()));
	QObject::connect(&importWnd, SIGNAL(importGetProviderMetaFields()), this, SLOT(importGetProviderMetaFields()));
	QObject::connect(&expProviderLoginWnd, SIGNAL(OK()), this, SLOT(importSetProviderLogin()));
	QObject::connect(&importWnd, SIGNAL(bImport()), this, SLOT(runImport()));
	QObject::connect(&importWnd, SIGNAL(bExport()), this, SLOT(runExport()));
	QObject::connect(&searchWnd, SIGNAL(startSearch()), this, SLOT(search2()));
	QObject::connect(&providersWnd, SIGNAL(setDefaultProvider()), this, SLOT(setDefaultProvider()));
	QObject::connect(&providersWnd, SIGNAL(changePassword()), this, SLOT(changeProviderPassword()));
	QObject::connect(&providersWnd, SIGNAL(syncNow()), this, SLOT(syncProviderNow()));
	QObject::connect(&providersWnd, SIGNAL(syncTask()), this, SLOT(bsyncProviderTask()));
	QObject::connect(&providersWnd, SIGNAL(getProviderMetaFields()), this, SLOT(addProviderGetMetaFields()));
	QObject::connect(&expProviderLoginWnd, SIGNAL(baddProvider()), this, SLOT(addProviderSetMetaFields()));
	QObject::connect(&selectBucketsWnd, SIGNAL(setBuckets()), this, SLOT(addProviderSetBuckets()));
	QObject::connect(&providersWnd, SIGNAL(manageBuckets()), this, SLOT(bmanageBuckets()));
	QObject::connect(&manageBucketsWnd, SIGNAL(setDefault()), this, SLOT(bsetDefaultBucket()));
	QObject::connect(&manageBucketsWnd, SIGNAL(saveBuckets()), this, SLOT(bupdateProviderBucket()));

	QObject::connect(&manageBucketsWnd, SIGNAL(addBucket()), this, SLOT(baddProviderBucket()));
	QObject::connect(&addProviderBucketWnd, SIGNAL(addBucket()), this, SLOT(addProviderBucket()));
//	QObject::connect(ui->comboBox1, SIGNAL(currentIndexChanged(int *)), this, SLOT(changeLocation(int *)));
//	QObject::connect(ui->comboBox1, SIGNAL(currentIndexChanged(int)), this, SLOT(changeLocation()));
	QObject::connect(ui->comboBox1, SIGNAL(activated (int)), this, SLOT(changeLocation()));

}
//////////////////////////////////////////////////////////////////////
SMEStorageExplorer::~SMEStorageExplorer(){
  delete ui;
}
//////////////////////////////////////////////////////////////////////
int SMEStorageExplorer::addToFileslist(Tfile file, bool needShow){
//debug("addToFileslist(name="+ file.name +")");
	if(explorerType!=3 && (file.id=="" || file.pid=="")) return -1;
	if((file.type!=0 && file.type!=1 && file.type!=2 && file.type!=3) || file.name=="") return -1;

	if(file.size=="") file.size="0";
	int n=getCountFiles(filelist);
	if(n>=maxCount) return -1;
	for(int i=0; i<n; i++){
		if((file.id!="" && filelist[i].id==file.id) || filelist[i].name==file.name){			// file exists in array
			QListWidgetItem *node=filelist[i].node;
			filelist[i]=file;
			filelist[i].node=node;
			return i;
		}
	}

	filelist[n]=file;
	if(needShow){
		int count=n;
		for(int i=n-1; i>=0; i--){
			if(filelist[i].type<filelist[i+1].type || (filelist[i].type==filelist[i+1].type && filelist[i].name.toLower()>filelist[i+1].name.toLower())){
				Tfile f=filelist[i+1];
				filelist[i+1]=filelist[i];
				filelist[i]=f;
			}
		}//for

		for(int i=0; i<count; i++){
			if(filelist[i].id==file.id && filelist[i].name==file.name){
				n=i;
				break;
			}
		}

		QString fname=filelist[n].name;
		if(explorerType==5 && filelist[n].us_name.length()>0)	fname+=" (By "+ filelist[n].us_name +")";
		QString pIcon=getFileIcon(filelist[n].type, filelist[n].name, filelist[n].extension);
//		filelist[n].node=new QListWidgetItem(QIcon(pIcon), fname);//, ui->listWidget);






		QIcon xicon;

/*
QString ext=filelist[n].extension;
bool L=false;
if(ext=="pdf"){
	if(QIcon::hasThemeIcon("application-pdf")){
		L=true;
		xicon=QIcon::fromTheme("application-pdf");
	}
}else if(ext.startsWith("doc")){
	if(QIcon::hasThemeIcon("application-msword")){
		L=true;
		xicon=QIcon::fromTheme("application-msword");
	}
}else if(ext=="zip" || ext=="gz"  ||  ext=="bz2" ){
	if(QIcon::hasThemeIcon("application-x-archive")){
		L=true;
		xicon=QIcon::fromTheme("application-x-archive");
	}
//}else if(ext=="png" || ext=="jpg"  || ext=="gif"  || ext=="svg" || ext=="bmp"){
//	xicon=QIcon::fromTheme("image-x-generic");


}else if(ext=="mp3"){
	if(QIcon::hasThemeIcon("audio-x-mp3") || 1){
		L=true;
		xicon=QIcon::fromTheme("audio-x-mp3");
	}
}

if(L){
	if(viewType==1){
		QSize isize(30, 30);
		xicon=QIcon(xicon.pixmap(isize));
	}
}else{
	xicon=QIcon(pIcon);
}
*/

		xicon=QIcon(pIcon);
		filelist[n].node=new QListWidgetItem(xicon, fname);//, ui->listWidget);
		filelist[n].node->setToolTip(filelist[n].name);		// hint
		ui->listWidget->insertItem(n, filelist[n].node);
	}

	return n;
}
//////////////////////////////////////////////////////////////////////
int SMEStorageExplorer::editNode(int n){
debug("editNode()");
	Tfile file=filelist[n];
//debug("file.name = "+ file.name);
	bool isSelected=filelist[n].node->isSelected();

	deleteFileAndNode(n);
	int k=addToFileslist(file, true);
	if(k>=0 && filelist[k].id==file.id)	filelist[k].node->setSelected(isSelected);

//debug("filelist[k].name = "+ filelist[k].name);
	return k;
}
//////////////////////////////////////////////////////////////////////
int SMEStorageExplorer::deleteFileAndNode(int n, QString id){
debug("deleteFileAndNode()");
	if(n<0 && id=="") return -1;

	int count=getCountFiles(filelist);

	if(n<0){
		for(int i=0; i<count; i++){
			if(filelist[i].id==id){
				n=i;
				break;
			}
		}//for
	}

	if(n<0) return -1;

	int i;
	delete filelist[n].node; 											// delete from list
	for(i=n; i<count-1 && filelist[i].name!=""; i++){	 	// delete from array
		filelist[i]=filelist[i+1];
	}//for

	filelist[i]=emptyFile;
	return 0;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bView(){
debug("bView()");
	if(!tryRunning()) return ;
	int x=ui->pushButton17->x();
	int y=ui->pushButton17->y()+ui->pushButton17->height()-2;

	QPoint pt;
	pt.setX(x);
	pt.setY(y);

	pt=mapToGlobal(pt);
	viewMenu->exec(pt);
//debug("pt => x => "+ intToQstring(pt.x())+" y => "+intToQstring(pt.y()));

	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::getToken(){
debug("getToken()");
	if(isActionCanceled){
		hideMessage();
		return ;
	}

	SrunFunction.restory2="";
	SrunFunction.restory2.append(SLOT(getTokenResp()));

	token="*";
	QString uri="gettoken/"+ base64(login) +","+ base64(password);
	showMessage("Retrieving user info", true);
	runFunction(uri);
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::getTokenResp(){
debug("getTokenResp()");
//debug("getTokenResp("+SrunFunction.response+")");

	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory2="";

	token="*";

	QString l1, l4, statusmessage;
	l1=getPartQString(res, "<token>", "</token>");
	l4=getPartQString(res, "<notice>", "</notice>");
	statusmessage=getPartQString(res, "<statusmessage>", "</statusmessage>");
	userId=getPartQString(res, "<userid>", "</userid>");

	if(l1!=""){
		token=l1;
		if(l4=="1"){  // need get provider login and provider password
			tmptoken=token;
			token="*";
			if(providerLogin=="" || providerPassword==""){
				getProviderLoginAndPassword();
			}else{
				setProviderData();
			}
			return ;
		}
	}else{		// error
		isActionCanceled=true;
		if(statusmessage=="" && res==""){
			statusmessage="Check your Internet connection.";
		}else if(statusmessage==""){
			statusmessage="Check Password!";
		}

		QMessageBox::critical(this, "Error", "Unable to authenticate. "+ statusmessage);
		hideMessage();
		return ;
	}

debug("token="+token);
	if(isActionCanceled) hideMessage();
	if(SgetToken.uri!="" || (SgetToken.isPost==true && SgetToken.postData!="")){
		runFunction(SgetToken.uri, SgetToken.isPost, SgetToken.postData);
		SgetToken.uri="";
		return ;
	}
	
	resume(1);
}
//////////////////////////////////////////////////////////////////////
QString SMEStorageExplorer::getToken2(){
debug("getToken2()");
	if(isActionCanceled){
		hideMessage();
		return "";
	}

	token = "*";
	QString uri="gettoken/"+ base64(login) +","+ base64(password);
	showMessage("Retrieving user info", true);

	QString res = runFunction2(uri);

	QString l1, l4, statusmessage;
	l1=getPartQString(res, "<token>", "</token>");
	statusmessage=getPartQString(res, "<statusmessage>", "</statusmessage>");
	userId=getPartQString(res, "<userid>", "</userid>");

	if(l1!=""){
		token=l1;
	}else{		// error
		isActionCanceled=true;
		if(statusmessage=="" && res==""){
			statusmessage="Check your Internet connection.";
		}else if(statusmessage==""){
			statusmessage="Check Password!";
		}

		QMessageBox::critical(this, "Error", "Unable to authenticate. "+ statusmessage);
		hideMessage();
		return "";
	}

	debug("token="+token);
	return token;
}
//////////////////////////////////////////////////////////////////////
QString SMEStorageExplorer::runFunction2(QString uri, bool isPost, QString postData, int attempt){
	if(token!="*") debug("runFunction2("+uri+")");
	QString host=smehost;

	bool HTTPS = false;
	int ss01 = host.indexOf("://");
	if(ss01>0){
		int ss02 = host.indexOf("https://", 0, Qt::CaseInsensitive);
		if(ss02>=0 && ss02<ss01) HTTPS=true;
		host = host.mid(ss01+3);
	}

//	if(uri.indexOf("gettoken/", -1, Qt::CaseInsensitive)==0){		// For gettoken we use HTTPS to protect password
//		HTTPS = true;
//	}

	QNetworkAccessManager *http_ = new QNetworkAccessManager(this);
	QNetworkRequest request1;

	if(useProxy){
		debug("useProxy=1");
		quint16 xport = proxyport;
		http_->setProxy(QNetworkProxy(QNetworkProxy::HttpProxy, proxyhost, xport, proxylogin, proxypass));
	}

	QSslConfiguration SSLconf(QSslSocket().sslConfiguration());
	SSLconf.setProtocol(QSsl::TlsV1);
	request1.setSslConfiguration(SSLconf);
	request1.setRawHeader("User-Agent", "Mozilla/4.0 (Linux Tools Explorer)");
	request1.setRawHeader("Accept", "*/*");
	request1.setRawHeader("Accept-Encoding", "deflate");
	request1.setRawHeader("Connection", "Keep-Alive");

	connect(http_, SIGNAL(sslErrors(QNetworkReply *, QList<QSslError>)), this, SLOT(slotSslErrors(QNetworkReply *, QList<QSslError>)));

	if(host.indexOf("://")<0){
		if(HTTPS){
			host = "https://" + host;
		}else{
			host = "http://" + host;
		}
	}

	QNetworkReply *reply;
	if(token.length()<2) token="*";
	if(!isPost){
		QString url01 = host + "/api/"+token+"/"+uri;
		request1.setUrl(QUrl(url01));

		reply = http_->get(request1);
		if(uri.indexOf("gettoken/", -1, Qt::CaseInsensitive)==0){
			debug("REQUEST => " + url01);
		}
	}else{
		debug("postData: "+postData.mid(0, 250));

		if(postData!="") postData+="&";
		postData+="token="+ token;

		QString url01 = host + "/api/rpc.php";
		request1.setUrl(QUrl(url01));

		reply = http_->post(request1, QString(postData + ((postData!="") ? "&" : "") + "token="+ token).toUtf8());
	}

	QEventLoop eventLoop;
	QObject::connect(http_, SIGNAL(finished(QNetworkReply*)), &eventLoop, SLOT(quit()));
	eventLoop.exec();


	QString res=QString::fromUtf8(reply->readAll());

	if(res.indexOf("<response>")>1){
		debug(res.mid(res.indexOf("<response>"), 280) +"\n");
	}else{
		debug(res.mid(0, 420) +"\n");
	}

	QString mess="";
	if(res==""){
		if(reply->error()!=QNetworkReply::NoError){
			mess="Cannot connect to server";

			if(reply->error()==QNetworkReply::NoError){
				debug("QNetworkReply::NoError");
			}else if(reply->error()==QNetworkReply::RemoteHostClosedError){
				debug("QNetworkReply::RemoteHostClosedError");
			}else if(reply->error()==QNetworkReply::HostNotFoundError){
				debug("QNetworkReply::HostNotFoundError");
				mess="Error. Check your Internet connection.";
			}else if(reply->error()==QNetworkReply::TimeoutError){
				debug("QNetworkReply::TimeoutError");
			}else if(reply->error()==QNetworkReply::OperationCanceledError){
				debug("QNetworkReply::OperationCanceledError");
			}else if(reply->error()==QNetworkReply::ProxyAuthenticationRequiredError){
				debug("QNetworkReply::SslHandshakeFailedError");
			}else if(reply->error()==QNetworkReply::ProxyConnectionRefusedError){
				debug("QNetworkReply::ProxyConnectionRefusedError");
			}else if(reply->error()==QNetworkReply::ProxyConnectionClosedError){
				debug("QNetworkReply::ProxyConnectionClosedError");
			}else if(reply->error()==QNetworkReply::ProxyNotFoundError){
				debug("QNetworkReply::ProxyNotFoundError");
			}else if(reply->error()==QNetworkReply::ProxyTimeoutError){
				debug("QNetworkReply::ProxyTimeoutError");
			}else if(reply->error()==QNetworkReply::ProxyAuthenticationRequiredError){
				debug("QNetworkReply::ProxyAuthenticationRequiredError");
			}else if(reply->error()==QNetworkReply::ContentAccessDenied){
				debug("QNetworkReply::ContentAccessDenied");
			}else if(reply->error()==QNetworkReply::ContentOperationNotPermittedError){
				debug("QNetworkReply::ContentOperationNotPermittedError");
			}else if(reply->error()==QNetworkReply::ContentNotFoundError){
				debug("QNetworkReply::ContentNotFoundError");
			}else if(reply->error()==QNetworkReply::AuthenticationRequiredError){
				debug("QNetworkReply::AuthenticationRequiredError");
			}else if(reply->error()==QNetworkReply::ContentReSendError){
				debug("QNetworkReply::ContentReSendError");
			}else if(reply->error()==QNetworkReply::ProtocolUnknownError){
				debug("QNetworkReply::ProtocolUnknownError");
			}else if(reply->error()==QNetworkReply::ProtocolInvalidOperationError){
				debug("QNetworkReply::ProtocolInvalidOperationError");
			}else if(reply->error()==QNetworkReply::UnknownNetworkError){
				debug("QNetworkReply::UnknownNetworkError");
			}else if(reply->error()==QNetworkReply::UnknownProxyError){
				debug("QNetworkReply::UnknownProxyError");
			}else if(reply->error()==QNetworkReply::UnknownContentError){
				debug("QNetworkReply::UnknownContentError");
			}else if(reply->error()==QNetworkReply::ProtocolFailure){
				debug("QNetworkReply::ProtocolFailure");
			}else{
				debug("QNetworkReply -> unknown network error");
			}

		}
	}

	int LL0=0;
	int s1=res.indexOf("<response>");
	int s2=res.lastIndexOf("</response>");
	if(s1<0 || s2<0){
		res="";
		LL0=1;
	}else{
		res=res.mid(s1);
	}

	if(res.indexOf("<status>login_token_expired</status>")>0){	// We are checking for error "login_token_expired"
		QDomDocument doc("response");
		doc.setContent(res, true);

		QDomElement root=doc.documentElement();
		QDomNode n=root.firstChild();
		while(!n.isNull()){
			QDomElement e=n.toElement();
			if(!e.isNull()){
				if(e.tagName()=="status"){
					if(e.text()=="login_token_expired") LL0=2;
					break;
				}
			}
			n=n.nextSibling();
		}
	}

	if(LL0==2 || (LL0!=0 && attempt<3)){
		debug("Request failed. Try to send again.");
		attempt++;
		getToken2();
		return runFunction2(uri, isPost, postData, attempt);
	}

	if(mess!="") SrunFunction.error=1;

	return res;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::runFunction(QString uri, bool isPost, QString postData){
if(token!="*") debug("runFunction("+uri+")");
	SrunFunction.uri=uri;
	SrunFunction.isPost=isPost;
	SrunFunction.postData=postData;
	QString host=smehost;

	bool HTTPS = false;
	int ss01 = host.indexOf("://");
	if(ss01>0){
		int ss02 = host.indexOf("https://", 0, Qt::CaseInsensitive);
		if(ss02>=0 && ss02<ss01) HTTPS=true;
		host = host.mid(ss01+3);
	}

//	if(uri.indexOf("gettoken/", -1, Qt::CaseInsensitive)==0){		// For gettoken we use HTTPS to protect password
//		HTTPS = true;
//	}

	http = new QNetworkAccessManager(this);
	QNetworkRequest request1;

	if(useProxy){
		debug("useProxy=1");
		quint16 xport = proxyport;
		http->setProxy(QNetworkProxy(QNetworkProxy::HttpProxy, proxyhost, xport, proxylogin, proxypass));
	}

	QSslConfiguration SSLconf(QSslSocket().sslConfiguration());
	SSLconf.setProtocol(QSsl::TlsV1);
	request1.setSslConfiguration(SSLconf);
	request1.setRawHeader("User-Agent", "Mozilla/4.0 (Linux Tools Explorer)");
	request1.setRawHeader("Accept", "*/*");
	request1.setRawHeader("Accept-Encoding", "deflate");
	request1.setRawHeader("Connection", "Keep-Alive");

	connect(http, SIGNAL(sslErrors(QNetworkReply *, QList<QSslError>)), this, SLOT(slotSslErrors(QNetworkReply *, QList<QSslError>)));

	if(host.indexOf("://")<0){
		if(HTTPS){
			host = "https://" + host;
		}else{
			host = "http://" + host;
		}
	}

	QNetworkReply *reply;
	if(token.length()<2) token="*";
	if(!isPost){
		QString url01 = host + "/api/"+token+"/"+uri;
		request1.setUrl(QUrl(url01));

		reply = http->get(request1);
		if(uri.indexOf("gettoken/", -1, Qt::CaseInsensitive)==0){
			debug("REQUEST => " + url01);
		}
	}else{
		debug("postData: "+postData.mid(0, 250));

		if(postData!="") postData+="&";
		postData+="token="+ token;

		QString url01 = host + "/api/rpc.php";
		request1.setUrl(QUrl(url01));

		reply = http->post(request1, postData.toUtf8());
	}

	QEventLoop eventLoop;
	QObject::connect(http, SIGNAL(finished(QNetworkReply*)), &eventLoop, SLOT(quit()));
	eventLoop.exec();
	runFunctionResp(reply);
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::slotSslErrors(QNetworkReply *reply, QList<QSslError> e0){
	if(e0.size()>0 && (
			e0.at(0).errorString()=="The root certificate of the certificate chain is self-signed, and untrusted"
			|| e0.at(0).errorString()=="The issuer certificate of a locally looked up certificate could not be found"
			|| e0.at(0).errorString()=="The root CA certificate is not trusted for this purpose"
		)){
		reply->ignoreSslErrors();
	}else{
		if(e0.size()>0){
			QMessageBox::critical(this, "Error", "  "+e0.at(0).errorString()+"  ");
		}
	}

	qDebug() << "SSL Error:" << e0;
	return ;	
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::runFunctionResp(QNetworkReply* reply){
debug("runFunctionResp()");
	QString res=QString::fromUtf8(reply->readAll());

	if(res.indexOf("<response>")>1){
		debug(res.mid(res.indexOf("<response>"), 280) +"\n");
	}else{
		debug(res.mid(0, 420) +"\n");
	}

	QString mess="";
	if(res==""){
		if(reply->error()!=QNetworkReply::NoError){
			mess="Cannot connect to server";
			debug("Error => "+ mess);

			if(reply->error()==QNetworkReply::NoError){
				debug("QNetworkReply::NoError");
			}else if(reply->error()==QNetworkReply::RemoteHostClosedError){
				debug("QNetworkReply::RemoteHostClosedError");
			}else if(reply->error()==QNetworkReply::HostNotFoundError){
				debug("QNetworkReply::HostNotFoundError");
				mess="Error. Check your Internet connection.";
			}else if(reply->error()==QNetworkReply::TimeoutError){
				debug("QNetworkReply::TimeoutError");
			}else if(reply->error()==QNetworkReply::OperationCanceledError){
				debug("QNetworkReply::OperationCanceledError");
			}else if(reply->error()==QNetworkReply::ProxyAuthenticationRequiredError){
				debug("QNetworkReply::SslHandshakeFailedError");
			}else if(reply->error()==QNetworkReply::ProxyConnectionRefusedError){
				debug("QNetworkReply::ProxyConnectionRefusedError");
			}else if(reply->error()==QNetworkReply::ProxyConnectionClosedError){
				debug("QNetworkReply::ProxyConnectionClosedError");
			}else if(reply->error()==QNetworkReply::ProxyNotFoundError){
				debug("QNetworkReply::ProxyNotFoundError");
			}else if(reply->error()==QNetworkReply::ProxyTimeoutError){
				debug("QNetworkReply::ProxyTimeoutError");
			}else if(reply->error()==QNetworkReply::ProxyAuthenticationRequiredError){
				debug("QNetworkReply::ProxyAuthenticationRequiredError");
			}else if(reply->error()==QNetworkReply::ContentAccessDenied){
				debug("QNetworkReply::ContentAccessDenied");
			}else if(reply->error()==QNetworkReply::ContentOperationNotPermittedError){
				debug("QNetworkReply::ContentOperationNotPermittedError");
			}else if(reply->error()==QNetworkReply::ContentNotFoundError){
				debug("QNetworkReply::ContentNotFoundError");
			}else if(reply->error()==QNetworkReply::AuthenticationRequiredError){
				debug("QNetworkReply::AuthenticationRequiredError");
			}else if(reply->error()==QNetworkReply::ContentReSendError){
				debug("QNetworkReply::ContentReSendError");
			}else if(reply->error()==QNetworkReply::ProtocolUnknownError){
				debug("QNetworkReply::ProtocolUnknownError");
			}else if(reply->error()==QNetworkReply::ProtocolInvalidOperationError){
				debug("QNetworkReply::ProtocolInvalidOperationError");
			}else if(reply->error()==QNetworkReply::UnknownNetworkError){
				debug("QNetworkReply::UnknownNetworkError");
			}else if(reply->error()==QNetworkReply::UnknownProxyError){
				debug("QNetworkReply::UnknownProxyError");
			}else if(reply->error()==QNetworkReply::UnknownContentError){
				debug("QNetworkReply::UnknownContentError");
			}else if(reply->error()==QNetworkReply::ProtocolFailure){
				debug("QNetworkReply::ProtocolFailure");
			}else{
				debug("QNetworkReply -> unknown network error");
			}

		}
	}

	int LL0=0;
	int s1=res.indexOf("<response>");
	int s2=res.lastIndexOf("</response>");
	if(s1<0 || s2<0){
		res="";
		LL0=1;
	}else{
		res=res.mid(s1);
	}

	if(res.indexOf("<status>login_token_expired</status>")>0){
		QDomDocument doc("response");
		doc.setContent(res, true);

		QDomElement root=doc.documentElement();
		QDomNode n=root.firstChild();
		while(!n.isNull()){
			QDomElement e=n.toElement();
			if(!e.isNull()){
				if(e.tagName()=="status"){
					if(e.text()=="login_token_expired") LL0=2;
					break;
				}
			}
			n=n.nextSibling();
		}
	}

	if(LL0==2 || (LL0!=0 && SrunFunction.attempt<3)){
		debug("Request failed. Try to send again.");
		SgetToken.uri=SrunFunction.uri;
		SgetToken.isPost=SrunFunction.isPost;
		SgetToken.postData=SrunFunction.postData;
		SrunFunction.attempt++;
		getToken();
		return ;
	}

	if(mess!="") SrunFunction.error=1;
	SrunFunction.response=res;

	if(SrunFunction.uri.indexOf("getToken",0,Qt::CaseInsensitive)<0 && SrunFunction.uri.indexOf("setProviderData",0,Qt::CaseInsensitive)<0) SrunFunction.attempt=0;

	resume(0);
//debug("Error => "+http->errorString());
	return ;
}
//////////////////////////////////////////////////////////////////////
int SMEStorageExplorer::initialization(int argc, char *argv[]){
	QString comm="";
	for(int i=1; i<argc; i++){
		QString command="";
		command.append(argv[i]);
		comm+=command+" ";
		command=command.toLower();
		if(command.indexOf("type=cloud")==0){
			explorerType=0;
		//}else if(command.indexOf("type=public")==0){
		//	explorerType=1;
		}else if(command.indexOf("type=favourite")==0 || command.indexOf("type=favorite")==0){
			explorerType=2;
		//}else if(command.indexOf("type=search")==0){
		//	explorerType=3;
		}else if(command.indexOf("type=clipboard")==0){
			explorerType=4;
		}else if(command.indexOf("type=group")==0){
			explorerType=5;
		}else if(command.indexOf("type=trash")==0 || command.indexOf("type=recycle")==0){
			explorerType=6;
		}
	}
// cloud, favourite, public, search, clipboard, group
debug("initialization("+intToQstring(argc)+", "+comm +")");
//return ;

	QString etype="  -  ";
	if(explorerType==0){
		etype+="Cloud";
	}else if(explorerType==1){
		etype+="Publics";
	}else if(explorerType==2){
		etype+="Favourites";
	}else if(explorerType==3){
		etype+="Search For Files";
	}else if(explorerType==4){
		etype+="Clipboard";
	}else if(explorerType==5){
		etype+="Business Groups";
	}else if(explorerType==6){
		etype+="Trash";
	}else{
		etype="";
	}
   this->setWindowTitle("SME Explorer "+ etype);

	loadConfig();
	setWindowPosition();
	bViewList();

	checkForOldVersion();
	if(comm.indexOf("--onlycheckforoldversion=1")>-1){
		return -1;	// close program
	}

	QTimer::singleShot(100, this, SLOT(initWnd()));
	return 0;
}
//////////////////////////////////////////////////////////////////////

void SMEStorageExplorer::repaintAllIcons(){
debug("repaintAllIcons()");
	QString pIcon="";						// repaint all icons
	int count=getCountFiles(filelist);
	for(int i=0; i<count; i++){
		pIcon=getFileIcon(filelist[i].type, filelist[i].name, filelist[i].extension);
		filelist[i].node->setIcon(QIcon(pIcon));
	}

}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bViewIcons(){
debug("bViewIcons()");
	if(!tryRunning()) return ;
	viewType=1;
	int zoom=62;
	ui->listWidget->setViewMode(QListView::IconMode);
	ui->listWidget->setGridSize(QSize(zoom+25,zoom+50)); //90
	ui->listWidget->setIconSize(QSize(zoom+20,zoom+120)); //48
	ui->listWidget->setFlow(QListView::LeftToRight);
	ui->listWidget->setWordWrap(1);
//	ui->listWidget->setMouseTracking(true);
// need repaint all files and folders with big icons
	ui->listWidget->setDragDropMode(QAbstractItemView::NoDragDrop);

	repaintAllIcons();
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bViewList(){
	if(!tryRunning()) return ;
debug("bViewList()");
	viewType=0;
	ui->listWidget->setViewMode(QListView::ListMode);
	ui->listWidget->setGridSize(QSize());
	ui->listWidget->setIconSize(QSize(17,17));
	ui->listWidget->setFlow(QListView::TopToBottom);
	ui->listWidget->setWordWrap(0);

//	disconnect(list,SIGNAL(entered(QModelIndex)),this,SLOT(itemHover(QModelIndex)));
	ui->listWidget->setMouseTracking(false);

	repaintAllIcons();
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::initWnd(){
debug("initWnd();");
	showMessage("Preparing... ", true);
	SrunFunction.up_level_command="";
	SrunFunction.up_level_command.append(SLOT(initWnd()));

	if(login.length()<1 || password.length()<1){
		properties();
		hideMessage();
		return ;
	}

	//debug("smehost="+smehost);
	if(token.length()<2){
		getToken();
		return ;
	}

	if(!isGetUserInfo){
		getMyInfo();
		return ;
	}

	if(!isGetFilesList){
		getFilesList(currentFolder);
		return ;
	}

	deleteOldTmpFiles();

	if(explorerType!=0){
		ui->comboBox1->setEnabled(false);
	}else{
		ui->comboBox1->setEnabled(true);
	}

	hideMessage();
	SrunFunction.up_level_command="";
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::getMyInfo(){
debug("getMyInfo()");
	showMessage("Retrieving user info", true);

	SrunFunction.restory="";
	SrunFunction.restory.append(SLOT(getMyInfoResp()));

	QString uri="getMyInfo/";
	if(isActionCanceled){
		hideMessage();
		return ;
	}
	runFunction(uri);

	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::getMyInfoResp(){
debug("getMyInfoResp()");
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory="";
	if(res.indexOf("<response>")<0 || res.indexOf("</response>")<0){
		QMessageBox::critical(this, "Error", "Can't get user info.");
		hideMessage();
		return ;
	}

	QDomDocument doc("response");
	doc.setContent(res, true);
	bool L=false;
	QDomElement root=doc.documentElement();
	QDomNode n=root.firstChild();
	while(!n.isNull()){
		QDomElement e = n.toElement();
		if(!e.isNull()){
			if(e.tagName()=="userinfo"){
				n=n.firstChild();
				L=true;
				break;
			}
		}
		n=n.nextSibling();
	}

	if(L){
		for(int i=0; !n.isNull(); i++){
			QDomElement e=n.toElement();
			if(!e.isNull() && e.tagName()=="us_isorg"){		// us_isorg==0 - single user, us_isorg==1 - org user, us_isorg==2 - org admin
				if(e.text()=="2"){
					isOrganizationAdmin=true;
				}else{
					isOrganizationAdmin=false;
				}
			}
			n=n.nextSibling();
		}// for
	}// if

	isGetUserInfo=true;
	resume(1);
	return ;
}
//////////////////////////////////////////////////////////////////////
int SMEStorageExplorer::getCountFiles(Tfile *arr){
//debug("getCountFiles()");
	int n=maxCount;
	QString name="";

	int i=0;
	for(; i<n; i++){
		if(i<n && arr[i].name=="")	return i;

		if(i*10		<n && arr[i*10].name!="")		i=i*10;
		if(i*2		<n && arr[i*2].name!="")		i=i*2;
		if(i+10000	<n && arr[i+10000].name!="")	i=i+10000;
		if(i+1000	<n && arr[i+1000].name!="")	i=i+1000;
		if(i+100		<n && arr[i+100].name!="")		i=i+100;
		if(i+20		<n && arr[i+20].name!="")		i=i+20;
		if(i+5		<n && arr[i+5].name!="")		i=i+5;
	}
//debug("getCountFiles  =>  i="+ intToQstring(i));
//	delete []arr;

	return i;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::contextMenuEvent(QContextMenuEvent* event){
debug("contextMenuEvent()");
	int x=ui->listWidget->x();
	int y=ui->listWidget->y();
	QPoint pt=event->pos();
	pt.setX(pt.x()-x);
	pt.setY(pt.y()-y);
//	QListWidgetItem* item=ui->listWidget->itemAt(event->pos());
	QListWidgetItem* item=ui->listWidget->itemAt(pt);
//debug("x => "+ intToQstring(event->pos().x())+" y => "+intToQstring(event->pos().y())+"  pt => x => "+ intToQstring(pt.x())+" y => "+intToQstring(pt.y()));
	if(item){
//		QPoint p1=ui->listWidget->pos();
		int w=ui->listWidget->width();
		int h=ui->listWidget->height();

		QPoint p2=event->pos();
		int x2=p2.x();
		int y2=p2.y();


		if(x2<x || y2<y || x+w<x || y+h<y2)	return ;
//debug("Item => "+item->text());
		contextMenu->exec(event->globalPos());
	}
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::debug(QString s, int level){
	if(level<=DEBUG) printf("%s\n", s.toUtf8().data());
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::closeEvent(QCloseEvent *event){
debug("closeEvent()");
	cancelCurrentAction();
	event->accept();
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::resizeEvent(QResizeEvent *e){
debug("resizeEvent()");
	int w=width();
	int h=height();
	int y=0;
	if(e){}
	ui->widget->setGeometry(QRect(0, 0, w, h));

	int fontSize=12;
	if(ui->MenuBar->font().pixelSize()>8){
		fontSize=ui->MenuBar->font().pixelSize();
	}else if(ui->MenuBar->font().pointSize()>7){
		fontSize=(int) (ui->MenuBar->font().pointSize()*1.3);
	}

//debug("font > "+intToQstring(fontSize));
	ui->MenuBar->setGeometry(QRect(0, y, w, fontSize+13));
	y+=fontSize+13;
//	ui->MenuBar->heightForWidth(800);

//	ui->lineEdit1->setGeometry(QRect(3, 26, w-6, 24));
	ui->comboBox1->setGeometry(QRect(3, y-3, w-6, 24));
	y+=24+42;
	ui->listWidget->setGeometry(QRect(3, y, w-6, h-y-27));
	ui->textLabel1->setGeometry(QRect(3, h-22, w-310, 22));		// 687
	ui->progressBar1->setGeometry(QRect(w-300, h-21, 200, 20));	// 200
	ui->pushButton9->setGeometry(QRect(w-90, h-23, 82, 23));		// 80

	if(nResize>0){
		saveConfig();
	}else{
		nResize++;
	}

	if(viewType==1) bViewIcons();
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::loadConfig(){
	if(fCnfName.length()<1)	return ;

	if(QFile::exists(fCnfName)==false){
		saveConfig();
		return ;
	}

	QString conf="";
	conf=readFromFile(fCnfName);
	conf="\n"+ conf + "\n";
	conf.replace("\n\n", "\n");

//debug("conf 1 =>"+ conf +";");
  if(conf.indexOf("<explorer>")<0 || conf.length()<=1){		// try old method
		QFile file(fCnfName);
		file.open(QIODevice::ReadOnly | QIODevice::Text);
		QDataStream in(&file);

		in >> conf;
		file.close();
	}

	QString proxyConf=getPartQString(conf, "<proxy>", "</proxy>");
	conf=getPartQString(conf, "<explorer>", "</explorer>");

  if(conf.length()<=1){
    saveConfig();
    return ;
  }

	smehost=getPartQString(conf, "<smehost>", "</smehost>");
	if(smehost.length()>0)	smehost=decodeBase64(smehost);
	if(smehost.length()<=1)	smehost="storagemadeeasy.com";

	login=getPartQString(conf, "<blogin>", "</blogin>");
	if(login.length()>0){
		login=decodeBase64(login);
	}else{
		login=getPartQString(conf, "<login>", "</login>");
		if(login.length()<1)	login="";
	}

	password=getPartQString(conf, "<apassword>", "</apassword>");
	if(password.length()>0){
		password=decryptSMEPassword(password);
	}else{
		password=getPartQString(conf, "<bpassword>", "</bpassword>");
		if(password.length()>0){
			password=decodeBase64(password);
		}else{
			password=getPartQString(conf, "<password>", "</password>");
			if(password.length()<1)	password="";
		}
	}

	providerLogin=getPartQString(conf, "<providerLogin>", "</providerLogin>");
	if(providerLogin.length()>0){
		providerLogin=decodeBase64(providerLogin);
	}else{
		providerLogin="";
	}

	providerPassword=getPartQString(conf, "<providerPassword>", "</providerPassword>");
	if(providerPassword.length()>0){
		providerPassword=decodeBase64(providerPassword);
	}else{
		providerPassword="";
	}


 	QString el="";
/*
	el=getPartQString(conf, "<detailedLogs>", "</detailedLogs>");
	if(el.length()>0){
		detailedLogs=el.toInt();
	}else{
//		detailedLogs=0;
	}
*/
	el=getPartQString(conf, "<wx>", "</wx>");
	if(el.length()>0)	wx=el.toInt();

	el=getPartQString(conf, "<wy>", "</wy>");
	if(el.length()>0)	wy=el.toInt();

	el=getPartQString(conf, "<ww>", "</ww>");
	if(el.length()>0)	ww=el.toInt();

	el=getPartQString(conf, "<wh>", "</wh>");
	if(el.length()>0)	wh=el.toInt();


	el=getPartQString(proxyConf, "<useproxy>", "</useproxy>");
	if(el.length()>0)	useProxy=el.toInt();

	el=getPartQString(proxyConf, "<proxyhost>", "</proxyhost>");
	proxyhost=(el=="")?(""):(decodeBase64(el));

	el=getPartQString(proxyConf, "<proxyport>", "</proxyport>");
	proxyport=(el=="")?(80):(decodeBase64(el).toInt());
	if(proxyport<1) proxyport=80;

	el=getPartQString(proxyConf, "<proxylogin>", "</proxylogin>");
	proxylogin=(el=="")?(""):(decodeBase64(el));

	el=getPartQString(proxyConf, "<proxypass>", "</proxypass>");
	proxypass=(el=="")?(""):(decodeBase64(el));

	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::saveConfig(){
	if(fCnfName.length()<1)	return ;

	getWindowPosition();

	QString conf="";
	QString lconf="";

	if(QFile::exists(fCnfName)){
		lconf=readFromFile(fCnfName);

//debug("READ 1 =>"+ lconf +"<<<;\n");

		if(lconf.length()<=1 || (lconf.indexOf("<mainWinget>")<0 && lconf.indexOf("<sync>")<0 && lconf.indexOf("<explorer>")<0)){			// try old method
		  QFile file2(fCnfName);
			file2.open(QIODevice::ReadOnly | QIODevice::Text);
			QDataStream in(&file2);
			in >> lconf;
			file2.close();
//debug("READ 2 =>"+ lconf +";\n");
		}

//debug("READ 3 =>"+ lconf +";\n");
//return ;

		QString nlconf="", lconf1="";
		lconf1=getPartQString(lconf, "<mainWinget>", "</mainWinget>");
		if(lconf1.length()>0) nlconf="<mainWinget>"+ lconf1 +"</mainWinget>";
		lconf1=getPartQString(lconf, "<sync>", "</sync>");
		if(lconf1.length()>0) nlconf+="<sync>"+ lconf1 +"</sync>";
		lconf=nlconf;
		nlconf="";
	}

//debug("lconf ==> \n"+ lconf +"\n");

	QFile::resize(fCnfName, 0);

	conf=lconf;
	conf.append("<explorer>");
//	conf.append("<ltoken>"+ base64(login) +"</ltoken>");
	conf.append("<smehost>"+ base64(smehost) +"</smehost>");
	conf.append("<blogin>"+ base64(login) +"</blogin>");
	conf.append("<apassword>"+ encryptSMEPassword(password) +"</apassword>");
	conf.append("<providerLogin>"+ base64(providerLogin) +"</providerLogin>");
	conf.append("<providerPassword>"+ base64(providerPassword) +"</providerPassword>");
//  conf.append("<detailedLogs>"+ intToQstring(detailedLogs) +"</detailedLogs>");
	conf.append("<wx>"+ intToQstring(wx) +"</wx>");
	conf.append("<wy>"+ intToQstring(wy) +"</wy>");
	conf.append("<ww>"+ intToQstring(ww) +"</ww>");
	conf.append("<wh>"+ intToQstring(wh) +"</wh>");
	conf.append("</explorer>");

	QString sUseProxy="0";
	if(useProxy) sUseProxy="1";
	conf.append("<proxy>");
	conf.append("<useproxy>"+ sUseProxy +"</useproxy>");
	conf.append("<proxyhost>"+ base64(proxyhost) +"</proxyhost>");
	conf.append("<proxyport>"+ base64(intToQstring(proxyport)) +"</proxyport>");
	conf.append("<proxylogin>"+ base64(proxylogin) +"</proxylogin>");
	conf.append("<proxypass>"+ base64(proxypass) +"</proxypass>");
	conf.append("</proxy>");

//	debug("WRITE =>\n"+ conf);

	if(writeToFile(fCnfName, conf)!=0){
		//	error
	}


// save proxy settings for perl script
	lconf="";
	QString cfName=QDir::homePath() + "/.storagemadeeasy.conf";
	QString cfNameOld=QDir::homePath() + "/.smestorage.conf";
	if(!QFile::exists(cfName) && QFile::exists(cfNameOld)) QFile::rename(cfNameOld, cfName);
	if(QFile::exists(cfName)) lconf=readFromFile(cfName);

	if(lconf==""){
		lconf+="host=storagemadeeasy.com\n";
		lconf+="SMALL_FILE_SIZE=1048576\n";
	}else{
		for(int j=0; lconf.lastIndexOf("\n")==lconf.length()-1 && j<100; j++){
			lconf=lconf.mid(0, lconf.length()-1);
		}
		lconf+="\n";
	}

	QString s=getPartQString(lconf, "useproxy=", "\n");
	if(s!="" || lconf.indexOf("useproxy=\n")>-1){
		lconf.replace("useproxy="+s+"\n", "useproxy="+sUseProxy+"\n");
	}else{
		lconf+="useproxy="+sUseProxy+"\n";
	}

	s=getPartQString(lconf, "proxyhost=", "\n");
	if(s!="" || lconf.indexOf("proxyhost=\n")>-1){
		lconf.replace("proxyhost="+s+"\n", "proxyhost="+proxyhost+"\n");
	}else{
		lconf+="proxyhost="+proxyhost+"\n";
	}

	s=getPartQString(lconf, "proxyport=", "\n");
	if(s!="" || lconf.indexOf("proxyport=\n")>-1){
		lconf.replace("proxyport="+s+"\n", "proxyport="+intToQstring(proxyport)+"\n");
	}else{
		lconf+="proxyport="+intToQstring(proxyport)+"\n";
	}

	s=getPartQString(lconf, "proxylogin=", "\n");
	if(s!="" || lconf.indexOf("proxylogin=\n")>-1){
		lconf.replace("proxylogin="+s+"\n", "proxylogin="+proxylogin+"\n");
	}else{
		lconf+="proxylogin="+proxylogin+"\n";
	}

	s=getPartQString(lconf, "proxypass=", "\n");
	if(s!="" || lconf.indexOf("proxypass=\n")>-1){
		lconf.replace("proxypass="+s+"\n", "proxypass="+proxypass+"\n");
	}else{
		lconf+="proxypass="+proxypass+"\n";
	}

//debug("lconf=>>>>>>\n"+ lconf +"\n");
	if(writeToFile(cfName, lconf)!=0){
		//	error
	}

	return ;
}
//////////////////////////////////////////////////////////////////////
QString SMEStorageExplorer::readFromFile(QString name){
	if(name=="")	return "";
	if(!QFile::exists(name))	return "";

	QString res="";
	char *buf =new char[1];
	buf[0]=' ';
	FILE * pFile;
	
	QByteArray tmName;
	if(localeEncoding!=""){
		QTextCodec *codec = QTextCodec::codecForName(localeEncoding.toUtf8().data());
		tmName = codec->fromUnicode(name);
	}else{
		tmName = name.toUtf8();
	}

	pFile=fopen(tmName.data(), "r");
	if(!pFile && localeEncoding!=""){		// try to use UTF-8 name
		tmName = name.toUtf8();
		pFile=fopen(tmName.data(), "r");
	}

//	pFile=fopen(name.toUtf8().data(), "r");
	if(!pFile)	return 0;
	while(!feof(pFile)){
		if(fread(buf, 1, 1, pFile)==1){
			res.append(buf[0]);
		}else{
			break;
		}
	}

	QByteArray b;					// convert  to UTF8
	b.append(res);
	res=QString::fromUtf8(b);
//debug(QString::fromUtf8(b));

	fclose(pFile);
	return res;
}
//////////////////////////////////////////////////////////////////////
int SMEStorageExplorer::writeToFile(QString name, QString s, bool append){
	if(name=="")	return -1;

	FILE *pFile;
/*
	if(append){
		pFile=fopen(name.toUtf8().data(), "a");
	}else{
		pFile=fopen(name.toUtf8().data(), "w");
	}
*/
	QString rwMode="w";
	if(append) rwMode="a";
	QByteArray tmName;
	if(localeEncoding!=""){
		QTextCodec *codec = QTextCodec::codecForName(localeEncoding.toUtf8().data());
		tmName = codec->fromUnicode(name);
	}else{
		tmName = name.toUtf8();
	}

	pFile=fopen(tmName.data(), rwMode.toUtf8().data());
	if(!pFile && localeEncoding!=""){		// try to use UTF-8 name
		tmName = name.toUtf8();
		pFile=fopen(tmName.data(), rwMode.toUtf8().data());
	}
	
	if(!pFile)	return 0;

	int leng=s.length();
	for(int i3=0; i3<=leng; i3=i3+100){
		int l1=100;
		if(i3+l1>leng)	l1=leng-i3;
		QString sa =s.mid(i3, l1);
		if(sa=="")	break;
//		char *buf2=sa.toLatin1().data();
		QByteArray b="";					// convert  to UTF8
		b.append(sa.toUtf8());
		char *buf2=b.data();
		size_t wsize=size_t (b.length());
		size_t rl_wsize=fwrite(buf2, 1, wsize, pFile);
		if(rl_wsize!=wsize){}
	}

	fclose(pFile);
	return 0;
}
//////////////////////////////////////////////////////////////////////
QString SMEStorageExplorer::intToQstring(int n){
	return QString::number(n);
}
//////////////////////////////////////////////////////////////////////
QString SMEStorageExplorer::boolToQstring(bool n){
	return QString((n)?("true"):("false"));
}
//////////////////////////////////////////////////////////////////////
QByteArray SMEStorageExplorer::qstringToQByteArray(QString s){
	QByteArray b;
	b.append(s);
	return b;
}
//////////////////////////////////////////////////////////////////////
QString SMEStorageExplorer::floatToQstring(double n){
	char buffer[100];
	sprintf(buffer, "%f", n);
	QString res;
	res.append(buffer);

	int s=res.indexOf(",");
	if(s>0){
		res=res.mid(0, s);
	}else{
		s=res.indexOf(".");
		if(s>0)	res=res.mid(0, s);
	}

	return res;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::setWindowPosition(){
//	if(isHidden) return ;

	if(wx>0 && wy>0)	move(QPoint(wx, wy));
	if(ww>0 && wh>0)	resize(QSize(ww, wh));
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::getWindowPosition(){
	QSize sz=size();
	ww=sz.width();
	wh=sz.height();
	wx=x();
	wy=y();
}
//////////////////////////////////////////////////////////////////////
QString SMEStorageExplorer::getPartQString(QString s, QString from, QString to){
   int st=s.indexOf(from);
   if(st<0) return "";
   st += from.length();
   int e=s.indexOf(to, st);
	if(to.length()==0) e = s.length();
   if(e-st<=0) return "";
   QString el=s.mid(st, e-st);
   if(el.length()>0 && st>=from.length() && e>-1){



      return el;
   }else{
      return "";
   }
}
//////////////////////////////////////////////////////////////////////
QString SMEStorageExplorer::base64(QString t){
	return QString(t.toUtf8().toBase64());
}
//////////////////////////////////////////////////////////////////////
QString SMEStorageExplorer::decodeBase64(QString t){
	QByteArray xx="";
	xx.append(t);
	return QString::fromUtf8(xx.fromBase64(xx));
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::showMessage(QString m, bool showButtonCancel, bool showProgressBar){
debug("Action: "+ m);
	isRunning=true;
	blockSelection();
	ui->textLabel1->setText("Action: "+ m);
	ui->textLabel1->show();
	ui->progressBar1->hide();
//	ui->pushButton9->hide();

	if(showButtonCancel) ui->pushButton9->show();
	if(showProgressBar){
		ui->progressBar1->show();
	}else{
		int w=width(), h=height();
		ui->textLabel1->setGeometry(QRect(3, h-20, w-310+205, 16));
	}
//	isActionCanceled=false;

	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::hideMessage(bool leaveText){
debug("hideMessage()");
	if(!leaveText) ui->textLabel1->setText("");
	ui->textLabel1->hide();
	ui->progressBar1->hide();
	ui->pushButton9->hide();

	SbUpload.filelist.clear();
	SbUpload.files.clear();

	SrunFunction.attempt=0;
	isActionCanceled=false;
	isRunning=false;
	SPasteFromClipboard.n=0;
	updateMenus();
	unBlockSelection();
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::logOut(){
debug("logOut()");
	if(!tryRunning()) return ;

	if(QMessageBox::question(this, "Confirm", "Do you want Logout?", QMessageBox::Ok, QMessageBox::No)!=QMessageBox::Ok){
		return ;
	}

	login = "";
	password = "";
	
	saveConfig();
	refreshAll(true, false);
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::refreshWnd(bool tree){
debug("refreshWnd()");
	repaint();
	if(tree){}

}
//////////////////////////////////////////////////////////////////////
QString SMEStorageExplorer::getFileIcon(int type, QString name, QString extension){
	QString path=pathToIcons +"files/";

	if(viewType==0){
		path+="small/";
	}else if(viewType==1){
		path+="big/";
	}

	if(type==1){
		path+="folder.gif";
		return path;
	}else if(type==2){
		path+="user.gif";
		return path;
	}else if(type==3){
		path+="group.gif";
		return path;
	}

	if(extension==""){
		int s=name.lastIndexOf(".");
		if(s>=0)	extension=name.mid(s+1);
	}
	extension=extension.toLower();

	if(extension=="mp3" || extension=="wma" || extension=="wav" || extension=="midi" || extension=="mmf" || extension=="aac" || extension=="ac3" || extension=="flac" || extension=="m4a" || extension=="ra"){
		path+="mp3";
	}else if(extension=="avi" || extension=="mkv" || extension=="flv" || extension=="mp4" || extension=="wmv" || extension=="mov" || extension=="mpg" || extension=="asf" || extension=="swf" || extension=="3gp" || extension=="3gp2" || extension=="rm" || extension=="rmvb" || extension=="vob" || extension=="dv" || extension=="fli" || extension=="ogv" || extension=="mpeg2" || extension=="mpeg4"){
		path+="avi";
	}else if(extension=="doc" || extension=="docx" || extension=="dot" || extension=="pages" || extension=="rtf"){
		path+="doc";
	}else if(extension=="exe"){
		path+="exe";
	}else if(extension=="pdf"){
		path+="pdf";
	}else if(extension=="rar"){
		path+="rar";
	}else if(extension=="deb"){
		path+="deb";
	}else if(extension=="rpm"){
		path+="rpm";
	}else if(extension=="java"){
		path+="java";
	}else if(extension=="asb"){
		path+="asb";
	}else if(extension=="asc"){
		path+="asc";
	}else if(extension=="vcf"){
		path+="vcf";
	}else if(extension=="asp" || extension=="aspx"){
		path+="asp";
	}else if(extension=="odp" || extension=="odpx"){
		path+="odp";
	}else if(extension=="ods" || extension=="odsx"){
		path+="ods";
	}else if(extension=="odt" || extension=="odtx"){
		path+="odt";
	}else if(extension=="sh"){
		path+="sh";
	}else if(extension=="php" || extension=="php3" || extension=="php4" || extension=="php5"){
		path+="php";
	}else if(extension=="pl" || extension=="cgi"){
		path+="pl";
	}else if(extension=="py"){
		path+="py";
	}else if(extension=="js"){
		path+="js";
	}else if(extension=="pas"){
		path+="pas";
	}else if(extension=="cpp" || extension=="cc" || extension=="cxx"){
		path+="cpp";
	}else if(extension=="c" || extension=="m" || extension=="mm"){
		path+="c";
	}else if(extension=="h" || extension=="hpp"){
		path+="h";
	}else if(extension=="cs"){
		path+="cs";
	}else if(extension=="rb"){
		path+="rb";
	}else if(extension=="mdb"){
		path+="mdb";
	}else if(extension=="ps"){
		path+="ps";
	}else if(extension=="eml" || extension=="mht"){
		path+="eml";
	}else if(extension=="wri"){
		path+="wri";
	}else if(extension=="xml" || extension=="xsl"){
		path+="xml";
	}else if(extension=="pps" || extension=="ppsx" || extension=="ppt" || extension=="pptx"){
		path+="pps";
	}else if(extension=="svg" || extension=="odg"){
		path+="svg";
	}else if(extension=="iso"){
		path+="iso";
	}else if(extension=="odc"){
		path+="odc";
	}else if(extension=="odf"){
		path+="odf";
	}else if(extension=="odi"){
		path+="odi";
	}else if(extension=="ttf"){
		path+="ttf";
	}else if(extension=="xls" || extension=="xlsx" || extension=="csv" || extension=="excel" || extension=="numbers"){
		path+="xls";
	}else if(extension=="zip" || extension=="gz" || extension=="tar" || extension=="7z" || extension=="arj" || extension=="bz2" || extension=="tbz" || extension=="tbz2"){
		path+="zip";
	}else if(extension=="jpg" || extension=="jpeg" || extension=="jpe" || extension=="bmp" || extension=="wbmp" || extension=="tif" || extension=="tiff" || extension=="psd" || extension=="gif" || extension=="png" || extension=="tga" || extension=="raw" || extension=="ico" || extension=="pcx"){
		path+="jpg";
	}else if(extension=="htm" || extension=="html" || extension=="shtm" || extension=="xhtm" || extension=="xhtml" || extension=="shtm" || extension=="shtml" || extension=="jhtml" || extension=="phtml" || extension=="css" || extension=="asp" || extension=="tpl"){
		path+="htm";
	}else if(extension=="txt" || extension=="log" || extension=="mbox" || extension=="jad"){
		path+="txt";
	}else{
		path+="file";
	}

	path+=".gif";

//	debug("path = "+ path);
	return path;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::clearList(bool deleteFromArray){
debug("clearList()");
	int n=getCountFiles(filelist);

//debug("n="+intToQstring(n));
	for(int i=n; i>=0; i--){
		if(filelist[i].name!=""){
//			ui->listWidget->removeItemWidget(filelist[i].node);
			delete filelist[i].node;
			if(deleteFromArray){
				filelist[i]=emptyFile;
			}
		}
	}//for

}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bRefresh(){
	if(!tryRunning()) return ;
debug("bRefresh()");

	refreshAll(false, false);
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::refreshAll(bool clearAll, bool changeExplorerType){
debug("refreshAll()");
	if(changeExplorerType){
		clearHistory();
		currentFolder=emptyFile;
		QString etype="  -  ";
		if(explorerType==0){
			etype+="Cloud";
		}else if(explorerType==1){
			etype+="Publics";
		}else if(explorerType==2){
			etype+="Favourites";
		}else if(explorerType==3){
			etype+="Search For Files";
		}else if(explorerType==4){
			etype+="Clipboard";
		}else if(explorerType==5){
			etype+="Business Groups";
		}else if(explorerType==6){
			etype+="Trash";
		}else{
			etype="";
		}
		this->setWindowTitle("SME Explorer"+ etype);
	}

	clearList(true);
	showMessage("Refreshing", false);

	if(clearAll){
		token="*";
		isGetUserInfo=false;
		SgetFileByPath.file=emptyFile;
	}

	SgetToken.uri="";

	isGetFilesList=false;
	SPasteFromClipboard.n=0;

	SrunFunction.error=0;
	SrunFunction.response="";
	SrunFunction.restory="";
	SrunFunction.up_level_command="";
//	SrunFunction.response_maxProgress=-1;

//	SrunFunction.response_upload=false;
//	SrunFunction.response_download=false;

	saveConfig();
	initWnd();
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bPropertiesGlobal(){
	if(!tryRunning()) return ;
debug("bPropertiesGlobal()");
	properties();
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::properties(){
debug("properties()");
	propertiesWnd.setWindowModality(Qt::ApplicationModal);
	propertiesWnd.move(QPoint((int) (x()+ww/2-250), y()+50));

	propertiesWnd.login=login;
	propertiesWnd.password=password;
	propertiesWnd.apihost=smehost;

	propertiesWnd.useProxy=useProxy;
	propertiesWnd.proxyhost=proxyhost;
	propertiesWnd.proxyport=proxyport;
	propertiesWnd.proxylogin=proxylogin;
	propertiesWnd.proxypass=proxypass;

	propertiesWnd.initWnd();
	propertiesWnd.show();

	hideMessage();
	saveConfig();
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::saveProperties(){
debug("saveProperties()");
	QString tlogin=propertiesWnd.login;
	QString tpassword=propertiesWnd.password;
	QString thost=propertiesWnd.apihost;

	QString tproxyhost	=propertiesWnd.proxyhost;
	QString tproxylogin	=propertiesWnd.proxylogin;
	QString tproxypass	=propertiesWnd.proxypass;
	int tproxyport			=propertiesWnd.proxyport;
	bool tuseProxy			=propertiesWnd.useProxy;

	bool L=false;
	if(tlogin!=login || tpassword!=password || thost!=smehost || tuseProxy!=useProxy || tproxyhost!=proxyhost || tproxyport!=proxyport || tproxylogin!=proxylogin || tproxypass!=proxypass){
		token="*";
		providerLogin="";
		providerPassword="";
		L=true;
	}

	login=tlogin;
	password=tpassword;
	smehost=thost;
	proxyhost=tproxyhost;
	proxylogin=tproxylogin;
	proxypass=tproxypass;
	proxyport=tproxyport;
	useProxy=tuseProxy;

	saveConfig();
	if(L){
		refreshAll(true);
	}else{
		hideMessage();
	}
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::getProviderLoginAndPassword(){
debug("getProviderLoginAndPassword()");
	providerlog.setWindowModality(Qt::ApplicationModal);
	providerlog.plogin=providerLogin;
	providerlog.ppass=providerPassword;

	providerlog.initWnd();
	providerlog.show();
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::saveProviderLoginAndPassword(){
debug("saveProviderLoginAndPassword()");
	providerLogin=providerlog.plogin;
	providerPassword=providerlog.ppass;

	setProviderData();
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::setProviderData(){
debug("setProviderData()");
	SrunFunction.restory2="";
	SrunFunction.restory2.append(SLOT(setProviderDataResp()));

	QString uri="setProviderData/"+ base64(providerLogin) +","+ base64(providerPassword);
	showMessage("Set Provider Data", true);

	if(token.length()<2 && tmptoken.length()>2) token=tmptoken;
	runFunction(uri);
	tmptoken="";
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::setProviderDataResp(){
debug("setProviderDataResp()");
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory2="";

	QString status;
	status=getPartQString(res, "<status>", "</status>");
	if(status!="ok"){
		QMessageBox::critical(this, "Error", "Check Provider login and password!");
		getProviderLoginAndPassword();
		return ;
	}else{
		if(token.length()<2 && tmptoken.length()>2) token=tmptoken;
		tmptoken="";
	}

	if(isActionCanceled) hideMessage();

	resume(1);
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::resume(int n){
debug("resume("+ intToQstring(n) +")");
	if(n<=0 && SrunFunction.restory2.length()>0){
		QTimer::singleShot(1, this, SrunFunction.restory2.toLatin1().data());
	}else if(n<=1 && SrunFunction.restory.length()>0){
		QTimer::singleShot(1, this, SrunFunction.restory.toLatin1().data());
	}else	if(n<=2 && SrunFunction.up_level_command.length()>0){
		QTimer::singleShot(1, this, SrunFunction.up_level_command.toLatin1().data());
	}else{
		hideMessage();
	}
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::getFilesList(Tfile folder){
debug("getFilesList()");
	QString folderid=folder.id;
	int type=folder.type;
	if(folderid=="" || folderid=="0"){
		folderid="0";
		type=1;
		currentFolder=emptyFile;
		currentFolder.id="0";
		currentFolder.type=1;
	}
	showMessage("Retrieving Files List", true);
	SrunFunction.restory="";
	SrunFunction.restory.append(SLOT(getFilesListResp()));

	QString uri="";
	if(explorerType==0){					// Cloud
//		uri="getFilesList/"+ base64(folderid) +","+ base64("0") +","+ base64("y");
		uri="getFolderContents/"+ base64(folderid) +",0,,,"+ base64("n")+",,"+ base64("n") +","+ base64("n") +",,,"+base64("n")+","+base64("y")+ "," + base64("filelist|fi_id|fi_pid|fi_name|fi_description|fi_tags|fi_type|fi_created|fi_modified|fi_lastaccessed|fi_size|fi_encrypted|fi_uid|sharer|fi_extension|fi_public|fi_favorite|fi_provider|fi_orgid|fi_orgfolderid|us_name|locker");
	}else if(explorerType==1){			// Public
		uri="";
	}else if(explorerType==2){			// Favourite
		uri="getMyFavouriteFiles/";
	}else if(explorerType==3){			// Search
		uri=Ssearch.uri;
		SrunFunction.restory="";
		SrunFunction.restory.append(SLOT(search2Resp()));
	}else if(explorerType==4){			// Clipboard
		uri="getClipboardFiles/"+ base64("n");
	}else if(explorerType==5){			// Groups
		if(folderid=="0"){
			uri="getGroupsList/";
			SrunFunction.restory="";
			SrunFunction.restory.append(SLOT(getGroupsListResp()));
		}else if(type==3){
			uri="getGroupsList/";
			SrunFunction.restory="";
			SrunFunction.restory.append(SLOT(getGroupsListResp()));
		}else if(type==2){
			getSharedByGroup(folder.shareGrId, folderid, "", "");
			return ;
		}else if(type==1){
			QString us_id=folder.shareUsId;
			if(folder.shareUsId=="" && folder.uid!="") us_id=folder.uid;
			if(folder.shareFolderId==""){
				getSharedByGroup(folder.shareGrId, us_id, folderid, "");
			}else{
				getSharedByGroup(folder.shareGrId, us_id, folder.shareFolderId, folderid);
			}
			return ;
		}
//debug("type = "+ intToQstring(type));
	}else if(explorerType==6){			// Trash
		if(folderid=="0"){
			uri="getFolderContentsFromTrash/"+ base64(folderid) +","+ base64("0") +",,,,"+ base64("n");
//folderid="";
		}else{
			uri="getTrash/"+ base64(folderid);
		}
	}

	runFunction(uri);
	tmptoken="";
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::getFilesListResp(){
debug("getFilesListResp()");
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory="";

	if(res.indexOf("<response>")<0 || res.indexOf("</response>")<0){
		QMessageBox::critical(this, "Error", "Can't get files list.");
		hideMessage();
		return ;
	}

	QDomDocument doc("response");
	doc.setContent(res, true);
	bool L=false;
	QDomElement root=doc.documentElement();
	QDomNode n=root.firstChild();
	while(!n.isNull()){
		QDomElement e = n.toElement();
		if(!e.isNull()){
			if(((explorerType==0 || explorerType==6) && e.tagName()=="filelist") || ((explorerType==2 || explorerType==4) && e.tagName()=="files")){
				n=n.firstChild();
				L=true;
				break;
			}
		}
		n=n.nextSibling();
	}

	if(L){
		for(int i=0; !n.isNull(); i++){
			QDomElement e=n.toElement();
			if(!e.isNull() && e.tagName()=="n"+intToQstring(i)){
				Tfile file=getFileFromDomNode(n);
				addToFileslist(file, true);
				n=n.nextSibling();
			}
		}// for
	}// if


	if(isActionCanceled) hideMessage();
	isGetFilesList=true;
	resume(1);
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::getGroupsListResp(){
debug("getGroupsListResp()");
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory="";
	bool needGetOnlyUsers=false;
	if(currentFolder.id!="0") needGetOnlyUsers=true;
	if(res.indexOf("<response>")<0 || res.indexOf("</response>")<0){
		if(needGetOnlyUsers){
			QMessageBox::critical(this, "Error", "Can't get users list.");
		}else{
			QMessageBox::critical(this, "Error", "Can't get groups list.");
		}
		hideMessage();
		return ;
	}

	QDomDocument doc("response");
	doc.setContent(res, true);
	bool L=false;
	QDomElement root=doc.documentElement();
	QDomNode n=root.firstChild();
	while(!n.isNull()){
		QDomElement e = n.toElement();
		if(!e.isNull()){
			if(e.tagName()=="grouplist"){
				n=n.firstChild();
				L=true;
				break;
			}
		}
		n=n.nextSibling();
	}

	if(L){
		QString fid="", pid="0", name="", type="3", created="", lastmodify="", lastaccess="", size="", encrypted="", desc="", tags="", uid="", extension="", fi_public="", fi_favorite="", provider="", orgid="", orgfolderid="";
		for(int i=0; !n.isNull(); i++){
			QDomElement e=n.toElement();
			if(!e.isNull() && e.tagName()=="n"+intToQstring(i)){
				if(!needGetOnlyUsers){
					Tfile file=getGroupFromDomNode(n);
					addToFileslist(file, true);
					n=n.nextSibling();
				}else{
					bool L0=false;
					QDomNode usersList;
					QDomNode nf=n.firstChild();
					do{
						QDomElement el=nf.toElement();
						if(el.tagName()=="gr_id")		pid=el.text();
						if(el.tagName()=="gr_users"){
							usersList=nf;
							L0=true;
						}
						nf=nf.nextSibling();
					}while(!nf.isNull());

//debug("id="+ fid+" pid="+ pid+" name="+ name+" type="+ type+" size="+ size+" encrypted="+ encrypted);
					if(L0){
						usersList=usersList.firstChild();
						for(int j=0; !usersList.isNull(); j++){
							QDomElement e=usersList.toElement();
							if(!e.isNull() && e.tagName()=="n"+intToQstring(j)){
								QDomNode nf=usersList.firstChild();
								do{
									QDomElement el=nf.toElement();
									if(el.tagName()=="us_id")		fid=el.text();
									if(el.tagName()=="us_name")	name=el.text();

									nf=nf.nextSibling();
								}while(!nf.isNull());

								if(fid.length()>0 && name.length()>0){
									Tfile file;
									file.id=fid;
									file.pid=pid;
									file.shareGrId=pid;
									file.type=2;
									file.name=name;
									file.path=Shistory.history[Shistory.current].path+"/"+file.name;
									file.lpath=Shistory.history[Shistory.current].lpath+"\n"+file.name;
debug("USER  =>      "+name);
									addToFileslist(file, true);
								}
								usersList=usersList.nextSibling();
							}
						}// for
						n=n.nextSibling();
					}
				}

			}
		}// for
	}// if

	if(currentFolder.type==3){
		getSharedByGroup(currentFolder.id);
		return ;
	}

	if(isActionCanceled) hideMessage();
	isGetFilesList=true;
	resume(1);
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::getSharedByGroup(QString groupid, QString userid, QString folderid, QString subfolderid){
	showMessage("Retrieving Shared by Group", true);
	SrunFunction.restory="";
	SrunFunction.restory.append(SLOT(getSharedByGroupResp()));
	QString uri="getSharedByGroup/"+ base64(groupid) +","+ base64(userid) +","+ base64(folderid) +","+ base64(subfolderid);
	runFunction(uri);
	SgetSharedByGroup.shareGrId=groupid;
	SgetSharedByGroup.shareUsId=userid;
	SgetSharedByGroup.shareFolderId=folderid;

	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::getSharedByGroupResp(){
debug("getSharedByGroupResp()");
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory="";
	if(res.indexOf("<response>")<0 || res.indexOf("</response>")<0){
		QMessageBox::critical(this, "Error", "Can't get files list.");
		hideMessage();
		return ;
	}

	bool L=false;
	QDomDocument doc("response");
	doc.setContent(res, true);
	QDomElement root=doc.documentElement();
	QDomNode n=root.firstChild();
	while(!n.isNull()){
		QDomElement e = n.toElement();
		if(!e.isNull()){
			if(e.tagName()=="files"){
				n=n.firstChild();
				L=true;
				break;
			}
		}
		n=n.nextSibling();
	}

	if(L){
		for(int i=0; !n.isNull(); i++){
			QDomElement e=n.toElement();
			if(!e.isNull() && e.tagName()=="n"+intToQstring(i)){
				Tfile file=getFileFromDomNode(n);
				file.shareGrId=SgetSharedByGroup.shareGrId;
				file.shareUsId=SgetSharedByGroup.shareUsId;
				file.shareFolderId=SgetSharedByGroup.shareFolderId;
				addToFileslist(file, true);
				n=n.nextSibling();
			}
		}// for
	}// if

	isGetFilesList=true;
	if(isActionCanceled) hideMessage();
	resume(1);
	return ;
}
//////////////////////////////////////////////////////////////////////
Tfile SMEStorageExplorer::getGroupFromDomNode(QDomNode n){
debug("getGroupFromDomNode()");
	QString fid="", pid="0", name="", type="3", created="", lastmodify="", lastaccess="", size="", encrypted="", desc="", tags="", uid="", extension="", fi_public="", fi_favorite="", provider="", orgid="", orgfolderid="", us_name="", gpermissions="", gprivate="";

	Tfile file=emptyFile;
	QDomNode nf=n.firstChild();
	do{
		QDomElement el=nf.toElement();
//debug(el.tagName());
		if(el.tagName()=="gr_id")				fid=el.text();
		if(el.tagName()=="gr_title")			name=el.text();
		if(el.tagName()=="gr_description")	desc=el.text();
		if(el.tagName()=="gr_permissions")	gpermissions=el.text();
		if(el.tagName()=="gr_private")		gprivate=el.text();
		nf=nf.nextSibling();
	}while(!nf.isNull());

//debug("id="+ fid+" pid="+ pid+" name="+ name+" type="+ type+" size="+ size+" encrypted="+ encrypted);
	if(fid.length()>0 && pid.length()>0 && name.length()>0 && type.length()>0){
		if(size=="") size="0";
		if(orgid=="0") orgid="";
		if(orgfolderid=="0") orgfolderid="";
		if(encrypted!="1") encrypted="0";

		file.id=fid;
		file.pid=pid;
		file.type=type.toInt();					// 0 - file, 1 - folder, 2 - user, 3 - group
		file.name=name;
		file.description=desc;
		file.tags=tags;
		file.size=size;
		file.created=created;
//		file.lastmodify=lastmodify;
		file.lastmodify=toLocal(QDateTime::fromString(lastmodify, Qt::ISODate)).toString("yyyy-MM-dd hh:mm:ss");	// Convert from UTC to local time
		file.lastaccess=lastaccess;
		file.uid=uid;
		file.extension=extension;
		file.provider=provider;
		file.us_name=us_name;
		file.gpermissions=gpermissions;
		file.gprivate=gprivate;
		if(file.type==0){
			file.path="";
			file.lpath="";
		}else{
			file.path="/"+file.name;
			file.lpath="\n"+file.name;
		}

		file.encrypted=false;
		if(encrypted=="1")	file.encrypted=true;
		file.isPublic=false;
		if(fi_public=="1")	file.isPublic=true;
		file.isFavorite=false;
		if(fi_favorite=="1")	file.isFavorite=true;

		file.orgid=orgid;
		file.orgfolderid=orgfolderid;
//		file.isProcessed=false;
	}
	return file;
}
//////////////////////////////////////////////////////////////////////
Tfile SMEStorageExplorer::getFileFromDomNode(QDomNode n, QString pid){
//debug("getFileFromDomNode()");
	QString fid="", name="", type="", created="", lastmodify="", lastaccess="", localtime="", size="", encrypted="", desc="", tags="", uid="", extension="", fi_public="", fi_favorite="", provider="", orgid="", orgfolderid="", us_name="", shareGrId="", shareUsId="", shareFolderId="", sharer="", lockedby="";

	Tfile file=emptyFile;
	QDomNode nf=n.firstChild();
	do{
		QDomElement el=nf.toElement();
		if(el.tagName()=="fi_id"){
			fid=el.text();
		}else if(el.tagName()=="fi_pid"){
			pid=el.text();
		}else if(el.tagName()=="fi_name"){
			name=el.text();
		}else if(el.tagName()=="fi_description"){
			desc=el.text();
		}else if(el.tagName()=="fi_tags"){
			tags=el.text();
		}else if(el.tagName()=="fi_type"){
			type=el.text();
		}else if(el.tagName()=="fi_created"){
			created=el.text();
		}else if(el.tagName()=="fi_modified"){
			lastmodify=el.text();
		}else if(el.tagName()=="fi_lastaccessed"){
			lastaccess=el.text();
		}else if(el.tagName()=="fi_size"){
			size=el.text();
		}else if(el.tagName()=="fi_encrypted"){
			encrypted=el.text();
		}else if(el.tagName()=="fi_uid"){
			uid=el.text();
		}else if(el.tagName()=="sharer"){
			sharer=el.text();
		}else if(el.tagName()=="fi_extension"){
			extension=el.text();
		}else if(el.tagName()=="fi_public"){
			fi_public=el.text();
		}else if(el.tagName()=="fi_favorite"){
			fi_favorite=el.text();
		}else if(el.tagName()=="fi_provider"){
			provider=el.text();
		}else if(el.tagName()=="fi_orgid"){
			orgid=el.text();
		}else if(el.tagName()=="fi_orgfolderid"){
			orgfolderid=el.text();
		}else if(el.tagName()=="us_name"){
			us_name=el.text();
		}else if(el.tagName()=="fi_localtime"){
			localtime=el.text();
		}else if(el.tagName()=="locker"){
			lockedby=el.text();
		}
		nf=nf.nextSibling();
	}while(!nf.isNull());

	if(type!="0" && type!="1") type="";
	if(fid.length()>0 && pid.length()>0 && name.length()>0 && type.length()>0){
		if(localtime!="" && localtime!="0000-00-00 00:00:00") lastmodify=localtime;
		if(size=="") size="0";
		if(orgid=="0") orgid="";
		if(orgfolderid=="0") orgfolderid="";
		if(encrypted!="1") encrypted="0";

		file.id=fid;
		file.pid=pid;
		file.type=type.toInt();					// 0 - file, 1 - folder, 2 - user, 3 - group
		file.name=name;
		file.description=desc;
		file.tags=tags;
		file.size=size;
		file.created=created;
//		file.lastmodify=lastmodify;
		file.lastmodify=toLocal(QDateTime::fromString(lastmodify, Qt::ISODate)).toString("yyyy-MM-dd hh:mm:ss");	// Convert from UTC to local time
		file.lastaccess=lastaccess;
		file.extension=extension;
		file.provider=provider;
		file.us_name=us_name;
		file.shareGrId=shareGrId;
		file.shareUsId=shareUsId;
		file.shareFolderId=shareFolderId;
		file.uid=uid;
		if(lockedby=="0") lockedby="";
		file.lockedby=lockedby;
		if((file.uid=="" || file.uid=="0") && sharer!="") file.uid=sharer;

		if(file.type==0){
			file.path="";
			file.lpath="";
		}else{
			file.path=Shistory.history[Shistory.current].path+"/"+file.name;
			file.lpath=Shistory.history[Shistory.current].lpath+"\n"+file.name;
		}
//debug("file.path = "+file.path);

		file.encrypted=false;
		if(encrypted=="1")	file.encrypted=true;
		file.isPublic=false;
		if(fi_public=="1")	file.isPublic=true;
		file.isFavorite=false;
//debug("fi_favorite="+ fi_favorite);
		if(fi_favorite=="1")	file.isFavorite=true;
		file.orgid=orgid;
		file.orgfolderid=orgfolderid;

//		file.isProcessed=false;
//		addToFileslist(file, true);
	}
	return file;
}
//////////////////////////////////////////////////////////////////////
Tfile SMEStorageExplorer::getPublicFileFromDomNode(QDomNode n){
debug("getPublicFileFromDomNode()");
	QString fid="", pid="", name="", type="", created="", lastmodify="", localtime="", lastaccess="", size="", encrypted="", desc="", tags="", uid="", extension="", fi_public="", fi_favorite="", provider="", orgid="", orgfolderid="", us_name="", shareGrId="", shareUsId="", shareFolderId="", link="";

	Tfile file=emptyFile;
	QDomNode nf=n.firstChild();
	do{
		QDomElement el=nf.toElement();
		if(el.tagName()=="fi_id"){
			fid=el.text();
		}else if(el.tagName()=="fi_pid"){
			pid=el.text();
		}else if(el.tagName()=="fi_name"){
			name=el.text();
		}else if(el.tagName()=="fi_description"){
			desc=el.text();
		}else if(el.tagName()=="fi_tags"){
			tags=el.text();
		}else if(el.tagName()=="fi_created"){
			created=el.text();
		}else if(el.tagName()=="fi_modified"){
			lastmodify=el.text();
		}else if(el.tagName()=="fi_lastaccessed"){
			lastaccess=el.text();
		}else if(el.tagName()=="fi_localtime"){
			localtime=el.text();
		}else if(el.tagName()=="fi_size"){
			size=el.text();
		}else if(el.tagName()=="fi_encrypted"){
			encrypted=el.text();
		}else if(el.tagName()=="fi_extension"){
			extension=el.text();
		}else if(el.tagName()=="fi_provider"){
			provider=el.text();
		}else if(el.tagName()=="us_name"){
			us_name=el.text();
		}else if(el.tagName()=="link"){
			link=el.text();
		}

		nf=nf.nextSibling();
	}while(!nf.isNull());

	if(type!="0" && type!="1") type="0";
	if(name!=""){
		if(localtime!="" && localtime!="0000-00-00 00:00:00") lastmodify=localtime;
		if(size=="") size="0";
		if(orgid=="0") orgid="";
		if(orgfolderid=="0") orgfolderid="";
		if(encrypted!="1") encrypted="0";

		file.id=fid;
		file.pid=pid;
		file.type=type.toInt();					// 0 - file, 1 - folder, 2 - user, 3 - group
		file.name=name;
		file.description=desc;
		file.tags=tags;
		file.size=size;
		file.created=created;
//		file.lastmodify=lastmodify;
		file.lastmodify=toLocal(QDateTime::fromString(lastmodify, Qt::ISODate)).toString("yyyy-MM-dd hh:mm:ss");	// Convert from UTC to local time
		file.lastaccess=lastaccess;
		file.uid=uid;
		file.extension=extension;
		file.provider=provider;
		file.us_name=us_name;
		file.link=link;
		file.path="";
		file.lpath="";
		file.encrypted=false;
		if(encrypted=="1")	file.encrypted=true;
		file.isPublic=true;

//		file.isProcessed=false;
	}
	return file;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bDoubleClicked(QListWidgetItem *item){
	if(!tryRunning()) return ;
debug("bDoubleClicked()");
	int n=-1;
	int count=getCountFiles(filelist);
	for(int i=0; i<count; i++){
		if(filelist[i].node==item){
			n=i;
			break;
		}
	}

	if(filelist[n].type==1 || filelist[n].type==2 || filelist[n].type==3){		// need open folder, user or group
//debug("need open folder, user or group");
//		addToHistory(filelist[n].id, filelist[n].name, filelist[n].type);
		addToHistory(filelist[n]);
		refreshAll(false);
	}else if(filelist[n].type==0){		// need download file
debug("need open file");
		openFile(n);
	}

}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::changeLocation(){
	showMessage("Preparing...", true);
	int index=ui->comboBox1->currentIndex();
	QString path=ui->comboBox1->itemText(index);

debug("changeLocation("+path+");");
	int n=-1;
	for(int i=0; i<1000; i++){
		QString tpath=SLocation[i].path;
		if(tpath=="") tpath="/";
//debug("if("+SLocation[i].id+"!=\"\" && "+tpath+"=="+path+");");
		if(SLocation[i].id!="" && tpath==path){
			n=i;
			break;
		}
	}


	if(n>-1 && Shistory.history[Shistory.current].id==SLocation[n].id){		// this folder is already opened
		hideMessage();
		return ;
	}

	if(n>-1 && (SLocation[n].path=="" || SLocation[n].path=="/")) SLocation[n].id="0";
	if(n>-1 && SLocation[n].id!=""){
		addToHistory(SLocation[n]);
		refreshAll(false);
		return ;
	}else if(path!="" && SgetFileByPath.file.id!="" && SgetFileByPath.file.path==path){

		addToHistory(SgetFileByPath.file);
		refreshAll(false);
		return ;
	}

	Tfile fl=emptyFile;
	for(int i=0; i<256; i++){	//!!!!!!!!!!!!!
//debug("if("+ Shistory.history[i].id +"!=\"\" && "+ Shistory.history[i].path +"=="+ path +"){");
		if(Shistory.history[i].id!="" && Shistory.history[i].path==path){
			fl=Shistory.history[i];
			break;
		}
	}

	if(fl.path!="" && fl.id!=""){
		addToHistory(fl);
		refreshAll(false);
		return ;
	}else{
		QString lpath=path;
		lpath=lpath.replace("/", "\n");
debug("Need get id");
		SrunFunction.up_level_command="";
		SrunFunction.up_level_command.append(SLOT(changeLocationResp()));
		getFileByPath(path, lpath);
		return ;
	}
	hideMessage();

	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::changeLocationResp(){
	SrunFunction.up_level_command="";
	showMessage("Preparing...", true);
	int index=ui->comboBox1->currentIndex();
	QString path=ui->comboBox1->itemText(index);

debug("changeLocationResp("+path+");");

debug("if("+ path +"!=\"\" && "+ SgetFileByPath.file.id +"!=\"\" && "+ SgetFileByPath.file.path +"=="+ path +"))");
	if(path!="" && SgetFileByPath.file.id!="" && SgetFileByPath.file.path==path){
		changeLocation();
		return ;
	}else{
		QMessageBox::critical(this, "Error", "Can't find this folder.");
	}

	hideMessage();

	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::addLocation(Tfile file){
debug("addLocation("+file.id+", "+file.path+");");
	if(file.id=="") file.id="0";
	if(file.id=="0") file.path="/";

	int n=0;
	for(int i=0; i<1000; i++){
//debug("if("+SLocation[i].path+"!=\"\" && "+file.path+"=="+SLocation[i].path+"){");
		if(SLocation[i].path!="" && file.path==SLocation[i].path){
//debug(SLocation[i].path+"      <= ok 1");
			n=i;
			break;
		}else if(SLocation[i].path=="" || file.path.indexOf(SLocation[i].path)!=0){
//debug(SLocation[i].path+"      <= need delete it");
			n=i;
			break;
		}
	}

	SLocation[n]=file;
	for(int i=ui->comboBox1->count()-1; i>=0; i--){		// removing old items
		ui->comboBox1->removeItem(i);
	}
/*
	for(int i=0; i<=n; i++){		// adding new items
		ui->comboBox1->insertItem(i, SLocation[i].path);
	}
*/

//debug("lpath1 = "+file.lpath+"\n");
//debug("lpath2 = "+SLocation[n].lpath+"\n");

	SLocation[n].lpath+="\n";
	SLocation[n].lpath=SLocation[n].lpath.replace("\n\n", "\n");
	int k=0;
	QString p="";
	for(int i=0; i>-1; i=SLocation[n].lpath.indexOf("\n", i+1)){		// adding new items
		p=SLocation[n].lpath.mid(0, i);
		if(i==0) p="\n";
//debug("p1="+p);
		p=p.replace("\n", "/");
//debug("p2="+p);
		ui->comboBox1->insertItem(k, p);
		k++;
	}

	if(k>0) k--;
	ui->comboBox1->setCurrentIndex(k);
	for(int i=n+1; i<1000; i++){
		SLocation[i]=emptyFile;
	}

	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::addToHistory(Tfile file){
debug("addToHistory("+file.id+", "+file.name+");");
	if(file.id=="") file.id="0";
	if(file.id=="0") file.name="";

// debug("X  ====>  Shistory.current="+Shistory.current);	for(int i=0; i<10; i++){	debug("id="+ Shistory.history[i].id +"; name="+ Shistory.history[i].name);	}

	int n=-1;
	if(Shistory.current<256){
		if(Shistory.current==0 && Shistory.history[0].id=="") Shistory.current=-1;
		n=Shistory.current+1;
		for(int i=n; i<256; i++){
			if(Shistory.history[i].id!="")	Shistory.history[i]=emptyFile;
		}
	}

	if(n==-1){				// remove first element and shift all elements
		for(int i=0; i<256-1; i++){
			Shistory.history[i]=Shistory.history[i+1];
		}
		n=255;
	}

	currentFolder=file;
	Shistory.history[n]=file;
	Shistory.current=n;
//	QString path=Shistory.history[Shistory.current].path;
//	if(path=="") path="/";
//	ui->lineEdit1->setText(path);

	if(Shistory.current>0){
		ui->pushButton0->setEnabled(true);
	}else{
		ui->pushButton0->setEnabled(false);
	}
	ui->pushButton1->setEnabled(false);
//debug("Shistory.history["+ intToQstring(n) +"].name = "+ Shistory.history[n].name +");");
	addLocation(Shistory.history[Shistory.current]);

// debug("Y  ====>  Shistory.current="+Shistory.current);	for(int i=0; i<10; i++){	debug("id="+ Shistory.history[i].id +"; name="+ Shistory.history[i].name);	}
	return ;
}
//////////////////////////////////////////////////////////////////////
QString SMEStorageExplorer::setHistory(int n){
debug("setHistory()");
	int i=Shistory.current+n;
//debug("Shistory.current="+intToQstring(Shistory.current) +"; id="+ Shistory.history[i].id  +"; name="+ Shistory.history[i].name);
	if(i<0 || i>255 || Shistory.history[i].id=="") return "";

//	addToHistory(Shistory.history[i].id, Shistory.history[i].name, Shistory.history[i].type);
	Shistory.current=i;
	currentFolder=Shistory.history[i];
//debug(currentFolder.id +", "+ currentFolder.name +", "+ intToQstring(currentFolder.type));

	if(Shistory.current>0){
		ui->pushButton0->setEnabled(true);
	}else{
		ui->pushButton0->setEnabled(false);
	}

	if(Shistory.current>=255 || Shistory.history[Shistory.current+1].id==""){
		ui->pushButton1->setEnabled(false);
	}else{
		ui->pushButton1->setEnabled(true);
	}

//	QString path=Shistory.history[Shistory.current].path;
//	if(path=="") path="/";
//	ui->lineEdit1->setText(path);
	addLocation(Shistory.history[Shistory.current]);
// debug("Z  ====>  Shistory.current="+Shistory.current);	for(int i=0; i<10; i++){	debug("id="+ Shistory.history[i].id +"; name="+ Shistory.history[i].name);	}
	return Shistory.history[Shistory.current].id;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::clearHistory(){
debug("clearHistory();");
	Shistory.current=0;
	for(int i=0; i<256; i++){
		Shistory.history[i]=emptyFile;
	}
	Shistory.history[0].id="0";

	ui->pushButton0->setEnabled(false);
	ui->pushButton1->setEnabled(false);
	Tfile fl=emptyFile;
	fl.id="0";
	addLocation(fl);

//	ui->lineEdit1->setText("/");
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bPrevious(){
	if(!tryRunning()) return ;
debug("bPrevious()");
	QString id=setHistory(-1);
	if(id=="") return ;

	currentFolder.id=id;
	refreshAll(false);

	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bNext(){
	if(!tryRunning()) return ;
debug("bNext()");
	QString id=setHistory(1);
	if(id=="") return ;

	currentFolder.id=id;
	refreshAll(false);

	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bCreate(){
	if(!tryRunning()) return ;
debug("bCreate()");
	createFolderWnd.setWindowModality(Qt::ApplicationModal);
	createFolderWnd.clear();

	createFolderWnd.sx=(int) (x()+ww/2-215);
	createFolderWnd.sy=(int) (y()+wh/2-92);
	createFolderWnd.createwnd=true;
	createFolderWnd.type=1;							// folder
	if(currentFolder.id=="0" && explorerType==5) createFolderWnd.type=3;		// group
	if(isOrganizationAdmin){
		createFolderWnd.checkBox1->setEnabled(true);
	}else{
		createFolderWnd.checkBox1->setEnabled(false);
	}

	createFolderWnd.initWnd();
	createFolderWnd.show();

	hideMessage();

	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::createFolder2(){
debug("createFolder2()");
	if(isActionCanceled){
		hideMessage();
		return ;
	}
	QString name=createFolderWnd.foldername;
	showMessage("Creating Folder  "+name, true);
	QString desc=createFolderWnd.folderdesc;
	QString isOrg="0";
	if(isOrganizationAdmin && createFolderWnd.isOrg) isOrg="1";

	SrunFunction.restory="";
	SrunFunction.restory.append(SLOT(createFolder2Resp()));

	if(isActionCanceled){
		hideMessage();
		return ;
	}

	QString pid=currentFolder.id;
	if(createFolderWnd.pid!="") pid=createFolderWnd.pid;

//	QString uri="doCreateNewFolder/"+ base64(name) +","+ base64(desc) +","+ base64(currentFolder.id) +","+ base64("g") +","+ base64(isOrg);
	QString postData="function=doCreateNewFolder";
	postData+="&fi_name="+ QUrl::toPercentEncoding(name) +"&fi_description="+ QUrl::toPercentEncoding(desc) +"&fi_pid="+ QUrl::toPercentEncoding(pid) +"&fi_structtype=g&fi_isorg="+ QUrl::toPercentEncoding(isOrg);
	runFunction("", true, postData);
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::createFolder2Resp(){
debug("createFolder2Resp()");
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory="";
	int s0=res.indexOf("<file>");
	int e0=res.lastIndexOf("</file>");
	if(res.indexOf("<response>")<0 || res.indexOf("</response>")<0 || s0<0 || e0<0 || s0>e0){
		QString statusMessage=getPartQString(res, "<statusmessage>", "</statusmessage>");
		if(statusMessage!=""){
			if(statusMessage.length()<15) statusMessage+="         ";
			QMessageBox::critical(this, "Error", statusMessage);
		}else{
			QMessageBox::critical(this, "Error", "Can't create folder.");
		}
		hideMessage();
		return ;
	}

	bool L=false;
	QDomDocument doc("response");
	doc.setContent(res, true);
	QDomElement root=doc.documentElement();
	QDomNode n=root.firstChild();
	while(!n.isNull()){
		QDomElement e=n.toElement();
		if(!e.isNull() && e.tagName()=="file"){
			Tfile file=getFileFromDomNode(n);
			if(file.pid==currentFolder.id) addToFileslist(file, true);
			createFolderWnd.lastid=file.id;
			if(file.name!="")	L=true;
			break;

		}
		n=n.nextSibling();
	}// for

	if(L){
		showMessage("Created", true);
	}else{
		QMessageBox::critical(this, "Error", "Can't create folder");
	}

	resume(1);
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bRename(){
	if(!tryRunning()) return ;
debug("bRename()");
	int count=getCountFiles(filelist);				// get first selected file, folder or group
	int n=-1;
	for(int i=0; i<count; i++){
		if(filelist[i].name!="" && filelist[i].node->isSelected()){
			n=i;
			break;
		}
	}

	if(n==-1)	return ;
//debug("name="+ filelist[n].name);

	SbRename.id=filelist[n].id;
	createFolderWnd.setWindowModality(Qt::ApplicationModal);
	createFolderWnd.clear();

	createFolderWnd.sx=(int) (x()+ww/2-215);
	createFolderWnd.sy=(int) (y()+wh/2-92);
	createFolderWnd.createwnd=false;
	createFolderWnd.type=filelist[n].type;							// folder

	if(isOrganizationAdmin){
		createFolderWnd.checkBox1->setEnabled(true);
	}else{
		createFolderWnd.checkBox1->setEnabled(false);
	}

	createFolderWnd.foldername=filelist[n].name;
	createFolderWnd.folderdesc=filelist[n].description;
	createFolderWnd.foldertags=filelist[n].tags;
	createFolderWnd.type=filelist[n].type;
	createFolderWnd.isOrg=false;

	if(filelist[n].type==3){
debug("gpermissions = "+filelist[n].gpermissions+";");
		if(filelist[n].gpermissions!="1"){
			createFolderWnd.allUserCanSubmits=true;
		}else{
			createFolderWnd.allUserCanSubmits=false;
		}
		if(filelist[n].gprivate=="y") createFolderWnd.gprivate=true;
	}

	createFolderWnd.initWnd();
	createFolderWnd.show();

	hideMessage();

	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::renameFolder2(){
debug("renameFolder2()");
	if(SbRename.id==""){
		QMessageBox::critical(this, "Error", "Folder not found");
		hideMessage();
		return ;
	}

	if(isActionCanceled){
		hideMessage();
		return ;
	}
	QString name=createFolderWnd.foldername;
	showMessage("Renaming Folder  "+name, true);
	QString desc=createFolderWnd.folderdesc;

	SrunFunction.restory="";
	SrunFunction.restory.append(SLOT(renameFolder2Resp()));

	if(isActionCanceled){
		hideMessage();
		return ;
	}

//	QString uri="doRenameFolder/"+ base64(SbRename.id) +","+ base64(name) +","+ base64(desc);
	QString postData="function=doRenameFolder";
	postData+="&fi_id="+ QUrl::toPercentEncoding(SbRename.id) +"&fi_name="+ QUrl::toPercentEncoding(name) +"&fi_description="+ QUrl::toPercentEncoding(desc);
	runFunction("", true, postData);

	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::renameFolder2Resp(){
debug("renameFolder2Resp()");
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory="";

	int s0=res.indexOf("<file>");
	int e0=res.lastIndexOf("</file>");
	if(res.indexOf("<response>")<0 || res.indexOf("</response>")<0 || s0<0 || e0<0 || s0>e0){
		QString status=getPartQString(res, "<status>", "</status>");
		QString statusMessage=getPartQString(res, "<statusmessage>", "</statusmessage>");
		if(status!="ok" && statusMessage!=""){
			if(statusMessage.length()<15) statusMessage+="         ";
			QMessageBox::critical(this, "Error", statusMessage);
			hideMessage();
			return ;
		}else{
			QMessageBox::critical(this, "Error", "Can't rename folder.");
			hideMessage();
			return ;
		}
	}

	bool L=false;
	QDomDocument doc("response");
	doc.setContent(res, true);
	QDomElement root=doc.documentElement();
	QDomNode n=root.firstChild();
	Tfile file;
	while(!n.isNull()){
		QDomElement e=n.toElement();
		if(!e.isNull() && e.tagName()=="file"){
			file=getFileFromDomNode(n);
			if(file.name!="")	L=true;
			break;
		}
		n=n.nextSibling();
	}// for

	if(L){
		int k=-1;
		int count=getCountFiles(filelist);				// get first selected file, folder or group
		for(int i=0; i<count; i++){
			if(filelist[i].id==SbRename.id){
				filelist[i].name=file.name;
				filelist[i].description=file.description;
				filelist[i].tags=file.tags;
				k=editNode(i);
				break;
			}
		}
		if(k<0 || filelist[k].id!=SbRename.id) L=false;
	}

	if(L){
		showMessage("Renamed", true);
	}else{
		QMessageBox::critical(this, "Error", "Can't rename folder");
	}
	resume(1);

	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::renameFile2(){
debug("renameFile2()");
	if(SbRename.id==""){
		QMessageBox::critical(this, "Error", "File not found");
		hideMessage();
		return ;
	}

	if(isActionCanceled){
		hideMessage();
		return ;
	}
	QString name=createFolderWnd.foldername;
	showMessage("Renaming File  "+name, true);
	QString desc=createFolderWnd.folderdesc;
	QString tags=createFolderWnd.foldertags;

	SrunFunction.restory="";
	SrunFunction.restory.append(SLOT(renameFile2Resp()));

	if(isActionCanceled){
		hideMessage();
		return ;
	}
//	QString uri="doRenameFile/"+ base64(SbRename.id) +","+ base64(name) +","+ base64(desc) +","+ base64(tags);
	QString postData="function=doRenameFile";
	postData+="&fi_id="+ QUrl::toPercentEncoding(SbRename.id) +"&fi_name="+ QUrl::toPercentEncoding(name) +"&fi_description="+ QUrl::toPercentEncoding(desc) +"&fi_tags="+ QUrl::toPercentEncoding(tags);
	runFunction("", true, postData);

	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::renameFile2Resp(){
debug("renameFile2Resp()");
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory="";

	int s0=res.indexOf("<file>");
	int e0=res.lastIndexOf("</file>");
	if(res.indexOf("<response>")<0 || res.indexOf("</response>")<0 || s0<0 || e0<0 || s0>e0){
		QString status=getPartQString(res, "<status>", "</status>");
		QString statusMessage=getPartQString(res, "<statusmessage>", "</statusmessage>");
		if(status!="ok" && statusMessage!=""){
			if(statusMessage.length()<15) statusMessage+="         ";
			QMessageBox::critical(this, "Error", statusMessage);
			hideMessage();
			return ;
		}else{
			QMessageBox::critical(this, "Error", "Can't rename file.");
			hideMessage();
			return ;
		}
	}

	bool L=false;
	QDomDocument doc("response");
	doc.setContent(res, true);
	QDomElement root=doc.documentElement();
	QDomNode n=root.firstChild();
	Tfile file;
	while(!n.isNull()){
		QDomElement e=n.toElement();
		if(!e.isNull() && e.tagName()=="file"){
			file=getFileFromDomNode(n);
			if(file.name!="")	L=true;
			break;
		}
		n=n.nextSibling();
	}// for

	if(L){
		int k=-1;
		int count=getCountFiles(filelist);				// get first selected file, folder or group
		for(int i=0; i<count; i++){
			if(filelist[i].id==SbRename.id){
debug("file.name="+ file.name +"; file.description="+ file.description +"; file.tags="+ file.tags);
				filelist[i].name=file.name;
				filelist[i].description=file.description;
				filelist[i].tags=file.tags;
				k=editNode(i);
				break;

			}
		}
		if(k<0 || filelist[k].id!=SbRename.id) L=false;
	}

	if(L){
		showMessage("Renamed", true);
	}else{
		QMessageBox::critical(this, "Error", "Can't rename file");
	}

	resume(1);
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::renameGroup2(){
debug("renameGroup2()");
	if(SbRename.id==""){
		QMessageBox::critical(this, "Error", "Group not found");
		hideMessage();
		return ;
	}

	if(isActionCanceled){
		hideMessage();
		return ;
	}
	QString name=createFolderWnd.foldername, desc=createFolderWnd.folderdesc, permissions="0", gprivate="n";
	showMessage("Renaming Group  "+name, true);
	if(!createFolderWnd.allUserCanSubmits) permissions="1";
	if(createFolderWnd.gprivate) gprivate="y";

	SrunFunction.restory="";
	SrunFunction.restory.append(SLOT(renameGroup2Resp()));
	if(isActionCanceled){
		hideMessage();
		return ;
	}

//	QString uri="doRenameGroup/"+ base64(SbRename.id) +","+ base64(name) +","+ base64(desc) +","+ base64(permissions) +","+ base64(gprivate);
	QString postData="function=doRenameGroup";
	postData+="&gr_id="+ QUrl::toPercentEncoding(SbRename.id) +"&gr_title="+ QUrl::toPercentEncoding(name) +"&gr_description="+ QUrl::toPercentEncoding(desc) +"&gr_permissions="+ QUrl::toPercentEncoding(permissions) +"&gr_private="+ QUrl::toPercentEncoding(gprivate);
	runFunction("", true, postData);

	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::renameGroup2Resp(){
debug("renameGroup2Resp()");
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory="";
	if(res.indexOf("<response>")<0 || res.indexOf("</response>")<0){
		QString status=getPartQString(res, "<status>", "</status>"), statusMessage=getPartQString(res, "<statusmessage>", "</statusmessage>");
		if(status!="ok" && statusMessage!=""){
			if(statusMessage.length()<15) statusMessage+="         ";
			QMessageBox::critical(this, "Error", statusMessage);
			hideMessage();
			return ;
		}else{
			QMessageBox::critical(this, "Error", "Can't rename group.");
			hideMessage();
			return ;
		}
	}

	bool L=false;
	QDomDocument doc("response");
	doc.setContent(res, true);
	QDomElement root=doc.documentElement();
	QDomNode n=root.firstChild();
	Tfile file;
	while(!n.isNull()){
		QDomElement e=n.toElement();
		if(!e.isNull() && e.tagName()=="group"){
			file=getGroupFromDomNode(n);
			if(file.name!="")	L=true;
			break;
		}
		n=n.nextSibling();
	}// for

	if(L){
		int k=-1;
		int count=getCountFiles(filelist);				// get first selected group
		for(int i=0; i<count; i++){
			if(filelist[i].id==SbRename.id){
				filelist[i].name=file.name;
				filelist[i].description=file.description;
				filelist[i].gpermissions=file.gpermissions;
				filelist[i].gprivate=file.gprivate;
				k=editNode(i);
				break;
			}
		}
		if(k<0 || filelist[k].id!=SbRename.id) L=false;
	}

	if(L){
		showMessage("Renamed", true);
	}else{
		QMessageBox::critical(this, "Error", "Can't rename group");
	}

	resume(1);
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::createGroup(){
debug("createGroup()");
	if(isActionCanceled){
		hideMessage();
		return ;
	}
	QString name=createFolderWnd.foldername;
	showMessage("Creating Group  "+name, true);
	QString desc=createFolderWnd.folderdesc;
	QString permissions="0", gprivate="n";
	if(!createFolderWnd.allUserCanSubmits) permissions="1";
	if(createFolderWnd.gprivate) gprivate="y";

	SrunFunction.restory="";
	SrunFunction.restory.append(SLOT(createGroupResp()));

	if(isActionCanceled){
		hideMessage();
		return ;
	}
//	QString uri="doCreateGroup/"+ base64(name) +","+ base64(desc) +","+ base64(permissions) +","+ base64(gprivate);
	QString postData="function=doCreateGroup";
	postData+="&gr_title="+ QUrl::toPercentEncoding(name) +"&gr_description="+ (desc) +"&gr_permissions="+ QUrl::toPercentEncoding(permissions) +"&gr_private="+ QUrl::toPercentEncoding(gprivate);
	runFunction("", true, postData);

}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::createGroupResp(){
debug("createGroupResp()");
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory="";
	if(res.indexOf("<response>")<0 || res.indexOf("</response>")<0){
		QMessageBox::critical(this, "Error", "Can't create group.");
		hideMessage();
		return ;
	}

	bool L=false;
	QDomDocument doc("response");
	doc.setContent(res, true);
	QDomElement root=doc.documentElement();
	QDomNode n=root.firstChild();
	while(!n.isNull()){
		QDomElement e=n.toElement();
		if(!e.isNull() && e.tagName()=="group"){
			Tfile file=getGroupFromDomNode(n);
			if(file.name!=""){
				L=true;
				addToFileslist(file, true);
			}
			break;
		}
		n=n.nextSibling();
	}// for


	if(L){
		showMessage("Created", true);
	}else{
		QMessageBox::critical(this, "Error", "Can't create group");
	}

	resume(1);
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bDelete(){
	if(!tryRunning()) return ;
debug("bDelete()");
	// is selected some files or folders ?
	int count=getCountFiles(filelist);
	bool L=false;
	for(int i=0; i<count; i++){
		if(filelist[i].name!="" && filelist[i].node->isSelected()){
			L=true;
			break;
		}
	}

	if(!L){
		QMessageBox::critical(this, "Error", "First select file, folder, user or group");
		hideMessage();
		return ;
	}


	QString mess="";
	if(explorerType==4){
		mess="Do you want to remove from Clipboard?";
	}else if(explorerType==6){
		mess="Do you want to remove from Trash?";
	}else{
		mess="Do you want to delete?";
	}
	if(QMessageBox::question(this, "Confirm", mess,  QMessageBox::Ok, QMessageBox::No)!=QMessageBox::Ok){
		hideMessage();
		return ;
	}

	showMessage("Deleting... ", true);
	deleteFiles();
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::deleteFiles(){
debug("deleteFiles()");
	if(isActionCanceled){
		hideMessage();
		return ;
	}
	SdeleteFiles.id="";
	SdeleteFiles.deleteAllfiles=false;
	int count=getCountFiles(filelist);				// get first selected folders
	int n=-1;
	for(int i=0; i<count; i++){
		if(filelist[i].name!="" && (filelist[i].type==1 || filelist[i].type==3) && filelist[i].node->isSelected()){
			n=i;
			break;
		}
	}

	if(n>-1 && (filelist[n].type==1 || filelist[n].type==3)){
		showMessage("Deleting  "+ filelist[n].name, true);
		SdeleteFiles.id=filelist[n].id;
		SrunFunction.restory="";
		SrunFunction.restory.append(SLOT(deleteFilesResp()));
		QString uri="";
		if(explorerType==6){
			uri+="doDeleteFromTrash/";
		}else{
			if(filelist[n].type==1){				// need delete folder
				uri+="doDeleteFolder/";
			}else if(filelist[n].type==3){		// need delete group
				uri+="doDeleteGroup/";
			}
		}
		uri+=base64(filelist[n].id);

		if(isActionCanceled){
			hideMessage();
			return ;
		}
		runFunction(uri);
		return ;

	}

	SdeleteFiles.id="";
	for(int i=0; i<count; i++){
		if(filelist[i].name!="" && filelist[i].type==0 && filelist[i].node->isSelected()){
			if(SdeleteFiles.id==""){
				SdeleteFiles.id=filelist[i].id;
			}else{
				SdeleteFiles.id+="," +filelist[i].id;
			}
		}
	}

	if(SdeleteFiles.id!=""){      // need delete files
		SdeleteFiles.deleteAllfiles=true;
		showMessage("Deleting selected files", true);
		SrunFunction.restory="";
		SrunFunction.restory.append(SLOT(deleteFilesResp()));
		QString postData="";
		if(explorerType==4){
			postData+="function=removeFilesFromClipboard&fi_id="+ QUrl::toPercentEncoding(SdeleteFiles.id) +"&returnonlyids=y";
		}else if(explorerType==6){
			postData+="function=doDeleteFromTrash&fi_id="+ QUrl::toPercentEncoding(SdeleteFiles.id);
		}else{
			postData+="function=doDeleteFile&fi_id="+ QUrl::toPercentEncoding(SdeleteFiles.id);
		}

		if(isActionCanceled){
			hideMessage();
			return ;
		}

		runFunction("", true, postData);
		return ;
	}

	hideMessage();
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::deleteFilesResp(){
debug("deleteFilesResp()");
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory="";

	QString status;
	status=getPartQString(res, "<status>", "</status>");
	if(status!="ok"){
		QMessageBox::critical(this, "Error", "   Can't delete   ");
		hideMessage();
		return ;
	}

	int count=getCountFiles(filelist);				// get first selected folders
	int r=0;
	if(SdeleteFiles.deleteAllfiles){
		for(int i=0; i<count; i++){
			if(filelist[i].name!="" && filelist[i].node->isSelected()){
				int r0=deleteFileAndNode(-1, filelist[i].id);
				if(r0!=0){
					r=r0;
				}else{
					i--;
				}
			}
		}
	}else{
		r=deleteFileAndNode(-1, SdeleteFiles.id);
	}

	if(r!=0){
		QMessageBox::critical(this, "Error 2", "   Can't delete   ");
		hideMessage();
		return ;
	}

	SdeleteFiles.id="";
	SdeleteFiles.deleteAllfiles=false;
	if(!SdeleteFiles.deleteAllfiles)	deleteFiles();

	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bRestore(){
	if(!tryRunning()) return ;
debug("bRestore()");
	// is selected some files or folders ?
	int count=getCountFiles(filelist);
	bool L=false;
	for(int i=0; i<count; i++){
		if(filelist[i].name!="" && filelist[i].node->isSelected()){
			L=true;
			break;
		}
	}

	if(!L){
		QMessageBox::critical(this, "Error", "First select file or folder");
		hideMessage();
		return ;
	}

	QString mess="Do you want to restore from Trash?";
	if(QMessageBox::question(this, "Confirm", mess,  QMessageBox::Ok, QMessageBox::No)!=QMessageBox::Ok){
		hideMessage();
		return ;
	}

	showMessage("Restoring... ", true);
	if(isActionCanceled){
		hideMessage();
		return ;
	}

	QString id="";
	for(int i=0; i<count; i++){
		if(filelist[i].name!="" && filelist[i].node->isSelected()){
			if(id==""){
				id=filelist[i].id;
			}else{
				id+="," +filelist[i].id;
			}
		}
	}

	if(id!=""){      // need delete files
		showMessage("Restoring selected file (folder)", true);
		SrunFunction.restory="";
		SrunFunction.restory.append(SLOT(restoreFilesResp()));
		QString postData="function=doRestoreFromTrash&fi_id="+ QUrl::toPercentEncoding(id);

		if(isActionCanceled){
			hideMessage();
			return ;
		}

		runFunction("", true, postData);
		return ;
	}

	hideMessage();
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::restoreFilesResp(){
debug("restoreFilesResp()");
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory="";

	QString status;
	status=getPartQString(res, "<status>", "</status>");
	if(status!="ok"){
		QMessageBox::critical(this, "Error", "   Can't restore   ");
		hideMessage();
		return ;
	}

	int count=getCountFiles(filelist);
	int r=0;
	for(int i=0; i<count; i++){				// removing from tree restored files and folders
		if(filelist[i].name!="" && filelist[i].node->isSelected()){
			int r0=deleteFileAndNode(-1, filelist[i].id);
			if(r0!=0){
				r=r0;
			}else{
				i--;
			}
		}
	}

	if(r!=0){
		QMessageBox::critical(this, "Error 2", "   Can't restore   ");
		hideMessage();
		return ;
	}

	hideMessage();
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bFavourite(){
	if(!tryRunning()) return ;
debug("bFavourite()");
	int count=getCountFiles(filelist);				// is selected files ?
	bool L=false, favorite=false;
	for(int i=0; i<count; i++){
		if(filelist[i].name!="" && filelist[i].type==0 && filelist[i].node->isSelected()){
			if(filelist[i].isFavorite) favorite=true;
			L=true;
			break;
		}
	}

	if(!L){
		QMessageBox::critical(this, "Error", "First select file(s)");
		hideMessage();
		return ;
	}

	if(favorite){
		if(QMessageBox::question(this, "Confirm", "Do you want remove from favourites?",  QMessageBox::Ok, QMessageBox::No)!=QMessageBox::Ok){
			hideMessage();
			return ;
		}
	}else{
		if(QMessageBox::question(this, "Confirm", "Do you want add to favourites?",  QMessageBox::Ok, QMessageBox::No)!=QMessageBox::Ok){
			hideMessage();
			return ;
		}
	}

	showMessage("Preparing... ", true);
	doFavourite(!favorite);
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::doFavourite(bool state){
debug("doFavourite()");
	int count=getCountFiles(filelist);
	QString id="";
	QString favorite="0";
	if(state) favorite="1";
	for(int i=0; i<count; i++){
		if(filelist[i].name!="" && filelist[i].type==0 && filelist[i].node->isSelected()){
			if(id==""){
				id=filelist[i].id;
			}else{
				id+="," +filelist[i].id;
			}
		}
	}

	if(isActionCanceled){
		hideMessage();
		return ;
	}

	if(id!=""){
		if(state){
			showMessage("Adding to favourite...", true);
		}else{
			showMessage("Removing from favourite...", true);
		}

		SFavourite.state=state;
		SrunFunction.restory="";
		SrunFunction.restory.append(SLOT(doFavouriteResp()));
		if(isActionCanceled){
			hideMessage();
			return ;
		}

//		QString uri="doFavouriteFile/"+ base64(id);
		QString postData="function=doFavouriteFile";
		postData+="&fi_id="+ QUrl::toPercentEncoding(id) +"&fi_favorite="+ QUrl::toPercentEncoding(favorite);
		runFunction("", true, postData);
		return ;
	}

	hideMessage();
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::doFavouriteResp(){
debug("doFavouriteResp()");
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory="";

	QString status;
	status=getPartQString(res, "<status>", "</status>");
	if(status!="ok"){
		QMessageBox::critical(this, "Error", "   Can't do favourite   ");
		hideMessage();
		return ;
	}

	int count=getCountFiles(filelist);
	for(int i=0; i<count; i++){
		if(filelist[i].name!="" && filelist[i].type==0 && filelist[i].node->isSelected())	filelist[i].isFavorite=SFavourite.state;
	}

	hideMessage();
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::blockSelection(){
	ui->listWidget->setSelectionMode(QAbstractItemView::NoSelection);
	ui->comboBox1->setEnabled(false);
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::unBlockSelection(){
	ui->listWidget->setSelectionMode(QAbstractItemView::ExtendedSelection);
	if(explorerType!=0){
		ui->comboBox1->setEnabled(false);
	}else{
		ui->comboBox1->setEnabled(true);
	}
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bSharing(){
	if(!tryRunning()) return ;
debug("bSharing()");
	int x=ui->pushButton5->x();
	int y=ui->pushButton5->y()+ui->pushButton5->height()-2;

	QPoint pt;
	pt.setX(x);
	pt.setY(y);

	pt=mapToGlobal(pt);
	sharingMenu->exec(pt);
//debug("pt => x => "+ intToQstring(pt.x())+" y => "+intToQstring(pt.y()));

	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bPublic(){

	if(!tryRunning()) return ;
debug("bPublic()");
	int count=getCountFiles(filelist);				// is selected files ?
	bool L=false, fpublic=false;
	for(int i=0; i<count; i++){
		if(filelist[i].name!="" && filelist[i].type==0 && filelist[i].node->isSelected()){
			if(!filelist[i].isPublic) fpublic=true;
			L=true;
			break;
		}
	}

	if(!L){
		QMessageBox::critical(this, "Error", "First select file(s)");
		hideMessage();
		return ;
	}

	if(!fpublic){
		if(QMessageBox::question(this, "Confirm", "Do you want remove from Public?",  QMessageBox::Ok, QMessageBox::No)!=QMessageBox::Ok){
			hideMessage();
			return ;
		}
	}else{
		if(QMessageBox::question(this, "Confirm", "Do you want add to Public?",  QMessageBox::Ok, QMessageBox::No)!=QMessageBox::Ok){
			hideMessage();
			return ;
		}
	}

	showMessage("Preparing... ", true);
	doPublic(fpublic);
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::doPublic(bool state){
debug("doPublic()");
	int count=getCountFiles(filelist);
	QString id="";
	QString fpublic="0";
	if(state) fpublic="1";
	for(int i=0; i<count; i++){
		if(filelist[i].name!="" && filelist[i].type==0 && filelist[i].node->isSelected()){
			if(id==""){
				id=filelist[i].id;
			}else{
				id+="," +filelist[i].id;
			}
		}
	}

	if(isActionCanceled){
		hideMessage();
		return ;
	}

	if(id!=""){
		if(state){
			showMessage("Adding to Public...", true);
		}else{
			showMessage("Removing from Public...", true);
		}

		SPublic.state=state;
		SrunFunction.restory="";
		SrunFunction.restory.append(SLOT(doPublicResp()));
		if(isActionCanceled){
			hideMessage();
			return ;
		}
//		QString uri="doPublicFile/"+ base64(id);
		QString postData="function=doPublicFile";
		postData+="&fi_id="+ QUrl::toPercentEncoding(id) +"&fi_public="+ QUrl::toPercentEncoding(fpublic);
		runFunction("", true, postData);
		return ;
	}

	hideMessage();
	return ;

}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::doPublicResp(){
debug("doPublicResp()");
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory="";

	QString status;
	status=getPartQString(res, "<status>", "</status>");
	if(status!="ok"){
		QMessageBox::critical(this, "Error", "    Error    ");
		hideMessage();
		return ;
	}

	int count=getCountFiles(filelist);
	for(int i=0; i<count; i++){
		if(filelist[i].name!="" && filelist[i].type==0 && filelist[i].node->isSelected())	filelist[i].isPublic=SPublic.state;
	}

	hideMessage();
	return ;
}

//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bLock(){
	if(!tryRunning()) return ;
debug("bLock()");
	int count=getCountFiles(filelist);				// is selected files ?
	bool L=false;
	for(int i=0; i<count; i++){
		if(filelist[i].name!="" && filelist[i].type==0 && filelist[i].node->isSelected()){
			L=true;
			break;
		}
	}

	if(!L){
		QMessageBox::critical(this, "Error", "First select file(s)");
		hideMessage();
		return ;
	}

	if(QMessageBox::question(this, "Confirm", "Do you want Lock selected File(s)?",  QMessageBox::Ok, QMessageBox::No)!=QMessageBox::Ok){
		hideMessage();
		return ;
	}

	showMessage("Preparing... ", true);
	doLock(true);
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bUnlock(){
	if(!tryRunning()) return ;
debug("bUnlock()");
	int count=getCountFiles(filelist);				// is selected files ?
	bool L=false;
	for(int i=0; i<count; i++){
		if(filelist[i].name!="" && filelist[i].type==0 && filelist[i].node->isSelected()){
			L=true;
			break;
		}
	}

	if(!L){
		QMessageBox::critical(this, "Error", "First select file(s)");
		hideMessage();
		return ;
	}

	if(QMessageBox::question(this, "Confirm", "Do you want Unlock selected File(s)?",  QMessageBox::Ok, QMessageBox::No)!=QMessageBox::Ok){
		hideMessage();
		return ;
	}

	showMessage("Preparing... ", true);
	doLock(false);
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::doLock(bool state){
debug("doLock()");
	int count=getCountFiles(filelist);
	QString id="", flock="0";
	if(state) flock="1";
	for(int i=0; i<count; i++){
		if(filelist[i].name!="" && filelist[i].type==0 && filelist[i].node->isSelected()){
debug("if("+userId+"!="+filelist[i].uid+" && "+boolToQstring(!isOrganizationAdmin)+"){");
//			if(userId!=filelist[i].uid && !isOrganizationAdmin){
			if((filelist[i].lockedby!="" && userId!=filelist[i].lockedby) && !isOrganizationAdmin){
				QMessageBox::critical(this, "Error", "No access to lock/unlock file "+filelist[i].name);
				hideMessage();
				return ;
			}
			if(id==""){
				id=filelist[i].id;
			}else{
				id+="," +filelist[i].id;
			}
		}
	}

	if(isActionCanceled){
		hideMessage();
		return ;
	}

	if(id==""){
		hideMessage();
		return ;
	}

	if(state){
		showMessage("Locking...", true);
	}else{
		showMessage("Unlocking...", true);
	}

	SLock.state=state;
	SrunFunction.restory="";
	SrunFunction.restory.append(SLOT(doLockResp()));
	if(isActionCanceled){
		hideMessage();
		return ;
	}

	QString postData="function=";
	if(state){
		postData+="lockFile";
	}else{
		postData+="unlockFile";
	}
	postData+="&fi_id="+ QUrl::toPercentEncoding(id);
	runFunction("", true, postData);
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::doLockResp(){
debug("doLockResp()");
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory="";

	QString status;
	status=getPartQString(res, "<status>", "</status>");
	if(status!="ok"){
		QString statusMessage=getPartQString(res, "<statusmessage>", "</statusmessage>");
		if(statusMessage!=""){
			if(statusMessage.length()<15) statusMessage+="         ";
			QMessageBox::critical(this, "Error", statusMessage);
		}else{
			QMessageBox::critical(this, "Error", "Can't to lock/unlock this file");
		}
		hideMessage();
		return ;
	}

	int count=getCountFiles(filelist);
	for(int i=0; i<count; i++){
		if(filelist[i].name!="" && filelist[i].type==0 && filelist[i].node->isSelected()){
			if(SLock.state){
				filelist[i].lockedby=userId;
			}else{
				filelist[i].lockedby="";
			}
		}
	}

	hideMessage();
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::updateMenus(){
//debug("updateMenus()");
	int cfiles=0, cfolders=0, cusers=0, cgroups=0, clfiles=0;	// clfiles - count locked files
	int count=getCountFiles(filelist);
	for(int i=0; i<count; i++){
		if(filelist[i].node && filelist[i].node->isSelected()){
			if(filelist[i].type==0){
				cfiles++;
			}else if(filelist[i].type==1){
				cfolders++;
			}else if(filelist[i].type==2){
				cusers++;
			}else if(filelist[i].type==3){
				cgroups++;
			}
			if(filelist[i].lockedby!="") clfiles++;
		}
	}
//debug("cfiles=" +intToQstring(cfiles)+ " cfolders=" +intToQstring(cfolders)+ " cusers=" +intToQstring(cusers)+ " cgroups=" +intToQstring(cgroups));

	bool eDownload=true, eUpload=true, eFavourite=true, eCreate=true, eCopy=true, ePaste=true, eRename=true, eDelete=true, eImpExp=true, ePublic=true, eLock=true, eUnlock=true, eShareWithGroupUser=true, eSendToEmail=true, eSendToTwitter=true, eGetFileUrl=true, eAutoShareWithGroupUser=true, eAutoSharingRules=true, eRequestShare=true, eProperties=true, eRestore=true;
	if(cfiles>0 && cfolders==0 && cusers==0 && cgroups==0){
		if(cfiles>1){
//			eDownload=false;
			eRename=false;
			eGetFileUrl=false;
			eSendToTwitter=false;
			eProperties=false;
			eRestore=false;
		}
	}else	if(cfiles==0 && cfolders>0 && cusers==0 && cgroups==0){
		if(cfiles>1){
			eRename=false;
			eProperties=false;
		}
		if(cfolders>1){
			eRestore=false;
		}
		eCopy=false;
		eDownload=false;
		eFavourite=false;
		ePublic=false;
		eLock=false;
		eUnlock=false;
		eSendToEmail=false;
		eSendToTwitter=false;
		eGetFileUrl=false;
	}else	if(cfiles>0 && cfolders>0 && cusers==0 && cgroups==0){
		eRename=false;
		eDownload=false;
		eFavourite=false;
		eCopy=false;
		ePublic=false;
		eLock=false;
		eUnlock=false;
		eSendToEmail=false;
		eSendToTwitter=false;
		eGetFileUrl=false;
		eProperties=false;
		eRestore=false;
	}else	if(cfiles==0 && cfolders==0 && cusers>0 && cgroups==0){
		if(cgroups>1){
			eProperties=false;
		}

		eDownload=false;
		eUpload=false;
		eFavourite=false;
		eCreate=false;
		eCopy=false;
		eRename=false;
		eDelete=false;
		eImpExp=false;
		ePublic=false;
		eLock=false;
		eUnlock=false;
		eShareWithGroupUser=false;
		eSendToEmail=false;
		eSendToTwitter=false;
		eGetFileUrl=false;
		eRestore=false;
	}else	if(cfiles==0 && cfolders==0 && cusers==0 && cgroups>0){
		eDownload=false;
		eUpload=false;
		eFavourite=false;
		eCopy=false;
		eImpExp=false;
		ePublic=false;
		eLock=false;
		eUnlock=false;
		eShareWithGroupUser=false;
		eSendToEmail=false;
		eSendToTwitter=false;
		eGetFileUrl=false;
		eRestore=false;
	}else	if(cfiles==0 && cfolders==0 && cusers==0 && cgroups==0){
		eDownload=false;
		eFavourite=false;
		eCopy=false;
		eRename=false;
		eDelete=false;
		eImpExp=false;
		ePublic=false;
		eLock=false;
		eUnlock=false;
		eShareWithGroupUser=false;
		eSendToEmail=false;
		eSendToTwitter=false;
		eGetFileUrl=false;
		eRestore=false;
	}else{		// Disable all
		eDownload=false;
		eUpload=false;
		eFavourite=false;
		eCreate=false;
		eCopy=false;
		eRename=false;
		eDelete=false;
		eImpExp=false;
		ePublic=false;
		eLock=false;
		eUnlock=false;
		eShareWithGroupUser=false;
		eSendToEmail=false;
		eSendToTwitter=false;
		eGetFileUrl=false;
		eAutoShareWithGroupUser=false;
		eAutoSharingRules=false;
		eRequestShare=false;
		eRestore=false;
	}

//debug("x1 +++++++++> "+intToQstring(explorerType));
	if(explorerType==0){					// Cloud
	}else if(explorerType==1){			// Public
		eCreate=false;

		eUpload=false;
		ePaste=false;
		eImpExp=false;
	}else if(explorerType==2){			// Favourite
		eCreate=false;
		eUpload=false;
		ePaste=false;
		eImpExp=false;
	}else if(explorerType==3){			// Search
		if(Ssearch.inPublic){
			eUpload=false;
			eFavourite=false;
			eCreate=false;
			eCopy=false;
			eRename=false;
			eDelete=false;
			eImpExp=false;
			ePublic=false;
			eLock=false;
			eUnlock=false;
			eShareWithGroupUser=false;
			eSendToEmail=false;
			eSendToTwitter=false;
			eGetFileUrl=false;
			eAutoShareWithGroupUser=false;
			eAutoSharingRules=false;
			eRequestShare=false;
		}
		eCreate=false;
		eUpload=false;
		ePaste=false;
		eImpExp=false;
	}else if(explorerType==4){			// Clipboard
		eCreate=false;
		eUpload=false;
		eCopy=false;
		ePaste=false;
		eImpExp=false;
	}else if(explorerType==5){			// Groups
		if(currentFolder.id!="0") eCreate=false;
		eUpload=false;
		ePaste=false;
		eImpExp=false;
	}else if(explorerType==6){			// Trash
		if(((cfiles==0 && cfolders==1) || (cfiles==1 && cfolders==0)) && cusers==0 && cgroups==0){
			eDelete=true;
		}else{
			eDelete=false;
		}
		eUpload=false;
		eFavourite=false;
		eCreate=false;
		eCopy=false;
		eRename=false;
		eImpExp=false;
		ePublic=false;
		eLock=false;
		eUnlock=false;
		eShareWithGroupUser=false;
		eSendToEmail=false;
		eSendToTwitter=false;
		eGetFileUrl=false;
		eAutoShareWithGroupUser=false;
		eAutoSharingRules=false;
		eRequestShare=false;
		ePaste=false;
	}

	amfCloudExp->setEnabled(true);
	amfPublicExp->setEnabled(true);
	amfFavouriteExp->setEnabled(true);
	amfSearchExp->setEnabled(true);
	amfClipboardExp->setEnabled(true);
	amfGroupsExp->setEnabled(true);
	amfTrashExp->setEnabled(true);
	if(explorerType==0) amfCloudExp->setEnabled(false);
	if(explorerType==1) amfPublicExp->setEnabled(false);
	if(explorerType==2) amfFavouriteExp->setEnabled(false);
	if(explorerType==3) amfSearchExp->setEnabled(false);
	if(explorerType==4) amfClipboardExp->setEnabled(false);
	if(explorerType==5) amfGroupsExp->setEnabled(false);
	if(explorerType==6) amfTrashExp->setEnabled(false);

	if(explorerType==6){
		if(currentFolder.id!="0"){
			eRestore=false;
			eDelete=false;
		}
		aRestore->setVisible(true);
	}else{
		aRestore->setVisible(false);
	}

	if(clfiles==0) eUnlock=false;		 // All is unlocked
	if(cfiles==clfiles) eLock=false;	 // All is locked

						// Buttons
	ui->pushButton3->setEnabled(eDownload);		// Download
	ui->pushButton4->setEnabled(eUpload);			// Upload
	ui->pushButton6->setEnabled(eImpExp);			// Import/Export
	ui->pushButton7->setEnabled(eFavourite);		// Add/Remove File(s) to/from Favourites
	ui->pushButton8->setEnabled(eCreate);			// New Folder/Group
	ui->pushButton10->setEnabled(eCopy);			// Copy
	ui->pushButton11->setEnabled(ePaste);			// Paste
	ui->pushButton13->setEnabled(eRename);			// Rename Folder/File/Group/Share
	ui->pushButton14->setEnabled(eDelete);			// Delete

						// Context menu
	aDownload->setEnabled(eDownload);
	aRename->setEnabled(eRename);
	aDelete->setEnabled(eDelete);
	aRestore->setEnabled(eRestore);
	aPublic->setEnabled(ePublic);
	aLock->setEnabled(eLock);
	aUnlock->setEnabled(eUnlock);
	aShare->setEnabled(eShareWithGroupUser);
	aEmail->setEnabled(eSendToEmail);
	aTwitter->setEnabled(eSendToTwitter);
	aFileUrl->setEnabled(eGetFileUrl);
	aProperties->setEnabled(eProperties);

						// Sharing menu
	asPublic->setEnabled(ePublic);
	asShareWithGroupUser->setEnabled(eShareWithGroupUser);
	asSendToEmail->setEnabled(eSendToEmail);
	asSendToTwitter->setEnabled(eSendToTwitter);
	asGetFileUrl->setEnabled(eGetFileUrl);
	asAutoShareWithGroupUser->setEnabled(eAutoShareWithGroupUser);
	asAutoSharingRules->setEnabled(eAutoSharingRules);
	asRequestShare->setEnabled(eRequestShare);


						// Share menu
	amsPublic->setEnabled(ePublic);
	amsShareWithGroupUser->setEnabled(eShareWithGroupUser);
	amsSendToEmail->setEnabled(eSendToEmail);
	amsSendToTwitter->setEnabled(eSendToTwitter);
	amsGetFileUrl->setEnabled(eGetFileUrl);
	amsAutoShareWithGroupUser->setEnabled(eAutoShareWithGroupUser);
	amsAutoSharingRules->setEnabled(eAutoSharingRules);
	amsRequestShare->setEnabled(eRequestShare);


	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bProperties(){
	if(!tryRunning()) return ;
debug("bProperties()");
	int count=getCountFiles(filelist);				// get first selected file, folder or group
	int n=-1;
	for(int i=0; i<count; i++){
		if(filelist[i].name!="" && filelist[i].node->isSelected()){
			n=i;
			break;
		}
	}

	if(n==-1)	return ;
//debug("name="+ filelist[n].name);
///*
	filePropertiesWnd.setWindowModality(Qt::ApplicationModal);
	filePropertiesWnd.clear();

	filePropertiesWnd.sx=(int) (x()+ww/2-215);
	filePropertiesWnd.sy=(int) (y()+wh/2-200);

	filePropertiesWnd.name=filelist[n].name;
	filePropertiesWnd.description=filelist[n].description;

	filePropertiesWnd.tags=filelist[n].tags;
	filePropertiesWnd.id=filelist[n].id;
	filePropertiesWnd.pid=filelist[n].pid;

	filePropertiesWnd.created=filelist[n].created;
	filePropertiesWnd.lastmodify=filelist[n].lastmodify;
	filePropertiesWnd.lastaccess=filelist[n].lastaccess;

	filePropertiesWnd.size=filelist[n].size;
	filePropertiesWnd.type=filelist[n].type;
	filePropertiesWnd.encrypted=filelist[n].encrypted;
	filePropertiesWnd.uid=filelist[n].uid;
	filePropertiesWnd.extension=filelist[n].extension;
	filePropertiesWnd.uid=filelist[n].uid;
	filePropertiesWnd.extension=filelist[n].extension;
	filePropertiesWnd.isPublic=filelist[n].isPublic;
	filePropertiesWnd.isFavorite=filelist[n].isFavorite;
	filePropertiesWnd.provider=filelist[n].provider;
	filePropertiesWnd.orgid=filelist[n].orgid;
	filePropertiesWnd.orgfolderid=filelist[n].orgfolderid;
	filePropertiesWnd.isLocked=(filelist[n].lockedby=="") ? (false) : (true);

	filePropertiesWnd.initWnd();
	filePropertiesWnd.show();
//*/
	hideMessage();

	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bShareWithGroupUser(){
	if(!tryRunning()) return ;
debug("bShareWithGroupUser()");
	showMessage("Loading Groups List", true);

	// is selected some files or folders ?
	int count=getCountFiles(filelist);
	bool L=false;
	for(int i=0; i<count; i++){
		if(filelist[i].name!="" && filelist[i].node->isSelected()){
			L=true;
			break;
		}
	}

	if(!L){
		QMessageBox::critical(this, "Error", "First select file or folder");
		hideMessage();
		return ;
	}

	SrunFunction.restory="";
	SrunFunction.restory.append(SLOT(bShareWithGroupUserResp()));
	QString uri="getGroupsList/";
	if(isActionCanceled){
		hideMessage();
		return ;
	}
	runFunction(uri);
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bShareWithGroupUserResp(){
//	if(!tryRunning()) return ;
debug("bShareWithGroupUserResp()");
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory="";

	if(res.indexOf("<response>")<0 || res.indexOf("</response>")<0){
		QMessageBox::critical(this, "Error", "Can't get groups list.");
		hideMessage();
		return ;
	}

	QDomDocument doc("response");
	doc.setContent(res, true);

//debug("\n\nserver folder => "+ list);
	bool L=false;
	QDomElement root=doc.documentElement();
	QDomNode n=root.firstChild();
	while(!n.isNull()){
		QDomElement e = n.toElement();
		if(!e.isNull()){
			if(e.tagName()=="grouplist"){
				n=n.firstChild();
				L=true;
				break;
			}
		}
		n=n.nextSibling();
	}
//return ;

	if(L){
		shareWithGroupUserWnd.setWindowModality(Qt::ApplicationModal);
		shareWithGroupUserWnd.clear();
		shareWithGroupUserWnd.sx=(int) (x()+ww/2-215);
		shareWithGroupUserWnd.sy=(int) (y()+wh/2-200);

		int count=getCountFiles(filelist);
		int num=-1;
		for(int i=0; i<count; i++){
			if(filelist[i].name!="" && filelist[i].node->isSelected()){
				num=i;
				break;
			}
		}


		if(num==-1){
			QMessageBox::critical(this, "Error", "First select file or folder");
			hideMessage();
			return ;
		}

		shareWithGroupUserWnd.id=filelist[num].id;
		shareWithGroupUserWnd.name=filelist[num].name;
		shareWithGroupUserWnd.type=filelist[num].type;

		bool L0=false;
		QDomNode usersList;
		for(int i=0; !n.isNull(); i++){
			QDomElement e=n.toElement();
			if(!e.isNull() && e.tagName()=="n"+intToQstring(i)){
				QString fid="", name="", type="";
				QDomNode nf=n.firstChild();

				do{
					QDomElement el=nf.toElement();
					if(el.tagName()=="gr_id")		fid=el.text();
					if(el.tagName()=="gr_title")	name=el.text();
					if(el.tagName()=="gr_users"){
						usersList=nf;
						L0=true;
					}
					type="3";

					nf=nf.nextSibling();
				}while(!nf.isNull());

//debug("id="+ fid+" pid="+ pid+" name="+ name+" type="+ type+" size="+ size+" encrypted="+ encrypted);
				if(type!="2" && type!="3") type="";
				if(fid.length()>0 && name.length()>0 && type.length()>0){
					Tfile file;
					file.id=fid;
					file.type=type.toInt();					// 0 - file, 1 - folder, 2 - user, 3 - group
					file.name=name;
//					file.isProcessed=false;

debug("GROUP  => "+name);
shareWithGroupUserWnd.addToTree(fid, name, type.toInt());

					QString pid=fid;
					usersList=usersList.firstChild();
					for(int j=0; !usersList.isNull() && L0; j++){
						QDomElement e=usersList.toElement();
						if(!e.isNull() && e.tagName()=="n"+intToQstring(j)){
							QString fid="", name="", type="";
							QDomNode nf=usersList.firstChild();
							do{
								QDomElement el=nf.toElement();
								if(el.tagName()=="us_id")		fid=el.text();
								if(el.tagName()=="us_name")	name=el.text();
								type="2";

								nf=nf.nextSibling();
							}while(!nf.isNull());

							if(fid.length()>0 && name.length()>0 && type.length()>0){
								Tfile file;
								file.id=fid;
								file.pid=pid;
								file.type=type.toInt();					// 0 - file, 1 - folder, 2 - user, 3 - group
								file.name=name;
debug("USER  =>      "+name);
//								file.isProcessed=false;
								shareWithGroupUserWnd.addToTree(fid, name, type.toInt(), file.pid);
							}

							usersList=usersList.nextSibling();
						}
					}// for

				}
				n=n.nextSibling();
			}
		}// for

		shareWithGroupUserWnd.initWnd();
		shareWithGroupUserWnd.show();
		hideMessage();
	}// if


	hideMessage();
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bshareWithGroupOrUser(){
	if(!tryRunning()) return ;
debug("bshareWithGroupOrUser()");
	showMessage("Preparing...", true);

	QString grid="", usid="", fi_id="", gr_expired="", gr_comment="";
	fi_id=shareWithGroupUserWnd.id;
	if(fi_id==""){
		QMessageBox::critical(this, "Error", "File/Folder not found");
		shareWithGroupUserWnd.clear2();
		hideMessage();
		return ;
	}

	bool L=false;
	for(int i=0; i<shareWithGroupUserWnd.countGU; i++){
		if(shareWithGroupUserWnd.grouplist[i].node->isSelected()){
			if(shareWithGroupUserWnd.grouplist[i].type==2){		// user
				grid=shareWithGroupUserWnd.grouplist[i].pid;
				usid=shareWithGroupUserWnd.grouplist[i].id;
			}else{
				grid=shareWithGroupUserWnd.grouplist[i].id;
			}
			L=true;
			break;
		}
	}

	if(!L){
		QMessageBox::critical(this, "Error", "Select group or user");
		shareWithGroupUserWnd.clear2();
		hideMessage();
		return ;
	}

	if(shareWithGroupUserWnd.expiredEnable)	gr_expired=intToQstring(shareWithGroupUserWnd.countDays);
	gr_comment=shareWithGroupUserWnd.comment;

	shareWithGroupUserWnd.hide();
	shareWithGroupUserWnd.clear2();

	SrunFunction.restory="";
	SrunFunction.restory.append(SLOT(bshareWithGroupOrUserResp()));
	QString postData="";

	if(shareWithGroupUserWnd.type==0){
		postData="function=doShareFileWithGroup";
	}else{
		postData="function=doShareFolderWithGroup";
	}

	postData+="&gr_id="+ QUrl::toPercentEncoding(grid) +"&fi_id="+ QUrl::toPercentEncoding(fi_id) +"&gr_expired="+ QUrl::toPercentEncoding(gr_expired) +"&gr_comment="+ QUrl::toPercentEncoding(gr_comment) +"&us_id="+ QUrl::toPercentEncoding(usid);
	if(shareWithGroupUserWnd.type==1){
		QString sharewithsubfolders="n";
		if(shareWithGroupUserWnd.sharewithsubfolders)	sharewithsubfolders="y";
		postData+="&sharewithsubfolders="+ QUrl::toPercentEncoding(sharewithsubfolders);
	}

	showMessage("Sharing...", true);

	if(isActionCanceled){
		hideMessage();
		return ;
	}
	runFunction("", true, postData);

}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bshareWithGroupOrUserResp(){
debug("bshareWithGroupOrUserResp()");
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory="";

	QString status = getPartQString(res, "<status>", "</status>");
	QString statusmessage = getPartQString(res, "<statusmessage>", "</statusmessage>");
	QString gr_sharedid = getPartQString(res, "<gr_sharedid>", "</gr_sharedid>");
debug("status="+status);
debug("statusmessage="+statusmessage);
debug("gr_sharedid="+gr_sharedid);
	if(status!="ok"){		// || gr_sharedid!=""
		QMessageBox::critical(this, "Error", "Cannot share: "+statusmessage);
		hideMessage();
		return ;
	}


	hideMessage();
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bCopy(){
	if(!tryRunning()) return ;
debug("bCopy()");
	if(QMessageBox::question(this, "Confirm", "Do you want to add to clipboard selected Folder/File(s)?",  QMessageBox::Ok, QMessageBox::No)!=QMessageBox::Ok){
		hideMessage();
		return ;
	}

	QString id="";
	int count=getCountFiles(filelist), type=-1;
	for(int i=0; i<count; i++){
		if(filelist[i].name!="" && filelist[i].node->isSelected()){
			if(type!=-1 && type!=filelist[i].type){
				id="";
				break;
			}
			if(id!="") id+=",";
			id+=filelist[i].id;
			type=filelist[i].type;
		}
	}

	if(id==""){
		QMessageBox::critical(this, "Error", "First select File(s) or Folder");
		hideMessage();
		return ;
	}

	if(isActionCanceled){
		hideMessage();
		return ;
	}

	showMessage("Adding to clipboard", true);
	SrunFunction.restory="";
	SrunFunction.restory.append(SLOT(bCopyResp()));

	QString uri="";
	QString postData="";
	if(type==0){
		postData="function=addFilesToClipboard&fi_id="+ QUrl::toPercentEncoding(id) +"&returnonlyids=y";
	}else{
		postData="function=addFolderToClipboard&fi_id="+ QUrl::toPercentEncoding(id) +"&includesubfolders=y&returnonlyids=y";
	}

	if(isActionCanceled){
		hideMessage();
		return ;
	}
	runFunction("", true, postData);
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bCopyResp(){
debug("bCopyResp()");
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory="";
	if(res.indexOf("<response>")<0 || res.indexOf("</response>")<0){
		QMessageBox::critical(this, "Error", "Can't add to clipboard.");
		hideMessage();
		return ;
	}

	bool L=false;
	QString status="", statusmessage="";
	QDomDocument doc("response");
	doc.setContent(res, true);
	QDomElement root=doc.documentElement();
	QDomNode n=root.firstChild();
	while(!n.isNull()){
		QDomElement e=n.toElement();
		if(!e.isNull() && e.tagName()=="status")	status=e.text();
		if(!e.isNull() && e.tagName()=="statusmessage")	statusmessage=e.text();
		if(!e.isNull() && e.tagName()=="files"){
			QDomNode nn=n.firstChild();
			while(!nn.isNull()){
				e=nn.toElement();
//debug("name="+ e.tagName());
				if(!e.isNull() && e.tagName()=="n0"){
					L=true;
					break;
				}
				nn=nn.nextSibling();
			}
			break;
		}
		n=n.nextSibling();
	}// for

	if(status!="ok") L=false;
	if(!L){
		QMessageBox::critical(this, "Error", "Can't add to clipboard. "+statusmessage);
	}

	resume(1);
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bPaste(){
	if(!tryRunning()) return ;
debug("bPaste()");
	if(QMessageBox::question(this, "Confirm", "Do you want to Paste from clipboard?",  QMessageBox::Ok, QMessageBox::No)!=QMessageBox::Ok){
		hideMessage();
		return ;
	}

	SrunFunction.restory="";
	SrunFunction.restory.append(SLOT(bPasteResp()));

	QString uri="getClipboardFiles/"+ base64("n");
	showMessage("Retrieving Clipboard Files", true);
	runFunction(uri);
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bPasteResp(){
debug("bPasteResp()");
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory="";

	if(res.indexOf("<response>")<0 || res.indexOf("</response>")<0){
		QMessageBox::critical(this, "Error", "Can't get Files from Clipboard.");
		hideMessage();
		return ;
	}

	int k=0;
	for(int i=0; i<maxCountClipboard; i++){		// remove old elements
		clipboardfilelist[i].id="";
		clipboardfilelist[i].name="";
	}

	QDomDocument doc("response");
	doc.setContent(res, true);

	QString id="";
	bool L=false;
	QDomElement root=doc.documentElement();
	QDomNode n=root.firstChild();
	while(!n.isNull()){
		QDomElement e = n.toElement();
		if(!e.isNull()){
			if(e.tagName()=="files"){
				n=n.firstChild();
				L=true;
				break;
			}
		}
		n=n.nextSibling();
	}

	if(!L){
		QMessageBox::critical(this, "Error", "Can't get Files from Clipboard.");
		hideMessage();
		return ;
	}else{
		for(int i=0; !n.isNull() && k<maxCountClipboard; i++){
			QDomElement e=n.toElement();
			if(!e.isNull() && e.tagName()=="n"+intToQstring(i)){
				Tfile file=getFileFromDomNode(n);
				clipboardfilelist[k]=file;
				n=n.nextSibling();
				k++;
			}
		}// for
	}// if

	if(k==0){
		QMessageBox::critical(this, "Info", "Clipboard is empty.");
		hideMessage();
		return ;
	}

	if(isActionCanceled) hideMessage();
	SPasteFromClipboard.n=0;
	bPasteFromClipboard();

	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bPasteFromClipboard(){
debug("bPasteFromClipboard()");
	SrunFunction.restory="";
	if(isActionCanceled){
		hideMessage();
		return ;
	}
	if(SPasteFromClipboard.n<0 || SPasteFromClipboard.n>=maxCountClipboard || clipboardfilelist[SPasteFromClipboard.n].name==""){
		hideMessage();
		return ;
	}
	SrunFunction.restory.append(SLOT(bPasteFromClipboardResp()));


	QString uri="doCopyFile/"+ base64(clipboardfilelist[SPasteFromClipboard.n].id) +","+ base64(currentFolder.id);
	showMessage("Copying Files...", true);
	runFunction(uri);

}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bPasteFromClipboardResp(){
debug("bPasteFromClipboardResp()");
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory="";

	if(res.indexOf("<response>")<0 || res.indexOf("</response>")<0){
		QMessageBox::critical(this, "Error", "Can't copy file.");
		hideMessage();
		return ;
	}


	QDomDocument doc("response");
	doc.setContent(res, true);

	QString id="";
	bool L=false;
	QDomElement root=doc.documentElement();
	QDomNode n=root.firstChild();
	while(!n.isNull()){
		QDomElement e = n.toElement();
		if(!e.isNull()){
			if(e.tagName()=="file"){
				L=true;
				break;
			}
		}
		n=n.nextSibling();
	}

	if(!L){
		QMessageBox::critical(this, "Error", "Can't paste file.");
		hideMessage();
		return ;
	}else{
		Tfile file=getFileFromDomNode(n);
		addToFileslist(file, true);
	}// if

	if(isActionCanceled){
		hideMessage();
		return ;
	}
	SPasteFromClipboard.n++;
	bPasteFromClipboard();

	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::downloadFile(){
	SbDownload.needOpen=false;
	bDownload();
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::openFile(int itemNumForOpen){
	SbDownload.needOpen=true;
	SbDownload.itemNumForOpen=itemNumForOpen;
	bDownload();
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bDownload(){
	if(!tryRunning()) return ;
debug("bDownload()");

	showMessage("Preparing... ", true);
	QString dir="";
	SbDownload.multidownload=false;
	SbDownload.filelist.clear();
	if(SbDownload.needOpen){
		SbDownload.filelist << filelist[SbDownload.itemNumForOpen];
		dir="";
	}else{
		int countFilesForDownload=0, count=getCountFiles(filelist);
		for(int i=0; i<count; i++){
			if(filelist[i].node->isSelected()){
				countFilesForDownload++;
				SbDownload.filelist << filelist[i];
				debug("add to list "+filelist[i].name);
			}
		}

		if(countFilesForDownload==1){
			dir=QFileDialog::getSaveFileName(this, tr("Download File"), lastDir +"/"+ SbDownload.filelist[0].name, tr(""));
		}else{
			SbDownload.multidownload=true;
			dir=QFileDialog::getExistingDirectory(this, tr("Download Files"),  lastDir);
		}

		if(dir==""){
			hideMessage();
			return ;
		}

		debug("dir="+dir);
		SbDownload.folder=dir;
	}

	SbDownload.status=0;
	SbDownload.size=0;
	SbDownload.filepath=dir;

	if(SbDownload.filelist.size()<1){
		hideMessage();
		return;
	}

	bDownload0();
	return;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bDownload0(){
debug("bDownload0()");
	SrunFunction.up_level_command="";
	SbDownload.wasEncrPhraseEntered = false;

	for(int k=0, size=SbDownload.filelist.size(); k<size; k++){
		if(SbDownload.filelist.at(k).name.length()>0){
			//SrunFunction.up_level_command.append(SLOT(bDownload0()));
			for(int m=0; m<maxCount && filelist[m].name!=""; m++){
				if(filelist[m].id==SbDownload.filelist.at(k).id){
					SbDownload.n=m;
					break;
				}
			}

			SbDownload.lastModify=QDateTime::fromString(SbDownload.filelist.at(k).lastmodify, Qt::ISODate);
			int error = bDownload1();
			if(error!=0) break;
		}
	}


	SbDownload.status=0;
	SbDownload.size=0;
	SbDownload.filepath="";

	hideMessage();
	return ;
}
//////////////////////////////////////////////////////////////////////
int SMEStorageExplorer::bDownload1(){
	debug("bDownload1()");
	showMessage("Preparing... ", true);
	int n = SbDownload.n;
	QString fileName="";
	if(SbDownload.needOpen){
		QString fol="/tmp/StorageMadeEasy/";
		QDir dir(fol);
		if(!dir.exists()){		// create temp folder
			dir.mkpath(fol);

			QFile f1(fol);
			f1.setPermissions(QFile::ReadOwner | QFile::WriteOwner | QFile::ReadUser | QFile::WriteUser | QFile::ReadGroup | QFile::WriteGroup | QFile::ReadOther |QFile::WriteOther | QFile::ExeOwner | QFile::ExeUser | QFile::ExeGroup | QFile::ExeOther); // set up permissions 777
			f1.close();
			debug("Created  "+ fol);
		}
		
		// Removing old files from temp fodler
		QDateTime pdate=QDateTime::currentDateTime();
		pdate=pdate.addDays(-2);

		QString tfol=fol+"tmp0";
		for(int i=1; QFile::exists(tfol); i++){
			tfol=fol+"tmp"+intToQstring(i);
		}
		dir.mkpath(tfol);
		fileName=tfol+"/"+filelist[n].name;
		debug("TMP file => "+ fileName);
	}else{
		if(SbDownload.multidownload){
			fileName=SbDownload.folder +"/"+ filelist[n].name;
		}else{
			fileName=SbDownload.folder;
		}

		fileName.replace("//", "/");
		if(fileName.length()<1){
			QMessageBox::critical(this, "Error 134", "Incorrect name of file");
			return -3;
		}
		int s0=fileName.lastIndexOf("/");
		if(s0>-1){
			lastDir=fileName.mid(0, s0);
		}else{
			lastDir="";
		}
		debug("lastDir='"+lastDir+"'");
	}

	if(SbDownload.multidownload || SbDownload.needOpen) SbDownload.filepath = fileName;


	QString encrPhrase = "";
	if(filelist[n].encrypted){
		if(SbDownload.wasEncrPhraseEntered && downloadFileWnd.checkBox1->checkState()==Qt::Checked){
			// User already entered Encryption Phrase and selected remember, so we should use this Encryption Phrase
			encrPhrase = downloadFileWnd.lineEdit1->text();
		}else{
			downloadFileWnd.setWindowModality(Qt::ApplicationModal);
			downloadFileWnd.move(QPoint((int) (x()+ww/2-215), (int) (y()+wh/2-200)));
			downloadFileWnd.initWnd();
			downloadFileWnd.show();
		
			QEventLoop eventLoop;
			QObject::connect(&downloadFileWnd, SIGNAL(closed()), &eventLoop, SLOT(quit()));
			eventLoop.exec();
		
			if(downloadFileWnd.isCanceled || downloadFileWnd.lineEdit1->text()==""){	// User pressed CANCEL, so we must to stop download
				return 100;
			}

			SbDownload.wasEncrPhraseEntered = true;
			encrPhrase = downloadFileWnd.lineEdit1->text();
		}

	}


	int r = downloadFileToDisk(filelist[n].id, filelist[n].link, encrPhrase, SbDownload.filepath, QDateTime::fromString(filelist[n].lastmodify, Qt::ISODate), filelist[n].name);
	if(r==0){
		debug("File success downloaded");
		if(SbDownload.needOpen){
			if(isActionCanceled){
				QDir d(SbDownload.filepath);
				QString parentFolder = d.dirName();

				QFile file01(SbDownload.filepath);		// Remove file
				file01.remove();
				if(!d.rmdir(parentFolder)){			// Remove folder
					debug("Can't delete folder using first way: "+parentFolder);

					QString tfol1="rm -rf \""+ commandLineEscape(parentFolder) +"\"";
					if(system(tfol1.toUtf8().data())!=0){
						debug("Can't delete folder  "+parentFolder);
					}
				}
				return 100;
			}

			/*
			QProcess *process2=new QProcess();
			if(isKDE()){
				process2->startDetached("kde-open", QStringList(SbDownload.filepath));
			}else{
				process2->startDetached("gnome-open", QStringList(SbDownload.filepath));
			}
			*/

			QString cmd = "\""+ commandLineEscape(SbDownload.filepath) +"\"";
			cmd = "gnome-open "+ cmd +" || kde-open "+ cmd;
			debug(cmd);
			QProcess *process2=new QProcess();
			process2->startDetached("sh", QStringList() << "-c" << cmd);

			deleteOldTmpFiles();		// deleting old files while we waiting for opening file
			delete process2;
		}

	}else	if(r==100){
		debug("Download canceled");
		return 100;
	}

	return 0;
}
//////////////////////////////////////////////////////////////////////
int SMEStorageExplorer::downloadFileToDisk(QString id, QString url, QString encryptionPhrase, QString localPath, QDateTime lastModify, QString name=""){
	// If "id" is unknown then "url" must be not empty.
	// "url" shold be used only for public files.
	// localPath - must be path with name
	// name - is need only for messages
	// Return 0 if downloaded correctly, 100 - if upload canceled
	// Note. This function download file to temp file. If download finished without errors then file will be renamed to original name.
debug("downloadFileToDisk("+ id +", "+ url +", "+ encryptionPhrase +", "+ localPath +", "+ name +")");
	int error = 0;		// 100 - action canceled
	if(id=="" && url==""){
		QMessageBox::critical(this, "Error 34", "Can't find the file.");
		return -1;
	}
	
	int timeout = 120;
	qint64 fileSize = -1;
	bool isHeadersRecived = false;
	bool TransferEncodingChunked = false;
	bool downloadCompleted = false;
	qint64 countDownloadedBytes = 0;
	QDateTime endTime = QDateTime::currentDateTime().addSecs(timeout);

	showMessage("Downloading  "+name+"... ", true);
	bool weCreatedLocalFile = false;
	bool existsLocalFileBeforeDownload = false;
	if(QFile::exists(localPath)) existsLocalFileBeforeDownload = true;

	// Prepare local file to download
/*
	FILE *file = openFile(localPath, "a");			// Try to open file
	QString tempPath = localPath + ".part1";
	if(!file){
		error = -6;
		QMessageBox::critical(this, "Error 143", "Cannot create file "+ localPath +". Check permissions.");
	}else{
		// We can open local file
		fclose(file);
		if(!existsLocalFileBeforeDownload && QFile::exists(localPath)) weCreatedLocalFile = true;

		// Generate temp name for the file
		for(int i=0; QFile::exists(tempPath); i++){
			tempPath = localPath +".part"+ QString::number(i);
		}

		file = openFile(tempPath, "w");			// Try to open temp file
	}
*/

	// Prepare local file to download
	QString tempPath = localPath + ".part1";
	QFile fileTest(localPath);
	fileTest.open(QIODevice::WriteOnly);
	if(!fileTest.isOpen()){
		error = -6;
		QMessageBox::critical(this, "Error 143", "Cannot create file "+ localPath +". Check permissions.");
	}else{
		// We can open local file
		fileTest.close();
		if(!existsLocalFileBeforeDownload && QFile::exists(localPath)) weCreatedLocalFile = true;

		// Generate temp name for the file
		for(int i=0; QFile::exists(tempPath); i++){
			tempPath = localPath +".part"+ QString::number(i);
		}

//		file = openFile(tempPath, "w");			// Try to open temp file
	}

	QFile file(tempPath);
	file.open(QIODevice::WriteOnly);

	if(error==0 && !file.isOpen()){
		QMessageBox::critical(this, "Error 144", "Cannot create file "+ localPath +". Check permissions.");
		error = -1;
	}else{		// Local file opened. We are ready for download
		QDataStream fStream(&file);
		showMessage("Downloading  "+ name +"... ", true, true);

		if(isActionCanceled){
			error = 100;
		}

		QSslSocket socket;
		SbDownload.socket = &socket;
		connect(&socket, SIGNAL(sslErrors(QList<QSslError>)), this, SLOT(slotSslErrorsDownload(QList<QSslError>)));
		if(useProxy){
			debug("useProxy=1");
			if(proxylogin!="" || proxypass!=""){
				socket.setProxy(QNetworkProxy(QNetworkProxy::HttpProxy, proxyhost, proxyport, proxylogin, proxypass));
			}else{
				socket.setProxy(QNetworkProxy(QNetworkProxy::HttpProxy, proxyhost, proxyport));
			}
		}

		QString proto="http", host="", spath="";
		if(id=="" && url!=""){		// Public files don't have ID, so we use URL in this case
			if(url.indexOf("https://", 0, Qt::CaseInsensitive)==0) proto="https";
			host = getPartQString(url, "://", "/");
			spath = getPartQString(url, "://"+ host, "");
		}else{
			host=smehost;
			if(host.indexOf("https://", 0, Qt::CaseInsensitive)==0) proto="https";
			if(host.indexOf("://")>0) host = getPartQString(host, "://", "");

			spath = "/api/"+ token +"/GetFile/"+ base64(id) +","+ base64(encryptionPhrase) +",,,,,"+ base64("y");
		}

		debug("Proto = "+ proto +"; host = "+ host +"; path = "+spath);
		if(proto=="https"){
			socket.setProtocol(QSsl::TlsV1);
			socket.connectToHostEncrypted(host, 443);
			if(!socket.waitForEncrypted()){
				error = 1;
				debug("Error = "+socket.errorString());
				QMessageBox::critical(this, "Error", "Cannot connect to server. "+ socket.errorString());
				//return ;
			}
		}else{
			socket.connectToHost(host, 80);
			if(!socket.waitForConnected()){
				error = 1;
				debug("Error = "+socket.errorString());
				QMessageBox::critical(this, "Error", "Cannot connect to server. "+ socket.errorString());
				//return ;
			}
		}
		
		if(error==0){
			// Send request to server
			QString request1 = "GET "+ spath +" HTTP/1.1\r\n"
				+ "User-Agent: Mozilla/4.0 (Linux Tools Explorer)\r\n"
				+ "Host: "+ host +"\r\n"
				+ "Accept: */*\r\n"
				+ "Accept-Encoding: deflate\r\n"
				+ "\r\n";
			socket.write(request1.toUtf8().data());

			// Prepare progress bar
			ui->progressBar1->setMinimum(0);
			ui->progressBar1->setMaximum(100);
			ui->progressBar1->setValue(0);

			char *d0;
			int blockSize = 40*1024;		// must be at last 8KB, to read all headers.
			d0 = new char[blockSize];
			QString buffer="";

			QDateTime endTime = QDateTime::currentDateTime().addSecs(timeout);
			while(QDateTime::currentDateTime() < endTime){		// read response
				QString d = "";
				qint64 l = socket.read(d0, blockSize);
				//debug("Readed "+ QString::number(l) +"; countDownloadedBytes="+ QString::number(countDownloadedBytes) +";");
				if(l>0){		// Recived data
					endTime = QDateTime::currentDateTime().addSecs(timeout);
					d = QString::fromAscii(d0, int(l));			// we interpretate recived data as Ascii, so later we must convert it back to Ascii

					if(!isHeadersRecived){
						int p0 = -1;
						int p1 = d.indexOf("\n\n");
						int p2 = d.indexOf("\n\r\n");
						if(p1>-1 && (p1<p2 || p2==-1)){
							p0 = p1 + 2;
						}else if(p2>-1){
							p0 = p2 + 3;
						}

						if(p0>-1){			// Headers received
							debug("Headers received");
							isHeadersRecived = true;
							QString headers = d.mid(0, p0);
							d = d.mid(p0);

							QString statusLine = getPartQString("\n"+headers, "\nHTTP/", "\n");
							QString httpStatusCode = getPartQString(statusLine, " ", " ");
							QString httpStatusMessage = getPartQString(statusLine+"\n", " "+httpStatusCode+" ", "\n");
							int sc = 0;
							try{
								sc = httpStatusCode.toInt();
							}catch(...){
								debug("Incorrect Status code: '"+ httpStatusCode +"'");
							}

							if(sc<100 || sc>299){
								error = -5;

								QString mess = decodeBase64(getPartQString("\n"+headers, "\nX-PROVIDER-DOWNLOAD-ERROR: ", "\n"));
								if(mess!=""){
									mess = "Storage Provider responds: "+mess;
								}else{
									mess = decodeBase64(getPartQString("\n"+headers, "\nX-SME-DOWNLOAD-ERROR: ", "\n"));
								}

								if(mess==""){
									mess = httpStatusMessage;
								}

								QMessageBox::critical(this, "Error", "Cannot download file. "+ mess);
								debug("Error. Status code: "+httpStatusCode+", message: "+mess);
								break;
							}

							int s1=headers.indexOf("\nContent-Length: ");
							if(s1>-1){
								int s2=headers.indexOf("\n", s1+2);
								if(s2>-1 && s1<s2){
									QString ssize = headers.mid(s1+17, s2-s1-17);
									ssize = ssize.replace("\r", "");
									try{
										fileSize = ssize.toLongLong();
									}catch(...){
										fileSize = -1;
										debug("Incorrect Content-Length. '"+ ssize +"'");
									}
									debug("Size of file '"+ QString::number(fileSize) +"'");
								}
							}

							if(fileSize<0){
								debug("Transfer-Encoding: chunked");
								TransferEncodingChunked = true;
								ui->progressBar1->setMaximum(0);	// We don't know size of file. So, we will be use "movable" progress bar
							}
						}
					}

					if(TransferEncodingChunked && isHeadersRecived && d!=""){
						if(buffer!=""){
							d = buffer + d;
							buffer = "";
						}

						while(d!=""){
							int k=d.indexOf("\n");
							if(k<0){
								// We have not enough data (chunk header, chunk data and \n that close chunk)
								// So, we save data to buffer
								//debug("We have not enough data 1");
								buffer = d;
								break;
							}

							k++;
							int k0 = k;
							QString sChunkSize = d.mid(0, k);	// We try to get size of chunk
							sChunkSize.replace("\r", "");
							sChunkSize.replace("\n", "");

							bool bStatus = false;
							uint chunkSize = sChunkSize.toUInt(&bStatus, 16);
							if(!bStatus){
								debug("Error 757. Cannot download file. Connection broken. Size of chunk: "+sChunkSize);
								error = 757;
								break;
							}

							if(chunkSize>0){
								// Checking if we have bytes that close chunk
								bool bytesThatCloseChunkExists = false;
								if((unsigned) d.length() >= k+chunkSize && d.mid(k+chunkSize,1)=="\r") k++;
								if((unsigned) d.length() >= k+chunkSize && d.mid(k+chunkSize,1)=="\n"){
									bytesThatCloseChunkExists = true;
									k++;
								}

								if(bytesThatCloseChunkExists && (unsigned) d.length() >= k+chunkSize){
									// We have enough data (chunk header, chunk data and \n that close chunk)
								}else{
									// We have not enough data (chunk header, chunk data and \n that close chunk)
									// So, we save data to buffer
									//debug("We have not enough data 2");
									buffer = d;
									break;
								}
							}

							if(chunkSize==0){		// Download finished
								downloadCompleted = true;
								break;
							}
							
							if(countDownloadedBytes<1) debug("write data to local file: " + QString::number(chunkSize) +" b.");
							QByteArray b = d.mid(k0, chunkSize).toAscii();		// We must convert to Ascii, because we recived data interpreted as Ascii
							int wsize = b.length();
							int rl_wsize = fStream.writeRawData(b.data(), wsize);
							if(rl_wsize!=wsize){
								QMessageBox::critical(this, "Error", "Cannot write data to local file");
								debug("Cannot write data to local file");
								error = 1;
								break;
							}

							countDownloadedBytes += wsize;
							d = d.mid(k + chunkSize);
						}

						if(downloadCompleted){
							break;
						}
					}else if(isHeadersRecived && d!=""){
						if(countDownloadedBytes<1) debug("write data to local file: " + QString::number(d.length()) +" b.");
						QByteArray b = d.toAscii();		// We must convert to Ascii, because we recived data interpreted as Ascii
						int wsize = b.length();
						int rl_wsize = fStream.writeRawData(b.data(), wsize);
						//size_t rl_wsize=fwrite(b.data(), 1, wsize, file);
						if(rl_wsize!=wsize){
							QMessageBox::critical(this, "Error", "Cannot write data to local file");
							debug("Cannot write data to local file");
							error = 1;
							break;
						}

						countDownloadedBytes += wsize;
						if(fileSize>0)
							ui->progressBar1->setValue((double (countDownloadedBytes*100/fileSize)));
					}
				}

				if(fileSize>0 && countDownloadedBytes>=fileSize){
					debug("File downloaded");
					break;
				}else if(fileSize==0){
					debug("File is empty");
					break;	// file is empty. So, don't need to download data - need to create empty file.
				}


											// Executing events loop while waiting for response
				QEventLoop eventLoop;

				QTimer timer;
				timer.setSingleShot(true);
				connect(&timer, SIGNAL(timeout()), &eventLoop, SLOT(quit()));
				//timer.start(100);
				timer.start(100);	// Timer is used to prevent infinity loop and provide access to the user to use Cancel button

				QObject::connect(&socket, SIGNAL(readyRead()), &eventLoop, SLOT(quit()));
				eventLoop.exec();

				timer.stop();
				if(isActionCanceled){
					error = 100;
					debug("Download canceled");
					break;
				}
			}

			// download finished
			debug("Download finished. error="+ QString::number(error));
		}

		//fclose(file);
		file.close();
		socket.close();

		if(fileSize>0 && countDownloadedBytes!=fileSize){
			QMessageBox::critical(this, "Error 147", "Cannot download file. Size of file should be "+ QString::number(fileSize) +"bytes, but received only "+ QString::number(countDownloadedBytes) +"bytes.");
			error = -8;
		}

		if(TransferEncodingChunked && !downloadCompleted){
			QMessageBox::critical(this, "Error 148", "Cannot download file. We received only part of file");
			error = -11;
		}

		if(error==0){		// File downloaded correctly. So, we must delete local file and rename temp file (this is need because the rename cannot to replace file)
			if(QFile::exists(localPath) && !QFile(localPath).remove()){
				QMessageBox::critical(this, "Error 145", "Cannot replace file "+ localPath +" by the file "+ tempPath);
				error = -9;
			}else{
				if(!QFile::rename(tempPath, localPath)){
					QMessageBox::critical(this, "Error 146", "Cannot replace file "+ localPath +" by the file "+ tempPath);
					error = -10;
				}

				if(error==0){
					if(!lastModify.isNull()){		// need to change modify time
						utimbuf mtime;
						mtime.actime = lastModify.toTime_t();
						mtime.modtime = mtime.actime;

						QByteArray tmName;
						if(localeEncoding!=""){
							QTextCodec *codec = QTextCodec::codecForName(localeEncoding.toUtf8().data());
							tmName = codec->fromUnicode(localPath);
						}else{
							tmName = localPath.toUtf8();
						}

						if(utime(tmName.data(), &mtime)!=0 && localeEncoding!=""){		// try to use UTF-8 name
							tmName = localPath.toUtf8();
							utime(tmName.data(), &mtime);
						}
					}
				}

			}
		}

		if(error!=0){		// File downloaded incorrectly. So, we must delete temp file.
			if(!QFile(tempPath).remove())
				QMessageBox::critical(this, "Error", "Cannot remove temp file "+ tempPath);

			if(weCreatedLocalFile){							// We created this file, so now we must remove it.
				if(!QFile(localPath).remove())
					QMessageBox::critical(this, "Error", "Cannot remove file (this file is BROKEN) "+ localPath);
			}
		}
	}

	return error;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::slotSslErrorsDownload(QList<QSslError> e0){
	if(e0.size()>0 && (
			e0.at(0).errorString()=="The root certificate of the certificate chain is self-signed, and untrusted"
			|| e0.at(0).errorString()=="The issuer certificate of a locally looked up certificate could not be found"
			|| e0.at(0).errorString()=="The root CA certificate is not trusted for this purpose"
		)){
		SbDownload.socket->ignoreSslErrors();
	}else{
		if(e0.size()>0){
			QMessageBox::critical(this, "Error", "  "+e0.at(0).errorString()+"  ");
		}
	}

	qDebug() << "SSL Error:" << e0;
	return ;	
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::slotSslErrorsUpload(QList<QSslError> e0){
	if(e0.size()>0 && (
			e0.at(0).errorString()=="The root certificate of the certificate chain is self-signed, and untrusted"
			|| e0.at(0).errorString()=="The issuer certificate of a locally looked up certificate could not be found"
			|| e0.at(0).errorString()=="The root CA certificate is not trusted for this purpose"
		)){
		SbUpload.socket->ignoreSslErrors();
	}else{
		if(e0.size()>0){
			QMessageBox::critical(this, "Error", "  "+e0.at(0).errorString()+"  ");
		}
	}

	qDebug() << "SSL Error:" << e0;
	return ;	
}
//////////////////////////////////////////////////////////////////////
FILE* SMEStorageExplorer::openFile(QString path, QString mode="r"){
	// This function open local file and return pointer
	// We try to use local encoding. If it doesn't work then we will be try to use UTF-8
	QByteArray tmName;
	if(localeEncoding!=""){
		QTextCodec *codec = QTextCodec::codecForName(localeEncoding.toUtf8().data());
		tmName = codec->fromUnicode(path);
	}else{
		tmName = path.toUtf8();
	}

	FILE *file = fopen(tmName.data(), mode.toUtf8().data());
	if(!file && localeEncoding!=""){		// try to use UTF-8
		tmName = path.toUtf8();
		file=fopen(tmName.data(), mode.toUtf8().data());
	}

	return file;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::deleteOldTmpFiles(){
debug("deleteOldTmpFiles()");
	QString fol="/tmp/StorageMadeEasy/";
	QDir dir(fol);
	if(!dir.exists()) return ;

	QDateTime pdate=QDateTime::currentDateTime();
	pdate=pdate.addDays(-1);

	int lst=0;
	QString tfol=fol+"tmp0";
	for(int i=1; i<=10000+lst; i++){
		if(QFile::exists(tfol)){
			lst=i;
			QFileInfo finfo(tfol);
			if(finfo.lastModified()<pdate){
				debug("deleting =>  "+tfol);
				tfol="rm -rf \""+tfol+"\"";
				if(system(tfol.toUtf8().data())!=0)	debug("Can't delete folder  "+tfol);
//				break;
			}
		}
		tfol=fol+"tmp"+intToQstring(i);
	}

	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bUpload(){
debug("bUpload()");

	if(!tryRunning()) return ;
	int x=ui->pushButton4->x();
	int y=ui->pushButton4->y()+ui->pushButton4->height()-2;

	QPoint pt;
	pt.setX(x);
	pt.setY(y);

	pt=mapToGlobal(pt);
	uploadMenu->exec(pt);
//debug("pt => x => "+ intToQstring(pt.x())+" y => "+intToQstring(pt.y()));

	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bUploadFiles(){
	if(!tryRunning()) return ;
debug("bUploadFiles()");
	showMessage("Preparing... ", true);
//	QString fileName=QFileDialog::getOpenFileName(this, tr("Upload File"),  lastDir, tr(""));
	SbUpload.files=QFileDialog::getOpenFileNames(this, tr("Upload File"),  lastDir, tr(""));

	SbUpload.status=0;
	SbUpload.size=0;
	SbUpload.source="";
	SbUpload.filepath="";
	SbUpload.uploadcode="";
	SbUpload.realName="";
	SbUpload.multiupload=false;

	if(SbUpload.files.size()<1 || SbUpload.files.at(0).length()<1 || !QFile::exists(SbUpload.files.at(0))){
		hideMessage();
		return;
	}

	if(SbUpload.files.size()>1) SbUpload.multiupload=true;

	QString fname="";
	int s0=SbUpload.files.at(0).lastIndexOf("/");
	if(s0>-1){
		lastDir=SbUpload.files.at(0).mid(0, s0);
		fname=SbUpload.files.at(0).mid(s0+1);
	}else{
		hideMessage();
		return ;
	}
//	debug(lastDir);

	SbUpload.source=SbUpload.files.at(0);
	uploadFileWnd.setWindowModality(Qt::ApplicationModal);
	uploadFileWnd.clear();
	uploadFileWnd.move(QPoint((int) (x()+ww/2-215), (int) (y()+wh/2-200)));
	uploadFileWnd.name=fname;
	uploadFileWnd.path="";
	for(int k=0, size=SbUpload.files.size(); k<size; k++){
		if(uploadFileWnd.path!="") uploadFileWnd.path+="; ";
		uploadFileWnd.path+=SbUpload.files.at(k);
	}
	if(SbUpload.files.size()>1) uploadFileWnd.lineEdit1->setReadOnly(true);

	uploadFileWnd.initWnd();
	uploadFileWnd.show();
//	hideMessage();

	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bUploadFolder(){
	if(!tryRunning()) return ;
debug("bUploadFolder()");

	showMessage("Preparing... ", true);
	QString dir=QFileDialog::getExistingDirectory(this, tr("Upload Folder"),  lastDir);
debug("dir="+dir);

	SbUpload.filelist.clear();

	QStringList	sfl;
	sfl << dir;
	sfl=sfl+scanDir(dir, true);
	int sz=sfl.size();
	for(int i=0; i<sz; i++){
		Tfile f=emptyFile;
		f.id="";
		f.pid="";
		f.path=sfl.at(i);
debug("f.path="+f.path);

		QFileInfo absFile(f.path);
		if(absFile.isDir()){
			f.type=1;
		}else{
			f.type=0;
		}
		SbUpload.filelist << f;
	}


	SbUpload.files.clear();

	SbUpload.status=0;
	SbUpload.size=0;
	SbUpload.source="";
	SbUpload.filepath="";
	SbUpload.uploadcode="";
	SbUpload.realName="";
	SbUpload.pid="";
	SbUpload.multiupload=true;

	if(SbUpload.filelist.size()<1){
		hideMessage();
		return;
	}

	uploadFolder1();
	return;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::uploadFolder1(){
debug("uploadFolder1()");
	SrunFunction.up_level_command="";
	uploadFileWnd.name="";		// This means that need to use real name
	for(int k=0, size=SbUpload.filelist.size(); k<size; k++){
		QString path=SbUpload.filelist.at(k).path;
//debug("x2; path="+path+"; id="+SbUpload.filelist.at(k).id+"; if(path.length()>0 && SbUpload.filelist.at(k).id.length()<1){");
		if(path.length()>0 && SbUpload.filelist.at(k).id.length()<1){
			QFileInfo absFile(path);
			if(absFile.isDir()){
//debug("lastid="+createFolderWnd.lastid.length());
				QDir d(path);
				if(createFolderWnd.foldername==d.dirName() && createFolderWnd.lastid.length()>0){
					Tfile kf=SbUpload.filelist.at(k);
					kf.id=createFolderWnd.lastid;
					createFolderWnd.lastid="";
					SbUpload.filelist.replace(k, kf);
					continue;
				}

				createFolderWnd.clear();
				createFolderWnd.createwnd=true;
				createFolderWnd.type=1;
				createFolderWnd.pid=getPID(SbUpload.filelist, path);
				createFolderWnd.foldername=d.dirName();
				createFolder2();
			}else{
				if(!QFile::exists(path)){
					QMessageBox::critical(this, "Error", "Cannot upload file "+path+". ");
					hideMessage();
					return;
				}
//				createFolderWnd.pid=getPID(SbUpload.filelist, path);
				SbUpload.pid=getPID(SbUpload.filelist, path);
				SbUpload.source=path;
				SbUpload.filelist.removeAt(k);
				bUpload2();
			}
			SrunFunction.up_level_command.append(SLOT(uploadFolder1()));
			return ;
		}
	}

	SbUpload.filelist.clear();
	SbUpload.files.clear();
	SbUpload.status=0;
	SbUpload.size=0;
	SbUpload.source="";
	SbUpload.filepath="";
	SbUpload.uploadcode="";
	SbUpload.realName="";
	SbUpload.pid="";
	hideMessage();
	return ;
}
//////////////////////////////////////////////////////////////////////
QString SMEStorageExplorer::getPID(QList<Tfile> filelist, QString fpath){
	QString pid="";
	int s0=fpath.lastIndexOf("/");
	if(s0>-1){
		fpath=fpath.mid(0, s0);
	}else{
		return "";
	}
//debug("fpath="+fpath);

	for(int k=0, size=filelist.size(); k<size; k++){
		QString path=filelist.at(k).path;
		if(path.length()>0 && path==fpath){
//debug("return => "+filelist.at(k).id);
			return filelist.at(k).id;
		}
	}

	return pid;
}
//////////////////////////////////////////////////////////////////////
QStringList SMEStorageExplorer::scanDir(QString folder, bool includeSubfolders){
	QStringList reslist;
	if(folder=="") return reslist;
	folder.replace("//", "/");

	QDir dir(folder);

	QStringList lstDirs =dir.entryList(QDir::Dirs | QDir::AllDirs | QDir::NoDotAndDotDot);		// get folders
	QStringList lstFiles=dir.entryList(QDir::Files | QDir::Hidden);		// get files

	foreach (QString entry, lstFiles){
		QString entryAbsPath=folder + "/" + entry;
		entryAbsPath.replace("//", "/");
		reslist << entryAbsPath;
	}

	foreach(QString entry, lstDirs){
		QString entryAbsPath = folder + "/" + entry;
		entryAbsPath.replace("//", "/");
		reslist << entryAbsPath;

		if(includeSubfolders){
			QStringList resslist;
			resslist=scanDir(entryAbsPath, includeSubfolders);
			reslist=reslist+resslist;
		}
	}
	return reslist;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bUpload1(){
debug("bUpload1()");
	SrunFunction.up_level_command="";
	if(SbUpload.multiupload) uploadFileWnd.name="";		// This means that need to use real name
	for(int k=0, size=SbUpload.files.size(); k<size; k++){
		if(SbUpload.files.at(k).length()>0 && QFile::exists(SbUpload.files.at(k))){
			SrunFunction.up_level_command.append(SLOT(bUpload1()));
			SbUpload.source=SbUpload.files.at(k);
			SbUpload.files.removeAt(k);
			bUpload2();
			return ;
		}
	}

	if(SbUpload.files.size()>=1 && !QFile::exists(SbUpload.files.at(0))){
		QMessageBox::critical(this, "Error", "Cannot upload file "+SbUpload.files.at(0)+". ");
		hideMessage();
		return;
	}

	SbUpload.status=0;
	SbUpload.size=0;
	SbUpload.source="";
	SbUpload.filepath="";
	SbUpload.uploadcode="";
	SbUpload.realName="";
	SbUpload.pid="";
	hideMessage();
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bUpload2(){
debug("bUpload2()");
	QString fileName=SbUpload.source;
	QString fol="/tmp/StorageMadeEasy/";
	QDir dir(fol);
	if(SbUpload.filepath==""){
		if(!dir.exists()){
			dir.mkpath(fol);

			QFile f1(fol);
			f1.setPermissions(QFile::ReadOwner | QFile::WriteOwner | QFile::ReadUser | QFile::WriteUser | QFile::ReadGroup | QFile::WriteGroup | QFile::ReadOther |QFile::WriteOther | QFile::ExeOwner | QFile::ExeUser | QFile::ExeGroup | QFile::ExeOther);
			f1.close();
			debug("Created  "+ fol);
		}
		
		QDateTime pdate=QDateTime::currentDateTime();
		pdate=pdate.addDays(-2);

		SbUpload.filepath=fol+"smeexplorer_0.tmp";
		for(int i=1; QFile::exists(SbUpload.filepath); i++){
			QFileInfo finfo(SbUpload.filepath);
			if(finfo.lastModified()<pdate){
				writeToFile(SbUpload.filepath, "");
				break;
			}
			SbUpload.filepath=fol+"smeexplorer_"+ intToQstring(i) +".tmp";
		}
//		writeToFile(SbUpload.filepath, "");
debug("TMP file => "+ SbUpload.filepath);
	}

	if(QFile::exists(SbUpload.filepath)) QFile::remove(SbUpload.filepath);

	QFile f2(SbUpload.filepath);
	if(f2.size()==0)	writeToFile(SbUpload.filepath, " ");
	
	QString realName="";
	int s0=fileName.lastIndexOf("/");
	if(s0>-1){
		realName=fileName.mid(s0+1);
	}else{
		hideMessage();
		return ;
	}

	SbUpload.realName=realName;
	if(uploadFileWnd.name=="")	uploadFileWnd.name=realName;

	f2.close();

	if(isActionCanceled){
		hideMessage();
		return ;
	}

//debug("++ > "+ uploadFileWnd.name +"; "+ uploadFileWnd.desc +"; "+ uploadFileWnd.tags);
	showMessage("Preparing to uploading...", true);

	SrunFunction.restory="";
	SrunFunction.restory.append(SLOT(bUpload2Resp()));
	if(isActionCanceled){
		hideMessage();
		return ;
	}
//	QString uri="doInitUpload/"+ base64(uploadFileWnd.name) +","+ base64(uploadFileWnd.desc) +","+ base64(uploadFileWnd.tags) +","+ base64(currentFolder.id)
//		 +","+ base64(realName) +","+ base64("xml") +",,"+ base64(uploadFileWnd.encrypt) +",,"+ base64("g") +",";

	QString fpid=currentFolder.id;
	if(SbUpload.pid!="") fpid=SbUpload.pid;

	QFileInfo finfo(SbUpload.source);
	QString postData="function=doInitUpload";
	postData+="&fi_name="+ QUrl::toPercentEncoding(uploadFileWnd.name) +"&fi_description="+ QUrl::toPercentEncoding(uploadFileWnd.desc)
		+"&fi_tags="+ QUrl::toPercentEncoding(uploadFileWnd.tags) +"&fi_pid="+ QUrl::toPercentEncoding(fpid)
		+"&fi_filename="+ QUrl::toPercentEncoding(realName) +"&responsetype=xml&responsedata=&encryptphrase="+ QUrl::toPercentEncoding(uploadFileWnd.encrypt)
		+"&fi_structtype=g&fi_id=&chunkifbig=";
	postData+="&fi_localtime="+ toUTC(finfo.lastModified()).toString("yyyy-MM-dd hh:mm:ss");

	runFunction("", true, postData);

	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bUpload2Resp(){
debug("bUpload2Resp()");
	if(SbUpload.filepath=="" || SbUpload.source==""){
		QMessageBox::critical(this, "Error", "Can't upload file");
		hideMessage();
		return;
	}

	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory="";

	QString uploadcode=getPartQString(res, "<uploadcode>", "</uploadcode>");
	if(uploadcode==""){
		QString statusMessage=getPartQString(res, "<statusmessage>", "</statusmessage>");
		if(statusMessage!=""){
			if(statusMessage.length()<15) statusMessage+="         ";
			QMessageBox::critical(this, "Error", statusMessage);
		}else{
			QMessageBox::critical(this, "Error", "Can't upload file. Can't get UploadCode.");
		}
		resume(1);
		return ;
	}
	SbUpload.uploadcode=uploadcode;

	// Upload code is recived, so we ready for upload
	int error = 0;
	int timeout = 120;
	qint64 countSentBytes = 0;
	QString bd="7d8X3ld8Y3Zc0sJ4aDh3Q86g6rG9z" + base64(QString::number(rand())+" 0123456789 ").mid(0, 10);
debug("bd="+bd);

	QFile file(SbUpload.source);
	file.open(QIODevice::ReadOnly);

	if(!file.isOpen()){
		QMessageBox::critical(this, "Error 244", "Cannot open file "+ SbUpload.source +". Check permissions.");
		error = -1;
	}else{		// Local file opened. We are ready for upload
		QDataStream fStream(&file);
		showMessage("Uploading  "+ SbUpload.source +"... ", true, true);

		QFile f3(SbUpload.source);
		qint64 sizeOfFile = f3.size();
debug("Size = "+ QString::number(sizeOfFile) +" B");

		QSslSocket socket;
		SbUpload.socket = &socket;
		connect(&socket, SIGNAL(sslErrors(QList<QSslError>)), this, SLOT(slotSslErrorsUpload(QList<QSslError>)));
		if(useProxy){
			debug("useProxy=1");
			if(proxylogin!="" || proxypass!=""){
				socket.setProxy(QNetworkProxy(QNetworkProxy::HttpProxy, proxyhost, proxyport, proxylogin, proxypass));
			}else{
				socket.setProxy(QNetworkProxy(QNetworkProxy::HttpProxy, proxyhost, proxyport));
			}
		}

		QString proto="http", host="", spath="";
		if(smehost.indexOf("https://", 0, Qt::CaseInsensitive)==0) proto="https";

		host=smehost;
		if(host.indexOf("://")>0)	host = getPartQString(smehost, "://", "");

		spath = "/cgi-bin/uploader/uploader1.cgi?"+ uploadcode;

		debug("Proto = "+ proto +"; host = "+ host +"; path = "+spath);
		if(proto=="https"){
			socket.setProtocol(QSsl::TlsV1);
			socket.connectToHostEncrypted(host, 443);
			if(!socket.waitForEncrypted()){
				error = 1;
				debug("Error = "+socket.errorString());
				QMessageBox::critical(this, "Error", "Cannot connect to server. "+ socket.errorString());
			}
		}else{
			socket.connectToHost(host, 80);
			if(!socket.waitForConnected()){
				error = 1;
				debug("Error = "+socket.errorString());
				QMessageBox::critical(this, "Error", "Cannot connect to server. "+ socket.errorString());
			}
		}
		
		if(error==0 && isActionCanceled){
			error = 100;
		}

		if(error==0){
			// Prepare request
			QString encFilename = SbUpload.realName.replace("\"", "\\\"");
			QString header = QString("--"+ bd +"\r\n")
				+"Content-Disposition: form-data; name=\"uploadedfile\"; filename=\""+ encFilename +"\"\r\n"
				+"Content-Type: image/jpeg\r\n"
				+"\r\n";
			QString footer="\r\n--"+ bd +"--\r\n";

			qint64 contentLength = sizeOfFile + header.toUtf8().length() + footer.length();

			// Send request to server
			QString request1 = "POST "+ spath +" HTTP/1.1\r\n";
			request1 += "Host: "+ host +"\r\n";
			request1 += "User-Agent: Mozilla/4.0 (Linux Tools Explorer)\r\n";
			request1 += "Content-Type: multipart/form-data; boundary="+bd+"\r\n";
			request1 += "Content-Length: "+ QString::number(contentLength)+"\r\n";
			request1 += "\r\n";
			request1 += header;

			socket.write(request1.toUtf8().data());
			//debug("request1=>\n"+request1+"<<<<<<<<<<<<<<<");

			// Prepare progress bar
			ui->progressBar1->setMinimum(0);
			ui->progressBar1->setMaximum(100);
			ui->progressBar1->setValue(0);

			char *d0;
			int blockSize = 1024;	// MUST be less than 102401
			d0 = new char[blockSize];

			QDateTime endTime = QDateTime::currentDateTime().addSecs(timeout);
			while(countSentBytes < sizeOfFile){
//				debug("Read data from local file");
				int cb = blockSize;
				if(countSentBytes+cb > sizeOfFile) cb = sizeOfFile - countSentBytes;

//				size_t l = fread(d0, 1, cb, file);
				int l = fStream.readRawData(d0, cb);

				if(l>0){
//debug("Upload "+ QString::number(l) +"bytes");
					socket.write(d0, l);

					//Here we wait while data will be sent. If data will be sent then we must calculate number of sent bytes
					QDateTime endTime2 = QDateTime::currentDateTime().addSecs(timeout);
					while(socket.bytesToWrite()>0 && QDateTime::currentDateTime() < endTime2){
						QEventLoop eventLoop;					// Executing events loop while waiting for response

						QTimer timer;
						timer.setSingleShot(true);
						connect(&timer, SIGNAL(timeout()), &eventLoop, SLOT(quit()));
						timer.start(10);	// Timer is used to prevent infinity loop and provide access to the user to use Cancel button

//						QObject::connect(&socket, SIGNAL(readyRead()), &eventLoop, SLOT(quit()));
						eventLoop.exec();

						timer.stop();
						if(isActionCanceled){
							error = 100;
							debug("Upload canceled");
							break;
						}
					}

					if(socket.bytesToWrite()==0){			// Data is sent
						countSentBytes += int(l);
						ui->progressBar1->setValue((double (countSentBytes*100/sizeOfFile)));

					}else{			// We tried to send data, but some error happened, so we must to stop upload
						QMessageBox::critical(this, "Error", "Cannot upload file. Check your Internet connection.");
						error = -15;
						break;
					}
				}else{
					if(countSentBytes<sizeOfFile){
						QMessageBox::critical(this, "Error", "Cannot read data from local file.");
						error = -20;
					}
					break;
				}
			}

			if(error==0){
				socket.write(footer.toUtf8().data());
				//debug("Send footer> "+footer);
				//Here we wait while data will be sent
				QDateTime endTime2 = QDateTime::currentDateTime().addSecs(timeout);
				while(socket.bytesToWrite()>0 && QDateTime::currentDateTime() < endTime2){
					QEventLoop eventLoop;					// Executing events loop while waiting for response


					QTimer timer;
					timer.setSingleShot(true);
					connect(&timer, SIGNAL(timeout()), &eventLoop, SLOT(quit()));
					timer.start(50);	// Timer is used to prevent infinity loop and provide access to the user to use Cancel button
					eventLoop.exec();
					timer.stop();

					if(isActionCanceled){
						error = 100;
						debug("Upload canceled");
						break;
					}
				}

			}

			if(error==0){
				// Here we wait while will be recieved response from server (we don't read response).
				// This is need because data is sent, but server can recieve last bytes after 1-2 sec.
				QDateTime endTime2 = QDateTime::currentDateTime().addSecs(timeout);
				while(socket.bytesAvailable()<75 && QDateTime::currentDateTime() < endTime2){
					QEventLoop eventLoop;					// Executing events loop while waiting for response

					QTimer timer;
					timer.setSingleShot(true);
					connect(&timer, SIGNAL(timeout()), &eventLoop, SLOT(quit()));
					timer.start(50);	// Timer is used to prevent infinity loop and provide access to the user to use Cancel button
					eventLoop.exec();
					timer.stop();

					if(isActionCanceled){
						error = 100;
						debug("Upload canceled");
						break;
					}
				}

debug("socket.bytesAvailable() => "+ QString::number(socket.bytesAvailable()));
			}

			// Upload finished
			debug("Upload finished. Sent "+ QString::number(countSentBytes) +" B. error="+ QString::number(error));
		}

		file.close();
		socket.close();

		if(sizeOfFile>0 && countSentBytes!=sizeOfFile){
			debug(QString::number(countSentBytes) +" != "+ QString::number(sizeOfFile));
			QMessageBox::critical(this, "Error 147", "Cannot upload file. Check your Internet connection");
			error = -8;
		}
	}

	if(error==0){			// We send request doCompleteUpload only if upload finished without errors
		SrunFunction.response="";
		SrunFunction.restory="";
		SrunFunction.restory.append(SLOT(bUpload4Resp()));

		QString uri="doCompleteUpload/"+ base64(SbUpload.uploadcode);
		if(isActionCanceled){
			hideMessage();
			return ;
		}
		runFunction(uri);
	}else{
		debug("Upload finished with error="+ QString::number(error) +", so we don't send doCompleteUpload");
		resume(1);
	}

	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bUpload4Resp(){
debug("bUpload4Resp()");
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory="";
//debug("res =\n"+res);

	if(res.indexOf("<response>")<0 || res.indexOf("</response>")<0){
		QString statusMessage=getPartQString(res, "<statusmessage>", "</statusmessage>");
		if(statusMessage!=""){
			if(statusMessage.length()<15) statusMessage+="         ";
			QMessageBox::critical(this, "Error", statusMessage);
		}else{
			QMessageBox::critical(this, "Error 7", "Can't upload file.");
		}
		hideMessage();
		return ;
	}

	bool L=false;
	QDomDocument doc("response");
	doc.setContent(res, true);

//debug("\n\nserver folder => "+ list);
	QDomElement root=doc.documentElement();
	QDomNode n=root.firstChild();
	while(!n.isNull()){
		QDomElement e=n.toElement();
		if(!e.isNull() && e.tagName()=="file"){
			Tfile file=getFileFromDomNode(n);
			if(file.pid==currentFolder.id) addToFileslist(file, true);
			if(file.name!="")	L=true;
			break;
		}
		n=n.nextSibling();
	}// for


	if(L){
		showMessage("File uploaded", true);
	}else{
		QMessageBox::critical(this, "Error 8", "Can't upload file");
	}

	resume(1);
}
//////////////////////////////////////////////////////////////////////
/*
void SMEStorageExplorer::startUploadProgressBar(){
debug("startUploadProgressBar()");
	qint64 fsize=SbDownload.file->size();
	if(fsize<0) fsize=0;

//debug("filepath = "+ SbDownload.filepath);
//debug("size = "+ intToQstring((int) SbDownload.size));
//debug("fsize = "+ intToQstring((int) fsize));

	ui->progressBar1->setValue(fsize);
	if(fsize>=SbDownload.size){		// file success download
		return ;
	}else{
		QTimer::singleShot(50, this, SLOT(startUploadProgressBar()));
		return ;
	}
}
*/
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::updateProgressBar(int bytesSent, int total){
	ui->progressBar1->setMaximum(total);
	ui->progressBar1->setValue(bytesSent);
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bSendToEmail(){
	if(!tryRunning()) return ;
debug("bSendToEmail()");
	SendToEmail.id="";
	showMessage("Preparing... ", true);
	QString names="", id="";
	int count=getCountFiles(filelist);
	for(int i=0; i<count; i++){
		if(filelist[i].name!="" && filelist[i].type==0 && filelist[i].node->isSelected()){
			if(id==""){
				id=filelist[i].id;
				names=filelist[i].name;
			}else{
				id+="," +filelist[i].id;
				names+=", " +filelist[i].name;
			}
		}
	}

	if(id==""){
		hideMessage();
		return ;
	}

	SendToEmail.id=id;
	sendEmailWnd.setWindowModality(Qt::ApplicationModal);
	sendEmailWnd.clear();
	sendEmailWnd.move(QPoint((int) (x()+ww/2-215), (int) (y()+wh/2-200)));

	sendEmailWnd.expiredEnable=false;
	sendEmailWnd.name=names;

	sendEmailWnd.initWnd();
	sendEmailWnd.show();

	hideMessage();

	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bSendToEmailResp(){
debug("bSendToEmailResp()");
	showMessage("Sharing via Email", true);
	QString email="", username="", countDays="", message="";
	email=sendEmailWnd.email;
	username=sendEmailWnd.username;
	message=sendEmailWnd.message;

	if(sendEmailWnd.expiredEnable) countDays=intToQstring(sendEmailWnd.countDays);

	SrunFunction.restory="";
	SrunFunction.restory.append(SLOT(bSendToEmail2Resp()));
	if(isActionCanceled){
		hideMessage();
		return ;
	}

//	QString uri="doSendEmail/"+ base64(SendToEmail.id) +","+ base64(email) +","+ base64(username) +","+ base64(message) +","+ base64(countDays);
	QString postData="function=doSendEmail";
	postData+="&fi_id="+ QUrl::toPercentEncoding(SendToEmail.id) +"&friend_email="+ QUrl::toPercentEncoding(email) +"&from_name="+ QUrl::toPercentEncoding(username) +"&text="+ QUrl::toPercentEncoding(message) +"&days="+ QUrl::toPercentEncoding(countDays);
	runFunction("", true, postData);

	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bSendToEmail2Resp(){
debug("bSendToEmail2Resp()");
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory="";

	int s0=res.indexOf("<n0>");
	int e0=res.lastIndexOf("</n0>");
	if(res.indexOf("<response>")<0 || res.indexOf("</response>")<0 || s0<0 || e0<0 || s0>e0){
		QMessageBox::critical(this, "Error", "Can't send file.");
		hideMessage();
		return ;
	}
	
	hideMessage();
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bSendToTwitter(){
	if(!tryRunning()) return ;
debug("bSendToTwitter()");
	SendToTwitter.id="";
	showMessage("Preparing... ", true);

	QString name="", id="";
	int count=getCountFiles(filelist);
	for(int i=0; i<count; i++){
		if(filelist[i].name!="" && filelist[i].type==0 && filelist[i].node->isSelected()){
			id=filelist[i].id;
			name=filelist[i].name;
			break;
		}
	}

	if(id==""){
		hideMessage();
		return ;
	}

	SendToTwitter.id=id;
	sendToTwitterWnd.setWindowModality(Qt::ApplicationModal);
	sendToTwitterWnd.clear();

	sendToTwitterWnd.move(QPoint((int) (x()+ww/2-215), (int) (y()+wh/2-200)));

	sendToTwitterWnd.name=name;

	sendToTwitterWnd.initWnd();
	sendToTwitterWnd.show();

	hideMessage();

	return ;
}
//////////////////////////////////////////////////////////////////////

void SMEStorageExplorer::bSendToTwitterResp(){
debug("bSendToTwitterResp()");
	showMessage("Sending to Twitter", true);

	SrunFunction.restory="";
	SrunFunction.restory.append(SLOT(bSendToTwitter2Resp()));
	if(isActionCanceled){
		hideMessage();
		return ;
	}

//	QString uri="doSendFileLinkToTwitter/"+ base64(SendToTwitter.id) +","+ base64(sendToTwitterWnd.message);
	QString postData="function=doSendFileLinkToTwitter";
	postData+="&fi_id="+ QUrl::toPercentEncoding(SendToTwitter.id) +"&message="+ QUrl::toPercentEncoding(sendToTwitterWnd.message);
	runFunction("", true, postData);

	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bSendToTwitter2Resp(){
debug("bSendToTwitter2Resp()");
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory="";
	QString status=getPartQString(res, "<status>", "</status>");
	QString statusMessage=getPartQString(res, "<statusmessage>", "</statusmessage>");
	if(status!="ok" && statusMessage!=""){
		if(statusMessage.length()<15) statusMessage+="         ";
		QMessageBox::critical(this, "Error", statusMessage);
		hideMessage();
		return ;
	}else if(status!="ok"){
		QMessageBox::critical(this, "Error", "Can't send file.");
		hideMessage();
		return ;
	}
	
	hideMessage();
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bFileUrl(){
	if(!tryRunning()) return ;
	debug("bFileUrl()");

	int count=getCountFiles(filelist), n=-1;
	for(int i=0; i<count; i++){
		if(filelist[i].name!="" && filelist[i].type==0 && filelist[i].node->isSelected()){
			n=i;
			break;
		}
	}

	if(n==-1){
		return ;
	}

	SFileUrl.n = n;

	QObject::connect(&fileurlWnd, SIGNAL(OKpressed()), this, SLOT(bFileUrlResp()));

	fileurlWnd.setWindowModality(Qt::ApplicationModal);
	fileurlWnd.move(QPoint((int) (x()+ww/2-215), (int) (y()+wh/2-105)));
	fileurlWnd.initWnd();
	fileurlWnd.show();

	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bFileUrlResp(){
debug("bFileUrlResp()");
	int n = SFileUrl.n;

	showMessage("Generating URL for file...", true);
	SrunFunction.restory="";
	SrunFunction.restory.append(SLOT(bFileUrlResp()));
	QString uri = "getFileUrl/"+ base64(filelist[n].id) + ","
		+ base64(QString::number(fileurlWnd.expireDays)) + ","
		+ base64(QString::number(fileurlWnd.expireHours)) + ","
		+ base64(QString::number(fileurlWnd.expireMinutes)) + ",";

	if(fileurlWnd.usePassword){
		uri += base64(fileurlWnd.password);
	}

	if(fileurlWnd.urltype==0){
		uri += ","+base64("n");
	}else{
		uri += ","+base64("y");
	}

	if(isActionCanceled){
		hideMessage();
		return ;
	}

	QString res = runFunction2(uri);
	QString shorturl=getPartQString(res, "<shorturl>", "</shorturl>");
	QString smeurl=getPartQString(res, "<url>", "</url>");
	QString statusmessage=getPartQString(res, "<statusmessage>", "</statusmessage>");
	if(shorturl=="" && smeurl==""){
		if(statusmessage=="Success") statusmessage = "";
		QMessageBox::critical(this, "Error", "Cannot get URL. "+statusmessage);
		hideMessage();
		return ;
	}

	if(shorturl!="") smeurl=shorturl;

	tinyurlWnd.setWindowModality(Qt::ApplicationModal);
	tinyurlWnd.move(QPoint((int) (x()+ww/2-215), (int) (y()+wh/2-105)));
	tinyurlWnd.name=filelist[n].name;
	tinyurlWnd.smeurl=smeurl;
	tinyurlWnd.initWnd();
	tinyurlWnd.show();

	hideMessage();
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bRequestShare(){
	if(!tryRunning()) return ;
debug("bRequestShare()");
	showMessage("Loading Groups List", true);

	SrunFunction.restory="";
	SrunFunction.restory.append(SLOT(bRequestShareResp()));
	QString uri="getGroupsList/";
	if(isActionCanceled){
		hideMessage();
		return ;
	}
	runFunction(uri);
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bRequestShareResp(){
debug("bRequestShareResp()");
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory="";

	if(res.indexOf("<response>")<0 || res.indexOf("</response>")<0){
		QMessageBox::critical(this, "Error", "Can't get groups list.");
		hideMessage();
		return ;
	}

	QDomDocument doc("response");
	doc.setContent(res, true);

	bool L=false;
	QDomElement root=doc.documentElement();
	QDomNode n=root.firstChild();
	while(!n.isNull()){
		QDomElement e = n.toElement();
		if(!e.isNull()){
			if(e.tagName()=="grouplist"){
				n=n.firstChild();
				L=true;
				break;
			}
		}
		n=n.nextSibling();
	}

	if(L){
		requestShareWnd.setWindowModality(Qt::ApplicationModal);
		requestShareWnd.clear();
		requestShareWnd.move(QPoint((int) (x()+ww/2-215), (int) (y()+wh/2-150)));

		bool L0=false;
		QDomNode usersList;
		for(int i=0; !n.isNull(); i++){
			QDomElement e=n.toElement();
			if(!e.isNull() && e.tagName()=="n"+intToQstring(i)){
				QString fid="", name="";
				QDomNode nf=n.firstChild();
				do{
					QDomElement el=nf.toElement();
					if(el.tagName()=="gr_id")		fid=el.text();
					if(el.tagName()=="gr_title")	name=el.text();
					if(el.tagName()=="gr_users"){
						usersList=nf;
						L0=true;
					}

					nf=nf.nextSibling();
				}while(!nf.isNull());

//debug("id="+ fid+" pid="+ pid+" name="+ name+" size="+ size+" encrypted="+ encrypted);
				if(fid.length()>0 && name.length()>0 && L0){
debug("GROUP  => "+name);
					requestShareWnd.add(true, fid, name);

					QString pid=fid;
					usersList=usersList.firstChild();
					for(int j=0; !usersList.isNull(); j++){
						QDomElement e=usersList.toElement();
						if(!e.isNull() && e.tagName()=="n"+intToQstring(j)){
							QString fid="", name="";
							QDomNode nf=usersList.firstChild();
							do{
								QDomElement el=nf.toElement();
								if(el.tagName()=="us_id")		fid=el.text();
								if(el.tagName()=="us_name")	name=el.text();

								nf=nf.nextSibling();
							}while(!nf.isNull());

							if(fid.length()>0 && name.length()>0){
debug("USER  =>      "+name);
								requestShareWnd.add(false, fid, name);
							}
							usersList=usersList.nextSibling();
						}
					}// for
				}

				n=n.nextSibling();
			}
		}// for

		if(requestShareWnd.countG<1 || requestShareWnd.countU<1){
			requestShareWnd.clear();
			hideMessage();
			return ;
		}

		requestShareWnd.initWnd();
		requestShareWnd.show();
	}// if

	hideMessage();
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bRequestShare2(){
debug("bRequestShare2()");
	showMessage("Sending File Request...", true);
	QString uid=requestShareWnd.uid;
	QString gid=requestShareWnd.gid;
	QString comment=requestShareWnd.comment;
//debug("uid "+ uid +" gid "+ gid +" comment "+ comment);
//return ;
	if(uid==""){
		QMessageBox::critical(this, "Error", "User not found.");
		hideMessage();
		return ;
	}

	if(gid==""){
		QMessageBox::critical(this, "Error", "Group not found.");
		hideMessage();
		return ;
	}

	SrunFunction.restory="";
	SrunFunction.restory.append(SLOT(bRequestShare2Resp()));
	if(isActionCanceled){
		hideMessage();
		return ;
	}
//	QString uri="doRequestFile/"+ base64(uid) +","+ base64(gid) +","+ base64(comment);
	QString postData="function=doRequestFile";
	postData+="&us_id="+ QUrl::toPercentEncoding(uid) +"&gr_id="+ QUrl::toPercentEncoding(gid) +"&comment="+ QUrl::toPercentEncoding(comment);
	runFunction("", true, postData);
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bRequestShare2Resp(){
debug("bRequestShare2Resp()");

	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory="";

	QString status=getPartQString(res, "<status>", "</status>");
	QString statusMessage=getPartQString(res, "<statusmessage>", "</statusmessage>");
	if(status!="ok" && statusMessage!=""){
		if(statusMessage.length()<15) statusMessage+="         ";
		QMessageBox::critical(this, "Error", statusMessage);
		hideMessage();
		return ;
	}else if(status!="ok"){
		QMessageBox::critical(this, "Error", "Unknown error");
		hideMessage();
		return ;
	}

	hideMessage();
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bAutoShareWithGroupUser(){
	if(!tryRunning()) return ;
debug("bAutoShareWithGroupUser()");
	showMessage("Loading Groups List", true);

	SrunFunction.restory="";
	SrunFunction.restory.append(SLOT(bAutoShareWithGroupUserResp()));
	QString uri="getGroupsList/";
	if(isActionCanceled){
		if(autoShareRuleWnd.isWaiting)	autoShareRuleWnd.show();
		hideMessage();
		return ;
	}
	runFunction(uri);
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bAutoShareWithGroupUserResp(){
debug("bAutoShareWithGroupUserResp()");
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory="";

	if(res.indexOf("<response>")<0 || res.indexOf("</response>")<0){
		QMessageBox::critical(this, "Error", "Can't get groups list.");
		if(autoShareRuleWnd.isWaiting)	autoShareRuleWnd.show();
		hideMessage();
		return ;
	}

	QDomDocument doc("response");
	doc.setContent(res, true);
	bool L=false;
	QDomElement root=doc.documentElement();
	QDomNode n=root.firstChild();
	while(!n.isNull()){
		QDomElement e = n.toElement();
		if(!e.isNull()){
			if(e.tagName()=="grouplist"){
				n=n.firstChild();
				L=true;
				break;
			}
		}
		n=n.nextSibling();
	}

	if(L){
		autoShareWithGroupUserWnd.setWindowModality(Qt::ApplicationModal);
		autoShareWithGroupUserWnd.clear();
		autoShareWithGroupUserWnd.move(QPoint((int) (x()+ww/2-255), (int) (y()+wh/2-200)));
		if(currentFolder.name!=""){
			autoShareWithGroupUserWnd.pname=currentFolder.name;
		}else{
			autoShareWithGroupUserWnd.pname="My Cloud Files";
		}
		int count=getCountFiles(filelist);
		QString rule="";
		for(int i=0; i<count; i++){
			if(filelist[i].name!="" && filelist[i].type==0 && filelist[i].node->isSelected()){
				rule=filelist[i].name;
				break;
			}
		}
		autoShareWithGroupUserWnd.rule=rule;

		bool L0=false;
		QDomNode usersList;
		for(int i=0; !n.isNull(); i++){
			QDomElement e=n.toElement();
			if(!e.isNull() && e.tagName()=="n"+intToQstring(i)){
				QString fid="", name="";
				QDomNode nf=n.firstChild();
				do{
					QDomElement el=nf.toElement();
					if(el.tagName()=="gr_id")		fid=el.text();
					if(el.tagName()=="gr_title")	name=el.text();
					if(el.tagName()=="gr_users"){
						usersList=nf;
						L0=true;
					}

					nf=nf.nextSibling();
				}while(!nf.isNull());

//debug("id="+ fid+" pid="+ pid+" name="+ name+" size="+ size+" encrypted="+ encrypted);

				if(fid.length()>0 && name.length()>0 && L0){
debug("GROUP  => "+name);
					autoShareWithGroupUserWnd.addToTree(fid, name, 3);

					QString pid=fid;
					usersList=usersList.firstChild();
					for(int j=0; !usersList.isNull(); j++){
						QDomElement e=usersList.toElement();
						if(!e.isNull() && e.tagName()=="n"+intToQstring(j)){
							QString fid="", name="", type="";
							QDomNode nf=usersList.firstChild();
							do{
								QDomElement el=nf.toElement();
								if(el.tagName()=="us_id")		fid=el.text();
								if(el.tagName()=="us_name")	name=el.text();

								nf=nf.nextSibling();
							}while(!nf.isNull());

							if(fid.length()>0 && name.length()>0){
debug("USER  =>      "+name);
								autoShareWithGroupUserWnd.addToTree(fid, name, 2, pid);
							}
							usersList=usersList.nextSibling();
						}
					}// for

				}

				n=n.nextSibling();
			}
		}// for

		autoShareWithGroupUserWnd.initWnd();
		autoShareWithGroupUserWnd.show();
	}// if

	hideMessage();
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bAutoShareWithGroupUser2(){
	if(!tryRunning()) return ;
debug("bAutoShareWithGroupUser2()");
	showMessage("Preparing...", true);

	QString grid="", usid="";
	bool L=false;
	for(int i=0; i<autoShareWithGroupUserWnd.countGU; i++){
		if(autoShareWithGroupUserWnd.grouplist[i].node->isSelected()){
			if(autoShareWithGroupUserWnd.grouplist[i].type==2){		// user
				grid=autoShareWithGroupUserWnd.grouplist[i].pid;
				usid=autoShareWithGroupUserWnd.grouplist[i].id;

			}else{
				grid=autoShareWithGroupUserWnd.grouplist[i].id;
			}
			L=true;
			break;
		}
	}

	if(!L){
		QMessageBox::critical(this, "Error", "Select group or user");
		autoShareWithGroupUserWnd.show();
		//autoShareWithGroupUserWnd.clear2();
		hideMessage();
		return ;
	}

	QString rule=autoShareWithGroupUserWnd.rule;
/*
	if(rule==""){
		autoShareWithGroupUserWnd.clear2();
		hideMessage();
		return ;
	}
*/
	QString rl_type="";
	if(autoShareWithGroupUserWnd.rfname){
		rl_type+="fi_name";
	}
	if(autoShareWithGroupUserWnd.rext){
		if(rl_type!="") rl_type+=",";
		rl_type+="fi_extension";
	}
	if(autoShareWithGroupUserWnd.rdescription){
		if(rl_type!="") rl_type+=",";
		rl_type+="fi_description";
	}

	QString rl_folder="0";
	if(autoShareWithGroupUserWnd.shareInPfolder)	rl_folder=currentFolder.id;
	QString rl_subfolders="n";

	autoShareWithGroupUserWnd.hide();
	autoShareWithGroupUserWnd.clear2();


	SrunFunction.restory="";
	SrunFunction.restory.append(SLOT(bAutoShareWithGroupUser2Resp()));
	QString postData="function=doAddAutoShareRule&gr_id="+ QUrl::toPercentEncoding(grid) +"&us_id="+ QUrl::toPercentEncoding(usid)
		+"&rl_rule="+ QUrl::toPercentEncoding(rule) +"&rl_type="+ QUrl::toPercentEncoding(rl_type) +"&rl_folder="+ QUrl::toPercentEncoding(rl_folder);
	showMessage("Adding auto sharing rule...", true);

	if(isActionCanceled){
		if(autoShareRuleWnd.isWaiting)	autoShareRuleWnd.show();
		hideMessage();
		return ;
	}
	runFunction("", true, postData);
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bAutoShareWithGroupUser2Resp(){
debug("bAutoShareWithGroupUser2Resp()");
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory="";

	QString status = getPartQString(res, "<status>", "</status>");
	QString statusmessage = getPartQString(res, "<statusmessage>", "</statusmessage>");
	QString rl_id = getPartQString(res, "<rl_id>", "</rl_id>");
debug("status="+status +"; statusmessage="+statusmessage +"; rl_id="+rl_id);
	if(status!="ok" || rl_id==""){
		QMessageBox::critical(this, "Error", "Can't add auto sharing rule: "+statusmessage);
		if(autoShareRuleWnd.isWaiting)	autoShareRuleWnd.show();
		hideMessage();
		return ;
	}

	hideMessage();

	if(autoShareRuleWnd.isWaiting){
		// New rule was added. So, we need to refresh window autoShareRuleWnd
		bAutoSharingRules();
	}

	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bAutoSharingRules(){
	if(!tryRunning()) return ;
debug("bAutoSharingRules()");
	showMessage("Loading Groups List", true);

	SrunFunction.restory="";
	SrunFunction.restory.append(SLOT(bAutoSharingRulesResp()));
	QString uri="getGroupsList/";
	if(isActionCanceled){
		hideMessage();
		return ;
	}
	runFunction(uri);
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bAutoSharingRulesResp(){
debug("bAutoSharingRulesResp()");
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory="";

	if(res.indexOf("<response>")<0 || res.indexOf("</response>")<0){
		QMessageBox::critical(this, "Error", "Can't get groups list.");
		if(autoShareRuleWnd.isWaiting)	autoShareRuleWnd.show();
		hideMessage();
		return ;
	}

	QDomDocument doc("response");
	doc.setContent(res, true);
	bool L1=false, L2=false;
	QDomElement root=doc.documentElement();
	QDomNode n=root.firstChild();
	QDomNode groups, sharingrules;
	while(!n.isNull()){
		QDomElement e = n.toElement();
		if(!e.isNull()){
			if(e.tagName()=="grouplist"){
				groups=n.firstChild();
				L1=true;
			}
			if(e.tagName()=="sharingrules"){
				sharingrules=n.firstChild();
				L2=true;
			}
		}
		n=n.nextSibling();
	}

	if(L1 && L2){
		int countFI=0;
		QString *foldersId=new QString[10000];
		autoShareRuleWnd.setWindowModality(Qt::ApplicationModal);
		autoShareRuleWnd.clear();
		autoShareRuleWnd.move(QPoint((int) (x()+ww/2-250), (int) (y()+wh/2-200)));

		Tfile *groupslist=new Tfile[10000];
		for(int i=0; i<10000; i++){
			groupslist[i].id="";
			groupslist[i].name="";
		}

		n=groups;
		for(int i=0; !n.isNull(); i++){
			QDomElement e=n.toElement();
			if(!e.isNull() && e.tagName()=="n"+intToQstring(i)){
				QString fid="", name="";

				QDomNode nf=n.firstChild();
				do{
					QDomElement el=nf.toElement();
					if(el.tagName()=="gr_id")		fid=el.text();
					if(el.tagName()=="gr_title")	name=el.text();
					nf=nf.nextSibling();
				}while(!nf.isNull());

//debug("id="+ fid+" pid="+ pid+" name="+ name+" size="+ size+" encrypted="+ encrypted);
				if(fid.length()>0 && name.length()>0){
debug("GROUP  => "+name);
					groupslist[i].id=fid;
					groupslist[i].name=name;
				}
				n=n.nextSibling();
			}
		}// for

		n=sharingrules;
		for(int i=0; !n.isNull(); i++){
			QDomElement e=n.toElement();
			if(!e.isNull() && e.tagName()=="n"+intToQstring(i)){
				QString rid="", gid="", uid="", rrule="", rtype="", rfolder="", rsubfolders="";
				QDomNode nf=n.firstChild();
				do{
					QDomElement el=nf.toElement();
					if(el.tagName()=="rl_id")				rid=el.text();
					if(el.tagName()=="gr_id")				gid=el.text();
					if(el.tagName()=="us_id")				uid=el.text();
					if(el.tagName()=="rl_rule")			rrule=el.text();
					if(el.tagName()=="rl_type")			rtype=el.text();
					if(el.tagName()=="rl_folder")			rfolder=el.text();
					if(el.tagName()=="rl_subfolders")	rsubfolders=el.text();

					nf=nf.nextSibling();
				}while(!nf.isNull());

				if(rid!=""){
//debug("id  => "+rid+ "; gid  => "+gid+ "; uid  => "+uid+ "; rrule  => "+rrule+ "; rtype  => "+rtype+ "; rfolder  => "+rfolder+ "; rsubfolders  => "+rsubfolders);
					QString gname="";
					for(int i=0; i<10000; i++){
						if(groupslist[i].id==gid){
							gname=groupslist[i].name;
							break;
						}
					}

					if(rrule==""){
						rrule="All files";
					}else{
						QString sz="";
						if(rtype.indexOf("fi_name")>=0){
							sz+="name";
						}

						if(rtype.indexOf("fi_extension")>=0){
							if(sz!="") sz+=", ";
							sz+="extension";
						}

						if(rtype.indexOf("fi_description")>=0){
							if(sz!="") sz+=", ";
							sz+="description";
						}

						rrule="Text \""+ rrule +"\" in "+sz;
					}

					if(gname!=""){
						autoShareRuleWnd.addToTree(rid, gname, rrule, "", rfolder);
						foldersId[countFI]=rfolder;
						countFI++;
					}
				}
				n=n.nextSibling();
			}
		}// for

//		autoShareRuleWnd.initWnd();
//		autoShareRuleWnd.show();
//		hideMessage();

		for(int i=0; i<countFI; i++){
			for(int j=i+1; j<countFI; j++){
				if(foldersId[i]==foldersId[j]) foldersId[j]="";
			}
		}
		QString fIds="";
		for(int i=0; i<countFI; i++){
			if(foldersId[i]!="" && foldersId[i]!="0"){
				if(fIds!="") fIds+=",";
				fIds+=foldersId[i];
			}
		}
debug("fIds = "+fIds);
//return ;
		bAutoSharingRules2(fIds);
		return ;
	}// if

	autoShareRuleWnd.clear();
	hideMessage();
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bAutoSharingRules2(QString ids){
debug("bAutoSharingRules2()");
	showMessage("Preparing...", true);
	if(ids==""){
		autoShareRuleWnd.initWnd();
		autoShareRuleWnd.show();
		hideMessage();
		return ;
	}

	if(isActionCanceled){
		autoShareRuleWnd.clear();
		hideMessage();
		return ;
	}

	SrunFunction.restory="";
	SrunFunction.restory.append(SLOT(bAutoSharingRules2Resp()));
	QString postData="function=getFilesInfo&fi_id="+ QUrl::toPercentEncoding(ids);
	showMessage("Retrieving Folders Names...", true);

	if(isActionCanceled){
		autoShareRuleWnd.clear();
		hideMessage();
		return ;
	}
	runFunction("", true, postData);
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bAutoSharingRules2Resp(){
debug("bAutoSharingRules2Resp()");
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory="";

	if(res.indexOf("<response>")<0 || res.indexOf("</response>")<0){
		QMessageBox::critical(this, "Error", "Can't get folders info.");
		autoShareRuleWnd.clear();
		hideMessage();
		return ;
	}

	QDomDocument doc("response");
	doc.setContent(res, true);

	bool L=false;
	QDomElement root=doc.documentElement();
	QDomNode n=root.firstChild();
	while(!n.isNull()){
		QDomElement e = n.toElement();
		if(!e.isNull()){
			if(e.tagName()=="filelist"){
				n=n.firstChild();
				L=true;
				break;
			}
		}
		n=n.nextSibling();
	}

	if(L){
		for(int i=0; !n.isNull(); i++){
			QDomElement e=n.toElement();
			if(!e.isNull() && e.tagName()=="n"+intToQstring(i)){
				Tfile file=getFileFromDomNode(n);
				autoShareRuleWnd.addFolder(file.id, file.name);
				n=n.nextSibling();
			}
		}// for
	}// if

	autoShareRuleWnd.initWnd();
	autoShareRuleWnd.show();
	hideMessage();
	return ;
}
//////////////////////////////////////////////////////////////////////

void SMEStorageExplorer::bDeleteAutoShare(){
	if(!tryRunning()) return ;
debug("bDeleteAutoShare()");
	showMessage("Deleting rule...", true);
	SrunFunction.restory="";
	SrunFunction.restory.append(SLOT(bDeleteAutoShareResp()));
	QString uri="doDeleteAutoShareRule/"+ base64(autoShareRuleWnd.selectedid);
	runFunction(uri);
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bDeleteAutoShareResp(){
debug("bDeleteAutoShareResp()");
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory="";

	QString status;
	status=getPartQString(res, "<status>", "</status>");
	if(status!="ok"){
		QMessageBox::critical(this, "Error", "Can't delete rule");
	}

	autoShareRuleWnd.deleteFromTree(autoShareRuleWnd.selectedid);
	autoShareRuleWnd.show();
	hideMessage();
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bAbout(){
	if(!tryRunning()) return ;
debug("bAbout()");
	aboutWnd.setWindowModality(Qt::ApplicationModal);
	aboutWnd.move(QPoint((int) (x()+ww/2-200), y()));
	aboutWnd.show();
	hideMessage();
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::changeExplorerTypeToCloud(){
	if(!tryRunning()) return ;
debug("changeExplorerTypeToCloud()");
	explorerType=0;
	refreshAll(false, true);

	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::changeExplorerTypeToPublic(){
	if(!tryRunning()) return ;
debug("changeExplorerTypeToPublic()");
	explorerType=1;
	refreshAll(false, true);
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::changeExplorerTypeToFavourite(){
	if(!tryRunning()) return ;
debug("changeExplorerTypeToFavourite()");
	explorerType=2;
	refreshAll(false, true);
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::changeExplorerTypeToSearch(){
	if(!tryRunning()) return ;
debug("changeExplorerTypeToSearch()");
	explorerType=3;
	refreshAll(false, true);
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::changeExplorerTypeToClipboard(){
	if(!tryRunning()) return ;
debug("changeExplorerTypeToClipboard()");
	explorerType=4;
	refreshAll(false, true);
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::changeExplorerTypeToGroups(){
	if(!tryRunning()) return ;
debug("changeExplorerTypeToGroups()");
	explorerType=5;
	refreshAll(false, true);
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::changeExplorerTypeToTrash(){
	if(!tryRunning()) return ;
debug("changeExplorerTypeToTrash()");
	explorerType=6;
	refreshAll(false, true);
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bImportExport(){
	if(!tryRunning()) return ;
debug("bImportExport()");
	int x=ui->pushButton6->x();
	int y=ui->pushButton6->y()+ui->pushButton6->height()-2;

	QPoint pt;
	pt.setX(x);
	pt.setY(y);

	pt=mapToGlobal(pt);
	importExportMenu->exec(pt);
//debug("pt => x => "+ intToQstring(pt.x())+" y => "+intToQstring(pt.y()));
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bImport(){
	if(!tryRunning()) return ;
debug("bImport()");
	impExpStart(true);
	return ;
}
//////////////////////////////////////////////////////////////////////

void SMEStorageExplorer::bExport(){
	if(!tryRunning()) return ;
debug("bExport()");
	impExpStart(false);
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::impExpStart(bool import){
debug("impExpStart()");
	SbImpExp.import=import;
	showMessage("Retrieving Import/Export Providers", true);
	SrunFunction.restory="";
	SrunFunction.restory.append(SLOT(bImportResp()));
	QString uri="getImpExpProviders/";
	if(isActionCanceled){
		hideMessage();
		return ;
	}
	runFunction(uri);

	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bImportResp(){
debug("bImportResp()");
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory="";

	importWnd.clear();
	importWnd.setWindowModality(Qt::ApplicationModal);
	importWnd.move(QPoint((int) (x()+ww/2-215), y()));
	if(res.indexOf("<response>")<0 || res.indexOf("</response>")<0){
		QMessageBox::critical(this, "Error", "Can't get groups list.");
		hideMessage();
		return ;
	}

	QDomDocument doc("response");
	doc.setContent(res, true);
	bool L=false;
	QDomElement root=doc.documentElement();
	QDomNode n=root.firstChild();
	while(!n.isNull()){
		QDomElement e = n.toElement();
		if(!e.isNull()){
			if(e.tagName()=="import"){
				n=n.firstChild();
				L=true;
				break;
			}
		}
		n=n.nextSibling();
	}

	if(L){
		for(int i=0; !n.isNull(); i++){
			QDomElement e=n.toElement();
			if(!e.isNull() && e.tagName()=="n"+intToQstring(i)){
				QString fid="", name="";
				QDomNode nf=n.firstChild();
				do{
					QDomElement el=nf.toElement();
					if(el.tagName()=="pr_id")		fid=el.text();
					if(el.tagName()=="pr_name")	name=el.text();
					nf=nf.nextSibling();
				}while(!nf.isNull());

//debug("id="+ fid+" pid="+ pid+" name="+ name+" type="+ type+" size="+ size+" encrypted="+ encrypted);
				if(fid.length()>0 && name.length()>0){
					importWnd.addToTree(fid, name);
				}
				n=n.nextSibling();
			}
		}// for

		SbImpExp.n=-1;
		int count=getCountFiles(filelist);				// get first selected folder
		for(int i=0; i<count; i++){
			if(filelist[i].type==1 && filelist[i].node->isSelected()){
				SbImpExp.n=i;
				break;
			}
		}

		if(SbImpExp.n>=0){
			importWnd.folderid=filelist[SbImpExp.n].id;
			importWnd.foldername=filelist[SbImpExp.n].name;
		}else{
			importWnd.folderid="0";
			importWnd.foldername="Cloud";
		}

		importWnd.import=SbImpExp.import;
		importWnd.initWnd();
		importWnd.show();
		hideMessage();
	}// if

	hideMessage();

	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::importGetProviderMetaFields(){
debug("importGetProviderMetaFields()");
	showMessage("Retrieving Provider Meta Fields", true);
	SrunFunction.restory="";
	SrunFunction.restory.append(SLOT(importGetProviderMetaFieldsResp()));
	QString uri="getAddProviderMetaFields/"+base64(importWnd.providerid);
	if(isActionCanceled){
		importWnd.unlockAll();
		hideMessage();
		return ;
	}
	runFunction(uri);

	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::importGetProviderMetaFieldsResp(){
debug("importGetProviderMetaFieldsResp()");
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory="";
	QString title=getPartQString(res, "<provider>", "</provider>");
	if(title==""){
		title="Login";
	}else{
		title+=" Login";
	}
	expProviderLoginWnd.clear();
	expProviderLoginWnd.setWindowModality(Qt::ApplicationModal);
	expProviderLoginWnd.setWindowTitle(title);

	int y=10;
	if(res.indexOf("<response>")<0 || res.indexOf("</response>")<0){
		importWnd.unlockAll();
		QMessageBox::critical(this, "Error", "Can't get provider fields.");
		hideMessage();
		return ;
	}

	if(res.indexOf("<aouthsupport>y</aouthsupport>")>0){
		importWnd.unlockAll();
		QMessageBox::critical(this, "Error", "Cannot import/export from this provider via this tool. You can do it via site.");
		hideMessage();
		return ;
	}

	QDomDocument doc("response");
	doc.setContent(res, true);
	bool L=false;
	QDomElement root=doc.documentElement();
	QDomNode n=root.firstChild();
	while(!n.isNull()){
		QDomElement e = n.toElement();
		if(!e.isNull()){
			if(e.tagName()=="fields"){
				n=n.firstChild();
				L=true;
				break;
			}
		}
		n=n.nextSibling();
	}

	if(L){
		for(int i=0; !n.isNull(); i++){
			QDomElement e=n.toElement();
			if(!e.isNull() && e.tagName()=="n"+intToQstring(i)){

				QString fid="", title="", defaultvalue="", ptype="";
				QDomNode nf=n.firstChild();
				do{

					QDomElement el=nf.toElement();
					if(el.tagName()=="n0")	fid=el.text();
					if(el.tagName()=="n1")	title=el.text();
					if(el.tagName()=="n2")	defaultvalue=el.text();
//					if(el.tagName()=="n3")	defaultvalue=el.text();
					if(el.tagName()=="n4")	ptype=el.text();
					nf=nf.nextSibling();
				}while(!nf.isNull());

				if(fid.length()>0 && title.length()>0){
					y=expProviderLoginWnd.addField(fid, title, defaultvalue, ptype, y);
				}
				n=n.nextSibling();
			}
		}// for

		y+=4;
		expProviderLoginWnd.pushButton1->setGeometry(QRect(160, y, 85, 29));
		expProviderLoginWnd.pushButton2->setGeometry(QRect(260, y, 85, 29));
		y+=33;
		expProviderLoginWnd.widget1->setGeometry(QRect(0, 0, 500, y));
		expProviderLoginWnd.setGeometry(QRect(0, 0, 500, y));

		expProviderLoginWnd.move(QPoint((int) (this->x()+ww/2-225), this->y()));
		expProviderLoginWnd.initWnd();
		expProviderLoginWnd.show();
		importWnd.unlockAll();
	}// if

	hideMessage();

	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::importSetProviderLogin(){
debug("importSetProviderLogin()");
	showMessage("Sets Provider Meta Fields", true);
	importWnd.lockAll();
	QString fieldsres=expProviderLoginWnd.fieldsres;
debug("fieldsres="+fieldsres);

/*
	SrunFunction.restory="";
	SrunFunction.restory.append(SLOT(importSetProviderLoginResp()));
	QString uri="doImpExpLogin/"+ base64(importWnd.providerid) +","+ base64(fieldsres);
	if(isActionCanceled){
		importWnd.unlockAll();
		hideMessage();
		return ;
	}
	runFunction(uri);
*/

	SrunFunction.restory="";
	SrunFunction.restory.append(SLOT(importSetProviderLoginResp()));
	QString postData="function=doImpExpLogin";
	postData+="&pr_id="+ QUrl::toPercentEncoding(importWnd.providerid) +"&data="+ QUrl::toPercentEncoding(fieldsres);

	if(isActionCanceled){
		importWnd.unlockAll();
		hideMessage();
		return ;
	}
	runFunction("", true, postData);
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::importSetProviderLoginResp(){
debug("importSetProviderLoginResp()");
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory="";
	QString status=getPartQString(res, "<status>", "</status>");
	QString statusMessage=getPartQString(res, "<statusmessage>", "</statusmessage>");
	if(status!="ok" && statusMessage!=""){
		if(statusMessage.length()<15) statusMessage+="         ";
		importWnd.unlockAll();
		QMessageBox::critical(this, "Error", statusMessage);
		hideMessage();
		return ;
	}else if(status!="ok"){
		importWnd.unlockAll();
		QMessageBox::critical(this, "Error", "Bad parameter");
		hideMessage();
		return ;
	}

	showMessage("Retrieving Sources...", true);
	SrunFunction.restory="";
	SrunFunction.restory.append(SLOT(importSetProviderLoginResp2()));
	QString func="doImpChoseSource";
	if(!importWnd.import)	func="doExpChoseDest";
	QString uri=func+"/"+ base64(importWnd.providerid) +","+ base64("0");
	if(isActionCanceled){
		importWnd.unlockAll();
		hideMessage();
		return ;


	}
	runFunction(uri);
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::importSetProviderLoginResp2(){
debug("importSetProviderLoginResp2()");
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory="";
	QDomDocument doc("response");
	doc.setContent(res, true);
	bool L=false;
	QDomElement root=doc.documentElement();
	QDomNode n=root.firstChild();
	while(!n.isNull()){
		QDomElement e = n.toElement();
		if(!e.isNull()){
			if(e.tagName()=="folders"){
				n=n.firstChild();
				L=true;
				break;
			}
		}
		n=n.nextSibling();
	}

	if(L){
		for(int i=0; !n.isNull(); i++){
			QDomElement e=n.toElement();

			if(!e.isNull() && e.tagName()=="n"+intToQstring(i)){
				QString fid="", name="";
				QDomNode nf=n.firstChild();
				do{
					QDomElement el=nf.toElement();
					if(el.tagName()=="id")		fid=el.text();
					if(el.tagName()=="name")	name=el.text();
					nf=nf.nextSibling();
				}while(!nf.isNull());

				if(fid.length()>0 && name.length()>0){
					importWnd.addFolderToTree(fid, name);
				}
				n=n.nextSibling();
			}
		}// for
	}// if

	if(L){
		showMessage("Success", true);
	}else{
		QMessageBox::critical(this, "Error", "Can't get destination folders list");
	}

	hideMessage();
	importWnd.unlockAll();
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::runImport(){
debug("runImport()");
	showMessage("Choosing Source...", true);
	QString sourceId=importWnd.destinationId;
debug("sourceId="+sourceId);

	SrunFunction.restory="";
	SrunFunction.restory.append(SLOT(runImportResp()));
	QString uri="doImpChoseSource/"+ base64(importWnd.providerid) +","+ base64("1")  +","+ base64(sourceId);
	if(isActionCanceled){
		importWnd.unlockAll();
		hideMessage();
		return ;
	}
	runFunction(uri);
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::runImportResp(){
debug("runImportResp()");
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory="";

	QString status=getPartQString(res, "<status>", "</status>");
	QString statusMessage=getPartQString(res, "<statusmessage>", "</statusmessage>");
	if(status!="ok" && statusMessage!=""){
		if(statusMessage.length()<15) statusMessage+="         ";
		importWnd.unlockAll();
		QMessageBox::critical(this, "Error", statusMessage);
		hideMessage();
		return ;
	}else if(status!="ok"){
		importWnd.unlockAll();
		QMessageBox::critical(this, "Error", "Bad parameter");
		hideMessage();
		return ;
	}

	showMessage("Choosing Destination...", true);

	QString destinationId="";
	int count=getCountFiles(filelist);
	for(int i=0; i<count; i++){
		if(filelist[i].name!="" && filelist[i].node->isSelected()){
			destinationId=filelist[i].id;
			break;
		}
	}


	SrunFunction.restory="";
	SrunFunction.restory.append(SLOT(runImportResp2()));
	QString uri="doImpChoseDest/"+ base64(importWnd.providerid) +","+ base64(destinationId);
	if(isActionCanceled){
		importWnd.unlockAll();
		hideMessage();
		return ;
	}
	runFunction(uri);
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::runImportResp2(){
debug("runImportResp2()");
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory="";

	QString status=getPartQString(res, "<status>", "</status>");
	QString statusMessage=getPartQString(res, "<statusmessage>", "</statusmessage>");
	if(status!="ok" && statusMessage!=""){
		if(statusMessage.length()<15) statusMessage+="         ";
		importWnd.unlockAll();
		QMessageBox::critical(this, "Error", statusMessage);
		hideMessage();
		return ;
	}else if(status!="ok"){
		importWnd.unlockAll();
		QMessageBox::critical(this, "Error", "Bad parameter");
		hideMessage();
		return ;
	}

	showMessage("Starting Import in Background...", true);
	SrunFunction.restory="";
	SrunFunction.restory.append(SLOT(runImportResp3()));
	QString uri="doImportInBackground/"+ base64(importWnd.providerid);
	if(isActionCanceled){
		importWnd.unlockAll();
		hideMessage();
		return ;
	}
	runFunction(uri);
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::runImportResp3(){
debug("runImportResp3()");
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory="";
	QString status=getPartQString(res, "<status>", "</status>");
	QString statusMessage=getPartQString(res, "<statusmessage>", "</statusmessage>");
	if(status!="ok" && statusMessage!=""){
		if(statusMessage.length()<15) statusMessage+="         ";
		importWnd.unlockAll();
		QMessageBox::critical(this, "Error", statusMessage);
		hideMessage();
		return ;
	}else if(status!="ok"){
		importWnd.unlockAll();

		QMessageBox::critical(this, "Error", "Bad parameter");
		hideMessage();
		return ;
	}

	QMessageBox::information(this, "Info", "Import started in background");
	importWnd.unlockAll();
	importWnd.clear2();
	importWnd.hide();
	hideMessage();
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::runExport(){
debug("runExport()");
	showMessage("Choosing Source...", true);
	QString destinationId=importWnd.destinationId;
debug("destinationId="+destinationId);

	QString sourcetype="0";
	int ftype=-1;
	if(importWnd.comboBox1->currentIndex()==1){
		ftype=1;
		sourcetype="1";
	}else	if(importWnd.comboBox1->currentIndex()==2){
		ftype=0;
		sourcetype="2";
	}

	QString ids="";
	if(ftype>=0){
		int count=getCountFiles(filelist);
		for(int i=0; i<count; i++){
			if(filelist[i].type==ftype && filelist[i].node->isSelected()){
				if(ids==""){
					ids=filelist[i].id;
				}else{
					ids+="," +filelist[i].id;
				}
			}
		}
	}

	SrunFunction.restory="";
	SrunFunction.restory.append(SLOT(runExportResp()));
	if(isActionCanceled){
		importWnd.unlockAll();
		hideMessage();
		return ;
	}

//	QString uri="doExpChoseSource/"+ base64(importWnd.providerid) +","+ base64(sourcetype)  +","+ base64(ids);
	QString postData="function=doExpChoseSource";
	postData+="&pr_id="+ QUrl::toPercentEncoding(importWnd.providerid) +"&sourcetype="+ QUrl::toPercentEncoding(sourcetype) +"&sourceids="+ QUrl::toPercentEncoding(ids);
	runFunction("", true, postData);
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::runExportResp(){
debug("runExportResp()");
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory="";
	QString status=getPartQString(res, "<status>", "</status>");
	QString statusMessage=getPartQString(res, "<statusmessage>", "</statusmessage>");
	if(status!="ok" && statusMessage!=""){
		if(statusMessage.length()<15) statusMessage+="         ";
		importWnd.unlockAll();
		QMessageBox::critical(this, "Error", statusMessage);
		hideMessage();
		return ;
	}else if(status!="ok"){
		importWnd.unlockAll();
		QMessageBox::critical(this, "Error", "Bad parameter");
		hideMessage();
		return ;
	}

	showMessage("Choosing Destination...", true);

	SrunFunction.restory="";
	SrunFunction.restory.append(SLOT(runExportResp2()));
	QString uri="doExpChoseDest/"+ base64(importWnd.providerid) +","+ base64("1") +","+ base64(importWnd.destinationId);
	if(isActionCanceled){
		importWnd.unlockAll();
		hideMessage();
		return ;
	}
	runFunction(uri);
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::runExportResp2(){
debug("runExportResp2()");
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory="";
	QString status=getPartQString(res, "<status>", "</status>");
	QString statusMessage=getPartQString(res, "<statusmessage>", "</statusmessage>");
	if(status!="ok" && statusMessage!=""){
		if(statusMessage.length()<15) statusMessage+="         ";
		importWnd.unlockAll();
		QMessageBox::critical(this, "Error", statusMessage);
		hideMessage();
		return ;
	}else if(status!="ok"){
		importWnd.unlockAll();
		QMessageBox::critical(this, "Error", "Bad parameter");
		hideMessage();
		return ;
	}


	int type = -1;
	QString ids = "";
	for(int i=0, count=getCountFiles(filelist); i<count; i++){
		if(filelist[i].name!="" && filelist[i].node->isSelected()){
			if(type>=0 && type!=filelist[i].type){
				continue;		// We cannot send files and folders together
			}else{
				type = filelist[i].type;
			}

			if(ids!="") ids += ",";
			ids += filelist[i].id;
		}
	}

	if(ids!=""){
		QString sourcetype = (type==1) ? "1" : "2";	// 1-folders, 2-files
		QString uri = "doExpChoseSource/"+ base64(importWnd.providerid) +","+ base64(sourcetype) +","+ base64(ids);
		QString res = runFunction2(uri);

		QString status=getPartQString(res, "<status>", "</status>");
		QString statusMessage=getPartQString(res, "<statusmessage>", "</statusmessage>");
		if(status!="ok" && statusMessage!=""){
			if(statusMessage.length()<15) statusMessage+="         ";
			importWnd.unlockAll();
			QMessageBox::critical(this, "Error", statusMessage);
			hideMessage();
			return ;
		}else if(status!="ok"){
			importWnd.unlockAll();
			QMessageBox::critical(this, "Error", "Cannot export files");
			hideMessage();
			return ;
		}
	}

	showMessage("Starting Export in Background...", true);
	SrunFunction.restory="";
	SrunFunction.restory.append(SLOT(runExportResp3()));
	QString uri="doExportInBackground/"+ base64(importWnd.providerid);
	if(isActionCanceled){
		importWnd.unlockAll();
		hideMessage();
		return ;
	}
	runFunction(uri);
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::runExportResp3(){
debug("runExportResp3()");
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory="";
	QString status=getPartQString(res, "<status>", "</status>");
	QString statusMessage=getPartQString(res, "<statusmessage>", "</statusmessage>");
	if(status!="ok" && statusMessage!=""){
		if(statusMessage.length()<15) statusMessage+="         ";
		importWnd.unlockAll();
		QMessageBox::critical(this, "Error", statusMessage);
		hideMessage();
		return ;
	}else if(status!="ok"){
		importWnd.unlockAll();
		QMessageBox::critical(this, "Error", "Bad parameter");
		hideMessage();
		return ;
	}

	QMessageBox::information(this, "Info", "Export started in background");
	importWnd.unlockAll();
	importWnd.clear2();
	importWnd.hide();
	hideMessage();
	return ;
}
//////////////////////////////////////////////////////////////////////
bool SMEStorageExplorer::tryRunning(){
	if(isRunning) return false;
	if(login.length()<1 || password.length()<1){
		properties();
		hideMessage();
		return false;
	}

	return true;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bSearch(){
	if(!tryRunning()) return ;
debug("bSearch()");
//search2Resp(); return ;
	searchWnd.setWindowModality(Qt::ApplicationModal);
	searchWnd.clear();
	searchWnd.move(QPoint((int) (x()+ww/2-215), y()));
	searchWnd.initWnd();
	searchWnd.show();

	hideMessage();

	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::search2(){
debug("search2()");
	showMessage("Searching for files", true);
	QString stext=searchWnd.stext, typeOfSearch=searchWnd.typeOfSearch, options="";

	if(searchWnd.byName) options+="n";
	if(searchWnd.byExtension) options+="p";
	if(searchWnd.byExtensionExactly) options+="e";
	if(searchWnd.byDescription) options+="d";
	if(searchWnd.byTags) options+="t";

	QString uri="";
	if(searchWnd.typeSearch==0 || searchWnd.typeSearch==1){
		QString includeShared="n";
		if(searchWnd.typeSearch==1) includeShared="y";
		uri="doSearchFiles/"+ base64(stext) +","+ base64(options) +","+ base64(includeShared) +","+ base64("n") +","+ base64("n") +","+ base64(typeOfSearch);
		Ssearch.inPublic=false;
	}else{
		QString includeShared="n";
		if(searchWnd.typeSearch==1) includeShared="y";
		uri="doSearchPublicFiles/"+ base64(stext) +","+ base64(options) +","+ base64(typeOfSearch) +","+ base64("y");
		Ssearch.inPublic=true;
	}
	Ssearch.uri=uri;
	explorerType=3;
	refreshAll(false, true);
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::search2Resp(){
debug("search2Resp()");
	explorerType=3;
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory="";
	if(res.indexOf("<response>")<0 || res.indexOf("</response>")<0){
		QMessageBox::critical(this, "Error", "Can't get files list.");
		hideMessage();
		return ;
	}

	QDomDocument doc("response");
	doc.setContent(res, true);
	bool L1=false, L2=false;
	QDomElement root=doc.documentElement();
	QDomNode n=root.firstChild(), sharedlist, fileslist;
	while(!n.isNull()){
		QDomElement e = n.toElement();
		if(!e.isNull()){
			if(e.tagName()=="files"){
				fileslist=n.firstChild();
				L1=true;
			}
			if(e.tagName()=="sharedfiles"){
				sharedlist=n.firstChild();
				L2=true;
			}
		}
		n=n.nextSibling();
	}

	if(L1){
		n=fileslist;
		for(int i=0; !n.isNull(); i++){
			QDomElement e=n.toElement();
			if(!e.isNull() && e.tagName()=="n"+intToQstring(i)){
				Tfile file=emptyFile;
				if(Ssearch.inPublic){
					file=getPublicFileFromDomNode(n);
				}else{
					file=getFileFromDomNode(n);
				}
				addToFileslist(file, true);
				n=n.nextSibling();
			}
		}// for
	}// if

	if(L2){
		n=sharedlist;
		for(int i=0; !n.isNull(); i++){
			QDomElement e=n.toElement();
			if(!e.isNull() && e.tagName()=="n"+intToQstring(i)){
				Tfile file=getFileFromDomNode(n);
				addToFileslist(file, true);
				n=n.nextSibling();
			}
		}// for
	}// if

	isGetFilesList=true;
	resume(1);
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bCloudProviders(){
debug("bCloudProviders()");
	if(!tryRunning()) return ;

	showMessage("Retrieving Providers...", true);
	SrunFunction.restory="";
	SrunFunction.restory.append(SLOT(cloudProvidersResp()));
	QString uri="getProviders/";
	if(isActionCanceled){
		hideMessage();
		return ;
	}
	runFunction(uri);

	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::cloudProvidersResp(){
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory="";

	if(res.indexOf("<response>")<0 || res.indexOf("</response>")<0){
		QString status=getPartQString(res, "<status>", "</status>");
		if(status!="ok"){
			QMessageBox::critical(this, "Error", "Can't get providers list.");
			hideMessage();
			return ;
		}
	}

	providersWnd.clear();

	QString defaultprovider="0";
	QDomDocument doc("response");
	doc.setContent(res, true);
	bool L1=false, L2=false;
	QDomNode nAllowed, nUsed;
	QDomElement root=doc.documentElement();
	QDomNode n=root.firstChild();
	while(!n.isNull()){
		QDomElement e = n.toElement();
		if(!e.isNull()){
			if(e.tagName()=="allowed"){
				nAllowed=n.firstChild();
				L1=true;
			}
			if(e.tagName()=="used"){
				nUsed=n.firstChild();
				L2=true;
			}
			if(e.tagName()=="allowedcount")	countAllowedProviders=e.text().toInt();
			if(e.tagName()=="defaultprovider")	defaultprovider=e.text();
debug("tag =>  "+ e.tagName());
		}
		n=n.nextSibling();
	}
//debug("countAllowedProviders="+ intToQstring(countAllowedProviders));

	if(L1){
		n=nAllowed;
		for(int i=0; !n.isNull(); i++){
			QDomElement e=n.toElement();
			if(!e.isNull() && e.tagName()=="n"+intToQstring(i)){
				QString prid="", pr_name="";
				QDomNode nf=n.firstChild();
				do{
					QDomElement el=nf.toElement();
					if(el.tagName()=="pr_id")				prid=el.text();
					if(el.tagName()=="pr_name")			pr_name=el.text();
					nf=nf.nextSibling();
				}while(!nf.isNull());

				if(prid.length()>0 && pr_name.length()>0){
					TNProvider pr;
					pr.prid=prid;
					pr.pr_name=pr_name;
					providersWnd.addAllowedPr(pr);
				}
				n=n.nextSibling();
			}
		}// for
	}// if

	if(L2){
		n=nUsed;
		for(int i=0; !n.isNull(); i++){
			QDomElement e=n.toElement();
			if(!e.isNull() && e.tagName()=="n"+intToQstring(i)){
				QString pi_login="", pi_id="", prid="", defaultfolderid="", defaultfolder="", pi_master="", pr_name="", pi_isbackup="", cf="";  // cf - count files

				QDomNode nf=n.firstChild();
				do{
					QDomElement el=nf.toElement();
					if(el.tagName()=="pi_login")			pi_login=el.text();
					if(el.tagName()=="pi_id")				pi_id=el.text();
					if(el.tagName()=="pr_id")				prid=el.text();
					if(el.tagName()=="defaultfolderid")	defaultfolderid=el.text();
					if(el.tagName()=="defaultfolder")	defaultfolder=el.text();
					if(el.tagName()=="pi_master")			pi_master=el.text();
					if(el.tagName()=="pr_name")			pr_name=el.text();
					if(el.tagName()=="pi_isbackup")		pi_isbackup=el.text();
					if(el.tagName()=="cf")					cf=el.text();
					nf=nf.nextSibling();
				}while(!nf.isNull());

// debug("pr.pi_login="+pi_login+";	pr.pi_id="+pi_id+";	pr.prid="+prid+"; pr.defaultfolderid="+defaultfolderid+"; pr.defaultfolder="+defaultfolder+"; pr.pr_name="+pr_name+"; pr.cf="+cf+";");
				if(pi_id.length()>0 && prid.length()>0){
					bool isMaster=false, isDefault=false, isBackup=false;
					if(pi_master=="y") isMaster=true;
					if(pi_isbackup=="1") isBackup=true;
					if(pi_id==defaultprovider) isDefault=true;

					TNProvider pr;
					pr.pi_login=pi_login;
					pr.pi_id=pi_id;
					pr.prid=prid;
					pr.defaultfolderid=defaultfolderid;
					pr.defaultfolder=defaultfolder;

					pr.pi_master=isMaster;
					pr.isBackup=isBackup;
					pr.isDefault=isDefault;
					pr.pr_name=pr_name;
					pr.cf=cf;
					providersWnd.addToTree(pr);
				}
				n=n.nextSibling();
			}
		}// for
	}// if

	providersWnd.setWindowModality(Qt::ApplicationModal);
	providersWnd.move(QPoint((int) (x()+ww/2-291), y()));
	providersWnd.initWnd();
	providersWnd.show();
	hideMessage();
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::setDefaultProvider(){
debug("setDefaultProvider()");
	if(!tryRunning()) return ;
	showMessage("Setting Default Provider...", true);
	providersWnd.hide();

	QString id="";
	for(int i=0; i<providersWnd.countP; i++){
		if(providersWnd.providerslist[i].node->isSelected()){
			id=providersWnd.providerslist[i].pi_id;
			break;
		}
	}

	if(id==""){
		QMessageBox::critical(this, "Error", "Can't find Provider");
		providersWnd.show();
		hideMessage();
		return ;
	}

	SrunFunction.restory="";
	SrunFunction.restory.append(SLOT(setDefaultProviderResp()));
	QString uri="doSetDefaultProvider/"+ base64(id);
	if(isActionCanceled){
		providersWnd.clear2();
		hideMessage();
		return ;
	}
	runFunction(uri);
	providersWnd.hide();
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::setDefaultProviderResp(){
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory="";

	if(res.indexOf("<response>")<0 || res.indexOf("</response>")<0){
		QString status=getPartQString(res, "<status>", "</status>");
		if(status!="ok"){

			QMessageBox::critical(this, "Error", "Can't set default provider.");
			providersWnd.show();
			hideMessage();
			return ;
		}
	}

	QString defaultprovider=getPartQString(res, "<defaultprovider>", "</defaultprovider>");
	if(defaultprovider==""){
		QMessageBox::critical(this, "Error", "Can't set default provider.");
		providersWnd.show();
		hideMessage();
		return ;
	}

	for(int i=0; i<providersWnd.countP; i++){
		if(providersWnd.providerslist[i].isDefault && providersWnd.providerslist[i].pi_id!=defaultprovider){
			providersWnd.providerslist[i].isDefault=false;
			providersWnd.upateNode(i);
		}
		if(providersWnd.providerslist[i].pi_id==defaultprovider){
			providersWnd.providerslist[i].isDefault=true;
			providersWnd.upateNode(i);
		}
	}

	providersWnd.show();
	hideMessage();
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::changeProviderPassword(){
debug("changeProviderPassword()");
	if(!tryRunning()) return ;
	showMessage("Changing Provider Password...", true);
	providersWnd.hide();
	QString id="", newPass=providersWnd.newPassword;
	if(newPass==""){
		QMessageBox::critical(this, "Error", "Can't find Password");
		providersWnd.show();
		hideMessage();
		return ;
	}

	for(int i=0; i<providersWnd.countP; i++){
		if(providersWnd.providerslist[i].node->isSelected()){
			id=providersWnd.providerslist[i].pi_id;
			break;
		}
	}

	if(id==""){
		QMessageBox::critical(this, "Error", "Can't find Provider");
		providersWnd.show();
		hideMessage();
		return ;
	}

	SrunFunction.restory="";
	SrunFunction.restory.append(SLOT(changeProviderPasswordResp()));
	QString uri="doChangeProviderPassword/"+ base64(id) +","+ base64(newPass);
	if(isActionCanceled){
		providersWnd.clear2();
		hideMessage();
		return ;
	}
	runFunction(uri);
	providersWnd.hide();
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::changeProviderPasswordResp(){
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory="";
	QString status=getPartQString(res, "<status>", "</status>");
	QString statusMessage=getPartQString(res, "<statusmessage>", "</statusmessage>");
	if(status!="ok" && statusMessage!=""){
		if(statusMessage.length()<15) statusMessage+="         ";
		QMessageBox::critical(this, "Error", statusMessage);
		providersWnd.show();
		hideMessage();
		return ;
	}else	if(status!="ok"){
		QMessageBox::critical(this, "Error", "Can't change Provider Password.");
		providersWnd.show();
		hideMessage();
		return ;
	}

	providersWnd.show();
	hideMessage();
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bsyncProviderTask(){
	SSyncProviderTask.needSyncNow=false;
	syncProviderTask();
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::syncProviderNow(){
	SSyncProviderTask.needSyncNow=true;
	syncProviderTask();
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::syncProviderTask(){
debug("syncProviderTask()");
	if(!tryRunning()) return ;
	showMessage("Preparing Provider for Background Synchronization...", true);
	providersWnd.hide();
	QString id="";
	for(int i=0; i<providersWnd.countP; i++){
		if(providersWnd.providerslist[i].node->isSelected()){
			id=providersWnd.providerslist[i].pi_id;
			break;
		}
	}

	if(id==""){
		QMessageBox::critical(this, "Error", "Can't find Provider");
		providersWnd.show();
		hideMessage();
		return ;
	}

	SrunFunction.restory="";
	SrunFunction.restory.append(SLOT(syncProviderTaskResp()));
	QString uri="doProviderSyncInBackground/"+ base64(id);
	if(isActionCanceled){
		providersWnd.show();
		hideMessage();
		return ;
	}
	runFunction(uri);
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::syncProviderTaskResp(){
debug("syncProviderTaskResp()");
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory="";
	QString status=getPartQString(res, "<status>", "</status>");
	QString statusMessage=getPartQString(res, "<statusmessage>", "</statusmessage>");
	if(status!="ok" && statusMessage!=""){
		if(statusMessage.length()<15) statusMessage+="         ";
		QMessageBox::critical(this, "Error", statusMessage);
		providersWnd.show();
		hideMessage();
		return ;
	}else	if(status!="ok"){
		QMessageBox::critical(this, "Error", "Can't sync Provider in Background.");
		providersWnd.show();
		hideMessage();
		return ;
	}

	if(SSyncProviderTask.needSyncNow){
		QString taskid=getPartQString(res, "<taskid>", "</taskid>");
		if(taskid==""){
			QMessageBox::critical(this, "Error", "Can't sync Provider");
			providersWnd.show();
			hideMessage();
			return ;
		}

		SSyncProviderTask.taskid=taskid;
		syncProviderNowResp();
	}else{
		providersWnd.show();
		hideMessage();
	}
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::syncProviderNowResp(){
debug("syncProviderNowResp()");
	showMessage("Retrieving Background Tasks", true);
	SrunFunction.restory="";
	SrunFunction.restory.append(SLOT(syncProviderNowResp2()));
	QString uri="getUserBackgroundTasks/";
	if(isActionCanceled){
		providersWnd.show();
		hideMessage();
		return ;
	}
	runFunction(uri);
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::syncProviderNowResp2(){
debug("syncProviderNowResp2()");
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory="";
	QString status=getPartQString(res, "<status>", "</status>");
	QString statusMessage=getPartQString(res, "<statusmessage>", "</statusmessage>");
	if(status!="ok" && statusMessage!=""){
		if(statusMessage.length()<15) statusMessage+="         ";
		QMessageBox::critical(this, "Error", statusMessage);
		providersWnd.show();
		hideMessage();
		return ;
	}else	if(status!="ok"){
		QMessageBox::critical(this, "Error", "Can't get list of Background Tasks.");
		providersWnd.show();
		hideMessage();
		return ;
	}

	QDomDocument doc("response");
	doc.setContent(res, true);
	bool L=false;
	QDomElement root=doc.documentElement();
	QDomNode n=root.firstChild();
	while(!n.isNull()){
		QDomElement e = n.toElement();
		if(!e.isNull()){
			if(e.tagName()=="tasks"){
				n=n.firstChild();
				L=true;
				break;
			}
		}
		n=n.nextSibling();
	}

	if(!L){
		QMessageBox::critical(this, "Error", "Can't get list of Background Tasks.");
		providersWnd.show();
		hideMessage();
		return ;
	}

	QString tid="", tstatus="";
	for(int i=0; !n.isNull(); i++){
		QDomElement e=n.toElement();
		if(!e.isNull() && e.tagName()=="n"+intToQstring(i)){
			QString tid, tstatus;
			QDomNode nf=e.firstChild();
			do{
				QDomElement el=nf.toElement();
				if(el.tagName()=="bt_id")		tid=el.text();
				if(el.tagName()=="bt_status")	tstatus=el.text();
				nf=nf.nextSibling();
			}while(!nf.isNull());

debug("tid="+ tid+" tstatus="+ tstatus);
			if(tid.length()>0 && tstatus.length()>0 && tid==SSyncProviderTask.taskid){
				if(tstatus.toLower()!="c"){
					SSyncProviderTask.countSec=10;
					showMessage("Waiting for "+ intToQstring(SSyncProviderTask.countSec) +" seconds. Waiting for Background Synchronization to complete", true);
					QTimer::singleShot(1000, this, SLOT(syncProviderNowTimer()));
					return ;
				}
				break;
			}
			nf=nf.nextSibling();
		}
		n=n.nextSibling();
	}// for

	providersWnd.show();
	hideMessage();
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::syncProviderNowTimer(){
debug("syncProviderNowTimer()");
	if(isActionCanceled){
		providersWnd.show();
		hideMessage();
		return ;
	}

	SSyncProviderTask.countSec--;
	if(SSyncProviderTask.countSec>0){
		showMessage("Waiting for "+ intToQstring(SSyncProviderTask.countSec) +" seconds. Waiting for Background Synchronization to complete", true);
		QTimer::singleShot(1000, this, SLOT(syncProviderNowTimer()));
	}else{
		SSyncProviderTask.countSec=0;
		syncProviderNowResp();
	}

	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::cancelCurrentAction(){
debug("cancelCurrentAction()");
	isActionCanceled=true;
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::addProviderGetMetaFields(){
debug("addProviderGetMetaFields()");
	showMessage("Retrieving Provider Meta Fields", true);
	SrunFunction.restory="";
	SrunFunction.restory.append(SLOT(addProviderGetMetaFieldsResp()));
	QString uri="getAddProviderMetaFields/"+ base64(providersWnd.newProviderId);
	if(isActionCanceled){
		providersWnd.show();
		hideMessage();
		return ;
	}
	runFunction(uri);
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::addProviderGetMetaFieldsResp(){
debug("addProviderGetMetaFieldsResp()");
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory="";
	QString title=getPartQString(res, "<provider>", "</provider>");
	if(title==""){
		title="Login";
	}else{
		title+=" Login";
	}
	expProviderLoginWnd.clear();
	expProviderLoginWnd.setWindowModality(Qt::ApplicationModal);
	expProviderLoginWnd.setWindowTitle(title);
	expProviderLoginWnd.addProvider=true;

	int y=10;
	if(res.indexOf("<response>")<0 || res.indexOf("</response>")<0){
		QMessageBox::critical(this, "Error", "Can't get provider meta fields.");
		providersWnd.show();
		hideMessage();
		return ;
	}

	if(res.indexOf("<aouthsupport>y</aouthsupport>")>0){
		QMessageBox::critical(this, "Error", "This provider cannot be added via this tool. You can add it via site.");
		providersWnd.show();
		hideMessage();
		return ;
	}

	QDomDocument doc("response");
	doc.setContent(res, true);
	bool L=false;
	QDomElement root=doc.documentElement();
	QDomNode n=root.firstChild();
	while(!n.isNull()){
		QDomElement e = n.toElement();
		if(!e.isNull()){
			if(e.tagName()=="fields"){
				n=n.firstChild();
				L=true;
				break;
			}
		}
		n=n.nextSibling();
	}

	if(L){
		for(int i=0; !n.isNull(); i++){
			QDomElement e=n.toElement();
			if(!e.isNull() && e.tagName()=="n"+intToQstring(i)){
				QString fid="", title="", defaultvalue="", ptype="";
				QDomNode nf=n.firstChild();
				do{
					QDomElement el=nf.toElement();
					if(el.tagName()=="n0")	fid=el.text();
					if(el.tagName()=="n1")	title=el.text();
					if(el.tagName()=="n2")	defaultvalue=el.text();
//					if(el.tagName()=="n3")	defaultvalue=el.text();
					if(el.tagName()=="n4")	ptype=el.text();
					nf=nf.nextSibling();
				}while(!nf.isNull());

				if(fid.length()>0 && title.length()>0){
					y=expProviderLoginWnd.addField(fid, title, defaultvalue, ptype, y);
				}
				n=n.nextSibling();
			}
		}// for

		y+=31;
//		expProviderLoginWnd.widget1->setGeometry(QRect(0, 0, 500, y));
//		expProviderLoginWnd.setGeometry(QRect(0, 0, 500, y));
		expProviderLoginWnd.resize(500, y);

		expProviderLoginWnd.move(QPoint((int) (this->x()+ww/2-225), this->y()));
		expProviderLoginWnd.initWnd();
		expProviderLoginWnd.show();
	}// if

	hideMessage();
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::addProviderSetMetaFields(){
debug("addProviderSetMetaFields()");
	showMessage("Sets Provider Meta Fields", true);
	QString fieldsres=expProviderLoginWnd.fieldsres;
debug("fieldsres="+fieldsres);

	SrunFunction.restory="";
	SrunFunction.restory.append(SLOT(addProviderSetMetaFieldsResp()));
	QString postData="function=doAddProvider";
	postData+="&pr_id="+ QUrl::toPercentEncoding(providersWnd.newProviderId) +"&step=0&data="+ QUrl::toPercentEncoding(fieldsres);

	if(isActionCanceled){
		providersWnd.show();
		hideMessage();
		return ;
	}
	runFunction("", true, postData);
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::addProviderSetMetaFieldsResp(){
debug("addProviderSetMetaFieldsResp()");
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory="";

	QString status=getPartQString(res, "<status>", "</status>");
	QString whatnextcode=getPartQString(res, "<whatnextcode>", "</whatnextcode>");
	QString statusMessage=getPartQString(res, "<statusmessage>", "</statusmessage>");
	if(status!="ok" && statusMessage!=""){
		if(statusMessage.length()<15) statusMessage+="         ";
		QMessageBox::critical(this, "Error", statusMessage);
		providersWnd.show();
		hideMessage();
		return ;
	}else if(status!="ok" || whatnextcode==""){
		QMessageBox::critical(this, "Error", "Bad parameter");
		providersWnd.show();
		hideMessage();
		return ;
	}

	if(whatnextcode=="-1"){
		addProviderSave();
		return ;
	}else if(whatnextcode=="3"){
		addProviderStep3();
		return ;
	}

	QDomDocument doc("response");
	doc.setContent(res, true);
	bool L=false;
	QDomElement root=doc.documentElement();
	QDomNode n=root.firstChild();
	while(!n.isNull()){
		QDomElement e = n.toElement();
		if(!e.isNull()){
			if(e.tagName()=="buckets"){
				n=n.firstChild();
				L=true;
				break;
			}
		}
		n=n.nextSibling();
	}

	if(L){
		selectBucketsWnd.setWindowModality(Qt::ApplicationModal);
		selectBucketsWnd.clear();
		for(int i=0; !n.isNull(); i++){
			QDomElement e=n.toElement();
			QString name="";
			if(!e.isNull() && e.tagName()=="n"+intToQstring(i)){
				name=e.text();
				if(name.length()>0){
					selectBucketsWnd.addToTree(name, name);
				}
			}
			n=n.nextSibling();
		}// for

		selectBucketsWnd.move(QPoint((int) (x()+ww/2-250), (int) (y()+wh/2-200)));
		selectBucketsWnd.initWnd();
		selectBucketsWnd.show();
	}// if

	hideMessage();
	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::addProviderSetBuckets(){
debug("addProviderSetBuckets()");
	showMessage("Sets Provider Buckets", true);

	QString list="", defb="", newb=selectBucketsWnd.lineEdit1->text();
	for(int i=0; i<selectBucketsWnd.countB; i++){
		if(selectBucketsWnd.buckets[i].node->checkState()==Qt::Checked){
			if(list==""){
				list+=selectBucketsWnd.buckets[i].name;
			}else{
				list+=","+selectBucketsWnd.buckets[i].name;
			}
		}
	}

	int ind=selectBucketsWnd.comboBox1->currentIndex();
	if(newb=="" && ind<selectBucketsWnd.countB && ind>=0)	defb=selectBucketsWnd.buckets[ind].name;
debug("list="+ list +"defb="+ defb +"newb="+ newb);

	SrunFunction.restory="";
	SrunFunction.restory.append(SLOT(addProviderSetBucketsResp()));
	QString postData="function=doAddProvider";
	postData+="&pr_id="+ QUrl::toPercentEncoding(providersWnd.newProviderId) +"&step=1&defaultbucket="+ QUrl::toPercentEncoding(defb) +"&buckets="+ QUrl::toPercentEncoding(list) +"&createnew="+ QUrl::toPercentEncoding(newb);
debug("postData="+ postData);
	if(isActionCanceled){
		providersWnd.show();
		hideMessage();
		return ;
	}
	runFunction("", true, postData);

	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::addProviderSetBucketsResp(){
debug("addProviderSetBucketsResp()");
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory="";

	QString status=getPartQString(res, "<status>", "</status>");
	QString whatnextcode=getPartQString(res, "<whatnextcode>", "</whatnextcode>");
	QString statusMessage=getPartQString(res, "<statusmessage>", "</statusmessage>");
	if(status!="ok" && statusMessage!=""){
		if(statusMessage.length()<15) statusMessage+="         ";
		QMessageBox::critical(this, "Error", statusMessage);
		providersWnd.show();
		hideMessage();
		return ;
	}else if(status!="ok" || whatnextcode==""){
		QMessageBox::critical(this, "Error", "Bad parameters");
		providersWnd.show();
		hideMessage();
		return ;
	}

	if(whatnextcode=="-1" || whatnextcode=="2"){
		addProviderSave();
		return ;
	}

	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::addProviderSave(){
debug("addProviderSave()");
debug("countAllowedProviders="+ intToQstring(countAllowedProviders));
//countAllowedProviders=2;
	if(countAllowedProviders!=2){
		addProviderStep3();
		return ;
	}

	QString saveInfo="y";
	if(QMessageBox::question(this, "SME MultiCloud Explorer", "It is recommended to save cloud provider access info in your Storage Made Easy account.\nWe protect your privacy by encrypting this info.\nWould you like to save cloud provider access info in your Storage Made Easy account?",  QMessageBox::Ok, QMessageBox::No)==QMessageBox::Ok){
		saveInfo="y";
	}else{
		saveInfo="n";
	}

	showMessage("Saving Provider Info...", true);

	SrunFunction.restory="";
	SrunFunction.restory.append(SLOT(addProviderSaveResp()));
	QString uri="doAddProvider/"+ base64(providersWnd.newProviderId) +","+ base64("2") +","+ base64(saveInfo);
	if(isActionCanceled){
		providersWnd.show();
		hideMessage();
		return ;
	}
	runFunction(uri);

	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::addProviderSaveResp(){
debug("addProviderSaveResp()");
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory="";
	QString status=getPartQString(res, "<status>", "</status>");
	QString statusMessage=getPartQString(res, "<statusmessage>", "</statusmessage>");
	if(status!="ok" && statusMessage!=""){
		if(statusMessage.length()<15) statusMessage+="         ";
		QMessageBox::critical(this, "Error", statusMessage);
		providersWnd.show();
		hideMessage();
		return ;
	}else if(status!="ok"){
		QMessageBox::critical(this, "Error", "Bad parameters");
		providersWnd.show();
		hideMessage();
		return ;
	}

	addProviderStep3();

	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::addProviderStep3(){
debug("addProviderStep3()");
	showMessage("Saving Provider Info...", true);

	SrunFunction.restory="";
	SrunFunction.restory.append(SLOT(addProviderStep3Resp()));
	QString uri="doAddProvider/"+ base64(providersWnd.newProviderId) +","+ base64("3");
	if(isActionCanceled){
		providersWnd.show();
		hideMessage();
		return ;
	}
	runFunction(uri);

	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::addProviderStep3Resp(){
debug("addProviderStep3Resp()");
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory="";
	QString status=getPartQString(res, "<status>", "</status>");
	QString statusMessage=getPartQString(res, "<statusmessage>", "</statusmessage>");
	QString piID=getPartQString(res, "<pi_id>", "</pi_id>");
	if(status!="ok" && statusMessage!=""){
		if(statusMessage.length()<15) statusMessage+="         ";
		QMessageBox::critical(this, "Error", statusMessage);
		providersWnd.show();
		hideMessage();
		return ;
	}else if(status!="ok"){
		QMessageBox::critical(this, "Error", "Bad parameters");
		providersWnd.show();
		hideMessage();
		return ;
	}

	debug("res="+res);

	if(piID==""){
		QMessageBox::critical(this, "Error", "Error 113. Provider added. But, we cannot resync this provider");
		hideMessage();
		return ;
	}else{
		QString uri="doProviderSyncInBackground/"+ base64(piID);
		showMessage("Start provider resync in background", true);
		QString res = runFunction2(uri);

		status=getPartQString(res, "<status>", "</status>");
		statusMessage=getPartQString(res, "<statusmessage>", "</statusmessage>");
		if(status!="ok" && statusMessage!=""){
			if(statusMessage.length()<15) statusMessage+="         ";
			QMessageBox::critical(this, "Error", statusMessage);

			providersWnd.show();
			hideMessage();
			return ;
		}else if(status!="ok"){
			QMessageBox::critical(this, "Error", "Error 114. Provider added. But, we cannot resync this provider");
			providersWnd.show();
			hideMessage();
			return ;
		}else{
			showMessage("Success...", true);
		}
	}

	providersWnd.clear2();			// Success. Clearing the window and loading providers list again
	hideMessage();
	bCloudProviders();

	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bmanageBuckets(){
debug("bmanageBuckets()");
	if(providersWnd.providerId=="") return ;
	showMessage("Retrieving Provider Buckets...", true);
	manageBucketsWnd.clear();
	SrunFunction.restory="";
	SrunFunction.restory.append(SLOT(bmanageBucketsResp()));
	QString uri="getProviderBuckets/"+ base64(providersWnd.providerId);
	if(isActionCanceled){
		providersWnd.show();
		hideMessage();
		return ;
	}
	runFunction(uri);

	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bmanageBucketsResp(){
debug("bmanageBucketsResp()");
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory="";
	QString status=getPartQString(res, "<status>", "</status>");
	QString statusMessage=getPartQString(res, "<statusmessage>", "</statusmessage>");
	if(status!="ok" && statusMessage!=""){
		if(statusMessage.length()<15) statusMessage+="         ";
		QMessageBox::critical(this, "Error", statusMessage);
		providersWnd.show();
		hideMessage();
		return ;
	}else if(status!="ok"){
		QMessageBox::critical(this, "Error", "Bad parameters");
		providersWnd.show();
		hideMessage();
		return ;
	}

	QDomDocument doc("response");
	doc.setContent(res, true);
	bool L=false;
	QDomElement root=doc.documentElement();
	QDomNode n=root.firstChild();
	while(!n.isNull()){
		QDomElement e = n.toElement();
		if(!e.isNull()){
			if(e.tagName()=="buckets"){
				n=n.firstChild();
				L=true;
				break;
			}
		}
		n=n.nextSibling();
	}
//debug("countAllowedProviders="+ intToQstring(countAllowedProviders));

	if(L){
		for(int i=0; !n.isNull(); i++){
			QDomElement e=n.toElement();
			if(!e.isNull() && e.tagName()=="n"+intToQstring(i)){
				QString name="", def="", used="";
				QDomNode nf=n.firstChild();
				do{
					QDomElement el=nf.toElement();
					if(el.tagName()=="n0") name=el.text();
					if(el.tagName()=="n1") used=el.text();
					if(el.tagName()=="n2") def=el.text();
					nf=nf.nextSibling();
				}while(!nf.isNull());

				if(name.length()>0){
					bool isdef=true, isused=true;
					if(def!="y") isdef=false;
					if(used!="y") isused=false;
					manageBucketsWnd.addToTree(name, isdef, isused);
				}
				n=n.nextSibling();
			}
		}// for
	}// if

	showMessage("Success...", true);
	manageBucketsWnd.setWindowModality(Qt::ApplicationModal);
	manageBucketsWnd.move(QPoint((int) (x()+ww/2-250), y()));
	manageBucketsWnd.initWnd();
	manageBucketsWnd.show();
	hideMessage();

	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bsetDefaultBucket(){
debug("bsetDefaultBucket()");
	if(manageBucketsWnd.selectedBucketName=="" || providersWnd.providerId=="") return ;
	showMessage("Seting Default Bucket...", true);
	providersWnd.hide();

	SrunFunction.restory="";
	SrunFunction.restory.append(SLOT(bsetDefaultBucketResp()));
	if(isActionCanceled){
		providersWnd.show();
		manageBucketsWnd.show();
		hideMessage();
		return ;
	}
//	QString uri="doSetDefaultBucket/"+ base64(providersWnd.providerId) +","+ base64(manageBucketsWnd.selectedBucketName);
	QString postData="function=doSetDefaultBucket";
	postData+="&pi_id="+ QUrl::toPercentEncoding(providersWnd.providerId) +"&bucket="+ QUrl::toPercentEncoding(manageBucketsWnd.selectedBucketName);
	runFunction("", true, postData);

	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bsetDefaultBucketResp(){
debug("bsetDefaultBucketResp()");
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory="";

	QString status=getPartQString(res, "<status>", "</status>");
	QString defaultbucket=getPartQString(res, "<defaultbucket>", "</defaultbucket>");
	QString statusMessage=getPartQString(res, "<statusmessage>", "</statusmessage>");
	if(status!="ok" && statusMessage!=""){
		if(statusMessage.length()<15) statusMessage+="         ";
		QMessageBox::critical(this, "Error", statusMessage);
		providersWnd.show();
		manageBucketsWnd.show();
		hideMessage();
		return ;
	}else if(status!="ok" || defaultbucket==""){
		QMessageBox::critical(this, "Error", "Bad parameters");
		providersWnd.show();
		manageBucketsWnd.show();
		hideMessage();
		return ;
	}

	for(int i=0; i<manageBucketsWnd.countB; i++){
		if(manageBucketsWnd.buckets[i].name==defaultbucket){
			manageBucketsWnd.buckets[i].isUsed=true;
			manageBucketsWnd.buckets[i].isDefault=true;
			manageBucketsWnd.updateNode(i);
		}else if(manageBucketsWnd.buckets[i].isDefault){
			manageBucketsWnd.buckets[i].isDefault=false;
			manageBucketsWnd.updateNode(i);
		}
	}


	showMessage("Success...", true);
	providersWnd.show();
	manageBucketsWnd.show();
	hideMessage();

	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bupdateProviderBucket(){
debug("bupdateProviderBucket()");
	showMessage("Updating buckets list...", true);
	providersWnd.hide();

	QString blist="";
	for(int i=0; i<manageBucketsWnd.countB; i++){
		if(manageBucketsWnd.buckets[i].name!="" && manageBucketsWnd.buckets[i].node->checkState(0)==Qt::CheckState(2)){		// 0 - not checked, 2 - checked
			if(blist!="") blist+=",";
			blist+=manageBucketsWnd.buckets[i].name;
		}
	}

	SrunFunction.restory="";
	SrunFunction.restory.append(SLOT(bupdateProviderBucketResp()));
	QString postData="function=doUpdateBucketsList&pi_id="+ QUrl::toPercentEncoding(providersWnd.providerId) +"&buckets="+ QUrl::toPercentEncoding(blist);
	if(isActionCanceled){
		providersWnd.show();
		manageBucketsWnd.show();
		hideMessage();
		return ;
	}
	runFunction("", true, postData);

	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::bupdateProviderBucketResp(){
debug("bupdateProviderBucketResp()");
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory="";

	QString status=getPartQString(res, "<status>", "</status>");
	QString statusMessage=getPartQString(res, "<statusmessage>", "</statusmessage>");
	if(status!="ok" && statusMessage!=""){
		if(statusMessage.length()<15) statusMessage+="         ";
		QMessageBox::critical(this, "Error", statusMessage);
		providersWnd.show();
		manageBucketsWnd.show();
		hideMessage();
		return ;
	}else if(status!="ok"){
		QMessageBox::critical(this, "Error", "Bad parameters");
		providersWnd.show();
		manageBucketsWnd.show();
		hideMessage();
		return ;
	}

	showMessage("Success...", true);
	for(int i=0; i<manageBucketsWnd.countB; i++){
		if(manageBucketsWnd.buckets[i].name=="") continue;
		if(manageBucketsWnd.buckets[i].node->checkState(0)==Qt::CheckState(2)){		// 0 - not checked, 2 - checked
			manageBucketsWnd.buckets[i].isUsed=true;
			manageBucketsWnd.updateNode(i);
		}else{
			manageBucketsWnd.buckets[i].isUsed=false;
			manageBucketsWnd.updateNode(i);
		}
	}

	providersWnd.show();
	manageBucketsWnd.show();
	hideMessage();

	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::baddProviderBucket(){
debug("baddProviderBucket()");
	showMessage("Preparing...", true);

	if(providersWnd.providerType!=1){
		addProviderBucketWnd.checkBox1->setEnabled(false);
	}else{
		addProviderBucketWnd.checkBox1->setEnabled(true);
	}

	addProviderBucketWnd.setWindowModality(Qt::ApplicationModal);
	addProviderBucketWnd.move(QPoint((int) (x()+ww/2-165), y()+60));
	addProviderBucketWnd.initWnd();
	addProviderBucketWnd.show();
	hideMessage();

	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::addProviderBucket(){
debug("baddProviderBucket()");
	showMessage("Adding Provider Bucket...", true);
	providersWnd.hide();
	manageBucketsWnd.hide();

	QString extra="";
	if(addProviderBucketWnd.EULocation) extra="EU";

	SrunFunction.restory="";
	SrunFunction.restory.append(SLOT(addProviderBucketResp()));
	QString postData="function=doAddBucket&pi_id="+ QUrl::toPercentEncoding(providersWnd.providerId)
		+"&bucket="+ QUrl::toPercentEncoding(addProviderBucketWnd.bucketname) +"&extra="+ QUrl::toPercentEncoding(extra);
	if(isActionCanceled){
		providersWnd.show();
		manageBucketsWnd.show();
		hideMessage();
		return ;
	}
	runFunction("", true, postData);

	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::addProviderBucketResp(){
debug("addProviderBucketResp()");
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory="";
//return ;

	QString status=getPartQString(res, "<status>", "</status>");
	QString newbucket=getPartQString(res, "<newbucket>", "</newbucket>");
	QString statusMessage=getPartQString(res, "<statusmessage>", "</statusmessage>");
	if(status!="ok" && statusMessage!=""){
		if(statusMessage.length()<15) statusMessage+="         ";
		QMessageBox::critical(this, "Error", statusMessage);
		providersWnd.show();
		manageBucketsWnd.show();
		hideMessage();
		return ;
	}else if(status!="ok" || newbucket==""){
		QMessageBox::critical(this, "Error", "Can't add bucket.");
		providersWnd.show();
		manageBucketsWnd.show();
		hideMessage();
		return ;
	}

	showMessage("Success...", true);

	manageBucketsWnd.addToTree(newbucket, false, true);
	manageBucketsWnd.tree->sortItems(0, Qt::AscendingOrder);

	providersWnd.show();
	manageBucketsWnd.show();
	hideMessage();

	return ;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::keyPressEvent(QKeyEvent *event){
debug("keyPressEvent()");
	int key=event->key();
	if(key==Qt::Key_Escape){
		if(!tryRunning()) cancelCurrentAction();
	}else if(key==Qt::Key_Enter || key==Qt::Key_Return){
		int count=getCountFiles(filelist);
		for(int i=0; i<count; i++){
			if(filelist[i].name!="" && filelist[i].node->isSelected()){
				bDoubleClicked(filelist[i].node);
				break;
			}
		}
	}else if(key==Qt::Key_F5){
		bRefresh();
	}else if(key==Qt::Key_Backspace){
		bPrevious();
	}else if(key==Qt::Key_Delete){
//debug("=> bDelete");
//		bDelete();
	}


}
//////////////////////////////////////////////////////////////////////
bool SMEStorageExplorer::isKDE(){
	QString cmdQSt="ps ax | grep kdeinit";

	QByteArray cmdArr=cmdQSt.toLatin1();
	char *cmd=cmdArr.data();
	int nn0=20000;
	char buf[nn0];

	QString buf2="";
	FILE *ptr;
	for(int i=0; i<nn0; i++)
		buf[i]=' ';

//debug(cmdQSt);
	ptr=popen(cmd, "r");
//	delete cmd;
	int ptrd=fileno(ptr);
	fcntl(ptrd, F_SETFL);
	ssize_t r=read(ptrd, buf, nn0);
	while(r==-1){
		r=read(ptrd, buf, nn0);
	}

	(void) pclose(ptr);
	QString s_utf8=QString::fromUtf8(buf);
	buf2.append(s_utf8);

	buf2=buf2.mid(0, nn0-1);
	int lngt=buf2.length();

	for(; lngt>0; lngt--){
		if(buf2.mid(lngt-1, 1)!=" ")	break;
		buf2=buf2.mid(0, lngt-1);
	}

	int lt=-1;
	for(; lt!=buf2.length();){
		lt=buf2.length();
		buf2.replace("   ", " ");
		buf2.replace("  ", " ");
	}

//	debug("response =>\n"+ buf2+";");

	QString rs;
//buf2+="2506 ?        Ss     0:00 kdeinit4: kdeinit4 Running...\n";
//buf2+="15135 pts/5    S+     0:00 grep --color=auto kdeinit\n";

	buf2+="\n";
	QRegExp rx(":(.*)kdeinit");
	while(buf2.length()>=5 && buf2.indexOf("\n")>-1){
		QString buf3=buf2.mid(0, buf2.indexOf("\n"));
		buf2=buf2.mid(buf2.indexOf("\n")+1);
//debug("buf3=\n"+buf3);

		int pos1 = rx.indexIn(buf3);
		if(pos1>-1){
			rs=rx.cap(1);
//debug("rs=\n"+rs);
			if(rs.length()>0 && rs.indexOf("grep ")<0){
//				debug("+\n");
				return true;
//			}else{
//				debug("-\n");
			}
		}
	}//for

//	int s=buf2.indexOf("SMESyncCenter --hidden");
//	if(s>-1 && buf2.indexOf("SMESyncCenter --hidden", s+10)>-1)	return true;
	return false;
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::getFileByPath(QString path, QString lpath){
debug("getFileByPath("+path+", "+lpath+")");
	if(isActionCanceled){
		hideMessage();
		return ;
	}
	showMessage("Searching folder  "+path, true);

	SgetFileByPath.path=path;
	SgetFileByPath.lpath=lpath;
	SrunFunction.restory="";
	SrunFunction.restory.append(SLOT(getFileByPathResp()));
	QString postData="function=checkPathExists&path="+ QUrl::toPercentEncoding(path) +"&pid=0";
	runFunction("", true, postData);
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::getFileByPathResp(){
debug("getFileByPathResp()");
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory="";
	int s0=res.indexOf("<file>");
	int e0=res.lastIndexOf("</file>");
	if(res.indexOf("<response>")<0 || res.indexOf("</response>")<0 || s0<0 || e0<0 || s0>e0){
		QMessageBox::critical(this, "Error", "Can't find this folder.");
		hideMessage();
		return ;
	}

	Tfile file=emptyFile;
//	bool L=false;
	QDomDocument doc("response");
	doc.setContent(res, true);
	QDomElement root=doc.documentElement();
	QDomNode n=root.firstChild();
	while(!n.isNull()){
		QDomElement e=n.toElement();
		if(!e.isNull() && e.tagName()=="file"){
			file=getFileFromDomNode(n);
			file.path=SgetFileByPath.path;
			file.lpath=SgetFileByPath.lpath;
//			addToFileslist(file, true);
//			if(file.name!="")	L=true;
			break;
		}
		n=n.nextSibling();
	}// for

	SgetFileByPath.file=file;
//debug("file.name = "+file.name+"; file.id = "+file.id);

	resume(1);
}
//////////////////////////////////////////////////////////////////////
void SMEStorageExplorer::checkForOldVersion(){
	if(!QFile::exists("/usr/local/bin/smestorage")) return ;

	QProcess *process2=new QProcess();
	process2->startDetached("/usr/bin/smesynccenter --hidden --checkforoldversion");		//This is need for changing scheduler task from old version to new version

	// Need to show window with massege about posible conflicts
	expInformationWnd=new ExpInformationWindow();
	expInformationWnd->setWindowModality(Qt::ApplicationModal);
	expInformationWnd->move(QPoint((int) (x()+ww/2-230), y()+10));

	QEventLoop pause;
	/* connect the Signal to the QEventLoop.quit() Slot */
	connect(expInformationWnd, SIGNAL(closed()), &pause, SLOT(quit()));

	/* This code will run during the QEventLoop */
	expInformationWnd->show();
	hideMessage();

	/* Execute the QEventLoop - it will quit when the above finished due to the connect() */
	pause.exec();
	return ;
}
//////////////////////////////////////////////////////////////////////
QString SMEStorageExplorer::runCommand(QString command){
	QString cmdQSt=command;

	QByteArray cmdArr=cmdQSt.toLatin1();
	char *cmd=cmdArr.data();
	int stimeout=120;
//	int maxtimeout=30;
	int nn0=10000;
	char buf[nn0];

	QString buf2="";
	FILE *ptr;

	for(int i=0; i<nn0; i++){
		buf[i]=' ';
	}

	if(command.indexOf("openssl ")==-1 && command.indexOf("gettoken")==-1 && command.indexOf("dmidecode")==-1){
		debug(cmdQSt);
	}

	ptr = popen(cmd, "r");
	int ptrd = fileno(ptr);
	fcntl(ptrd, F_SETFL, O_NONBLOCK);
	ssize_t r = read(ptrd, buf, nn0);
	while(r==-1){
		Cqthread::msleep(stimeout);
		r=read(ptrd, buf, nn0);
	}

	buf2.append(QString::fromUtf8(buf));
	buf2=buf2.mid(0, nn0-1);

	int lngt=buf2.length();
	for(; lngt>0; lngt--){
//debug("buf2.length() = > "+ intToQstring(buf2.length()));
//debug(">>> "+buf2.mid(lngt-1, 1)+"!=' ' <<<<<<<");
		if(buf2.mid(lngt-1, 1)!=" "){
			break;
		}

		buf2=buf2.mid(0, lngt-1);
	}

	if(command.indexOf("openssl ")==-1 && command.indexOf("gettoken")==-1 && command.indexOf("dmidecode")==-1){
		debug("lngt="+ intToQstring(lngt)+"; response => "+ buf2+";");
	}

	(void) pclose(ptr);

	return buf2;
}
//////////////////////////////////////////////////////////////////////
QDateTime SMEStorageExplorer::toLocal(QDateTime t, int d){
	if(gmt_offset<-86400){	// 86400=24h
		return t;
	}

	uint ut=t.toTime_t();
	ut=ut+gmt_offset + d;
	t.setTime_t(ut);

	return t;
}
//////////////////////////////////////////////////////////////////////
QDateTime SMEStorageExplorer::toUTC(QDateTime t){
	if(gmt_offset<-86400){	// 86400=24h
		return t;
	}

	uint ut=t.toTime_t();
	ut=ut-gmt_offset;
	t.setTime_t(ut);

	return t;
}
//////////////////////////////////////////////////////////////////////
QString SMEStorageExplorer::commandLineEscape(QString s){
	s = s.replace("\\", "\\\\");
	s = s.replace("\"", "\\\"");
	s = s.replace("$", "\\$");
	return s;
}
//////////////////////////////////////////////////////////////////////
QString SMEStorageExplorer::getEncryptionKeyForPassword(){
	return "def1pa2s2swor44de5e56seu1jai3kd7";		// Temporary will be used static
/*
	// dmidecode 2>/dev/null | grep "Serial Number" | grep -v "Not Specified" |  grep -v "None" || /usr/sbin/dmidecode 2>/dev/null | grep "Serial Number" | grep -v "Not Specified" |  grep -v "None" || cat  /sys/class/dmi/id/[bios]* 2>/dev/null | grep -v "cat: " | grep -v "Permission denied"
	QString command = "dmidecode 2>/dev/null | grep \"Serial Number\" | grep -v \"Not Specified\" |  grep -v \"None\" || /usr/sbin/dmidecode 2>/dev/null | grep \"Serial Number\" | grep -v \"Not Specified\" |  grep -v \"None\" || cat  /sys/class/dmi/id/[bios]* 2>/dev/null | grep -v \"cat: \" | grep -v \"Permission denied\"";

	QString s = runCommand(command);
	s = s.replace("\r", "");
	if(s.indexOf("\n")>2){
		if(s.indexOf("Serial Number:")>-1){		// Take only first line
			s = s.mid(0, s.indexOf("\n"));
		}

		std::string utf8_text = base64(s).toUtf8().constData(); 
		MD5 cx = MD5(utf8_text);
		s = QString::fromUtf8(cx.getResult().c_str());
		return s;
	}else{
		return "def1pa2s2swor44de5e56seu1jai3kd7";
	}
*/
}
//////////////////////////////////////////////////////////////////////
QString SMEStorageExplorer::encryptSMEPassword(QString password){
	if(!canPasswordBeEncrypted){
		return password;
	}

	QString command = "echo \"x"+ base64(password) +"x\" | openssl enc -aes-256-cbc -a -k \""+ base64(encryptionKeyForPassword) +"\"";
	QString s = runCommand(command);
	s = s.replace("\n", "");
	s = s.replace("\r", "");
	return "-aes-" + s;
}
//////////////////////////////////////////////////////////////////////
QString SMEStorageExplorer::decryptSMEPassword(QString password){
	if(!canPasswordBeEncrypted){
		return password;
	}

	if(password.indexOf("-aes-")!=0){
		return password;			// password is not encrypted
	}

	password = password.mid(QString("-aes-").length());

	if(password.length()>64){
		// For OpenSSL base64 encoded data should have \n after each 64 bytes
		QString xPassword = "";
		while(password.length()>0){
			if(password.length()>64){
				xPassword += password.mid(0, 64) + "\\n";
				password = password.mid(64);
			}else{
				xPassword += password;
				password = "";
			}
		}
		password = xPassword;
	}

	QString command = "printf \""+ password +"\\n\" | openssl enc -d -aes-256-cbc -a -k \""+ base64(encryptionKeyForPassword) +"\"";
//command = "printf \""+ password +"\"";
//debug("command="+command);
	QString s = runCommand(command);
	s = s.replace("\n", "");
	s = s.replace("\r", "");

//debug("s = "+s);
	if(s.indexOf("x")==0 && s.lastIndexOf("x")==s.length()-1){
		password = decodeBase64(s.mid(1, s.length()-2));
		return password;
	}else{				// Password is incorrect
		return "";
	}
}
//////////////////////////////////////////////////////////////////////
