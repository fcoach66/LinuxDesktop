#include "expfileurl.h"
#include <QIntValidator>

ExpFileurl::ExpFileurl(QWidget *parent) : QWidget(parent){
	widget1 = new QWidget(this);
	widget1->setGeometry(QRect(0, 0, 510, 290));
	widget1->setMinimumSize(250, 150);
	this->setMinimumSize(150, 150);
	this->setWindowTitle("Get file URL");
	this->setWindowIcon(QIcon("/usr/share/pixmaps/sme_explorer_icon_42.png"));
   widget1->setObjectName(QString::fromUtf8("widget1"));

	radioButton1 = new QRadioButton(QString::fromUtf8("SME URL"), widget1);
	radioButton2 = new QRadioButton(QString::fromUtf8("Short URL"), widget1);

	checkBox1 = new QCheckBox(QString::fromUtf8("Expire after:"), widget1);

	lineEdit1=new QLineEdit(widget1);
	textLabel1=new QLabel("days", widget1);

	lineEdit2=new QLineEdit(widget1);
	textLabel2=new QLabel("hours", widget1);

	lineEdit3=new QLineEdit(widget1);
	textLabel3=new QLabel("minutes", widget1);

	checkBox2 = new QCheckBox(QString::fromUtf8("Set password:"), widget1);

	textLabel4=new QLabel("Password", widget1);
	lineEdit4=new QLineEdit(widget1);
	lineEdit4->setEchoMode(QLineEdit::Password);

	textLabel5=new QLabel("Verify", widget1);
	lineEdit5=new QLineEdit(widget1);
	lineEdit5->setEchoMode(QLineEdit::Password);

	pushButton1=new QPushButton(widget1);
	pushButton1->setText("Generate URL");

	pushButton3=new QPushButton(widget1);
	pushButton3->setText("Cancel");

	QObject::connect(pushButton1, SIGNAL(clicked()), this, SLOT(OK()));
	QObject::connect(pushButton3, SIGNAL(clicked()), this, SLOT(hideWindow()));
	QObject::connect(checkBox1, SIGNAL(stateChanged(int)), this, SLOT(checkBoxStateChanged(int)));
	QObject::connect(checkBox2, SIGNAL(stateChanged(int)), this, SLOT(checkBoxStateChanged(int)));
}
//////////////////////////////////////////////////////////////////////
ExpFileurl::~ExpFileurl(){
}
//////////////////////////////////////////////////////////////////////
void ExpFileurl::OK(){
	if(radioButton1->isChecked()){
		urltype = 0;
	}else{
		urltype = 1;
	}

	if(checkBox1->checkState()==Qt::Checked){
		useExpire = true;
	}else{
		useExpire = false;
	}

	if(checkBox2->checkState()==Qt::Checked){
		usePassword = true;
		password = lineEdit4->text();
		if(password!=lineEdit5->text()){
			QMessageBox::critical(this, "Error", "Provided and repeated passwords should match");
			return ;
		}
	}else{
		usePassword = false;
		password = "";
	}


	if(lineEdit1->text()!=""){
		expireDays = lineEdit1->text().toInt();
	}else{
		expireDays = 0;
	}

	if(lineEdit2->text()!=""){
		expireHours = lineEdit2->text().toInt();
	}else{
		expireHours = 0;
	}

	if(lineEdit3->text()!=""){
		expireMinutes = lineEdit3->text().toInt();
	}else{
		expireMinutes = 0;
	}

	emit OKpressed();
	this->hide();
}
//////////////////////////////////////////////////////////////////////
void ExpFileurl::hideWindow(){
	this->hide();
}
//////////////////////////////////////////////////////////////////////
void ExpFileurl::initWnd(){
	lineEdit1->setText("");
	lineEdit2->setText("");
	lineEdit3->setText("");
	lineEdit4->setText("");
	lineEdit5->setText("");

	lineEdit1->setValidator(new QIntValidator(0, 2097151, this));
	lineEdit2->setValidator(new QIntValidator(0, 2097151, this));
	lineEdit3->setValidator(new QIntValidator(0, 2097151, this));

	lineEdit1->setEnabled(false);
	lineEdit2->setEnabled(false);
	lineEdit3->setEnabled(false);
	lineEdit4->setEnabled(false);
	lineEdit5->setEnabled(false);

	radioButton1->setChecked(true);

	checkBox1->setCheckState(Qt::Unchecked);
	checkBox2->setCheckState(Qt::Unchecked);

}
//////////////////////////////////////////////////////////////////////
void ExpFileurl::keyPressEvent(QKeyEvent *event){
	int key=event->key();
	if(key==Qt::Key_Escape || key==Qt::Key_Enter || key==Qt::Key_Return){
		hideWindow();
	}

}
//////////////////////////////////////////////////////////////////////
void ExpFileurl::resizeEvent(QResizeEvent *e){
	int w=width();
	int h=height();
	if(e){}

	int x1=5, y1=21, y2=25;
	int dy=3, dx1=(int) (w/5);
	int x2=x1+dx1+5;
	int y=3;

	widget1->setGeometry(QRect(0, 0, w, h));

	radioButton1->setGeometry(QRect(x1, y, w-2*x1, y1));
	y+=y1;

	radioButton2->setGeometry(QRect(x1, y, w-2*x1, y1));
	y+=y1+dy*3;

	checkBox1->setGeometry(QRect(x1, y, w-2*x1, y1));
	y+=y1+dy;

	lineEdit1->setGeometry(QRect(5*x1, y, dx1, y1));
	textLabel1->setGeometry(QRect(x2+4*x1, y-3, w-x2-5, y2));
	y+=y1+dy;

	lineEdit2->setGeometry(QRect(5*x1, y, dx1, y1));
	textLabel2->setGeometry(QRect(x2+4*x1, y-3, w-x2-5, y2));
	y+=y1+dy;
	lineEdit3->setGeometry(QRect(5*x1, y, dx1, y1));
	textLabel3->setGeometry(QRect(x2+4*x1, y-3, w-x2-5, y2));
	y+=y1+dy*3;

	checkBox2->setGeometry(QRect(x1, y, w-2*x1, y1));
	y+=y1+dy;

	textLabel4->setGeometry(QRect(6*x1, y, dx1, y1));
	lineEdit4->setGeometry(QRect(x2+5*x1, y, w-x2-7*x1, y1));
	y+=y1+2;

	textLabel5->setGeometry(QRect(6*x1, y, dx1, y1));
	lineEdit5->setGeometry(QRect(x2+5*x1, y, w-x2-7*x1, y1));
	y+=y1+dy;

	pushButton1->setGeometry(QRect((int) (w/2-140), y+5, 135, 29));
	pushButton3->setGeometry(QRect((int) (w/2+5), y+5, 85, 29));

	QWidget::resizeEvent(e);
}
//////////////////////////////////////////////////////////////////////
void ExpFileurl::checkBoxStateChanged(int par){
	if(par){}
	bool s1=false, s2=false;
	if(checkBox1->checkState()==Qt::Checked)	s1=true;
	if(checkBox2->checkState()==Qt::Checked)	s2=true;

	lineEdit1->setEnabled(s1);
	lineEdit2->setEnabled(s1);
	lineEdit3->setEnabled(s1);
	lineEdit4->setEnabled(s2);
	lineEdit5->setEnabled(s2);

}
//////////////////////////////////////////////////////////////////////

