#include "expabout.h"

ExpAbout::ExpAbout(QWidget *parent) : QWidget(parent){
	widget1 = new QWidget(this);
	widget1->setGeometry(QRect(0, 0, 400, 345));
	this->setWindowTitle("About Storage Made Easy");
	this->setWindowIcon(QIcon("/usr/share/pixmaps/sme_explorer_icon_42.png"));
   widget1->setObjectName(QString::fromUtf8("widget1"));

	textLabel1 = new QLabel(widget1);
	textLabel1->setObjectName(QString::fromUtf8("textLabel1"));
	textLabel1->setGeometry(QRect(1, 10, 300, 25));
	textLabel1->setWordWrap(false);
	textLabel1->setText("<center><font size=\"+1\"><b>Storage Made Easy MultiCloud Explorer</b></font></center>");

	textLabel2 = new QLabel(widget1);
	textLabel2->setObjectName(QString::fromUtf8("textLabel2"));
	textLabel2->setGeometry(QRect(1, 45, 300, 18));
	textLabel2->setWordWrap(false);
	textLabel2->setText("<center>Version 4.3.3</center>");

	textLabel4 = new QLabel(widget1);
	textLabel4->setObjectName(QString::fromUtf8("textLabel4"));
	textLabel4->setGeometry(QRect(1, 70, 300, 25));
	textLabel4->setWordWrap(false);
	textLabel4->setOpenExternalLinks(true);
	textLabel4->setText("<center><a href='http://storagemadeeasy.com'>http://storagemadeeasy.com</a></center>");

	textLabel3 = new QLabel(widget1);
	textLabel3->setObjectName(QString::fromUtf8("textLabel3"));
	textLabel3->setGeometry(QRect(86, 100, 128, 128));
	textLabel3->setWordWrap(false);
	textLabel3->setPixmap(QPixmap("/usr/share/smeclient/smeclient.png"));

	textLabel5 = new QLabel(widget1);
	textLabel5->setObjectName(QString::fromUtf8("textLabel5"));
	textLabel5->setGeometry(QRect(26, 232, 250, 55));
	textLabel5->setWordWrap(true);
	textLabel5->setText("<center>Contact <a href='support@storagemadeeasy.com'>support@storagemadeeasy.com</a> to report errors</center>");

	textLabel6 = new QLabel(widget1);
	textLabel6->setObjectName(QString::fromUtf8("textLabel6"));
	textLabel6->setGeometry(QRect(26, 290, 250, 20));
	textLabel6->setWordWrap(false);
	textLabel6->setText("<center>Powered by Storage Made Easy</center>");

	pushButton1 = new QPushButton(widget1);
	pushButton1->setObjectName(QString::fromUtf8("pushButton1"));
	pushButton1->setGeometry(QRect(100, 321, 100, 27));
	pushButton1->setText("Close");


	QObject::connect(pushButton1, SIGNAL(clicked()), this, SLOT(hideWindow()));
}
//////////////////////////////////////////////////////////////////////
ExpAbout::~ExpAbout(){
}
//////////////////////////////////////////////////////////////////////
void ExpAbout::hideWindow(){
  this->hide();
}
//////////////////////////////////////////////////////////////////////
void ExpAbout::keyPressEvent(QKeyEvent *event){
	int key=event->key();
	if(key==Qt::Key_Escape || key==Qt::Key_Enter || key==Qt::Key_Return){
		hideWindow();
	}

}
//////////////////////////////////////////////////////////////////////
void ExpAbout::resizeEvent(QResizeEvent *e){
	int w=width(), h=height();
	int y=3;
	widget1->setGeometry(QRect(0, 0, w, h));
	if(e){}

	int fontSize=12;
	if(textLabel2->font().pixelSize()>8){
		fontSize=textLabel2->font().pixelSize();
	}else if(textLabel2->font().pointSize()>7){
		fontSize=(int) (textLabel2->font().pointSize()*1.3);
	}

	textLabel1->setGeometry(QRect(1, y, w-2, fontSize+13));
	y+=fontSize+13+2;
	textLabel2->setGeometry(QRect(1, y, w-2, fontSize+6));
	y+=fontSize+6+5;
	textLabel4->setGeometry(QRect(1, y, w-2, fontSize+13));
	y+=fontSize+13+5;
	textLabel3->setGeometry(QRect((int) ((w-128)/2), y, 128, 128));
	y+=128+4;
	textLabel5->setGeometry(QRect(1, y, w-2, fontSize+43));
	y+=fontSize+43+3;
	textLabel6->setGeometry(QRect(1, y, w-2, fontSize+8));
	y+=fontSize+8+5;
	pushButton1->setGeometry(QRect((int) ((w-120)/2), y, 120, fontSize+14));
	y+=fontSize+14+1;

	this->setMinimumHeight(y);
	widget1->setMinimumHeight(y);
}
