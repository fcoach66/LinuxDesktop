#include "exptinyurl.h"

ExpTinyurl::ExpTinyurl(QWidget *parent) : QWidget(parent){
	widget1 = new QWidget(this);
	widget1->setGeometry(QRect(0, 0, 510, 138));
	widget1->setMinimumSize(150, 50);
	this->setMinimumSize(150, 50);
	this->setWindowTitle("File URL");
	this->setWindowIcon(QIcon("/usr/share/pixmaps/sme_explorer_icon_42.png"));
   widget1->setObjectName(QString::fromUtf8("widget1"));

	int x1=5, y1=18, y2=25;
	int dy=20, dx1=60, dx2=435;
	int x2=x1+dx1+5;
	int y=23;

	textLabel1=new QLabel(widget1);
	textLabel1->setObjectName(QString::fromUtf8("textLabel1"));
	textLabel1->setGeometry(QRect(x1, y, dx1, y1));
	textLabel1->setText("File:");
	lineEdit1=new QLineEdit(widget1);
	lineEdit1->setObjectName(QString::fromUtf8("lineEdit1"));
	lineEdit1->setGeometry(QRect(x2, y-3, dx2, y2));
	lineEdit1->setReadOnly(true);
	y+=y1+dy-5;
/*
	textLabel2=new QLabel(widget1);
	textLabel2->setObjectName(QString::fromUtf8("textLabel2"));
	textLabel2->setGeometry(QRect(x1, y, dx1, y1));
	textLabel2->setText("TinyURL:");
	lineEdit2=new QLineEdit(widget1);
	lineEdit2->setObjectName(QString::fromUtf8("lineEdit2"));
	lineEdit2->setGeometry(QRect(x2, y-3, dx2, y2));
	lineEdit2->setReadOnly(true);
	y+=y1+dy-2;
*/
	textLabel3=new QLabel(widget1);
	textLabel3->setObjectName(QString::fromUtf8("textLabel3"));
	textLabel3->setGeometry(QRect(x1, y, dx1, y1));
	textLabel3->setText("URL:");
	lineEdit3=new QLineEdit(widget1);
	lineEdit3->setObjectName(QString::fromUtf8("lineEdit3"));
	lineEdit3->setGeometry(QRect(x2, y-3, dx2, y2));
	lineEdit3->setReadOnly(true);
	y+=y1+dy-2;

	pushButton1=new QPushButton(widget1);
	pushButton1->setObjectName(QString::fromUtf8("pushButton1"));
	pushButton1->setGeometry(QRect(160, y+5, 85, 29));
	pushButton1->setText("OK");

	pushButton2=new QPushButton(widget1);
	pushButton2->setObjectName(QString::fromUtf8("pushButton2"));
	pushButton2->setGeometry(QRect(265, y+5, 85, 29));
	pushButton2->setText("Cancel");

// Buttons
	QObject::connect(pushButton1, SIGNAL(clicked()), this, SLOT(hideWindow()));
	QObject::connect(pushButton2, SIGNAL(clicked()), this, SLOT(hideWindow()));
}
//////////////////////////////////////////////////////////////////////
ExpTinyurl::~ExpTinyurl(){
}
//////////////////////////////////////////////////////////////////////
void ExpTinyurl::hideWindow(){
  this->hide();
}
//////////////////////////////////////////////////////////////////////
void ExpTinyurl::initWnd(){
	lineEdit1->setText(name);
//	lineEdit2->setText(url);
	lineEdit3->setText(smeurl);

}
//////////////////////////////////////////////////////////////////////
void ExpTinyurl::keyPressEvent(QKeyEvent *event){
	int key=event->key();
	if(key==Qt::Key_Escape || key==Qt::Key_Enter || key==Qt::Key_Return){
		hideWindow();
	}

}
//////////////////////////////////////////////////////////////////////
void ExpTinyurl::resizeEvent(QResizeEvent *e){
	int w=width();
	int h=height();
	if(e){}

	int x1=5, y1=18, y2=25;
	int dy=20, dx1=(int) (w/5);
	int x2=x1+dx1+5;
	int y=23;

	widget1->setGeometry(QRect(0, 0, w, h));
//	ui->textLabel1->setGeometry(QRect(3, h-20, w-310, 16));		// 687

	textLabel1->setGeometry(QRect(x1, y, dx1, y1));
	lineEdit1->setGeometry(QRect(x2, y-3, w-x2-5, y2));
	y+=y1+dy;
/*
	textLabel2->setGeometry(QRect(x1, y, dx1, y1));
	lineEdit2->setGeometry(QRect(x2, y-3, w-x2-5, y2));
	y+=y1+dy-2;
*/
	textLabel3->setGeometry(QRect(x1, y, dx1, y1));
	lineEdit3->setGeometry(QRect(x2, y-3, w-x2-5, y2));
	y+=y1+dy-2;

	pushButton1->setGeometry(QRect((int) (w/2-90), y+5, 85, 29));
	pushButton2->setGeometry(QRect((int) (w/2+5), y+5, 85, 29));

	QWidget::resizeEvent(e);
}
//////////////////////////////////////////////////////////////////////

