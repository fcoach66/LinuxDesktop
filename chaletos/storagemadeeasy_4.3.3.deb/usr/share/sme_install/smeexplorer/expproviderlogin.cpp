#include <QDebug>
#include "expproviderlogin.h"

ExpProviderLogin::ExpProviderLogin(QWidget *parent) : QWidget(parent){
	widget1 = new QWidget(this);
	widget1->setGeometry(QRect(0, 0, 430, 178));
	this->setWindowTitle("Login");
	this->setWindowIcon(QIcon("/usr/share/pixmaps/sme_explorer_icon_42.png"));
   widget1->setObjectName(QString::fromUtf8("widget1"));

	countF=0;
	addProvider=false;
	pushButton1 = new QPushButton(widget1);
	pushButton1->setObjectName(QString::fromUtf8("pushButton1"));
	pushButton1->setGeometry(QRect(220, 10, 85, 29));
	pushButton1->setText("OK");
	pushButton2 = new QPushButton(widget1);
	pushButton2->setObjectName(QString::fromUtf8("pushButton2"));
	pushButton2->setGeometry(QRect(326, 10, 85, 29));
	pushButton2->setText("Cancel");


// Buttons
	QObject::connect(pushButton1, SIGNAL(clicked()), this, SLOT(bOK()));
	QObject::connect(pushButton2, SIGNAL(clicked()), this, SLOT(hideWindow()));
}
//////////////////////////////////////////////////////////////////////
ExpProviderLogin::~ExpProviderLogin(){
}
//////////////////////////////////////////////////////////////////////
void ExpProviderLogin::bOK(){
	fieldsres="";
	for(int i=0; i<countF; i++){
		if(fields[i].title!=""){
			if(fieldsres!="") fieldsres+="\n";
			if(fields[i].ptype=="c"){
				QString cvalue="0";
				if(fields[i].checkBox->checkState()==Qt::Checked) cvalue="1";
				fieldsres+=fields[i].id+ "=" +cvalue;
			}else{
				fieldsres+=fields[i].id+ "=" +fields[i].lineEdit->text();
			}
		}
	}

	if(addProvider){
		emit baddProvider();
	}else{
		emit OK();
	}
	this->hide();
}
//////////////////////////////////////////////////////////////////////
void ExpProviderLogin::hideWindow(){
  this->hide();
}
//////////////////////////////////////////////////////////////////////
void ExpProviderLogin::clear2(){
	if(countF>0){
		for(int i=countF-1; i>=0; i--){
			if(fields[i].title!=""){
				fields[i].title="";
				if(fields[i].ptype=="c"){
					delete fields[i].checkBox;
				}else{
					delete fields[i].textLabel;
					delete fields[i].lineEdit;
				}
			}
		}

		delete []fields;
		countF=0;
	}
	return ;
}
//////////////////////////////////////////////////////////////////////
void ExpProviderLogin::clear(){
	addProvider=false;
	fieldsres="";
	clear2();
	int maxCount=50;
	countF=0;
	fields=new Tfield[maxCount];
	for(int i=0; i<maxCount; i++){
		fields[i].id="";
		fields[i].title="";
	}
}
//////////////////////////////////////////////////////////////////////
void ExpProviderLogin::initWnd(){

}
//////////////////////////////////////////////////////////////////////
int ExpProviderLogin::addField(QString id, QString title, QString dafaultvalue, QString ptype, int y){
	Tfield elem;
	elem.id=id;
	elem.title=title;
	elem.ptype=ptype;
	if(ptype=="c"){
		elem.checkBox=new QCheckBox(title, widget1);
		elem.checkBox->setGeometry(QRect(5, y, 490, 26));
		if(dafaultvalue=="1" || dafaultvalue.toLower()=="y" || dafaultvalue.toLower()=="true"){
			elem.checkBox->setCheckState(Qt::Checked);
		}else{
			elem.checkBox->setCheckState(Qt::Unchecked);
		}
		QFont font1=elem.checkBox->font();
		font1.setPointSize(10);
		font1.setFamily("Arial");
	}else{
		elem.textLabel = new QLabel(widget1);
		QFont font1=elem.textLabel->font();
		font1.setPointSize(9);
		font1.setFamily("Arial");
		elem.textLabel->setFont(font1);

		elem.textLabel->setGeometry(QRect(5, y-1, 270, 28));
		elem.textLabel->setText(title);
		elem.textLabel->setWordWrap(true);

		elem.lineEdit = new QLineEdit(widget1);
		elem.lineEdit->setGeometry(QRect(275, y, 220, 26));
		elem.lineEdit->setText(dafaultvalue);

		if(ptype=="p"){		// this is password field
			elem.lineEdit->setEchoMode(QLineEdit::Password);
		}
	}

	fields[countF]=elem;
	countF++;

	return y+30;
}
//////////////////////////////////////////////////////////////////////
void ExpProviderLogin::keyPressEvent(QKeyEvent *event){
	int key=event->key();
	if(key==Qt::Key_Escape){
		hideWindow();
	}else if(key==Qt::Key_Enter || key==Qt::Key_Return){
		bOK();
	}

}
//////////////////////////////////////////////////////////////////////
void ExpProviderLogin::resizeEvent(QResizeEvent *e){
	int w=width();
	int h=height();
	widget1->setGeometry(QRect(0, 0, w, h));
	if(e){}

	if(countF<1) return ;

	int x=3, y=1;
	int x1=(int) ((w-2*x)/2), x2=w-x1-2*x-1;
	for(int i=0; i<countF; i++){
		if(fields[i].ptype=="c"){
			fields[i].checkBox->setGeometry(QRect(x, y, w-2*x, 26));
		}else{
			fields[i].textLabel->setGeometry(QRect(x, y-1, x1, 28));
			fields[i].lineEdit->setGeometry(QRect(x+x1+1, y, x2, 26));
		}
		y+=30;
	}

	pushButton1->setGeometry(QRect((int) (w/2-90), y+3, 85, 29));
	pushButton2->setGeometry(QRect((int) (w/2+5), y+3, 85, 29));
}



