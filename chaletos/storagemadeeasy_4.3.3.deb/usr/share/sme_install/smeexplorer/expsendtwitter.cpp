#include "stdio.h"
#include "expsendtwitter.h"

ExpSendTwitter::ExpSendTwitter(QWidget *parent) : QWidget(parent){
	widget1 = new QWidget(this);
	widget1->setGeometry(QRect(0, 0, 430, 228));
	this->setWindowTitle("Send File Link to Twitter");
	this->setWindowIcon(QIcon("/usr/share/pixmaps/sme_explorer_icon_42.png"));
   widget1->setObjectName(QString::fromUtf8("widget1"));

	int x1=3, y1=18, y2=25;
	int dy=20, dx1=75, dx2=295;
	int x2=x1+dx1+20;
	int y=7;

	textLabel1 = new QLabel(widget1);
	textLabel1->setObjectName(QString::fromUtf8("textLabel1"));
	textLabel1->setGeometry(QRect(x1, y, dx1, y1));
	textLabel1->setText("File:");
	lineEdit1 = new QLineEdit(widget1);
	lineEdit1->setObjectName(QString::fromUtf8("lineEdit1"));
	lineEdit1->setGeometry(QRect(x2, y-3, dx2, y2));
	lineEdit1->setReadOnly(true);
	y+=y1+dy-5;

	textLabel2 = new QLabel(widget1);
	textLabel2->setObjectName(QString::fromUtf8("textLabel2"));
	textLabel2->setGeometry(QRect(x1, y, dx1, y1));
	textLabel2->setText("Message:");
	textEdit1 = new QTextEdit(widget1);
	textEdit1->setObjectName(QString::fromUtf8("textEdit1"));
	textEdit1->setGeometry(QRect(x2, y-3, dx2, y2*6+3));
	y+=y2*6+dy-12;


	pushButton1 = new QPushButton(widget1);
	pushButton1->setObjectName(QString::fromUtf8("pushButton1"));
	pushButton1->setGeometry(QRect(122, y+5, 85, 29));
	pushButton1->setText("Send");

	pushButton2 = new QPushButton(widget1);
	pushButton2->setObjectName(QString::fromUtf8("pushButton2"));
	pushButton2->setGeometry(QRect(242, y+5, 85, 29));
	pushButton2->setText("Cancel");

// Buttons
	QObject::connect(pushButton1, SIGNAL(clicked()), this, SLOT(bshare()));
	QObject::connect(pushButton2, SIGNAL(clicked()), this, SLOT(hideWindow()));
}
//////////////////////////////////////////////////////////////////////
ExpSendTwitter::~ExpSendTwitter(){
}
//////////////////////////////////////////////////////////////////////
void ExpSendTwitter::hideWindow(){
  this->hide();
}
//////////////////////////////////////////////////////////////////////
void ExpSendTwitter::clear(){
	name="";
	message="";
	lineEdit1->setText("");
	textEdit1->setPlainText("");
}
//////////////////////////////////////////////////////////////////////
void ExpSendTwitter::initWnd(){
	lineEdit1->setText(name);

}
//////////////////////////////////////////////////////////////////////
void ExpSendTwitter::bshare(){
	message=textEdit1->toPlainText();
	if(message.length()<1){
		QMessageBox::critical(this, "Error", "    Enter your message    ");
		return ;
	}

	if(message.length()>113){
		QMessageBox::critical(this, "Error", "Message too long. Maximum 113 symbols.");
		return ;
	}

	emit sendToTwitter();
	this->hide();
}
//////////////////////////////////////////////////////////////////////
void ExpSendTwitter::keyPressEvent(QKeyEvent *event){
	int key=event->key();
	if(key==Qt::Key_Escape){
		hideWindow();
	}else if(key==Qt::Key_Enter || key==Qt::Key_Return){
		bshare();
	}

}
//////////////////////////////////////////////////////////////////////
void ExpSendTwitter::resizeEvent(QResizeEvent *e){
	int w=width();
	int h=height();
	widget1->setGeometry(QRect(0, 0, w, h));
	if(e){}

	int x1=3, y1=18, y2=25;
	int dy=20, dx1=(int) (w/3.5-x1), dx2=w-dx1-2*x1-5;
	int x2=x1+dx1+4;
	int y=7;

	textLabel1->setGeometry(QRect(x1, y-1, dx1, y1+2));
	lineEdit1->setGeometry(QRect(x2, y-3, dx2, y2));
	y+=y1+dy-5;

	textLabel2->setGeometry(QRect(x1, y-1, dx1, y1+2));
	textEdit1->setGeometry(QRect(x2, y-3, dx2, h-y-35));
	y+=h-y-35+4;

	pushButton1->setGeometry(QRect(x1+5, y, 100, 29));
	pushButton2->setGeometry(QRect(x1+125, y, 100, 29));

}


