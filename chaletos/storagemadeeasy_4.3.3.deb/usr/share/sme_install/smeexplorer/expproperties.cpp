#include "stdio.h"
#include "expproperties.h"

ExpProperties::ExpProperties(QWidget *parent) : QWidget(parent){
	widget1 = new QWidget(this);
	widget1->setGeometry(QRect(0, 0, 380, 335));
	this->setWindowTitle("Properties");
	this->setWindowIcon(QIcon("/usr/share/pixmaps/sme_explorer_icon_42.png"));
   widget1->setObjectName(QString::fromUtf8("widget1"));

	int x1=3, y1=18, y2=25;
	int dy=15, dx1=100, dx2=270;
	int x2=x1+dx1+20;
	int y=18;

	textLabel1 = new QLabel(widget1);
	textLabel1->setObjectName(QString::fromUtf8("textLabel1"));
	textLabel1->setGeometry(QRect(x1, y, dx1, y1));
	textLabel1->setText("Name:");
	lineEdit1 = new QLineEdit(widget1);
	lineEdit1->setObjectName(QString::fromUtf8("lineEdit1"));
	lineEdit1->setGeometry(QRect(x2, y-3, dx2, y2));
	lineEdit1->setReadOnly(true);
	y+=y1+dy;

	textLabel2 = new QLabel(widget1);
	textLabel2->setObjectName(QString::fromUtf8("textLabel2"));
	textLabel2->setGeometry(QRect(x1, y, dx1, y1));
	textLabel2->setText("Description:");
	lineEdit2 = new QLineEdit(widget1);
	lineEdit2->setObjectName(QString::fromUtf8("lineEdit2"));
	lineEdit2->setGeometry(QRect(x2, y-3, dx2, y2));
	lineEdit2->setReadOnly(true);
	y+=y1+dy;
//y-=35;		// ???

	textLabel3 = new QLabel(widget1);
	textLabel3->setObjectName(QString::fromUtf8("textLabel3"));
	textLabel3->setGeometry(QRect(x1, y, dx1, y1));
	textLabel3->setText("Tags:");
	lineEdit3 = new QLineEdit(widget1);
	lineEdit3->setObjectName(QString::fromUtf8("lineEdit3"));
	lineEdit3->setGeometry(QRect(x2, y-3, dx2, y2));
	lineEdit3->setReadOnly(true);
	y+=y1+dy;

	textLabel4 = new QLabel(widget1);
	textLabel4->setObjectName(QString::fromUtf8("textLabel4"));
	textLabel4->setGeometry(QRect(x1, y, dx1, y1));
	textLabel4->setText("Size:");
	lineEdit4 = new QLineEdit(widget1);
	lineEdit4->setObjectName(QString::fromUtf8("lineEdit4"));
	lineEdit4->setGeometry(QRect(x2, y-3, dx2, y2));
	lineEdit4->setReadOnly(true);
	y+=y1+dy;

	textLabel5 = new QLabel(widget1);
	textLabel5->setObjectName(QString::fromUtf8("textLabel5"));
	textLabel5->setGeometry(QRect(x1, y, dx1, y1));
	textLabel5->setText("Is Public:");
	lineEdit5 = new QLineEdit(widget1);
	lineEdit5->setObjectName(QString::fromUtf8("lineEdit5"));
	lineEdit5->setGeometry(QRect(x2, y-3, dx2, y2));
	lineEdit5->setReadOnly(true);
	y+=y1+dy;

	textLabel6 = new QLabel(widget1);
	textLabel6->setObjectName(QString::fromUtf8("textLabel6"));
	textLabel6->setGeometry(QRect(x1, y, dx1, y1));
	textLabel6->setText("Is Favourite:");
	lineEdit6 = new QLineEdit(widget1);
	lineEdit6->setObjectName(QString::fromUtf8("lineEdit6"));
	lineEdit6->setGeometry(QRect(x2, y-3, dx2, y2));
	lineEdit6->setReadOnly(true);
	y+=y1+dy;

	textLabel7 = new QLabel(widget1);
	textLabel7->setObjectName(QString::fromUtf8("textLabel7"));
	textLabel7->setGeometry(QRect(x1, y, dx1, y1));
	textLabel7->setText("Created:");
	lineEdit7 = new QLineEdit(widget1);
	lineEdit7->setObjectName(QString::fromUtf8("lineEdit7"));
	lineEdit7->setGeometry(QRect(x2, y-3, dx2, y2));
	lineEdit7->setReadOnly(true);
	y+=y1+dy;

	textLabel8 = new QLabel(widget1);
	textLabel8->setObjectName(QString::fromUtf8("textLabel8"));
	textLabel8->setGeometry(QRect(x1, y, dx1, y1));
	textLabel8->setText("Edited:");
	lineEdit8 = new QLineEdit(widget1);
	lineEdit8->setObjectName(QString::fromUtf8("lineEdit8"));
	lineEdit8->setGeometry(QRect(x2, y-3, dx2, y2));
	lineEdit8->setReadOnly(true);
	y+=y1+dy;

	textLabel9 = new QLabel(widget1);
	textLabel9->setObjectName(QString::fromUtf8("textLabel9"));
	textLabel9->setGeometry(QRect(x1, y, dx1, y1));
	textLabel9->setText("Last accessed:");
	lineEdit9 = new QLineEdit(widget1);
	lineEdit9->setObjectName(QString::fromUtf8("lineEdit9"));
	lineEdit9->setGeometry(QRect(x2, y-3, dx2, y2));
	lineEdit9->setReadOnly(true);
	y+=y1+dy;

	textLabel10 = new QLabel(widget1);
	textLabel10->setObjectName(QString::fromUtf8("textLabel10"));
	textLabel10->setGeometry(QRect(x1, y, dx1, y1));
	textLabel10->setText("Is Encrypted:");
	lineEdit10 = new QLineEdit(widget1);
	lineEdit10->setObjectName(QString::fromUtf8("lineEdit10"));
	lineEdit10->setGeometry(QRect(x2, y-3, dx2, y2));
	lineEdit10->setReadOnly(true);
	y+=y1+dy;

	textLabel11 = new QLabel(widget1);
	textLabel11->setObjectName(QString::fromUtf8("textLabel11"));
	textLabel11->setGeometry(QRect(x1, y, dx1, y1));
	textLabel11->setText("Is Locked:");
	lineEdit11 = new QLineEdit(widget1);
	lineEdit11->setObjectName(QString::fromUtf8("lineEdit11"));
	lineEdit11->setGeometry(QRect(x2, y-3, dx2, y2));
	lineEdit11->setReadOnly(true);
	y+=y1+dy;

	pushButton1 = new QPushButton(widget1);
	pushButton1->setObjectName(QString::fromUtf8("pushButton1"));
	pushButton1->setGeometry(QRect(172, y+5, 85, 29));
	pushButton1->setText("OK");



// Buttons
	QObject::connect(pushButton1, SIGNAL(clicked()), this, SLOT(hideWindow()));
}
//////////////////////////////////////////////////////////////////////
ExpProperties::~ExpProperties(){
}
//////////////////////////////////////////////////////////////////////
void ExpProperties::hideWindow(){
  this->hide();
}
//////////////////////////////////////////////////////////////////////
void ExpProperties::clear(){
	name="";
	description="";
	tags="";
	lastmodify="";
	id="";
	pid="";
	size="";
	type=0;					// 0 - file, 1 - folder, 2 - user, 3 - group
	encrypted=false;
	uid="";
	extension="";
	isPublic=false;
	isLocked=false;
	isFavorite=false;
	provider=-1;
	orgid=-1;
	orgfolderid=-1;

//	textLabel3->hide();
//	lineEdit3->hide();

}
//////////////////////////////////////////////////////////////////////
QString ExpProperties::readableSize(QString size){
	if(size=="") size="0";
	QString orignSize="";

	bool ok;
	qint64 n = size.toLongLong(&ok, 10);
	if(!ok) return size;		// Cannot convert to int

	QString v="B";
	if(n>1024){
		n=(qint64) n/1024;
		v="KB";
		orignSize=size;
		if(n>1024){
			n=(qint64) n/1024;
			v="MB";
			if(n>1024){
				n=(qint64) n/1024;
				v="GB";
			}
		}
	}

	//char buffer[100];
	//sprintf(buffer, "%d", n);
	QString res;
	//res.append(buffer);
	res = QString::number(n) +" "+ v;
	if(orignSize!="")
		res += "  ("+orignSize+" B)";

	return res;
}
//////////////////////////////////////////////////////////////////////
void ExpProperties::initWnd(){
	lineEdit1->setText(name);
	lineEdit2->setText(description);
	lineEdit3->setText(tags);
	lineEdit4->setText(readableSize(size));
	if(isPublic){
		lineEdit5->setText("Yes");
	}else{
		lineEdit5->setText("No");
	}

	if(isFavorite){
		lineEdit6->setText("Yes");
	}else{
		lineEdit6->setText("No");
	}

	lineEdit7->setText(created);
	lineEdit8->setText(lastmodify);
	lineEdit9->setText(lastaccess);

	if(encrypted){
		lineEdit10->setText("Yes");
	}else{
		lineEdit10->setText("No");
	}

	if(isLocked){
		lineEdit11->setText("Yes");
	}else{
		lineEdit11->setText("No");
	}

	QString eName="";
	if(type==0){
		eName="File";
	}else if(type==1){
		eName="Folder";
	}else if(type==2){
		eName="User";
	}else if(type==3){
		eName="Group";
	}

	if(sx<0) sx=0;
	if(sy<0) sy=0;
	move(QPoint(sx, sy));

}
//////////////////////////////////////////////////////////////////////
void ExpProperties::keyPressEvent(QKeyEvent *event){
	int key=event->key();
	if(key==Qt::Key_Escape || key==Qt::Key_Enter || key==Qt::Key_Return){
		hideWindow();
	}

}
//////////////////////////////////////////////////////////////////////
void ExpProperties::resizeEvent(QResizeEvent *e){
	int w=width();
	int h=height();
	widget1->setGeometry(QRect(0, 0, w, h));
	if(e){}

	int fontSize=12;
	if(textLabel1->font().pixelSize()>8){
		fontSize=textLabel1->font().pixelSize();
	}else if(textLabel1->font().pointSize()>7){
		fontSize=(int) (textLabel1->font().pointSize()*1.3);
	}

	int x1=3, y1=fontSize+4, y2=fontSize+9;
	int dy=10, dx1=(int) (w/2-x1-30-3), dx2=dx1+60;
	int x2=x1+dx1+3;
	int y=5;

	textLabel1->setGeometry(QRect(x1, y, dx1, y1));
	lineEdit1->setGeometry(QRect(x2, y-3, dx2, y2));
	y+=y1+dy;

	textLabel2->setGeometry(QRect(x1, y, dx1, y1));
	lineEdit2->setGeometry(QRect(x2, y-3, dx2, y2));
	y+=y1+dy;

	textLabel3->setGeometry(QRect(x1, y, dx1, y1));
	lineEdit3->setGeometry(QRect(x2, y-3, dx2, y2));
	y+=y1+dy;

	textLabel4->setGeometry(QRect(x1, y, dx1, y1));
	lineEdit4->setGeometry(QRect(x2, y-3, dx2, y2));
	y+=y1+dy;

	textLabel5->setGeometry(QRect(x1, y, dx1, y1));
	lineEdit5->setGeometry(QRect(x2, y-3, dx2, y2));
	y+=y1+dy;

	textLabel6->setGeometry(QRect(x1, y, dx1, y1));
	lineEdit6->setGeometry(QRect(x2, y-3, dx2, y2));
	y+=y1+dy;

	textLabel7->setGeometry(QRect(x1, y, dx1, y1));
	lineEdit7->setGeometry(QRect(x2, y-3, dx2, y2));
	y+=y1+dy;

	textLabel8->setGeometry(QRect(x1, y, dx1, y1));
	lineEdit8->setGeometry(QRect(x2, y-3, dx2, y2));
	y+=y1+dy;

	textLabel9->setGeometry(QRect(x1, y, dx1, y1));
	lineEdit9->setGeometry(QRect(x2, y-3, dx2, y2));
	y+=y1+dy;

	textLabel10->setGeometry(QRect(x1, y, dx1, y1));
	lineEdit10->setGeometry(QRect(x2, y-3, dx2, y2));
	y+=y1+dy;

	textLabel11->setGeometry(QRect(x1, y, dx1, y1));
	lineEdit11->setGeometry(QRect(x2, y-3, dx2, y2));
	y+=y1+dy;

	pushButton1->setGeometry(QRect((int) (w/2-45), y, 90, 29));
}

