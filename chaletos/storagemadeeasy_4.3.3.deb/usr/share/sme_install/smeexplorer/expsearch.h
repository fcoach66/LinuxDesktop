#ifndef EXPSEARCH_H
#define EXPSEARCH_H

#include <QtGui/QWidget>
#include <QtGui/QLabel>
#include <QtGui/QCheckBox>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QWidget>
#include <Qt3Support/Q3MimeSourceFactory>
#include <QtGui/QMessageBox>
#include <QtGui/QCheckBox>
#include <QComboBox>
#include <QtGui/QKeyEvent>

class ExpSearch : public QWidget
{
    Q_OBJECT

public:
	ExpSearch(QWidget *parent = 0);
	~ExpSearch();
	void clear();
	void initWnd();
	QString stext, typeOfSearch;
	bool byName, byExtension, byExtensionExactly, byDescription, byTags;
	int typeSearch;			// 0 - My files only, 1 - My & shared file, 2 - Public files

	QWidget *widget1;
	QLabel *textLabel1;
	QPushButton *pushButton1, *pushButton2;
	QLineEdit *lineEdit1;
	QCheckBox *checkBox1, *checkBox2, *checkBox3, *checkBox4, *checkBox5;
	QComboBox *comboBox1, *comboBox2;

public
  slots:
    void bOK();
    void hideWindow();

  signals:
    void startSearch();

private:
	virtual void keyPressEvent(QKeyEvent * event);
	virtual void resizeEvent(QResizeEvent * e);

};

#endif // EXPSEARCH_H
