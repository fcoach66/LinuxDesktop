#ifndef EXPCREATEFOLDER_H
#define EXPCREATEFOLDER_H

#include <QtGui/QWidget>
#include <QtGui/QLabel>
#include <QtGui/QCheckBox>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QWidget>
#include <Qt3Support/Q3MimeSourceFactory>
#include <QtGui/QMessageBox>
#include <QtGui/QCheckBox>
#include <QtGui/QKeyEvent>


class ExpCreateFolder : public QWidget
{
    Q_OBJECT

public:
	ExpCreateFolder(QWidget *parent = 0);
	~ExpCreateFolder();
	void clear();
	void initWnd();
	QString foldername, folderdesc, foldertags, pid, lastid;
	bool isOrg, allUserCanSubmits, gprivate;
	int sx, sy;
	bool createwnd, uploadfolder;
	int type;	// 0 - file, 1 - folder, 2 - user, 3 - group

	QWidget *widget1;
	QLabel *textLabel1, *textLabel2, *textLabel3;
	QPushButton *pushButton1, *pushButton2;
	QLineEdit *lineEdit1, *lineEdit2, *lineEdit3;
	QCheckBox *checkBox1, *checkBox2;

public
  slots:
    void bcreateFolder();
    void hideWindow();

  signals:
    void createFolder();
    void createGroup();
    void renameFolder();
    void renameFile();
    void renameGroup();

private:
	virtual void keyPressEvent(QKeyEvent * event);


};

#endif // EXPCREATEFOLDER_H
