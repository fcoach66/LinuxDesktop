#ifndef EXPABOUT_H
#define EXPABOUT_H

#include <QtGui/QWidget>
#include <QtGui/QLabel>
#include <QtGui/QPushButton>
#include <QtGui/QWidget>
#include <Qt3Support/Q3MimeSourceFactory>
#include <QtGui/QMessageBox>
#include <QtGui/QKeyEvent>

class ExpAbout : public QWidget
{
    Q_OBJECT
public:
	ExpAbout(QWidget *parent = 0);
	~ExpAbout();

	QWidget *widget1;
	QLabel *textLabel1, *textLabel2, *textLabel3, *textLabel4, *textLabel5, *textLabel6;
	QPushButton *pushButton1;

public
  slots:
	void hideWindow();

private:
	virtual void keyPressEvent(QKeyEvent * event);
	virtual void resizeEvent(QResizeEvent * e=NULL);


};

#endif // EXPABOUT_H
