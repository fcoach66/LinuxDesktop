#ifndef EXPIMPORT_H
#define EXPIMPORT_H

#include <QtGui/QWidget>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QWidget>
#include <Qt3Support/Q3MimeSourceFactory>
#include <QtGui/QMessageBox>
#include <QListWidget>
#include <QListWidgetItem>
#include <QModelIndex>
#include <QtGui/QComboBox>
#include <QtGui/QKeyEvent>


typedef struct {
	QString id, name;
	QListWidgetItem *node;
} TProvider;

typedef struct {
	QString id, name;
	QListWidgetItem *node;
} TFolder;

class ExpImport : public QWidget
{
    Q_OBJECT

public:
	ExpImport(QWidget *parent = 0);
	~ExpImport();
	void clear();
	void clear2();
	void initWnd();
	bool addToTree(QString id, QString name);
	bool addFolderToTree(QString id, QString name);
	void lockAll();
	void unlockAll();

	QString foldername, folderid, providerid, destinationId;

	bool import, isLocked;
	int countP, countF;
	TProvider *providers;
	TFolder *folders;

	QWidget *widget1;
	QLabel *textLabel1, *textLabel2, *textLabel3;
	QPushButton *pushButton1, *pushButton2;
	QLineEdit *lineEdit1;
	QComboBox *comboBox1;
	QListWidget *prList, *dirList;


private:
	virtual void resizeEvent(QResizeEvent * e);

public
  slots:
	void bimport();
	void hideWindow();
	void getProviderMetaFields();

  signals:
	void bImport();
	void importGetProviderMetaFields();
	void bExport();
//	void importGetProviderMetaFields();

private:
	virtual void keyPressEvent(QKeyEvent * event);


};

#endif // EXPIMPORT_H
