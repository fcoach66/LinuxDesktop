#include "propertieswidget.h"
#include "ui_propertieswidget.h"

#include <stdio.h>

propertiesWidget::propertiesWidget(QWidget *parent) : QWidget(parent), ui(new Ui::propertiesWidget){
	ui->setupUi(this);

	login="";
	password="";
	apihost="";
	proxyhost="";
	proxyport=80;
	proxylogin="";
	proxypass="";
	useProxy=false;
//	defaultFolder="";

	DEBUG=-1;		//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

	QObject::connect(ui->pushButton1, SIGNAL(clicked()), this, SLOT(saveProperties()));
	QObject::connect(ui->pushButton2, SIGNAL(clicked()), this, SLOT(hideWindow()));
	QObject::connect(ui->checkBox1, 	SIGNAL(stateChanged(int)), this, SLOT(checkBox1StateChanged(int)));
}
//////////////////////////////////////////////////////////////////////
propertiesWidget::~propertiesWidget(){
  delete ui;
}
//////////////////////////////////////////////////////////////////////
void propertiesWidget::saveProperties(){
	login		=ui->lineEdit1->text();
	password	=ui->lineEdit2->text();

	if(login.length()<1){
		QMessageBox::critical(this, tr("Error"), "     Enter login     ");
		return ;
	}

	if(password.length()<1){
		QMessageBox::critical(this, tr("Error"), "   Enter password   ");
		return ;
	}

	if(ui->checkBox1->checkState()==Qt::Checked){
		useProxy=true;
	}else{
		useProxy=false;
	}

	if(useProxy){
		QString xproxyhost=ui->lineEdit3->text();
		int xproxyport=ui->lineEdit4->text().toInt();
		if(xproxyhost.length()<1){
			QMessageBox::critical(this, tr("Error"), "   Enter proxy host   ");
			return ;
		}

		if(xproxyport<1){
			QMessageBox::critical(this, tr("Error"), "Proxy port must be between 1 and 65535 ");
			return ;
		}
		proxyhost	=xproxyhost;
		proxyport	=xproxyport;
		proxylogin	=ui->lineEdit5->text();
		proxypass	=ui->lineEdit6->text();
	}

	QLineEdit *edit=ui->comboBox1->lineEdit();
	apihost=edit->text().toLower();
	if(apihost=="") apihost="storagemadeeasy.com";

	emit propertiesWidgetClickOKButton();

	this->hide();
}
//////////////////////////////////////////////////////////////////////
void propertiesWidget::hideWindow(){
	this->hide();
}
//////////////////////////////////////////////////////////////////////
void propertiesWidget::initWnd(){
	ui->lineEdit1->setText(login);
	ui->lineEdit2->setText(password);

	ui->lineEdit3->setText(proxyhost);
	ui->lineEdit4->setText(intToQstring(proxyport));
	ui->lineEdit5->setText(proxylogin);
	ui->lineEdit6->setText(proxypass);

	if(useProxy){
		ui->checkBox1->setCheckState(Qt::Checked);
	}else{
		ui->checkBox1->setCheckState(Qt::Unchecked);
	}
	ui->groupBox->setEnabled(useProxy);


	QLineEdit *edit=ui->comboBox1->lineEdit();
	edit->setText(apihost);
}
//////////////////////////////////////////////////////////////////////
void propertiesWidget::debug(QString s, int level){
	if(level<=DEBUG){
		QByteArray b = s.toLatin1();
		char *c=b.data();
		printf("%s\n", c);
	}

}
//////////////////////////////////////////////////////////////////////
QString propertiesWidget::intToQstring(int n){
	char buffer[100];
	sprintf(buffer, "%d", n);
	QString res;
	res.append(buffer);

	return res;
}
//////////////////////////////////////////////////////////////////////
QString propertiesWidget::floatToQstring(double n){
	char buffer[100];
	sprintf(buffer, "%f", n);
	QString res;
	res.append(buffer);

  int s=res.indexOf(",");
  if(s>0){
	  res=res.mid(0, s);
  }else{
	  s=res.indexOf(".");
		if(s>0)	res=res.mid(0, s);
  }

	return res;
}
//////////////////////////////////////////////////////////////////////
void propertiesWidget::keyPressEvent(QKeyEvent *event){
	int key=event->key();
	if(key==Qt::Key_Escape){
		hideWindow();
	}else if(key==Qt::Key_Enter || key==Qt::Key_Return){
		saveProperties();
	}

}
//////////////////////////////////////////////////////////////////////
void propertiesWidget::checkBox1StateChanged(int par){
	if(par){}
	bool s=false;
	if(ui->checkBox1->checkState()==Qt::Checked)	s=true;
	ui->groupBox->setEnabled(s);

}
//////////////////////////////////////////////////////////////////////

