#include "mainwidget.h"
#include "ui_mainwidget.h"
#include "cqthread.h"

#include <stdio.h>
#include <QTimer>
#include <QProcess>
#include <QTextCodec>
#include <QInputDialog>

#include <sys/mman.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <sys/ipc.h> 
#include <fcntl.h>
#include <unistd.h>
 
MainWidget *MainWidgetObj;

////////////////////////////////////////////////////////////////////////////////////////
// Gtk slots of App Indicator
void gOnShowLog(GtkMenu *menu, gpointer data){	//IgnoreOnCentOS
	if(menu || data){}			//IgnoreOnCentOS
	MainWidgetObj->bShowLog();		//IgnoreOnCentOS
}						//IgnoreOnCentOS

void gOnShowWindow(GtkMenu *menu, gpointer data){	//IgnoreOnCentOS
	if(menu || data){}			//IgnoreOnCentOS
	MainWidgetObj->showWindowFromTray();			//IgnoreOnCentOS
}						//IgnoreOnCentOS
////////////////////////////////////////////////////////////////////////////////////////

MainWidget::MainWidget(QWidget *parent) : QWidget(parent), ui(new Ui::MainWidget){
	// type = 0 - need to open normal window
	// type = 1 - need to open specific window
	ui->setupUi(this);
	MainWidgetObj = this;

	DEBUG = 100;

	typeOfTrayIcon = 0;	// 0 - icon in system tray, 1 - app indicator
	trayIcon=new QSystemTrayIcon(this);
	trayIconMenu=new QMenu(this);
	trayIcon->setContextMenu(trayIconMenu);

	// Add action to tray icon menu
	aShowLog = trayIconMenu->addAction(tr("Show log"));
	aShowWindow = trayIconMenu->addAction(tr("Show window"));

	QObject::connect(aShowLog, SIGNAL(triggered()), this, SLOT(bShowLog()));
	QObject::connect(aShowWindow, SIGNAL(triggered()), this, SLOT(showWindowFromTray()));
	//QObject::connect(trayIcon, SIGNAL(activated(QSystemTrayIcon::ActivationReason)), this, SLOT(showWindowFromTray()));

	server="storagemadeeasy.com";
	login="";
	password="";
	providerLogin="";
	providerPassword="";

	useProxy=false;
	proxyport=80;
	proxyhost="";
	proxylogin="";
	proxypass="";
	
	cacheLiveTime=30;
	curentFolder="";
	shareDrive=false;
	showEncryptedFiles = false;
	defaultEncryptionPhrase = "";

	fErrorLogName = QDir::homePath() + "/StorageMadeEasy_log.txt";
	fCnfName = QDir::homePath() + "/.StorageMadeEasy.cnf";
	fLogName = QDir::homePath() + "/.StorageMadeEasy.log";
	QString fCnfNameOld = QDir::homePath() + "/.SMEStorage.cnf";
	QString fLogNameOld = QDir::homePath() + "/.smestorage.log";
	if(!QFile::exists(fCnfName) && QFile::exists(fCnfNameOld)) QFile::rename(fCnfNameOld, fCnfName);
	if(!QFile::exists(fLogName) && QFile::exists(fLogNameOld)) QFile::rename(fLogNameOld, fLogName);

	canPasswordBeEncrypted = true;
	encryptionKeyForPassword = getEncryptionKeyForPassword();
	if(decryptSMEPassword(encryptSMEPassword("12345678901234567890123456789012345678901234567890"))!="12345678901234567890123456789012345678901234567890"){
		canPasswordBeEncrypted = false;
	}

	fileMen=new QString[5];
	fileMen[0]="gnome-open";
	fileMen[1]="kde-open";
	fileMen[2]="konqueror";
	fileMen[3]="nautilus";
	fileMen[4]="krusader --left";

// Buttons
	QObject::connect(ui->pushButton1, SIGNAL(clicked()), this, SLOT(selectFolder()));
	QObject::connect(ui->pushButton2, SIGNAL(clicked()), this, SLOT(mount()));
	QObject::connect(ui->pushButton3, SIGNAL(clicked()), this, SLOT(hideInTray()));
	QObject::connect(ui->pushButton4, SIGNAL(clicked()), this, SLOT(exit()));

	QObject::connect(ui->pushButton11,SIGNAL(clicked()), this, SLOT(openFolder()));
	QObject::connect(ui->pushButton21,SIGNAL(clicked()), this, SLOT(unMount()));

// Menu
	QObject::connect(ui->filenew_itemAction,		SIGNAL(triggered()), this, SLOT(selectFolder()));
	QObject::connect(ui->fileMountAction,			SIGNAL(triggered()), this, SLOT(mount()));
	QObject::connect(ui->fileExitAction,			SIGNAL(triggered()), this, SLOT(exit()));
	QObject::connect(ui->fileOpen_folderAction,	SIGNAL(triggered()), this, SLOT(openFolder()));
	QObject::connect(ui->fileUnmountAction,		SIGNAL(triggered()), this, SLOT(unMount()));
	QObject::connect(ui->fileSyncAction,			SIGNAL(triggered()), this, SLOT(sync()));
	QObject::connect(ui->fileQuickSyncAll,			SIGNAL(triggered()), this, SLOT(quickSyncAll()));
	QObject::connect(ui->fileQuickSyncUp,			SIGNAL(triggered()), this, SLOT(quickSyncUp()));
	QObject::connect(ui->fileQuickSyncDown,		SIGNAL(triggered()), this, SLOT(quickSyncDown()));
	QObject::connect(ui->fileClearCacheAction,	SIGNAL(triggered()), this, SLOT(clearCache()));
	QObject::connect(ui->fileAdvancedAction,		SIGNAL(triggered()), this, SLOT(advanced()));
	QObject::connect(ui->helpAboutAction,			SIGNAL(triggered()), this, SLOT(about()));
	QObject::connect(ui->logout,						SIGNAL(triggered()), this, SLOT(logOut()));
//	QObject::connect(ui->copyMountCommandToClipboard,	SIGNAL(triggered()), this, SLOT(bCopyMountCommandToClipboard()));
	QObject::connect(ui->showCommandForMount,		SIGNAL(triggered()), this, SLOT(bshowCommandForMount()));

	QObject::connect(&ad, SIGNAL(clickOKButton()), this, SLOT(saveAdvanced()));
	QObject::connect(&providerlog, SIGNAL(saveProviderLog()), this, SLOT(saveProviderLog()));
}
//////////////////////////////////////////////////////////////////////
MainWidget::~MainWidget(){
	delete ui;
}
//////////////////////////////////////////////////////////////////////
void MainWidget::init(){
	showTrayIcon(trayIcon);
	QTimer::singleShot(100, this, SLOT(refreshTrayMenu()));

	localeEncoding=runCommand("locale charmap");
	if(localeEncoding.indexOf("utf8", 0, Qt::CaseInsensitive)>-1 || localeEncoding.indexOf("utf-8", 0, Qt::CaseInsensitive)>-1){
		localeEncoding="";
	}else if(localeEncoding!=""){
		localeEncoding.replace(QRegExp("[ \t\r\n]+"), "");
	}else{
		localeEncoding="";
	}
	if(localeEncoding!="")	debug("localeEncoding="+localeEncoding +";");

	loadConfig();
	updateMenu();

	if(QFile::exists("/usr/local/bin/smestorage")){		// need show window with information about deleting old version
		QProcess *process2=new QProcess();
		if(!process2->startDetached("smeexplorer --onlycheckforoldversion=1")) debug("Can't show window with information about deleting old version");	
	}

}
//////////////////////////////////////////////////////////////////////
void MainWidget::selectFolder(){
	QString dir=QFileDialog::getExistingDirectory(this, tr("Select Folder"), "", QFileDialog::ShowDirsOnly | QFileDialog::DontResolveSymlinks);

	if(dir.length()>0){
		curentFolder=dir;
		if(curentFolder[curentFolder.length()-1]!='/') curentFolder.append("/");
		ui->lineEdit3->setText(curentFolder);
	}

}
//////////////////////////////////////////////////////////////////////
QStringList MainWidget::getCommandForMount(bool runCheckOptions, int type){
	// type=0 - with "--DEBUG --al"
	// This function return LIST OF ARGUMENTS that should be added to smemount!
	// return empty list if login/password/server/folder is incorrect
	QStringList arguments;
	if(runCheckOptions){
		if(checkOptions(true, true, true)!=0)	return arguments;
	}

	QString provLog = "";
	if(providerLogin.length()>0 && providerPassword.length()>0)	provLog=" base64-"+ base64(providerLogin) +":base64-"+ base64(providerPassword);

	if(canPasswordBeEncrypted){
		arguments << curentFolder << "base64-"+ base64(login) +":base64a-"+ base64(encryptSMEPassword(password));
	}else{
		arguments << curentFolder << "base64-"+ base64(login) +":base64-"+ base64(password);
	}

	if(provLog!="") arguments << provLog;
	if(type==0)
		arguments << "--DEBUG" <<  "--al";
	arguments << "--server=\""+ server +"\"" << "--ct="+intToQstring(cacheLiveTime);
	if(shareDrive) arguments << "--ao";

	if(showEncryptedFiles){
		arguments << "--se" << "--ef" << encryptSMEPassword(defaultEncryptionPhrase);
	}

	return arguments;
}
//////////////////////////////////////////////////////////////////////
void MainWidget::mount(){
	QStringList arguments = getCommandForMount(true, 0);	// type=0 - with "--DEBUG --al"
	if(arguments.size()<1) return ;

	saveConfig();
	unMount();

	QString cmdQSt = "smemount";
	QStringList argumentsTMP = arguments;
	QString messX1 = "\""+ QString(argumentsTMP.at(0)).replace("\\", "\\\\").replace("$", "\\$").replace("\"", "\\\"") + "\" ";
	argumentsTMP.removeFirst();
	for(int k1=0; k1<argumentsTMP.size(); k1++){
		if(argumentsTMP.at(k1)=="--al") argumentsTMP.removeAt(k1);
	}

	messX1 += argumentsTMP.join(" ");

	debug(cmdQSt + " " + messX1, 2);		// Show command in terminal

	char buf[5];
	QString buf2="", buf3="";
	int error=-1;

	for(int i=0; i<5; i++){
		buf[i]=' ';
	}

	QProcess *process2=new QProcess();
	process2->startDetached(cmdQSt, arguments);

	QFile logFile(fLogName);
	logFile.open(QIODevice::ReadOnly | QIODevice::Text);
	//  QDataStream in(&logFile);

	int i001=0;
	sleep(1);
	while((QFile::exists(fLogName)==false || logFile.size()<3) && i001<11){
		sleep(1);
		i001++;
	}

	sleep(1);

	if(QFile::exists(fLogName)!=false){
		FILE *f_in;

		QByteArray tmName;
		if(localeEncoding!=""){
			QTextCodec *codec = QTextCodec::codecForName(localeEncoding.toUtf8().data());
			tmName = codec->fromUnicode(fLogName);
		}else{
			tmName = fLogName.toUtf8();
		}

		f_in=fopen(tmName.data(), "r");
		if(!f_in && localeEncoding!=""){		// try to use UTF-8 name
			tmName = fLogName.toUtf8();
			f_in=fopen(tmName.data(), "r");
		}
		
//		f_in = fopen(fLogName.toUtf8().data(), "r");
		if(f_in){
			while(!feof(f_in)){
				if(fread(buf, 1, 1, f_in)>0){
					buf2.append(buf[0]);
				}
			}

			fclose(f_in);
		}
	}

	debug(buf2, 10);
	if(buf2.indexOf("notice=1")>-1){
		getProviderLoginAndPassword();
		return ;
	}

	if(buf2.length()>1 && buf2.indexOf("Backgrounding...")>0){
		buf2.replace(" Backgrounding...\n", "");
		buf2.replace("Backgrounding...", "");
	}

	if(buf2.length()>1 && buf2.indexOf("Check your Provider login and Provider password")>0){
		error=20;
		QMessageBox::critical(this, tr("Error"), "Check your Provider login and Provider password!");
		getProviderLoginAndPassword();
		return ;
	}

	if(buf2.length()>1 && buf2.indexOf("failed to exec fusermount: Permission denied")>0){
		error=21;
		QMessageBox::critical(this, tr("Error"), "fuse: failed to exec fusermount: Permission denied<br>Could not mount fuse filesystem!<br>You do not have access for executing file /bin/fusermount");
	}

	buf2.replace("fusermount: failed to open /etc/fuse.conf: Permission denied", ""); // This is not error.
	if(buf2.length()>1 && error==-1){
		QMessageBox::critical(this, tr("Error"), buf2);
		error=1;
	}

	bool status=false;
	for(int k1=0; (k1<10 && error==-1) || (k1<2 && error!=-1); k1++){
debug("k1="+intToQstring(k1));
		repaint();
//		int L=0;
		status=isMounted(curentFolder);
		if(status){
//			if(shareDrive && PermissionFUSE==0 && L==0){
//			  QMessageBox::critical(this, tr("Information"), "Failed to open /etc/fuse.conf: Permission denied.<br>fuse.conf is not edited so mounting in unshared mode.");
//				L=1;
//			}

//			if(L==0){
				QString mess_1="       Success       ";
//				if(shareDrive && PermissionFUSE==0){
//					mess_1 = mess_1 + "<br><br>Warnings<br>Failed to open /etc/fuse.conf: Permission denied.<br>fuse.conf is not edited so mounting in unshared mode.";
//				}
	
				QMessageBox::information(this, tr("Success"), mess_1);
//			}
			break;
		}else{
//			if(error<1) QMessageBox::critical(this, tr("Error"), "Can't mount!       ");
		}
		sleep(1);
	}

	if(!status && error<1) QMessageBox::critical(this, tr("Error"), "Can't mount!       ");

	updateMenu();
	return ;
}
//////////////////////////////////////////////////////////////////////
void MainWidget::unMount(){
	if(!isMounted(curentFolder)) return ;

	QString curFolder=curentFolder;
	curFolder.replace("\\", "\\\\");
	curFolder.replace("\"", "\\\"");
	curFolder.replace("$", "\\$");
	QString cmdQSt1 = "fusermount -u \""+ curFolder +"\"";
	QByteArray cmdQSt2;

	if(localeEncoding!=""){
		QTextCodec *codec = QTextCodec::codecForName(localeEncoding.toUtf8().data());
		QByteArray tmName = codec->fromUnicode(curFolder);
		cmdQSt2.append("fusermount -u \""+ tmName +"\"");
	}

	char buf[BUFSIZ];
	QString buf2="";
	FILE *ptr;
debug("cmdQSt1 => " +cmdQSt1);
	ptr = popen(cmdQSt1.toUtf8().data(), "r");			// Try to unmount folder with UTF-8 name
	while (fgets(buf, BUFSIZ, ptr) != NULL){
		buf2.append(buf);
		break;
	}
	(void) pclose(ptr);

	if(cmdQSt2!=""){						// Try to unmount folder with locale encoding name
		char bufX[BUFSIZ];
		QString buf2X="";
		FILE *ptrX;
debug("cmdQSt2 => " +cmdQSt2);
		ptrX = popen(cmdQSt2.data(), "r");
		while (fgets(bufX, BUFSIZ, ptrX) != NULL){
			buf2X.append(bufX);
			break;
		}
		(void) pclose(ptrX);
	}
	
	if(isMounted(curentFolder)) QMessageBox::critical(this, tr("Error"), "Folder "+ curentFolder +" is busy!");
	updateMenu();
}
//////////////////////////////////////////////////////////////////////
void MainWidget::exit(){
	this->close();
}
//////////////////////////////////////////////////////////////////////
void MainWidget::loadConfig(){
	QFile file(fCnfName);
	QString conf;

	if(QFile::exists(fCnfName)==false){
		saveConfig();
		return ;
	}

	conf=readFromFile(fCnfName);

	conf="\n"+ conf + "\n";
	conf.replace("\n\n", "\n");

//debug("conf 1 =>"+ conf +";");
	if(conf.indexOf("<mainWinget>")<0 || conf.length()<=1){		// try old method
		file.open(QIODevice::ReadOnly | QIODevice::Text);
		QDataStream in(&file);

		in >> conf;
		file.close();
//debug("conf 3 => "+ conf);
	}

	QString proxyConf=getPartQString(conf, "<proxy>", "</proxy>");
	conf=getPartQString(conf, "<mainWinget>", "</mainWinget>");
//debug("conf 4 => "+ conf);

	if(conf.length()<1){
		saveConfig();
		return ;
	}


	QString el="";
//debug("conf => "+conf);
	el=getPartQString(conf, "<login>", "</login>");
	if(el.length()>0){
		login=decodeBase64(el);
	}else{
		login="";
	}

	password=getPartQString(conf, "<apassword>", "</apassword>");
	if(password.length()>0){
		password=decryptSMEPassword(password);
	}else{
		el=getPartQString(conf, "<password>", "</password>");
		if(el.length()>0){
			password=decodeBase64(el);
		}else{
			password="";
		}
	}

	el=getPartQString(conf, "<server>", "</server>");
	if(el.length()>0){
		server=decodeBase64(el);
	}else{
		server="storagemadeeasy.com";
	}

	el=getPartQString(conf, "<folder>", "</folder>");
	if(el.length()>0){
		curentFolder=decodeBase64(el);
	}else{
		curentFolder="";
	}

	el=getPartQString(conf, "<shareDrive>", "</shareDrive>");
	if(el=="1"){
		shareDrive=true;
	}else{
		shareDrive=false;
	}

	el=getPartQString(conf, "<showEncryptedFiles>", "</showEncryptedFiles>");
	if(el=="1"){
		showEncryptedFiles=true;
	}else{
		showEncryptedFiles=false;
	}

	defaultEncryptionPhrase = getPartQString(conf, "<defaultEncryptionPhrase>", "</defaultEncryptionPhrase>");
	if(defaultEncryptionPhrase.length()>0){
		defaultEncryptionPhrase = decryptSMEPassword(defaultEncryptionPhrase);
	}else{
		defaultEncryptionPhrase = "";
	}

	el=getPartQString(conf, "<providerLogin>", "</providerLogin>");
	if(el.length()>0){
		providerLogin=decodeBase64(el);
	}else{
		providerLogin="";
	}

	el=getPartQString(conf, "<cacheLiveTime>", "</cacheLiveTime>");
	if(el.length()>0){
		cacheLiveTime=el.toInt();
	}

	if(el=="" || cacheLiveTime<1) cacheLiveTime=30;

	el=getPartQString(conf, "<providerPassword>", "</providerPassword>");
	if(el.length()>0){
		providerPassword=decodeBase64(el);
	}else{
		providerPassword="";
	}
//QMessageBox::critical(this, tr("xxxxxxxxx"), login + " | " + password + " | " + curentFolder);


	el=getPartQString(proxyConf, "<useproxy>", "</useproxy>");
	if(el.length()>0)	useProxy=el.toInt();

	el=getPartQString(proxyConf, "<proxyhost>", "</proxyhost>");
	proxyhost=(el=="")?(""):(decodeBase64(el));

	el=getPartQString(proxyConf, "<proxyport>", "</proxyport>");
	proxyport=(el=="")?(80):(decodeBase64(el).toInt());
	if(proxyport<1) proxyport=80;

	el=getPartQString(proxyConf, "<proxylogin>", "</proxylogin>");
	proxylogin=(el=="")?(""):(decodeBase64(el));

	el=getPartQString(proxyConf, "<proxypass>", "</proxypass>");
	proxypass=(el=="")?(""):(decodeBase64(el));

	ui->lineEdit1->setText(login);
	ui->lineEdit2->setText(password);
	ui->lineEdit3->setText(curentFolder);
	QLineEdit *edit=ui->comboBox1->lineEdit();
	edit->setText(server);
}
//////////////////////////////////////////////////////////////////////
void MainWidget::saveConfig(){
	if(fCnfName.length()<1)	return ;

	QString conf="", lconf="";
	if(QFile::exists(fCnfName)){
		lconf=readFromFile(fCnfName);
//debug("READ 1 =>"+ lconf +"<<<;\n");
		if(lconf.length()<=1 || (lconf.indexOf("<mainWinget>")<0 && lconf.indexOf("<sync>")<0)){			// try old method
			QFile file2(fCnfName);
			file2.open(QIODevice::ReadOnly | QIODevice::Text);
			QDataStream in(&file2);
			in >> lconf;
			file2.close();
//debug("READ 2 =>"+ lconf +";\n");
		}

//debug("READ 3 =>"+ lconf +";\n");
		QString lconfNew="";
		QString tlconf=getPartQString(lconf, "<sync>", "</sync>");
		if(lconf.length()>0) lconfNew+="<sync>"+ tlconf +"</sync>";

		tlconf=getPartQString(lconf, "<explorer>", "</explorer>");
		if(lconf.length()>0) lconfNew+="<explorer>"+ tlconf +"</explorer>";
		lconf=lconfNew;
		lconfNew="";
		tlconf="";
  }
//debug("lconf ==> \n"+ lconf +"\n", -20);

	QString tmpLogin, tmpPassword;
	tmpLogin     =ui->lineEdit1->text();
	tmpPassword  =ui->lineEdit2->text();
	curentFolder =ui->lineEdit3->text();

	QLineEdit *edit=ui->comboBox1->lineEdit();
	server=edit->text().toLower();
	if(server=="") server="storagemadeeasy.com";

	if(login!=tmpLogin || password!=tmpPassword){
		providerLogin="";
		providerPassword="";
	}

	login=tmpLogin;
	password=tmpPassword;

	if(curentFolder[curentFolder.length()-1]!='/'){
		curentFolder.append("/");
		ui->lineEdit3->setText(curentFolder);
	}

	conf=lconf;
	conf.append("<mainWinget>");
	conf.append("<login>"+ base64(login) +"</login>");
	conf.append("<apassword>"+ encryptSMEPassword(password) +"</apassword>");
	conf.append("<server>"+ base64(server) +"</server>");
	conf.append("<folder>"+ base64(curentFolder) +"</folder>");
	conf.append("<providerLogin>"+ base64(providerLogin) +"</providerLogin>");
	conf.append("<providerPassword>"+ base64(providerPassword) +"</providerPassword>");
	conf.append("<cacheLiveTime>"+ intToQstring(cacheLiveTime) +"</cacheLiveTime>");
	conf.append("<defaultEncryptionPhrase>"+ encryptSMEPassword(defaultEncryptionPhrase) +"</defaultEncryptionPhrase>");

	if(shareDrive){
		conf.append("<shareDrive>1</shareDrive>");
	}else{
		conf.append("<shareDrive>0</shareDrive>");
	}

	if(showEncryptedFiles){
		conf.append("<showEncryptedFiles>1</showEncryptedFiles>");
	}else{
		conf.append("<showEncryptedFiles>0</showEncryptedFiles>");
	}

	conf.append("</mainWinget>");

	QString sUseProxy="0";
	if(useProxy) sUseProxy="1";
	conf.append("<proxy>");
	conf.append("<useproxy>"+ sUseProxy +"</useproxy>");
	conf.append("<proxyhost>"+ base64(proxyhost) +"</proxyhost>");
	conf.append("<proxyport>"+ base64(intToQstring(proxyport)) +"</proxyport>");
	conf.append("<proxylogin>"+ base64(proxylogin) +"</proxylogin>");
	conf.append("<proxypass>"+ base64(proxypass) +"</proxypass>");
	conf.append("</proxy>");

	QFile::resize(fCnfName, 0);
//	debug("WRITE =>\n"+ conf);
	writeToFile(fCnfName, conf);


// save proxy settings for perl script
	lconf="";
	QString cfName=QDir::homePath() + "/.storagemadeeasy.conf";
	QString cfNameOld=QDir::homePath() + "/.smestorage.conf";
	if(!QFile::exists(cfName) && QFile::exists(cfNameOld)) QFile::rename(cfNameOld, cfName);
	if(QFile::exists(cfName)) lconf=readFromFile(cfName);

	if(lconf==""){
		lconf+="host=storagemadeeasy.com\n";
		lconf+="SMALL_FILE_SIZE=1048576\n";
	}else{
		for(int j=0; lconf.lastIndexOf("\n")==lconf.length()-1 && j<100; j++){
			lconf=lconf.mid(0, lconf.length()-1);
		}
		lconf+="\n";
	}

	QString s=getPartQString(lconf, "useproxy=", "\n");
	if(s!="" || lconf.indexOf("useproxy=\n")>-1){
		lconf.replace("useproxy="+s+"\n", "useproxy="+sUseProxy+"\n");
	}else{
		lconf+="useproxy="+sUseProxy+"\n";
	}

	s=getPartQString(lconf, "proxyhost=", "\n");
	if(s!="" || lconf.indexOf("proxyhost=\n")>-1){
		lconf.replace("proxyhost="+s+"\n", "proxyhost="+proxyhost+"\n");
	}else{
		lconf+="proxyhost="+proxyhost+"\n";
	}

	s=getPartQString(lconf, "proxyport=", "\n");
	if(s!="" || lconf.indexOf("proxyport=\n")>-1){
		lconf.replace("proxyport="+s+"\n", "proxyport="+intToQstring(proxyport)+"\n");
	}else{
		lconf+="proxyport="+intToQstring(proxyport)+"\n";
	}

	s=getPartQString(lconf, "proxylogin=", "\n");
	if(s!="" || lconf.indexOf("proxylogin=\n")>-1){
		lconf.replace("proxylogin="+s+"\n", "proxylogin="+proxylogin+"\n");
	}else{
		lconf+="proxylogin="+proxylogin+"\n";
	}

	s=getPartQString(lconf, "proxypass=", "\n");
	if(s!="" || lconf.indexOf("proxypass=\n")>-1){
		lconf.replace("proxypass="+s+"\n", "proxypass="+proxypass+"\n");
	}else{
		lconf+="proxypass="+proxypass+"\n";
	}

//debug("lconf=>>>>>>\n"+ lconf +"\n");
	if(writeToFile(cfName, lconf)!=0){
		//	error
	}
}
//////////////////////////////////////////////////////////////////////
int MainWidget::checkOptions(bool clogin, bool cpassword, bool cfolder){
debug("checkOptions()");
	login        =ui->lineEdit1->text();
	password     =ui->lineEdit2->text();
	curentFolder =ui->lineEdit3->text();

	QLineEdit *edit=ui->comboBox1->lineEdit();
	server=edit->text().toLower();
	if(server=="") server="storagemadeeasy.com";


	if(clogin && login.length()<1){
		QMessageBox::critical(this, tr("Error"), "     Enter login     ");
		return -1;
	}

	if(cpassword && password.length()<1){
		QMessageBox::critical(this, tr("Error"), "   Enter password   ");
		return -2;
	}

	if(cfolder && curentFolder.length()<1){
		QMessageBox::critical(this, tr("Error"), "   Select folder   ");
		return -3;
	}

	if(curentFolder[curentFolder.length()-1]!='/'){
		curentFolder.append("/");
		ui->lineEdit3->setText(curentFolder);
	}

	if(cfolder && !QFile::exists(curentFolder)){
		QMessageBox::critical(this, tr("Error"), "Folder not exists or you do not have right to access to this folder.");
		return -3;
	}

	return 0;
}
//////////////////////////////////////////////////////////////////////
bool MainWidget::isMounted(QString folder){
	bool L;
	if(QFile::exists(folder + "*#.....................................#sme_mount_test_file")) {
		L=true;
	}else{
		L=false;
	}

	return L;
}
//////////////////////////////////////////////////////////////////////
void MainWidget::updateMenu(){
	if(isMounted(curentFolder)){
		ui->filenew_itemAction->setEnabled(false);
		ui->fileMountAction->setEnabled(false);

		ui->fileUnmountAction->setEnabled(true);
		ui->fileOpen_folderAction->setEnabled(true);
		ui->fileClearCacheAction->setEnabled(true);

		ui->pushButton1->hide();
		ui->pushButton2->hide();

		ui->pushButton11->show();
		ui->pushButton21->show();

		ui->comboBox1->setEnabled(false);
		ui->lineEdit1->setEnabled(false);
		ui->lineEdit2->setEnabled(false);
//    ui->lineEdit3->setEnabled(false);
		ui->lineEdit3->setReadOnly(true);
	}else{
		ui->filenew_itemAction->setEnabled(true);
		ui->fileMountAction->setEnabled(true);

		ui->fileUnmountAction->setEnabled(false);
		ui->fileOpen_folderAction->setEnabled(false);
		ui->fileClearCacheAction->setEnabled(false);

		ui->pushButton1->show();
		ui->pushButton2->show();

		ui->pushButton11->hide();
		ui->pushButton21->hide();

		ui->comboBox1->setEnabled(true);
		ui->lineEdit1->setEnabled(true);
		ui->lineEdit2->setEnabled(true);
//    ui->lineEdit3->setEnabled(true);
		ui->lineEdit3->setReadOnly(false);
	}
}
//////////////////////////////////////////////////////////////////////
void MainWidget::openFolder(){
	if(checkOptions(true, true, true)!=0)	return ;
	if(isMounted(curentFolder)==false)	return ;
	
	QStringList arguments;
	arguments << curentFolder;

	unsigned int i=0;
	bool L=true;
	for(; L && i<sizeof(fileMen) && fileMen[i].length()>1; i++){
//		QString cmdQSt=fileMen[i] + " \"" + curentFolder +"\"";
		QString cmdQSt=fileMen[i];
debug(cmdQSt+" "+arguments.join(" "));
		QProcess *process2=new QProcess();
		if(process2->startDetached(cmdQSt, arguments)) L=false;
	}
	updateMenu();
	return ;
}
//////////////////////////////////////////////////////////////////////
void MainWidget::clearCache(){
	if(isMounted(curentFolder) && QFile::exists(curentFolder + "*#..........#_storagemadeeasy_clear_cache")){
		QMessageBox::information(this, tr("Information"), " Cache cleared            ");
	}else{
		QMessageBox::critical(this, tr("Error"), "Error. Cannot clear cache.    ");
	}
}
//////////////////////////////////////////////////////////////////////
void MainWidget::about(){
	aw=new AboutWidget();
	aw->setWindowModality(Qt::ApplicationModal);
	aw->show();
}
//////////////////////////////////////////////////////////////////////
void MainWidget::advanced(){
	ad.setWindowModality(Qt::ApplicationModal);
	ad.shareDrive=shareDrive;
	ad.cacheLiveTime=cacheLiveTime;

	ad.useProxy=useProxy;
	ad.proxyhost=proxyhost;
	ad.proxyport=proxyport;
	ad.proxylogin=proxylogin;
	ad.proxypass=proxypass;

	ad.encryptionPhrase = defaultEncryptionPhrase;
	ad.showEncrypted = showEncryptedFiles;

	ad.initWnd();
	ad.show();
}
//////////////////////////////////////////////////////////////////////
void MainWidget::sync(){
	openSyncWnd(0);
}
//////////////////////////////////////////////////////////////////////
void MainWidget::openSyncWnd(int command){		// command=0 - open sync window, command=1 - sync all, command=2 - sync up, command=3 - sync down
	QString cmdQSt="/usr/bin/smesynccenter";
	if(command==1 || command==2 || command==3) cmdQSt+=" --hidden";

	if(command==1){
		cmdQSt+=" --syncall";
	}else if(command==2){
		cmdQSt+=" --syncup";
	}else if(command==3){
		cmdQSt+=" --syncdown";
	}
debug(cmdQSt);

	QProcess *process2=new QProcess();
	process2->startDetached(cmdQSt);

	if(command>0) QMessageBox::information(this, tr("Information"), "Synchronization started at background");
}
//////////////////////////////////////////////////////////////////////
void MainWidget::quickSyncAll(){
	openSyncWnd(1);
}
//////////////////////////////////////////////////////////////////////
void MainWidget::quickSyncUp(){
	openSyncWnd(2);
}
//////////////////////////////////////////////////////////////////////
void MainWidget::quickSyncDown(){
	openSyncWnd(3);
}
//////////////////////////////////////////////////////////////////////
void MainWidget::saveAdvanced(){
	shareDrive = ad.shareDrive;
	cacheLiveTime = ad.cacheLiveTime;

	useProxy		= ad.useProxy;
	proxyhost	= ad.proxyhost;
	proxylogin	= ad.proxylogin;
	proxypass	= ad.proxypass;
	proxyport	= ad.proxyport;
	defaultEncryptionPhrase = ad.encryptionPhrase;
	showEncryptedFiles = ad.showEncrypted;

	saveConfig();
}
//////////////////////////////////////////////////////////////////////
void MainWidget::debug(QString s, int level){
	if(level<=DEBUG) printf("%s\n", s.toUtf8().data());
}
//////////////////////////////////////////////////////////////////////
QString MainWidget::base64(QString t){
	return QString(t.toUtf8().toBase64());
}
//////////////////////////////////////////////////////////////////////
QString MainWidget::decodeBase64(QString t){
	QByteArray xx="";
	xx.append(t);
	return QString::fromUtf8(xx.fromBase64(xx));
}
//////////////////////////////////////////////////////////////////////
void MainWidget::getProviderLoginAndPassword(){
	providerlog.setWindowModality(Qt::ApplicationModal);
	providerlog.plogin=providerLogin;
	providerlog.ppass=providerPassword;

	providerlog.initWnd();
	providerlog.show();
}
//////////////////////////////////////////////////////////////////////
void MainWidget::saveProviderLog(){
	providerLogin=providerlog.plogin;
	providerPassword=providerlog.ppass;

	saveConfig();
	QTimer::singleShot(300, this, SLOT(mount()));
}
//////////////////////////////////////////////////////////////////////
QString MainWidget::getPartQString(QString s, QString from, QString to){
	int st=s.indexOf(from)+from.length();
	if(st<0) return "";
	int e=s.indexOf(to, st);
	if(e-st<=0) return "";
	QString el=s.mid(st, e-st);
	if(el.length()>0 && st>=from.length() && e>-1){
		return el;
	}else{
		return "";
	}
}
//////////////////////////////////////////////////////////////////////
QString MainWidget::readFromFile(QString name){
	if(name=="")	return "";
	if(!QFile::exists(name))	return "";

	QString res="";
	char *buf =new char[1];
	buf[0]=' ';
	FILE * pFile;

	QByteArray tmName;
	if(localeEncoding!=""){
		QTextCodec *codec = QTextCodec::codecForName(localeEncoding.toUtf8().data());
		tmName = codec->fromUnicode(name);
	}else{
		tmName = name.toUtf8();
	}

	pFile=fopen(tmName.data(), "r");
	if(!pFile && localeEncoding!=""){		// try to use UTF-8 name
		tmName = name.toUtf8();
		pFile=fopen(tmName.data(), "r");
	}

	if(!pFile)	return 0;
	while(!feof(pFile)){
		if(fread(buf, 1, 1, pFile)==1){
			res.append(buf[0]);
		}else{
			break;
		}
	}

	QByteArray b;					// convert  to UTF8
	b.append(res);
	res=QString::fromUtf8(b);
//debug(QString::fromUtf8(b));

	fclose(pFile);
	return res;
}
//////////////////////////////////////////////////////////////////////
int MainWidget::writeToFile(QString name, QString s){
	if(name=="")	return -1;

	FILE *pFile;
	QString rwMode="w";
	QByteArray tmName;
	if(localeEncoding!=""){
		QTextCodec *codec = QTextCodec::codecForName(localeEncoding.toUtf8().data());
		tmName = codec->fromUnicode(name);
	}else{
		tmName = name.toUtf8();
	}

	pFile=fopen(tmName.data(), rwMode.toUtf8().data());
	if(!pFile && localeEncoding!=""){		// try to use UTF-8 name
		tmName = name.toUtf8();
		pFile=fopen(tmName.data(), rwMode.toUtf8().data());
	}

//	pFile=fopen(name.toUtf8().data(), "w");
	if(!pFile)	return -2;

	int leng=s.length();
	for(int i3=0; i3<=leng; i3=i3+100){
		int l1=100;
		if(i3+l1>leng)	l1=leng-i3;
		QString sa =s.mid(i3, l1);
		if(sa=="")	break;
//		char *buf2=sa.toLatin1().data();
		QByteArray b="";					// convert  to UTF8
		b.append(sa.toUtf8());
		char *buf2=b.data();
		size_t wsize=size_t (b.length());
		fwrite(buf2, 1, wsize, pFile);
	}

	fclose(pFile);
	return 0;
}
//////////////////////////////////////////////////////////////////////
void MainWidget::showTrayIcon(QSystemTrayIcon *trayIcon){
	QString trayIconPath="/usr/share/smeclient/smeclient.png";
	QString cmdQSt="gconftool -g /desktop/gnome/interface/gtk_theme";
	char buf[BUFSIZ];
	QString buf2="";
	FILE *ptr;

	ptr=popen(cmdQSt.toUtf8().data(), "r");
	if(fgets(buf, BUFSIZ, ptr)!=NULL) buf2.append(buf);
	(void) pclose(ptr);

	for(int i=buf2.length(); i>=0; i--){
		if(buf2.mid(i)=="\n" || buf2.mid(i)=="\r" || buf2.mid(i)==" "){
			buf2=buf2.mid(0, i);
			i--;
		}
	}

	debug("Theme = "+ buf2 +";");
	buf2 = buf2.toLower();
	if(buf2=="ambiance" || buf2=="clearlooks") trayIconPath="/usr/share/smeclient/sme_tray_22_mono.png";

	QString desktop = QString(getenv("XDG_CURRENT_DESKTOP")).toLower();
	debug("desktop = "+desktop);
	if(desktop=="unity"){ //In Unity we show an App Indicator
		typeOfTrayIcon = 1;
		AppIndicator *indicator;		//IgnoreOnCentOS
		GtkWidget *menu;		//IgnoreOnCentOS

		menu = gtk_menu_new();		//IgnoreOnCentOS
		//Show log item
		showLogItem = gtk_menu_item_new_with_label("Show log");		//IgnoreOnCentOS
		gtk_menu_shell_append(GTK_MENU_SHELL(menu), showLogItem);		//IgnoreOnCentOS
		g_signal_connect(showLogItem, "activate", G_CALLBACK(gOnShowLog), qApp);		//IgnoreOnCentOS
		gtk_widget_show(showLogItem);		//IgnoreOnCentOS

		//Show window item
		showWindowItem = gtk_menu_item_new_with_label("Show window");		//IgnoreOnCentOS
		gtk_menu_shell_append(GTK_MENU_SHELL(menu), showWindowItem);		//IgnoreOnCentOS
		g_signal_connect(showWindowItem, "activate", G_CALLBACK(gOnShowWindow), qApp);		//IgnoreOnCentOS
		gtk_widget_show(showWindowItem);		//IgnoreOnCentOS

		indicator = app_indicator_new("Linux Cloud Tools", trayIconPath.toUtf8().data(), APP_INDICATOR_CATEGORY_OTHER);		//IgnoreOnCentOS

		app_indicator_set_status(indicator, APP_INDICATOR_STATUS_ACTIVE);		//IgnoreOnCentOS
		app_indicator_set_menu(indicator, GTK_MENU(menu));		//IgnoreOnCentOS
	}else{
		typeOfTrayIcon = 0;
		trayIcon->setIcon(QIcon(trayIconPath));
		trayIcon->setToolTip("Linux Cloud Tools");
		trayIcon->show();
	}
}
//////////////////////////////////////////////////////////////////////
void MainWidget::bShowLog(){
	QString error = "";

	if(!QFile::exists(fErrorLogName)){
		error = "Error log is empty";
		writeToFile(fErrorLogName, "");		// We create file
	}

	if(error==""){
		QFile file(fErrorLogName);
		qint64 sizeOfFile = file.size();
		if(sizeOfFile<1){
			error = "Error log is empty";
		}
	}

	if(error!=""){
		if(isHidden()){	// We show main window, because in different case the app will be closed when user will try to close message box
			show();
		}

		QMessageBox::information(this, tr("Information"), error);
		return ;
	}

	QString cmd = "\""+ commandLineEscape(fErrorLogName) +"\"";
	cmd = "gnome-open "+ cmd +" || kde-open "+ cmd +" || gedit "+ cmd +" || kate "+ cmd;
	debug(cmd);

	QProcess *process2=new QProcess();
	process2->startDetached("sh", QStringList() << "-c" << cmd);
	return ;
}
//////////////////////////////////////////////////////////////////////
void MainWidget::showWindowFromTray(){
	if(!isHidden()){
		hide();
	}else{
		show();
	}

	refreshTrayMenu();
	//QTimer::singleShot(1, this, SLOT(hideTrayIcon()));
}
//////////////////////////////////////////////////////////////////////
void MainWidget::refreshTrayMenu(){
	if(isHidden()){
		if(typeOfTrayIcon==0){
			aShowWindow->setText("Show window");
		}else{
			gtk_menu_item_set_label(GTK_MENU_ITEM(showWindowItem), "Show window");		//IgnoreOnCentOS
		}
	}else{
		if(typeOfTrayIcon==0){
			aShowWindow->setText("Hide window");
		}else{
			gtk_menu_item_set_label(GTK_MENU_ITEM(showWindowItem), "Hide window");		//IgnoreOnCentOS
		}
	}

	//QTimer::singleShot(1, this, SLOT(hideTrayIcon()));
}
//////////////////////////////////////////////////////////////////////
void MainWidget::hideInTray(){
	//trayIcon->show();
	hide();
	refreshTrayMenu();
}
//////////////////////////////////////////////////////////////////////
void MainWidget::hideTrayIcon(){
	trayIconMenu->hide();
	trayIcon->hide();
}
//////////////////////////////////////////////////////////////////////
QString MainWidget::commandLineEscape(QString s){
	s = s.replace("\\", "\\\\");
	s = s.replace("\"", "\\\"");
	s = s.replace("$", "\\$");
	return s;
}
//////////////////////////////////////////////////////////////////////
void MainWidget::resizeEvent(QResizeEvent *e){
	int w=width();
	int h=height();
	if(e){}
//	MainWidget->resize(410, 408);
	ui->widget->setGeometry(QRect(0, 0, w, h));

	int fontSize=12;
	if(ui->MenuBar->font().pixelSize()>8){
		fontSize=ui->MenuBar->font().pixelSize();
	}else if(ui->MenuBar->font().pointSize()>7){
		fontSize=(int) (ui->MenuBar->font().pointSize()*1.3);
	}

	ui->MenuBar->setGeometry(QRect(0, 0, 418, 13+fontSize));

	int y=13+fontSize+15, y1=0, y2=0, x1=3;
	int dx1=(int) (w/3.5-x1), dx2=w-dx1-2*x1-3, x2=x1+dx1+3;
	ui->textLabel5->setGeometry(QRect(x1, y, dx1, 30));
	ui->comboBox1->setGeometry(QRect(x2, y, dx2, 31));
	y+=46;

	ui->textLabel2->setGeometry(QRect(x1, y, dx1, 30));
	ui->lineEdit1->setGeometry(QRect(x2, y, dx2, 31));
	y+=40;

	ui->textLabel3->setGeometry(QRect(x1, y, dx1, 30));
	ui->lineEdit2->setGeometry(QRect(x2, y, dx2, 31));
	y+=45;


	ui->textLabel4->setGeometry(QRect(x1, y, w-2*x1, 30));
	ui->lineEdit3->setGeometry(QRect(x1, y+25, w-2*x1, 31));
	y+=65;

	ui->pushButton1->setGeometry(QRect(w-x1-140, y+y1, 140, 35));
	ui->pushButton2->setGeometry(QRect(x1, y+y1, 160, 80));

	ui->pushButton11->setGeometry(QRect(w-x1-140, y+y2, 140, 35));
	ui->pushButton21->setGeometry(QRect(x1, y+y2, 160, 80));
	y+=93;

	ui->pushButton3->setGeometry(QRect(w-260, y, 130, 30));
	ui->pushButton4->setGeometry(QRect(w-115, y, 110, 30));

}
//////////////////////////////////////////////////////////////////////
QString MainWidget::intToQstring(int n){
	char buffer[100];
	sprintf(buffer, "%d", n);
	QString res;
	res.append(buffer);

	return res;
}
//////////////////////////////////////////////////////////////////////
QString MainWidget::runCommand(QString command){
	QString cmdQSt=command;

	QByteArray cmdArr=cmdQSt.toLatin1();
	char *cmd=cmdArr.data();
	int stimeout=35;
//	int maxtimeout=30;
	int nn0=10000;
	char buf[nn0];

	QString buf2="";
	FILE *ptr;

	for(int i=0; i<nn0; i++){
		buf[i]=' ';
	}

	if(command.indexOf("openssl ")==-1 && command.indexOf("gettoken")==-1 && command.indexOf("dmidecode")==-1){
		debug(cmdQSt);
	}

	ptr = popen(cmd, "r");
	int ptrd = fileno(ptr);
	fcntl(ptrd, F_SETFL, O_NONBLOCK);
	ssize_t r = read(ptrd, buf, nn0);
	while(r==-1){
		Cqthread::msleep(stimeout);
		r=read(ptrd, buf, nn0);
	}

	buf2.append(QString::fromUtf8(buf));
	buf2=buf2.mid(0, nn0-1);

	int lngt=buf2.length();
	for(; lngt>0; lngt--){
//debug("buf2.length() = > "+ intToQstring(buf2.length()));
//debug(">>> "+buf2.mid(lngt-1, 1)+"!=' ' <<<<<<<");
		if(buf2.mid(lngt-1, 1)!=" "){
			break;
		}

		buf2=buf2.mid(0, lngt-1);
	}

	if(command.indexOf("openssl ")==-1 && command.indexOf("gettoken")==-1 && command.indexOf("dmidecode")==-1){
		debug("lngt="+ intToQstring(lngt)+"; response => "+ buf2+";");
	}

	(void) pclose(ptr);

	return buf2;
}
//////////////////////////////////////////////////////////////////////
void MainWidget::logOut(){
	if(QMessageBox::question(this, "Confirm", "Do you want Logout?", QMessageBox::Ok, QMessageBox::No)!=QMessageBox::Ok){
		return ;
	}

	login = "";
	password = "";
	ui->lineEdit1->setText("");
	ui->lineEdit2->setText("");
	saveConfig();

	return ;
}
//////////////////////////////////////////////////////////////////////
/*
void MainWidget::bCopyMountCommandToClipboard(){
	QStringList arguments = getCommandForMount(true, 1);
	if(arguments.size()<1) return ;

	QString mountCommand = "smemount ";
	mountCommand += "\""+ QString(arguments.at(0)).replace("\\", "\\\\").replace("$", "\\$").replace("\"", "\\\"") + "\" ";
	arguments.removeFirst();
	mountCommand += arguments.join(" ");
	QClipboard *clipboard = QApplication::clipboard();
	clipboard->setText(mountCommand);

	QMessageBox::information(this, tr("Linux Cloud Tools"), tr("The command for mount is in clipboard"));

	return ;
}
*/
//////////////////////////////////////////////////////////////////////
void MainWidget::bshowCommandForMount(){
	QStringList arguments = getCommandForMount(true, 1);
	if(arguments.size()<1) return ;

	QString mountCommand = "smemount ";
	mountCommand += "\""+ QString(arguments.at(0)).replace("\\", "\\\\").replace("$", "\\$").replace("\"", "\\\"") + "\" ";
	arguments.removeFirst();
	mountCommand += arguments.join(" ");

	bool ok;
	QString text = QInputDialog::getText(this, tr("Mount command"), tr("If you want to mount folder on startup automatically then you should \nenter the following command into a bash startup script:"), QLineEdit::Normal, mountCommand, &ok);

	return ;
}
//////////////////////////////////////////////////////////////////////
QString MainWidget::getEncryptionKeyForPassword(){
	return "def1pa2s2swor44de5e56seu1jai3kd7";		// Temporary will be used static
/*
	// dmidecode 2>/dev/null | grep "Serial Number" | grep -v "Not Specified" |  grep -v "None" || /usr/sbin/dmidecode 2>/dev/null | grep "Serial Number" | grep -v "Not Specified" |  grep -v "None" || cat  /sys/class/dmi/id/[bios]* 2>/dev/null | grep -v "cat: " | grep -v "Permission denied"
	QString command = "dmidecode 2>/dev/null | grep \"Serial Number\" | grep -v \"Not Specified\" |  grep -v \"None\" || /usr/sbin/dmidecode 2>/dev/null | grep \"Serial Number\" | grep -v \"Not Specified\" |  grep -v \"None\" || cat  /sys/class/dmi/id/[bios]* 2>/dev/null | grep -v \"cat: \" | grep -v \"Permission denied\"";

	QString s = runCommand(command);
	s = s.replace("\r", "");
	if(s.indexOf("\n")>2){
		if(s.indexOf("Serial Number:")>-1){		// Take only first line
			s = s.mid(0, s.indexOf("\n"));
		}

		std::string utf8_text = base64(s).toUtf8().constData(); 
		MD5 cx = MD5(utf8_text);
		s = QString::fromUtf8(cx.getResult().c_str());
		return s;
	}else{
		return "def1pa2s2swor44de5e56seu1jai3kd7";
	}
*/
}
//////////////////////////////////////////////////////////////////////
QString MainWidget::encryptSMEPassword(QString password){
	if(!canPasswordBeEncrypted){
		return password;
	}

	QString command = "echo \"x"+ base64(password) +"x\" | openssl enc -aes-256-cbc -a -k \""+ base64(encryptionKeyForPassword) +"\"";
//debug("command="+command);
	QString s = runCommand(command);
	s = s.replace("\n", "");
	s = s.replace("\r", "");
	return "-aes-" + s;
}
//////////////////////////////////////////////////////////////////////
QString MainWidget::decryptSMEPassword(QString password){
	if(!canPasswordBeEncrypted){
		return password;
	}

	if(password.indexOf("-aes-")!=0){
		return password;			// password is not encrypted
	}

	password = password.mid(QString("-aes-").length());

	if(password.length()>64){
		// For OpenSSL base64 encoded data should have \n after each 64 bytes
		QString xPassword = "";
		while(password.length()>0){
			if(password.length()>64){
				xPassword += password.mid(0, 64) + "\\n";
				password = password.mid(64);
			}else{
				xPassword += password;
				password = "";
			}
		}
		password = xPassword;
	}

	QString command = "printf \""+ password +"\\n\" | openssl enc -d -aes-256-cbc -a -k \""+ base64(encryptionKeyForPassword) +"\"";
//command = "printf \""+ password +"\"";
//debug("command="+command);
	QString s = runCommand(command);
	s = s.replace("\n", "");
	s = s.replace("\r", "");

//debug("s = "+s);
	if(s.indexOf("x")==0 && s.lastIndexOf("x")==s.length()-1){
		password = decodeBase64(s.mid(1, s.length()-2));
		return password;
	}else{				// Password is incorrect
		return "";
	}
}
//////////////////////////////////////////////////////////////////////
void MainWidget::askForEncryptionPhrase(){
	this->hide();

	AskForEncryptionPhrase wnd;
	//wnd.setWindowModality(Qt::ApplicationModal);
	//wnd.move(QPoint((int) (x()+ww/2-215), (int) (y()+wh/2-200)));
	wnd.initWnd(AskForEncryptionPhrase_title, AskForEncryptionPhrase_message);
	wnd.show();

	QEventLoop eventLoop;		// Wait while user enter encryption phrase
	QObject::connect(&wnd, SIGNAL(wCancel()), &eventLoop, SLOT(quit()));
	QObject::connect(&wnd, SIGNAL(wOK()), &eventLoop, SLOT(quit()));
	eventLoop.exec();

	QString text = wnd.encryptionPhrase;
	QString save = (wnd.save) ? "1" : "0";
	QString timeout = (wnd.timeout) ? "1" : "0";
	QString dontAskAgain = (wnd.dontAskAgain) ? "1" : "0";

	if(text!="") text = base64(encryptSMEPassword(text));
	debug("<response><encryptionPhrase>"+ text +"</encryptionPhrase><save>"+save+"</save><timeout>"+timeout+"</timeout><dontAskAgain>"+dontAskAgain+"</dontAskAgain></response>", -1);

	QApplication::exit();
	return ;
}
//////////////////////////////////////////////////////////////////////



