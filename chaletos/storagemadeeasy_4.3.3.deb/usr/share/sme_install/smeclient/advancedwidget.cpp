#include "advancedwidget.h"
#include "ui_advancedwidget.h"

AdvancedWidget::AdvancedWidget(QWidget *parent) : QWidget(parent), ui(new Ui::AdvancedWidget){
  ui->setupUi(this);

  shareDrive=false;
  showEncrypted = false;

// Buttons
  QObject::connect(ui->pushButton1, SIGNAL(clicked()), this, SLOT(saveAdvanced()));
  QObject::connect(ui->pushButton2, SIGNAL(clicked()), this, SLOT(hideWindow()));
  QObject::connect(ui->checkBox2, 	SIGNAL(stateChanged(int)), this, SLOT(checkBox2StateChanged(int)));
  QObject::connect(ui->checkBox3, 	SIGNAL(stateChanged(int)), this, SLOT(checkBox3StateChanged(int)));
}
//////////////////////////////////////////////////////////////////////
AdvancedWidget::~AdvancedWidget(){
  delete ui;
}
//////////////////////////////////////////////////////////////////////
void AdvancedWidget::saveAdvanced(){
	QString cLT=ui->lineEdit1->text();
	cacheLiveTime=cLT.toInt();
	if(cacheLiveTime<1 || cacheLiveTime>999){
		QMessageBox::critical(this, tr("Error"), "The time to live for cache must be a number between 1 and 999!");
		return ;
	}

	if(ui->checkBox->isChecked()){
		shareDrive=true;
//    QMessageBox::critical(this, tr("Error"), "    +   ");
	}else{
		shareDrive=false;
	}


	if(ui->checkBox2->checkState()==Qt::Checked){
		useProxy=true;
	}else{
		useProxy=false;
	}

	if(useProxy){
		QString xproxyhost=ui->lineEdit2->text();
		int xproxyport=ui->lineEdit3->text().toInt();
		if(xproxyhost.length()<1){
			QMessageBox::critical(this, tr("Error"), "   Enter proxy host   ");
			return ;
		}

		if(xproxyport<1){
			QMessageBox::critical(this, tr("Error"), "Proxy port must be between 1 and 65535 ");
			return ;
		}
		proxyhost	=xproxyhost;
		proxyport	=xproxyport;
		proxylogin	=ui->lineEdit4->text();
		proxypass	=ui->lineEdit5->text();
	}

	showEncrypted = ui->checkBox3->isChecked();
	encryptionPhrase = ui->lineEdit6->text();
	if(!showEncrypted) encryptionPhrase = "";

	emit clickOKButton();

	this->hide();
}
//////////////////////////////////////////////////////////////////////
void AdvancedWidget::hideWindow(){
	this->hide();
}
//////////////////////////////////////////////////////////////////////
void AdvancedWidget::initWnd(){
	isInitwnd = true;
	ui->checkBox->setChecked(shareDrive);
	ui->lineEdit1->setText(intToQstring(cacheLiveTime));

	ui->lineEdit2->setText(proxyhost);
	ui->lineEdit3->setText(intToQstring(proxyport));
	ui->lineEdit4->setText(proxylogin);
	ui->lineEdit5->setText(proxypass);

	if(useProxy){
		ui->checkBox2->setCheckState(Qt::Checked);
	}else{
		ui->checkBox2->setCheckState(Qt::Unchecked);
	}

	ui->groupBox1->setEnabled(useProxy);

	if(showEncrypted){
		ui->checkBox3->setCheckState(Qt::Checked);
		ui->lineEdit6->setEnabled(true);
	}else{
		ui->checkBox3->setCheckState(Qt::Unchecked);
		ui->lineEdit6->setEnabled(false);
	}

	ui->lineEdit6->setText(encryptionPhrase);
	isInitwnd = false;

}
//////////////////////////////////////////////////////////////////////
QString AdvancedWidget::intToQstring(int n){
	char buffer[100];
	sprintf(buffer, "%d", n);
	QString res;
	res.append(buffer);

	return res;
}
//////////////////////////////////////////////////////////////////////
void AdvancedWidget::checkBox2StateChanged(int par){
	if(par){}
	bool s=false;
	if(ui->checkBox2->checkState()==Qt::Checked)	s=true;
	ui->groupBox1->setEnabled(s);
}
//////////////////////////////////////////////////////////////////////
void AdvancedWidget::checkBox3StateChanged(int par){
	if(par){}
	bool s=false;
	if(ui->checkBox3->checkState()==Qt::Checked){
		s=true;
		if(!isInitwnd){
			QMessageBox::information(this, "SME Linux Drive", "We recommend disabling thumbnails as the files need to be accessed/downloaded to generate the thumbnails. Click <a href='https://storagemadeeasy.com/wiki/linuxcloudtools/'>here</a> to find out how you can do this.");
		}
	}

	ui->lineEdit6->setEnabled(s);
}
//////////////////////////////////////////////////////////////////////
void AdvancedWidget::resizeEvent(QResizeEvent *e){
	int w=width();
	int h=height();
	if(e){}
//	MainWidget->resize(410, 408);
	ui->widget->setGeometry(QRect(0, 0, w, h));

	int fontSize=12;
	if(ui->checkBox->font().pixelSize()>8){
		fontSize=ui->checkBox->font().pixelSize();
	}else if(ui->checkBox->font().pointSize()>7){
		fontSize=(int) (ui->checkBox->font().pointSize()*1.3);
	}

	int y=2, h1=fontSize+3, x=3, gx=8, w1=int ((w-2*gx)/2.5), w2=w-w1-4*gx-5, y2=20, GBH=y2+6*(h1+4)+5;
	ui->checkBox->setGeometry(QRect(x, y, w-2*x, h1+4));
	y+=h1+3;
	ui->textLabel1->setGeometry(QRect(x+2, y, w-x, h-100-GBH+3));
	y+=h-100-GBH+4;

	ui->checkBox3->setGeometry(QRect(x, y, w-2*x, h1));
	y+=h1+2;

	ui->lineEdit6->setGeometry(QRect(x, y, (int) (w/3)-2*x, h1+4));
	ui->textLabel7->setGeometry(QRect(x+(int) (w/3), y, (int) (1.99*w/3)-2*x, h1+4));
	y+=h1+9;

	ui->checkBox2->setGeometry(QRect(x, y, w-2*x, h1+4));
	y+=h1+3;
	ui->groupBox1->setGeometry(QRect(x, y, w-2*x-5, GBH));
	y+=GBH+3;

	ui->textLabel3->setGeometry(QRect(gx, y2, w1, h1));
	ui->lineEdit2->setGeometry(QRect(gx+w1, y2-1, w2, h1+3));
	y2+=h1+4;

	ui->textLabel4->setGeometry(QRect(gx, y2, w1, h1));
	ui->lineEdit3->setGeometry(QRect(gx+w1, y2-1, 76, h1+3));
	y2+=h1+4;

	ui->textLabel5->setGeometry(QRect(gx, y2, w1, h1));
	ui->lineEdit4->setGeometry(QRect(gx+w1, y2-1, w2, h1+3));
	y2+=h1+4;

	ui->textLabel6->setGeometry(QRect(gx, y2, w1, h1));
	ui->lineEdit5->setGeometry(QRect(gx+w1, y2-1, w2, h1+3));
	y2+=h1+4;

	ui->lineEdit1->setGeometry(QRect(3, h-57, 35, 23));
	ui->textLabel2->setGeometry(QRect(40, h-57, w-25-6, 23));

	ui->pushButton1->setGeometry(QRect(10, h-29, 100, 27));
	ui->pushButton2->setGeometry(QRect(150, h-29, 100, 27));
}

