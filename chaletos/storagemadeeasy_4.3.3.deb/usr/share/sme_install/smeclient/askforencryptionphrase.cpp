#include "stdio.h"
#include "askforencryptionphrase.h"
#include <QDateTime>
#include <QEventLoop>
#include <QTimer>

AskForEncryptionPhrase::AskForEncryptionPhrase(QWidget *parent) : QWidget(parent){
	widget1 = new QWidget(this);
	widget1->setGeometry(QRect(0, 0, 460, 220));
	this->setWindowTitle("SME Linux Drive");
	this->setWindowIcon(QIcon("/usr/share/pixmaps/sme_explorer_icon_42.png"));
   widget1->setObjectName(QString::fromUtf8("widget1"));

	int x1=2, y1=18, y2=25, dy=10, dx1=210;
	int y=20;
	textLabel1 = new QLabel(widget1);
	textLabel1->setObjectName(QString::fromUtf8("textLabel1"));
	textLabel1->setGeometry(QRect(x1, y-10, dx1, y1));
	textLabel1->setWordWrap(true);
	textLabel1->setText("");
	y+=3*y1+dy;

	textLabel2 = new QLabel(widget1);
	textLabel2->setObjectName(QString::fromUtf8("textLabel2"));
	textLabel2->setGeometry(QRect(x1, y, dx1, y1));
	textLabel2->setText("Decryption phrase:");
	y+=y1+dy;

	textLabel3 = new QLabel(widget1);
	textLabel3->setObjectName(QString::fromUtf8("textLabel2"));
	textLabel3->setGeometry(QRect(x1, y, dx1, y1));
	textLabel3->setText("");
	y+=y1+dy;

	lineEdit1 = new QLineEdit(widget1);
	lineEdit1->setObjectName(QString::fromUtf8("lineEdit1"));
	lineEdit1->setGeometry(QRect(x1, y-3, dx1, y2));
	lineEdit1->setEchoMode(QLineEdit::Password);
	y+=y1+dy+3;

	checkBox1=new QCheckBox("Use encryption phrase for session", widget1);
	checkBox1->setObjectName(QString::fromUtf8("checkBox"));
	checkBox1->setGeometry(QRect(x1+20, y, 300, y2));
	checkBox1->setCheckState(Qt::Unchecked);
	y+=y1+dy-5;

	x1+=25;
	pushButton1 = new QPushButton(widget1);
	pushButton1->setGeometry(QRect(x1, y, 80, 28));
	pushButton1->setText("OK");
	pushButton2 = new QPushButton(widget1);
	pushButton2->setGeometry(QRect(x1+90, y, 80, 28));
	pushButton2->setText("Cancel");
	pushButton3 = new QPushButton(widget1);
	pushButton3->setGeometry(QRect(x1+90, y, 80, 28));
	pushButton3->setText("Don't ask any more");
	pushButton4 = new QPushButton(widget1);
	pushButton4->setGeometry(QRect(x1+90, y, 80, 28));
	pushButton4->setText("More info");

	QObject::connect(lineEdit1, SIGNAL(textChanged(QString)), this, SLOT(textChanged(QString)));

// Buttons
	QObject::connect(pushButton1, SIGNAL(clicked()), this, SLOT(bOK()));
	QObject::connect(pushButton2, SIGNAL(clicked()), this, SLOT(bCancel()));
	QObject::connect(pushButton3, SIGNAL(clicked()), this, SLOT(bDontAskAnyMore()));
	QObject::connect(pushButton4, SIGNAL(clicked()), this, SLOT(bMoreInfo()));
}
//////////////////////////////////////////////////////////////////////
AskForEncryptionPhrase::~AskForEncryptionPhrase(){
}
//////////////////////////////////////////////////////////////////////
void AskForEncryptionPhrase::bOK(){
	encryptionPhraseChanged = true;
	QString ef = lineEdit1->text();
	if(ef.length()<1){
		QMessageBox::critical(this, "Error", "Enter Decryption phrase");
		return ;
	}

	encryptionPhrase = ef;

	if(checkBox1->checkState()==Qt::Checked){
		save = true;
	}else{
		save = false;
	}

	emit wOK();
	this->hide();
}
//////////////////////////////////////////////////////////////////////
void AskForEncryptionPhrase::bCancel(){
	encryptionPhraseChanged = true;
	emit wCancel();
	this->hide();
	return ;
}
//////////////////////////////////////////////////////////////////////
void AskForEncryptionPhrase::bDontAskAnyMore(){
	encryptionPhraseChanged = true;
	QMessageBox::StandardButton reply;
	reply = QMessageBox::question(this, "SME Linux Drive", "It will be impossible to open any encrypted files on this session!<br />Don't ask again for decryption phrase?", QMessageBox::Yes|QMessageBox::No);
	if(reply == QMessageBox::Yes){
		dontAskAgain = true;
		bCancel();
	}
}
//////////////////////////////////////////////////////////////////////
void AskForEncryptionPhrase::bMoreInfo(){
	encryptionPhraseChanged = true;
	QMessageBox::information(this, "SME Linux Drive", "The file you are trying to access tried is encrypted. You need to provide a phrase to access it.");
}
//////////////////////////////////////////////////////////////////////
void AskForEncryptionPhrase::initWnd(QString title = "SME Linux Drive", QString message = ""){
	this->setWindowTitle(title);
	textLabel1->setText(message);

	encryptionPhrase = "";
	save = false;
	encryptionPhraseChanged = false;
	timeout = false;
	dontAskAgain = false;

	lineEdit1->setText("");
	checkBox1->setCheckState(Qt::Checked);

	startDate = QDateTime::currentDateTime();
	QTimer::singleShot(100, this, SLOT(updateTimer()));
}
//////////////////////////////////////////////////////////////////////
void AskForEncryptionPhrase::updateTimer(){
	// We wait 30 sec.
	// If user enter at last 1 symbol of encryption phrase then we stop this.
	// If after 30 sec. encryption phrase is empty then this is equivalent to press cancel (user don't want to enter encryption 
	int n = startDate.toTime_t() - QDateTime::currentDateTime().toTime_t() + 30;
	if(n<0){
		timeout = true;
		bCancel();
		return ;
	}else{
		textLabel3->setText("You have "+QString::number(n)+" sec. to enter decryption phrase");
	}

	if(this->encryptionPhraseChanged){
		textLabel3->hide();
		return ;
	}

	QTimer::singleShot(100, this, SLOT(updateTimer()));
}
//////////////////////////////////////////////////////////////////////
void AskForEncryptionPhrase::textChanged(QString text){
	if(text==""){}
	encryptionPhraseChanged = true;
}
//////////////////////////////////////////////////////////////////////
void AskForEncryptionPhrase::keyPressEvent(QKeyEvent *event){
	int key=event->key();
	if(key==Qt::Key_Escape){
		bCancel();
	}else if(key==Qt::Key_Enter || key==Qt::Key_Return){
		bOK();
	}

}
//////////////////////////////////////////////////////////////////////
void AskForEncryptionPhrase::resizeEvent(QResizeEvent *e){
	int w=width(), h=height();
	widget1->setGeometry(QRect(0, 0, w, h));
	if(e){}

	int x1=2, y1=18, y2=25, dy=9;
	int y=3;
	textLabel1->setGeometry(QRect(x1, y, w-2*x1, (int) (3.5*y1)+dy-1));
	y+=(int) (3.5*y1)+dy;

	textLabel2->setGeometry(QRect(x1, y, w-2*x1, y1));
	y+=y1+dy;

	lineEdit1->setGeometry(QRect(x1, y-3, w-2*x1, y2));
	y+=y1+dy;

	checkBox1->setGeometry(QRect(x1+10, y, w-2*x1, y2));
	y+=y1+dy-2;

	textLabel3->setGeometry(QRect(x1, y, w-2*x1, y1));
	y+=y1+dy-4;

	pushButton1->setGeometry(QRect(x1, y, 75, 28));
	pushButton2->setGeometry(QRect(x1+90, y, 75, 28));
	pushButton3->setGeometry(QRect(x1+2*90, y, 142, 28));
	pushButton4->setGeometry(QRect(w-2*x1-72, y, 72, 28));
	return ;
}
//////////////////////////////////////////////////////////////////////

