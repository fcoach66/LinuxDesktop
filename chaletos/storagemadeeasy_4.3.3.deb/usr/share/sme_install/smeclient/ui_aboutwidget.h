#ifndef UI_ABOUTWIDGET_H
#define UI_ABOUTWIDGET_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QWidget>

#include <QtGui/QFileDialog>
#include <QFile>

#include <Qt3Support/Q3MimeSourceFactory>
#include <QtGui/QDialog>
#include <QtGui/QMenu>
#include <QtGui/QMenuBar>
#include <QtGui/QMessageBox>

class Ui_AboutWidget
{
public:
    QWidget *widget;
    QLabel *textLabel1, *textLabel2, *textLabel3, *textLabel4, *textLabel5;
    QPushButton *pushButton1;

    void setupUi(QWidget *AboutWidget)
    {
      if (AboutWidget->objectName().isEmpty())
          AboutWidget->setObjectName(QString::fromUtf8("AboutWidget"));
      AboutWidget->resize(420, 310);
      AboutWidget->setWindowIcon(QIcon("/usr/share/smeclient/smeclient.png"));
  
      widget = new QWidget(AboutWidget);
      widget->setObjectName(QString::fromUtf8("widget"));
      widget->setGeometry(QRect(0, 0, 301, 325));
      textLabel1 = new QLabel(widget);
      textLabel1->setObjectName(QString::fromUtf8("textLabel1"));
      textLabel1->setGeometry(QRect(1, 10, 300, 25));
      textLabel1->setWordWrap(false);
      textLabel2 = new QLabel(widget);
      textLabel2->setObjectName(QString::fromUtf8("textLabel2"));
      textLabel2->setGeometry(QRect(1, 45, 300, 18));
      textLabel2->setWordWrap(false);
  
      textLabel4 = new QLabel(widget);
      textLabel4->setObjectName(QString::fromUtf8("textLabel4"));
      textLabel4->setGeometry(QRect(1, 70, 300, 25));
      textLabel4->setWordWrap(false);
      textLabel4->setOpenExternalLinks(true);
  
      textLabel3 = new QLabel(widget);
      textLabel3->setObjectName(QString::fromUtf8("textLabel3"));
      textLabel3->setGeometry(QRect(86, 100, 128, 128));
      textLabel3->setWordWrap(false);
  
      textLabel5 = new QLabel(widget);
      textLabel5->setObjectName(QString::fromUtf8("textLabel5"));
      textLabel5->setGeometry(QRect(26, 232, 250, 55));
      textLabel5->setWordWrap(true);
  
      pushButton1 = new QPushButton(widget);
      pushButton1->setObjectName(QString::fromUtf8("pushButton1"));
      pushButton1->setGeometry(QRect(100, 290, 100, 27));
  
      retranslateUi(AboutWidget);
  
      QMetaObject::connectSlotsByName(AboutWidget);
    } // setupUi

    void retranslateUi(QWidget *AboutWidget)
    {
  
      AboutWidget->setWindowTitle(QApplication::translate("AboutWidget", "SME About", 0, QApplication::UnicodeUTF8));

      pushButton1->setText(QApplication::translate("Dialog", "Close", 0, QApplication::UnicodeUTF8));
      textLabel1->setText(QApplication::translate("Dialog", "<center><font size=\"+1\"><b>Storage Made Easy Linux Cloud Tools</b></font></center>", 0, QApplication::UnicodeUTF8));
      textLabel2->setText(QApplication::translate("Dialog", "<center>Version 4.3.3</center>", 0, QApplication::UnicodeUTF8));
  
      textLabel3->setPixmap(QPixmap("/usr/share/smeclient/smeclient.png"));
  
      textLabel4->setText(QApplication::translate("Dialog", "<center><a href='http://storagemadeeasy.com'>http://storagemadeeasy.com</a></center>", 0, QApplication::UnicodeUTF8));
      textLabel5->setText(QApplication::translate("Dialog", "<center>Contact <a href='support@storagemadeeasy.com'>support@storagemadeeasy.com</a> to report errors</center>", 0, QApplication::UnicodeUTF8));
  
      Q_UNUSED(AboutWidget);
    }// retranslateUi

};

namespace Ui {
    class AboutWidget: public Ui_AboutWidget {};
} // namespace Ui

#endif // UI_ABOUTWIDGET_H
