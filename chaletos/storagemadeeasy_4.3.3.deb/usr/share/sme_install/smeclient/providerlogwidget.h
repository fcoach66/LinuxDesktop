#ifndef PROVIDERLOGWIDGET_H
#define PROVIDERLOGWIDGET_H

#include <QtGui/QWidget>

namespace Ui
{
    class ProviderlogWidget;
}

class ProviderlogWidget : public QWidget
{
    Q_OBJECT

public:
    ProviderlogWidget(QWidget *parent = 0);
    ~ProviderlogWidget();
    void initWnd();
		QString plogin;
		QString ppass;

public
  slots:
    void saveProviderlog();
    void hideWindow();

  signals:
    void saveProviderLog();

private:
    Ui::ProviderlogWidget *ui;

};

#endif // PROVIDERLOGWIDGET_H
