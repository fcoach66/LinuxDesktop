#ifndef UI_SYNCWIDGET_H
#define UI_SYNCWIDGET_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
// #include <QtGui/QButtonGroup>
#include <QtGui/QLabel>
#include <QtGui/QCheckBox>
// #include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QWidget>
#include <QtGui/QProgressBar>

#include <QtGui/QFileDialog>
// #include <QFile>

#include <Qt3Support/Q3MimeSourceFactory>
// #include <QtGui/QDialog>
#include <QtGui/QMenu>
#include <QtGui/QMenuBar>
#include <QtGui/QMessageBox>

#include <QTreeWidget>
#include <QTreeWidgetItem>
#include <QString>
#include <QDate>


class Ui_SyncWidget
{
public:
    QWidget *widget;
    QPushButton *pushButton0, *pushButton1, *pushButton2, *pushButton3, *pushButton4, *pushButton5,
								*pushButton6, *pushButton7, *pushButton8, *pushButton9, *pushButton10, *pushButton11;
    QLabel *textLabel1;
    QProgressBar *progressBar1;
    QTreeWidget *tree;
    QMenuBar *MenuBar;
    QMenu *fileMenu, *syncMenu;

    void setupUi(QWidget *SyncWidget)
    {
		QString pathToIcon="/usr/share/smeclient/";
		QString pathToWIcon="/usr/share/pixmaps/";

      if(SyncWidget->objectName().isEmpty())
          SyncWidget->setObjectName(QString::fromUtf8("SyncWidget"));
		int w0=889, h0=391;
      SyncWidget->resize(w0, h0);
		SyncWidget->setMinimumSize(300, 120);
      SyncWidget->setWindowIcon(QIcon(pathToWIcon +"sme_synccenter_icon_42.png"));

      widget = new QWidget(SyncWidget);
      widget->setObjectName(QString::fromUtf8("widget"));
      widget->setGeometry(QRect(0, 0, w0, h0));

		int sw=2;
		int w=98;
		int w_small=w-59;
		int w_big=w+20;
		int h=43;
		int p=5;
		int p_big=14;

		MenuBar = new QMenuBar(widget);
		MenuBar->setObjectName(QString::fromUtf8("MenuBar"));
		MenuBar->setGeometry(QRect(0, 0, w0, 26));
		fileMenu = new QMenu(MenuBar);
		fileMenu->setObjectName(QString::fromUtf8("fileMenu"));
      fileMenu->setTitle("&File");
		syncMenu = new QMenu(MenuBar);
		syncMenu->setObjectName(QString::fromUtf8("syncMenu"));
      syncMenu->setTitle("&Sync");
		MenuBar->addAction(fileMenu->menuAction());
		MenuBar->addAction(syncMenu->menuAction());

      pushButton0 = new QPushButton(QIcon(pathToIcon +"refresh.gif"), "", widget);
      pushButton0->setObjectName(QString::fromUtf8("pushButton0"));
      pushButton0->setGeometry(QRect( sw, 0, w_small, h));
		pushButton0->setToolTip("Refresh");
		sw+=w_small+p_big;
      pushButton1 = new QPushButton(QIcon(pathToIcon +"sync_all.gif"), "", widget);
      pushButton1->setObjectName(QString::fromUtf8("pushButton1"));
      pushButton1->setGeometry(QRect(sw, 0, w, h));
		pushButton1->setToolTip("Sync All");
		sw+=w+p;
      pushButton3 = new QPushButton(QIcon(pathToIcon +"sync_down.gif"), "", widget);
      pushButton3->setObjectName(QString::fromUtf8("pushButton3"));
      pushButton3->setGeometry(QRect(sw, 0, w_big, h));
		pushButton3->setToolTip("Sync Down");
		sw+=w_big+p;
		pushButton2 = new QPushButton(QIcon(pathToIcon +"sync_up.gif"), "", widget);
		pushButton2->setObjectName(QString::fromUtf8("pushButton2"));
		pushButton2->setGeometry(QRect(sw, 0, w, h));
		pushButton2->setToolTip("Sync Up");
		sw+=w+p_big;
		pushButton5 = new QPushButton(QIcon(pathToIcon +"clone_down.gif"), "", widget);
		pushButton5->setObjectName(QString::fromUtf8("pushButton5"));
		pushButton5->setGeometry(QRect(sw, 0, w_big, h));
		pushButton5->setToolTip("Clone Down");
		sw+=w_big+p;
		pushButton4 = new QPushButton(QIcon(pathToIcon +"clone_up.gif"), "", widget);
		pushButton4->setObjectName(QString::fromUtf8("pushButton4"));
		pushButton4->setGeometry(QRect(sw, 0, w, h));
		pushButton4->setToolTip("Clone Up");
		sw+=w+p_big;

		pushButton10 = new QPushButton(QIcon(pathToIcon +"plus.gif"), "", widget);
		pushButton10->setObjectName(QString::fromUtf8("pushButton10"));
		pushButton10->setGeometry(QRect(sw, 0, w_small, h));
		pushButton10->setToolTip("Expand/Collapse folder and subfolders");
		sw+=w_small+p+2;

		pushButton11 = new QPushButton(QIcon(pathToIcon +"hide.gif"), "", widget);
		pushButton11->setObjectName(QString::fromUtf8("pushButton11"));
		pushButton11->setGeometry(QRect(sw, 0, w_small, h));
		pushButton11->setToolTip("Hide synced files and folders");
		sw+=w_small+p+2;

		pushButton6 = new QPushButton(QIcon(pathToIcon +"add_folder.gif"), "", widget);
		pushButton6->setObjectName(QString::fromUtf8("pushButton6"));
		pushButton6->setGeometry(QRect(sw, 0, w_small, h));
		pushButton6->setToolTip("Add sync pair");
		sw+=w_small+p;
		pushButton7 = new QPushButton(QIcon(pathToIcon +"del_folder.gif"), "", widget);
		pushButton7->setObjectName(QString::fromUtf8("pushButton7"));
		pushButton7->setGeometry(QRect(sw, 0, w_small, h));
		pushButton7->setToolTip("Remove sync pair");
		sw+=w_small+p_big;
		pushButton8 = new QPushButton(QIcon(pathToIcon +"properties.gif"), "", widget);
		pushButton8->setObjectName(QString::fromUtf8("pushButton8"));
		pushButton8->setGeometry(QRect(sw, 0, w_small, h));
		pushButton8->setToolTip("Properties");
		sw+=w_small+p;

		tree = new QTreeWidget(widget);
		tree->setObjectName(QString::fromUtf8("tree"));
		tree->setGeometry(QRect(3, 65, 800-6, 300));

		tree->setUpdatesEnabled(true);
		tree->setColumnCount(5);
/*
		QStringList headers;
		headers << "Name" << "Location" << "Local Date" << "X" << "Cloud Date";
		tree->setHeaderLabels(headers);
*/

		QTreeWidgetItem * stateNode;
		stateNode = new QTreeWidgetItem();
		stateNode->setText(0, "Local Folder");
		stateNode->setText(1, "Cloud Folder");
		stateNode->setText(2, "Local Date");
		stateNode->setIcon(3, QIcon(pathToIcon +"state.gif"));
		stateNode->setText(4, "Cloud Date");
		tree->setHeaderItem(stateNode);

		tree->setColumnWidth(0, 295-6-15-20-2);
		tree->setColumnWidth(1, 220);
		tree->setColumnWidth(2, 140);
		tree->setColumnWidth(3, 22);
		tree->setColumnWidth(4, 140);

		textLabel1 = new QLabel(widget);
		textLabel1->setObjectName(QString::fromUtf8("textLabel1"));
		textLabel1->setGeometry(QRect(3, 370, 700, 16));
//		textLabel1->setWordWrap(true);
		textLabel1->setWordWrap(false);

		progressBar1 = new QProgressBar(widget);
		progressBar1->setObjectName(QString::fromUtf8("progressBar1"));
		progressBar1->setGeometry(QRect(503, 369, 200, 18));

		pushButton9 = new QPushButton(widget);
		pushButton9->setObjectName(QString::fromUtf8("pushButton9"));
		pushButton9->setGeometry(QRect(710, 370, 80, 18));

		retranslateUi(SyncWidget);

		QMetaObject::connectSlotsByName(SyncWidget);
    } // setupUi

    void retranslateUi(QWidget *SyncWidget)
    {

      SyncWidget->setWindowTitle(QApplication::translate("SyncWidget", "Storage Made Easy Sync Center", 0, QApplication::UnicodeUTF8));
/*
      QFont font;
      font.setFamily(QString::fromUtf8("Tahoma"));
      font.setPointSize(10);
      pushButton0->setFont(font);
      pushButton1->setFont(font);
      pushButton2->setFont(font);
      pushButton3->setFont(font);
      pushButton4->setFont(font);
      pushButton5->setFont(font);
      pushButton6->setFont(font);
      pushButton7->setFont(font);
*/
//      pushButton0->setText(QApplication::translate("Dialog", "Refresh", 0, QApplication::UnicodeUTF8));
      pushButton1->setText(QApplication::translate("Dialog", "Sync All", 0, QApplication::UnicodeUTF8));
      pushButton2->setText(QApplication::translate("Dialog", "Sync Up", 0, QApplication::UnicodeUTF8));
      pushButton3->setText(QApplication::translate("Dialog", "Sync Down", 0, QApplication::UnicodeUTF8));
      pushButton4->setText(QApplication::translate("Dialog", "Clone Up", 0, QApplication::UnicodeUTF8));
      pushButton5->setText(QApplication::translate("Dialog", "Clone Down", 0, QApplication::UnicodeUTF8));
//      pushButton6->setText(QApplication::translate("Dialog", "Add", 0, QApplication::UnicodeUTF8));
//      pushButton7->setText(QApplication::translate("Dialog", "Remove", 0, QApplication::UnicodeUTF8));

      textLabel1->setText(QApplication::translate("Dialog", "", 0, QApplication::UnicodeUTF8));
		textLabel1->hide();
      pushButton9->setText(QApplication::translate("Dialog", "Cancel", 0, QApplication::UnicodeUTF8));
      pushButton9->hide();
		progressBar1->hide();

/*
		int fontSize=12;
		if(textLabel1->font().pixelSize()>8){
			fontSize=textLabel1->font().pixelSize();
			if(fontSize>13){
				QFont font=textLabel1->font();
				font.setPixelSize(13);
//				font.setPointSize(13);
			}
		}else if(textLabel1->font().pointSize()>7){
			fontSize=textLabel1->font().pointSize();
			if(fontSize>11){
				QFont font=textLabel1->font();
				font.setPixelSize(11);
//				font.setPointSize(13);
			}
		}
*/


      Q_UNUSED(SyncWidget);
    }// retranslateUi

};

namespace Ui {
	class SyncWidget: public Ui_SyncWidget {};
} // namespace Ui

#endif // UI_SYNCWIDGET_H
