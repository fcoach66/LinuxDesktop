#ifndef UTILS_CP
#define UTILS_CP

#include <QThread>

QString boolToQstring(bool b);
QString intToQstring(int n);
QString floatToQstring(double n);
QString getPartQString(QString s, QString from, QString to);
QString readFromFile(QString name);
int writeToFile(QString name, QString s, bool append);
void debug(QString s, int level=0, int DEBUG=1);
bool isNumber(QString s);
int getInt(QString s, int defaultValue=0);
QString base64(QString t);
QString decodeBase64(QString t);
QString getCorrectFilePath(QString s);          // It replace "//" to "/" and add "/" on the start
QList<QString> getFileInfo(QString s);          // return QList(name, path) from fullname


#endif // UTILS_CP
