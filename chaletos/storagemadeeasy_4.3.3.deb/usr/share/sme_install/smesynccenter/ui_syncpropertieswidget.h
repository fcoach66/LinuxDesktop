#ifndef UI_SYNCPROPERTIESWIDGET_H
#define UI_SYNCPROPERTIESWIDGET_H

#include <QtGui/QApplication>
// #include <QtGui/QButtonGroup>
#include <QtGui/QLabel>
#include <QtGui/QCheckBox>
#include <QtGui/QRadioButton>
#include <QtGui/QGroupBox>
//#include <QtGui/QVBoxLayout>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QComboBox>
#include <QtGui/QWidget>

#include <Qt3Support/Q3MimeSourceFactory>
#include <QScrollArea>

class Ui_SyncpropertiesWidget
{
	public:
		QWidget *widget;
		QLabel *textLabel0, *textLabel1, *textLabel2, *textLabel3, *textLabel4, *textLabel5, *textLabel6, *textLabel7, *textLabel8, *textLabel9, *textLabel10, *textLabel11, *textLabel12, *textLabel13;
		QPushButton *pushButton1, *pushButton2, *pushButton3, *pushButton4, *pushButton5;
		QLineEdit *lineEdit1, *lineEdit2, *lineEdit4, *lineEdit5, *lineEdit6, *lineEdit7, *lineEdit8;
		QRadioButton *radio1, *radio2, *radio3, *radio4, *radio5;

		QCheckBox *checkBox1, *checkBox3, *checkBox4, *checkBox5, *checkBox6, *checkBox7, *checkBox8;
		QGroupBox *groupBox, *groupBox2;
		QComboBox *comboBox0, *comboBox1, *comboBox2, *comboBox3, *comboBox4;
		QScrollArea scrollArea, *scrollArea2;
    void setupUi(QWidget *SyncpropertiesWidget)
    {
      if(SyncpropertiesWidget->objectName().isEmpty())
         SyncpropertiesWidget->setObjectName(QString::fromUtf8("SyncpropertiesWidget"));

			int windowW=673, windowH=515;		// size must be set in initWnd()
			SyncpropertiesWidget->resize(windowW, windowH);
			SyncpropertiesWidget->setMinimumSize(200, 240);
			SyncpropertiesWidget->setWindowIcon(QIcon("/usr/share/pixmaps/sme_synccenter_icon_42.png"));

			widget=new QWidget(SyncpropertiesWidget);
			widget->setObjectName(QString::fromUtf8("widget"));
			widget->setGeometry(QRect(0, 0, windowW, windowH));

/*
QFont wdgfont("Arial", 11);
widget->setFont(wdgfont);
*/

			int left=16, leftTextEdit=left+150;
			int h=16, hTextEdit=h+7;
			int p=15;
			int w=135, wTextEdit=w+175;
			int sh=10;

			textLabel0=new QLabel(widget);
			textLabel0->setGeometry(QRect(left, sh, w, h));
	      textLabel0->setText("Server: ");
			comboBox0=new QComboBox(widget);
			comboBox0->setGeometry(QRect(leftTextEdit, sh-8, wTextEdit, hTextEdit));
			comboBox0->setEditable(true);
			comboBox0->insertItem(0, "");
			comboBox0->insertItem(1, "storagemadeeasy.com");
			comboBox0->insertItem(2, "eu.storagemadeeasy.com");
			comboBox0->insertItem(3, "https://storagemadeeasy.com");
			comboBox0->insertItem(4, "https://eu.storagemadeeasy.com");
			sh+=p+h-3;

			textLabel1=new QLabel(widget);
			textLabel1->setObjectName(QString::fromUtf8("textLabel1"));
			textLabel1->setGeometry(QRect(left, sh, w, h));
		   textLabel1->setText("Login:");
			lineEdit1=new QLineEdit(widget);
			lineEdit1->setObjectName(QString::fromUtf8("lineEdit1"));
			lineEdit1->setGeometry(QRect(leftTextEdit, sh-8, wTextEdit, hTextEdit));
			sh+=p+h-3;

			textLabel2=new QLabel(widget);
			textLabel2->setObjectName(QString::fromUtf8("textLabel2"));
			textLabel2->setGeometry(QRect(left, sh, w, h));
	      textLabel2->setText("Password:");
			lineEdit2=new QLineEdit(widget);
			lineEdit2->setObjectName(QString::fromUtf8("lineEdit2"));
			lineEdit2->setGeometry(QRect(leftTextEdit, sh-8, wTextEdit, hTextEdit));
			lineEdit2->setEchoMode(QLineEdit::Password);
			sh+=p+h-3;

			textLabel9=new QLabel(widget);
			textLabel9->setObjectName(QString::fromUtf8("textLabel9"));
			textLabel9->setGeometry(QRect(left, sh, w, h));
	      textLabel9->setText("Encryption password:");
			lineEdit4=new QLineEdit(widget);
			lineEdit4->setObjectName(QString::fromUtf8("lineEdit9"));
			lineEdit4->setGeometry(QRect(leftTextEdit, sh-8, wTextEdit, hTextEdit));
			lineEdit4->setEchoMode(QLineEdit::Password);
			sh+=p+h-3;

			checkBox8=new QCheckBox(QString::fromUtf8("Show the notify when Scheduled/Quick sync completed"), widget);
			checkBox8->setGeometry(QRect(left, sh, 500, 18));
			checkBox8->setCheckState(Qt::Unchecked);
			sh+=p+3;

			checkBox3=new QCheckBox(QString::fromUtf8("Show sync results when Scheduled/Quick sync completed"), widget);
			checkBox3->setGeometry(QRect(left, sh, 500, 18));
			checkBox3->setCheckState(Qt::Unchecked);
			sh+=p+3;

			checkBox4=new QCheckBox(QString::fromUtf8("Extended logs"), widget);
			checkBox4->setGeometry(QRect(left, sh, 400, 18));
			checkBox4->setCheckState(Qt::Unchecked);
			sh+=p+3;

			checkBox5=new QCheckBox(QString::fromUtf8("Delete files (folders) from cloud when I delete it from local drive"), widget);
			checkBox5->setGeometry(QRect(left, sh, 500, 18));
			checkBox5->setCheckState(Qt::Unchecked);
			sh+=p+3;

			checkBox6=new QCheckBox(QString::fromUtf8("Delete files (folders) from local drive when I delete it from cloud"), widget);
			checkBox6->setGeometry(QRect(left, sh, 500, 18));
			checkBox6->setCheckState(Qt::Unchecked);
			sh+=p+3;

			checkBox1=new QCheckBox(QString::fromUtf8("Sync Schedule"), widget);
			checkBox1->setObjectName(QString::fromUtf8("checkBox"));
			checkBox1->setGeometry(QRect(left, sh, 300, 18));
			checkBox1->setCheckState(Qt::Unchecked);
			sh+=20;

			groupBox=new QGroupBox(QString::fromUtf8("Schedule Options"), widget);
			groupBox->setGeometry(QRect(left+10, sh, windowW-(left+10)-13, 246));
			sh+=190+5;

//			scrollArea.setWidget(groupBox);
//			scrollArea.setGeometry(QRect(left+10, sh, windowW-(left+10)-13, 246));
//			scrollArea.show();

			scrollArea2=new QScrollArea(SyncpropertiesWidget);
			scrollArea2->setGeometry(QRect(0, 0, windowW, windowH));
			scrollArea2->setWidget(widget);
//			scrollArea2->show();


			radio1=new QRadioButton(QString::fromUtf8("Sync All"), groupBox);
			radio2=new QRadioButton(QString::fromUtf8("Sync Down (Cloud to Desktop)"), groupBox);
			radio3=new QRadioButton(QString::fromUtf8("Sync Up (Desktop to Cloud)"), groupBox);
			radio4=new QRadioButton(QString::fromUtf8("Cloning down (Cloud to Desktop, deleting\nnon-existent files on Desktop)"), groupBox);
			radio5=new QRadioButton(QString::fromUtf8("Cloning up (Desktop to Cloud, deleting\nnon-existent files on Cloud)"), groupBox);

			int sh2=20;
			int left2=6;
//			h=18;
//			p=15;
			int w2=350;
			int d2=3;
//radio1->setGeometry(QRect(left, sh, w, h));
			radio1->setGeometry(QRect(left2, sh2, w2, h));
			sh2+=h+d2;
			radio2->setGeometry(QRect(left2, sh2, w2, h));
			sh2+=h+d2;
			radio3->setGeometry(QRect(left2, sh2, w2, h));
			sh2+=h+d2;
			radio4->setGeometry(QRect(left2, sh2, w2, h*2));
			sh2+=h*2+d2;
			radio5->setGeometry(QRect(left2, sh2, w2, h*2));
			sh2+=h*2+d2+8;


			textLabel4=new QLabel(groupBox);
			textLabel5=new QLabel(groupBox);
			textLabel6=new QLabel(groupBox);
			textLabel7=new QLabel(groupBox);
			textLabel8=new QLabel(groupBox);

			int sh3=25;
			int w3=175;
			//int left3=left2+w2+20;
			//int left31=left3+w3+12;
			int left31=left2+w2+10;
			int left3=left31+55;
			int d3=9;

			textLabel4->setGeometry(QRect(left31-5, sh3, w3, h));
			textLabel4->setText("Run every: ");
			sh3+=h+d3;


			comboBox1=new QComboBox(groupBox);
			comboBox2=new QComboBox(groupBox);
			comboBox3=new QComboBox(groupBox);
			comboBox4=new QComboBox(groupBox);

			comboBox1->setGeometry(QRect(left3, sh3-2, w3, h+4));
			textLabel5->setGeometry(QRect(left31, sh3, w3, h));
			textLabel5->setText("Month:");
			sh3+=h+d3;

			comboBox2->setGeometry(QRect(left3, sh3-2, w3, h+4));
			textLabel6->setGeometry(QRect(left31, sh3, w3, h));
			textLabel6->setText("Day:");
			sh3+=h+d3;

			comboBox3->setGeometry(QRect(left3, sh3-2, w3, h+4));
			textLabel7->setGeometry(QRect(left31, sh3, w3, h));
			textLabel7->setText("Hour:");
			sh3+=h+d3;

			comboBox4->setGeometry(QRect(left3, sh3-2, w3, h+4));
			textLabel8->setGeometry(QRect(left31, sh3, w3, h));
			textLabel8->setText("Minute:");
			sh3+=h+d3;

			radio1->setChecked(true);

			pushButton4=new QPushButton(groupBox);
			pushButton4->setObjectName(QString::fromUtf8("pushButton1"));
			pushButton4->setGeometry(QRect(left2, sh2, 100, h+5));
			pushButton4->setText("View log");

			pushButton5=new QPushButton(groupBox);
			pushButton5->setObjectName(QString::fromUtf8("pushButton1"));
			pushButton5->setGeometry(QRect(left2+135, sh2, 100, h+5));
			pushButton5->setText("Clear log");

			checkBox7=new QCheckBox(QString::fromUtf8("Use Proxy"), widget);
			checkBox7->setGeometry(QRect(left, sh, windowW-2*left, h));
			checkBox7->setCheckState(Qt::Unchecked);
			sh+=20;

			int gw=windowW-2*left-10;
			groupBox2=new QGroupBox(QString::fromUtf8("Proxy Options"), widget);
			groupBox2->setGeometry(QRect(left+10, sh, gw, 128));
			sh+=128+5;

			int gy=22, gx=3, gw1=int(gw/3-2*gx), gw2=gw-gw1-2*gx-5, gh=h;
			left+=6;
			textLabel10=new QLabel(groupBox2);
			textLabel10->setGeometry(QRect(gx, gy, gw1, gh));
			textLabel10->setText("Proxy host:");
			lineEdit5=new QLineEdit(groupBox2);
			lineEdit5->setGeometry(QRect(gx+gw1+5, gy-2, gw2, gh+4));
			gy+=gh+7;

			textLabel11=new QLabel(groupBox2);
			textLabel11->setGeometry(QRect(gx, gy, gw1, gh));
			textLabel11->setText("Proxy port:");
			lineEdit6=new QLineEdit(groupBox2);
			lineEdit6->setGeometry(QRect(gx+gw1+5, gy-2, 75, gh+4));
			gy+=gh+7;

			textLabel12=new QLabel(groupBox2);
			textLabel12->setGeometry(QRect(gx, gy, gw1, gh));
			textLabel12->setText("Proxy login:");
			lineEdit7=new QLineEdit(groupBox2);
			lineEdit7->setGeometry(QRect(gx+gw1+5, gy-2, gw2, gh+4));
			gy+=gh+7;

			textLabel13=new QLabel(groupBox2);
			textLabel13->setGeometry(QRect(gx, gy, gw1, gh));
			textLabel13->setText("Proxy password:");
			lineEdit8=new QLineEdit(groupBox2);
			lineEdit8->setGeometry(QRect(gx+gw1+5, gy-2, gw2, gh+4));
			lineEdit8->setEchoMode(QLineEdit::Password);
			gy+=gh+7;

			left=left+40;
			pushButton1=new QPushButton(widget);
			pushButton1->setObjectName(QString::fromUtf8("pushButton1"));
			pushButton1->setGeometry(QRect(left, sh, 100, h+11));
			pushButton1->setText(QApplication::translate("Dialog", "OK", 0, QApplication::UnicodeUTF8));
			pushButton2=new QPushButton(widget);
			pushButton2->setObjectName(QString::fromUtf8("pushButton2"));
			pushButton2->setGeometry(QRect(left+145, sh, 100, h+11));
			pushButton2->setText(QApplication::translate("Dialog", "Cancel", 0, QApplication::UnicodeUTF8));

			retranslateUi(SyncpropertiesWidget);

			QMetaObject::connectSlotsByName(SyncpropertiesWidget);
		} // setupUi

		void retranslateUi(QWidget *SyncpropertiesWidget)
		{
			SyncpropertiesWidget->setWindowTitle(QApplication::translate("SyncpropertiesWidget", "Sync Properties", 0, QApplication::UnicodeUTF8));
//      checkBox->setText(QApplication::translate("Dialog", "Share your drive", 0, QApplication::UnicodeUTF8));

			Q_UNUSED(SyncpropertiesWidget);
		}// retranslateUi

};

namespace Ui {
    class SyncpropertiesWidget: public Ui_SyncpropertiesWidget {};
} // namespace Ui

#endif // UI_SYNCPROPERTIESWIDGET_H
