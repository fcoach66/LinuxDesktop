#ifndef LINKFOLDERSWIDGET_H
#define LINKFOLDERSWIDGET_H

#include <QtGui/QWidget>
#include <QtGui/QLabel>
#include <QtGui/QPushButton>
#include <QtGui/QWidget>
//#include <Qt3Support/Q3MimeSourceFactory>
#include <QtGui/QMessageBox>
#include <QtGui/QCheckBox>
//#include <QDateTime>
#include <QTreeWidget>
#include <QTreeWidgetItem>
#include <QtGui/QKeyEvent>
#include <QDir>


typedef struct {
	QString id, pid, name;
	bool loaded;
	QTreeWidgetItem *node;
} Tsfolder;

typedef struct {
	QString path;
	bool loaded;
	QTreeWidgetItem *node;
} Tlfolder;

class LinkFoldersWidget : public QWidget
{
    Q_OBJECT

public:
	LinkFoldersWidget(QWidget *parent = 0);
	~LinkFoldersWidget();
	void clear();
	void initWnd();

	QList<Tsfolder> sfolderslist;
	QList<Tlfolder> lfolderslist;

	QWidget *widget1;
	QLabel *textLabel1, *textLabel2;
	QPushButton *pushButton1, *pushButton2;
	QTreeWidget *tree1, *tree2;
	QCheckBox *checkBox1;
	bool needShowHiddenFolders;
	bool addToSTree(Tsfolder folder);
	bool addToLTree(QString path, QTreeWidgetItem *pnode=NULL);

	void addLocalDir(QString path);
	void blockAll();
	void unblockAll();

	void debug(QString s);
public
  slots:
	void hideWindow();
	void bOK();
	void expandItem(QTreeWidgetItem *item);
	void selectionChanged();
	void checkBox1StateChanged(int par);

  signals:
    void openServerFolder(QString id);
	 void link(QString path, QString id, QString serverfoldername, QString pid);


private:
	virtual void keyPressEvent(QKeyEvent * event);
	virtual void resizeEvent(QResizeEvent * e=NULL);


};

#endif // LINKFOLDERSWIDGET_H
