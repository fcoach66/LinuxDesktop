#include "fileclass.h"

FileClass::FileClass(){
	name="";
	servername="";
	path="";
	existsOnServer=-1;
	existsOnLocal=-1;
	type=0;
	id=-1;
	pid=-1;
	serverSize=-1;
	localdate=QDateTime();
	serverdate=QDateTime();
	isProcessed=false;
	isOpened=false;
	realserverdate=QDateTime();
	isSyncedUp = false;
	isSyncedDown = false;
}
//////////////////////////////////////////////////////////////////////
FileClass::FileClass(QString fname, QString fpath){
	name=fname;
	servername="";
	path=fpath;
	existsOnServer=-1;
	existsOnLocal=-1;
	type=0;
	id=-1;
	pid=-1;
	serverSize=-1;
	localdate=QDateTime();
	serverdate=QDateTime();
	isProcessed=false;
	isOpened=false;
	realserverdate=QDateTime();
	isSyncedUp = false;
	isSyncedDown = false;
}
//////////////////////////////////////////////////////////////////////
FileClass::FileClass(QString fname, QString fpath, int fexistsOnServer, int fexistsOnLocal){
	name=fname;
	servername="";
	path=fpath;
	existsOnServer=fexistsOnServer;
	existsOnLocal=fexistsOnLocal;
	localdate=QDateTime();
	serverdate=QDateTime();
	realserverdate=QDateTime();
	type=0;
	id=-1;
	pid=-1;
	serverSize=-1;
	isOpened=false;
	isProcessed=false;
	isSyncedUp = false;
	isSyncedDown = false;
}
//////////////////////////////////////////////////////////////////////
FileClass::FileClass(QString fname, QString fpath, int fexistsOnServer, int fexistsOnLocal, QDateTime flocaldate, QDateTime fserverdate){
	name=fname;
	servername="";
	path=fpath;
	existsOnServer=fexistsOnServer;
	existsOnLocal=fexistsOnLocal;
	localdate =flocaldate;
	serverdate=fserverdate;
	realserverdate=QDateTime();
	type=0;
	id=-1;
	pid=-1;
	serverSize=-1;
	isProcessed=false;
	isOpened=false;
	isSyncedUp = false;
	isSyncedDown = false;
}
//////////////////////////////////////////////////////////////////////
FileClass::~FileClass(){
}
//////////////////////////////////////////////////////////////////////



