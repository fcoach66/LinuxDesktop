#include "stdio.h"
#include "linkfolderswidget.h"

LinkFoldersWidget::LinkFoldersWidget(QWidget *parent) : QWidget(parent){
	widget1 = new QWidget(this);
	widget1->setGeometry(QRect(0, 0, 560, 350));
	this->setWindowTitle("Link Folders");
	this->setWindowIcon(QIcon("/usr/share/pixmaps/sme_explorer_icon_42.png"));
   widget1->setObjectName(QString::fromUtf8("widget1"));

	needShowHiddenFolders=false;
	int x1=3;//, y1=18;
	int dy=2, dy2=15, dx1=485;
	int y=6;

	tree1 = new QTreeWidget(widget1);
	tree1->setObjectName(QString::fromUtf8("tree"));
	tree1->setGeometry(QRect(x1, y, dx1, 170));
	tree1->setUpdatesEnabled(true);
	tree1->setColumnCount(1);
	tree1->headerItem()->setHidden(false);
	y+=170+dy+dy2-7;

	tree2 = new QTreeWidget(widget1);
	tree2->setObjectName(QString::fromUtf8("tree"));
	tree2->setGeometry(QRect(x1, y, dx1, 170));
	tree2->setUpdatesEnabled(true);
	tree2->setColumnCount(1);
	tree2->headerItem()->setHidden(false);
	y+=170+dy+dy2-7;

	checkBox1=new QCheckBox(QString::fromUtf8("Show hidden folders"), widget1);
	checkBox1->setGeometry(QRect(x1, y, 125, 29));
	checkBox1->setCheckState(Qt::Unchecked);
	y+=30;

	pushButton1 = new QPushButton(widget1);
	pushButton1->setObjectName(QString::fromUtf8("pushButton1"));
	pushButton1->setGeometry(QRect(x1, y+5, 125, 29));
	pushButton1->setText("OK");
	pushButton2 = new QPushButton(widget1);
	pushButton2->setObjectName(QString::fromUtf8("pushButton2"));
	pushButton2->setGeometry(QRect(x1+130, y+5, 125, 29));
	pushButton2->setText("Cancel");

	QTreeWidgetItem *stateNode1, *stateNode2;
	stateNode1=new QTreeWidgetItem();
	stateNode1->setText(0, "Local Folder");
	tree1->setHeaderItem(stateNode1);
	stateNode2=new QTreeWidgetItem();
	stateNode2->setText(0, "Cloud Folder");
	tree2->setHeaderItem(stateNode2);

	QObject::connect(pushButton1, SIGNAL(clicked()), this, SLOT(bOK()));
	QObject::connect(pushButton2, SIGNAL(clicked()), this, SLOT(hideWindow()));
	QObject::connect(tree1, SIGNAL(itemExpanded(QTreeWidgetItem *)), this, SLOT(expandItem(QTreeWidgetItem *)));
	QObject::connect(tree2, SIGNAL(itemExpanded(QTreeWidgetItem *)), this, SLOT(expandItem(QTreeWidgetItem *)));
	QObject::connect(tree1, SIGNAL(itemSelectionChanged()), this, SLOT(selectionChanged()));
	QObject::connect(tree2, SIGNAL(itemSelectionChanged()), this, SLOT(selectionChanged()));
	QObject::connect(checkBox1, SIGNAL(stateChanged(int)), this, SLOT(checkBox1StateChanged(int)));
}
//////////////////////////////////////////////////////////////////////
LinkFoldersWidget::~LinkFoldersWidget(){
}
//////////////////////////////////////////////////////////////////////
void LinkFoldersWidget::hideWindow(){
  this->hide();
}
//////////////////////////////////////////////////////////////////////
void LinkFoldersWidget::clear(){
	lfolderslist.clear();
	sfolderslist.clear();

	tree1->clear();
	tree2->clear();
}
//////////////////////////////////////////////////////////////////////
void LinkFoldersWidget::initWnd(){
	addLocalDir("/");
	emit openServerFolder("0");
}
//////////////////////////////////////////////////////////////////////
void LinkFoldersWidget::selectionChanged(){
	if(tree1->selectedItems().size()==1 && tree2->selectedItems().size()==1){
		pushButton1->setEnabled(true);
	}else{
		pushButton1->setEnabled(false);
	}
}
//////////////////////////////////////////////////////////////////////
void LinkFoldersWidget::expandItem(QTreeWidgetItem *item){
	debug("expandItem()");
	if(item->treeWidget()==tree1){
		for(int k=0, size=lfolderslist.size(); k<size; k++){
			Tlfolder f=lfolderslist.at(k);
			if(f.node==item){
				if(!f.loaded && f.node->childCount()==1){
					delete f.node->child(0);
					f.loaded=true;
					lfolderslist.replace(k, f);
					addLocalDir(f.path);
				}
				return ;
			}
		}
	}else{
		for(int k=0, size=sfolderslist.size(); k<size; k++){
			Tsfolder f=sfolderslist.at(k);
			if(f.node==item){
				if(!f.loaded && f.node->childCount()==1){
					delete f.node->child(0);
					f.loaded=true;
					sfolderslist.replace(k, f);
					emit openServerFolder(f.id);
					blockAll();
				}
				return ;
			}
		}
	}
}
//////////////////////////////////////////////////////////////////////
void LinkFoldersWidget::addLocalDir(QString path){
	if(path=="") path="/";
	path.replace("//", "/");

	QTreeWidgetItem *node=NULL;
	for(int k=0, size=lfolderslist.size(); k<size; k++){
		if(lfolderslist.at(k).path==path){
			node=lfolderslist.at(k).node;
			break;
		}
	}

	QDir dir(path);
	QStringList lstDirs;
	lstDirs=dir.entryList(QDir::Dirs | QDir::AllDirs | QDir::NoDotAndDotDot | QDir::Hidden);

	foreach(QString entry, lstDirs){
		if(entry=="." || entry=="..") continue;
		QString entryAbsPath = path + "/" + entry;
		entryAbsPath.replace("//", "/");
		addToLTree(entryAbsPath, node);
	}

	checkBox1StateChanged(0);	// need to update hidden files
	return ;
}
//////////////////////////////////////////////////////////////////////
bool LinkFoldersWidget::addToLTree(QString path, QTreeWidgetItem *pnode){
//debug("addToLTree("+path+", pnode)");
	if(path=="") return false;
	if(path.mid(path.length()-1, 1)=="/")	path=path.mid(0, path.length()-1);

	for(int k=0, size=lfolderslist.size(); k<size; k++){
		if(lfolderslist.at(k).node->parent()==pnode && lfolderslist.at(k).path==path){
			return true;	// Already added
		}
	}

	Tlfolder folder;
	folder.loaded=false;
	folder.path=path;
	if(pnode){
		folder.node=new QTreeWidgetItem(pnode);
		new QTreeWidgetItem(folder.node);
	}else{
		folder.node=new QTreeWidgetItem(tree1);
		new QTreeWidgetItem(folder.node);
	}

	QDir d(path);
	QString name=d.dirName();
	QString ipath="/usr/share/smeclient/files/folder.gif";
	folder.node->setText(0, name);
	folder.node->setIcon(0, QIcon(ipath));
	lfolderslist << folder;
//	tree->insertTopLevelItem(tree->topLevelItemCount(), grouplist[countGU-1].node);

	return true;
}
//////////////////////////////////////////////////////////////////////
bool LinkFoldersWidget::addToSTree(Tsfolder folder){
	if(folder.name=="" || folder.id=="") return false;

	folder.loaded=false;
	if(folder.pid=="" || folder.pid=="0"){
		folder.node=new QTreeWidgetItem(tree2);
		new QTreeWidgetItem(folder.node);
	}else{
		bool L=false;	
		for(int k=0, size=sfolderslist.size(); k<size; k++){
			if(sfolderslist.at(k).id==folder.pid){
				L=true;	
				folder.node=new QTreeWidgetItem(sfolderslist.at(k).node);
				new QTreeWidgetItem(folder.node);
				break;
			}
		}
		if(!L) return false;
	}

	QString ipath="/usr/share/smeclient/files/folder.gif";
	folder.node->setText(0, folder.name);
	folder.node->setIcon(0, QIcon(ipath));
	sfolderslist << folder;
//	tree->insertTopLevelItem(tree->topLevelItemCount(), grouplist[countGU-1].node);

	return true;
}
//////////////////////////////////////////////////////////////////////
void LinkFoldersWidget::bOK(){
	QString localfolder="",	serverfolder="", serverfoldername="", pid="";
	for(int k=0, size=lfolderslist.size(); k<size; k++){
		if(lfolderslist.at(k).node->isSelected()){
			localfolder=lfolderslist.at(k).path;
			break;
		}
	}

	for(int k=0, size=sfolderslist.size(); k<size; k++){
		if(sfolderslist.at(k).node->isSelected()){
			serverfolder=sfolderslist.at(k).id;
			serverfoldername=sfolderslist.at(k).name;
			pid=sfolderslist.at(k).pid;

			QTreeWidgetItem *nd=sfolderslist.at(k).node;
			while(nd){ // Get path on server by tree
				nd=nd->parent();
				if(nd) serverfoldername=nd->text(0)+"/"+serverfoldername;
			}
			serverfoldername="/"+serverfoldername;
			serverfoldername.replace("//", "/");
			break;
		}
	}

	if(localfolder=="" || serverfolder=="" || serverfoldername=="") return ;

	emit link(localfolder, serverfolder, serverfoldername, pid);
}
//////////////////////////////////////////////////////////////////////
void LinkFoldersWidget::keyPressEvent(QKeyEvent *event){
	int key=event->key();
	if(key==Qt::Key_Escape){
		hideWindow();
	}else if(key==Qt::Key_Enter || key==Qt::Key_Return){
		bOK();
	}

}
//////////////////////////////////////////////////////////////////////
void LinkFoldersWidget::resizeEvent(QResizeEvent *e){
	int w=width();
	int h=height();
	widget1->setGeometry(QRect(0, 0, w, h));
	if(e){}

	int x1=2, y=3, dx1=(int) (w-2*x1-6)/2;
	tree1->setGeometry(QRect(x1, y, dx1, h-y-64));
	tree2->setGeometry(QRect(x1+dx1+6, y, dx1, h-y-64));
	y=h-60;

	checkBox1->setGeometry(QRect(x1, y, w-2*x1, 28));
	y+=30;

	pushButton1->setGeometry(QRect(x1, y, 125, 29));
	pushButton2->setGeometry(QRect(x1+130, y, 125, 29));
}
//////////////////////////////////////////////////////////////////////
void LinkFoldersWidget::blockAll(){
	tree2->setEnabled(false);
	pushButton1->setEnabled(false);
}
//////////////////////////////////////////////////////////////////////
void LinkFoldersWidget::unblockAll(){
	tree2->setEnabled(true);
	selectionChanged();
}
//////////////////////////////////////////////////////////////////////
void LinkFoldersWidget::debug(QString s){
	printf("%s\n", s.toUtf8().data());
}
//////////////////////////////////////////////////////////////////////
void LinkFoldersWidget::checkBox1StateChanged(int par){
	if(par){}
	needShowHiddenFolders=false;
	if(checkBox1->checkState()==Qt::Checked)	needShowHiddenFolders=true;

	for(int k=0, size=lfolderslist.size(); k<size; k++){
		QString name=lfolderslist.at(k).path.mid(lfolderslist.at(k).path.lastIndexOf("/")+1);
		if(name.indexOf(".")==0){
			lfolderslist.at(k).node->setHidden(!needShowHiddenFolders);
		}
	}

}
//////////////////////////////////////////////////////////////////////

