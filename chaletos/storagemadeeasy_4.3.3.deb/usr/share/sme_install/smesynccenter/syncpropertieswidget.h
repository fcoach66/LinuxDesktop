#ifndef SYNCPROPERTIESWIDGET_H
#define SYNCPROPERTIESWIDGET_H

#include <QtGui/QWidget>

namespace Ui
{
    class SyncpropertiesWidget;
}

class SyncpropertiesWidget : public QWidget
{
    Q_OBJECT

	public:
		SyncpropertiesWidget(QWidget *parent=0);
		~SyncpropertiesWidget();

		QString login, password, logFileName, server, encryptPassword, proxyhost, proxylogin, proxypass, localeEncoding, scheduleOptions;
		int proxyport;
		int scheduleSyncType;	// scheduleSyncType - 1-syncall, 2-syncup, 3-syncdown, 4-cloneup, 5-clonedown

		bool useProxy;
      bool extendedLogs, showLogAfterQuickSync, deleteFromLocalWhenDeletedFromServer, deleteFromServerWhenDeletedFromLocal, showNotifyAfterScheduledSync;
		int DEBUG, versionType;

		bool cronTaskExists;
		void debug(QString s, int level=5);
		void initWnd();
/*
		QString floatToQstring(double n);
		QString intToQstring(int n);
*/
		QString runCommand(QString command);
		QString getPart(QString q, QString s1, QString s2);
		QString getCronTasks(bool withSme=true, bool onlySme=false, int needCheckForOldVersion=1);
		void saveCronTask(QString s);
		void removeSmeFromCronTasks();

	public
  slots:
		void saveProperties();
		void hideWindow();
		void checkBox1StateChanged(int par);
		void checkBox7StateChanged(int par);
		void showLog();
		void clearLog();

  signals:
		void SyncpropertiesWidgetClickOKButton();
		void SyncpropertiesWidgetShowLogs(QString caption, QString s, QString filename);

	private:
		Ui::SyncpropertiesWidget *ui;
		virtual void resizeEvent(QResizeEvent * e);
		virtual void keyPressEvent(QKeyEvent * event);

};

#endif // SYNCPROPERTIESWIDGET_H
