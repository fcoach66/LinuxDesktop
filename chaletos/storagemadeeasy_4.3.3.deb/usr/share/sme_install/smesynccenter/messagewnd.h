#ifndef MESSAGEWND_H
#define MESSAGEWND_H

#include <QtGui/QWidget>
#include <QCloseEvent>

namespace Ui
{
    class MessageWnd;
}

class MessageWnd : public QWidget
{
    Q_OBJECT

	public:
    MessageWnd(QWidget *parent = 0);
    ~MessageWnd();

		int DEBUG;

		void debug(QString s, int level=5);
		void initWnd();
		QString caption;
		QString logs;

		QString floatToQstring(double n);
		QString intToQstring(int n);
		QString getPart(QString q, QString s1, QString s2);

		Ui::MessageWnd *ui;
	private:
		virtual void resizeEvent(QResizeEvent * e);
		virtual void closeEvent(QCloseEvent * event);
	public
  slots:
    void hideWindow();

};

#endif // MESSAGEWND_H
