#include "syncpropertieswidget.h"
#include "ui_syncpropertieswidget.h"
#include "utils.h"
#include <QtGui/QKeyEvent>
#include <QTextCodec>
#include <QMessageBox>
#include <QFile>
#include <QDir>
#include <fcntl.h>
#include <unistd.h>

#include "cqthread.h"

SyncpropertiesWidget::SyncpropertiesWidget(QWidget *parent) : QWidget(parent), ui(new Ui::SyncpropertiesWidget){
	ui->setupUi(this);

	server="storagemadeeasy.com";
	login="";
	password="";
	proxyhost="";
	proxyport=80;
	proxylogin="";
	proxypass="";
	useProxy=false;

	logFileName=QDir::homePath() + "/.smesynccenter.log";

	showLogAfterQuickSync=false;
	extendedLogs=false;
	cronTaskExists=false;
	DEBUG=-1;		//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	versionType=0;

	ui->comboBox1->insertItem(0, "Every month");
	ui->comboBox1->insertItem(1, "Every January");
	ui->comboBox1->insertItem(2, "Every February");
	ui->comboBox1->insertItem(3, "Every March");
	ui->comboBox1->insertItem(4, "Every April");
	ui->comboBox1->insertItem(5, "Every May");
	ui->comboBox1->insertItem(6, "Every June");
	ui->comboBox1->insertItem(7, "Every July");
	ui->comboBox1->insertItem(8, "Every August");
	ui->comboBox1->insertItem(9, "Every September");
	ui->comboBox1->insertItem(10, "Every October");
	ui->comboBox1->insertItem(11, "Every November");
	ui->comboBox1->insertItem(12, "Every December");
	ui->comboBox1->insertItem(13, "Every 2 months");
	ui->comboBox1->insertItem(14, "Every 3 months");
	ui->comboBox1->insertItem(15, "Every 4 months");
	ui->comboBox1->insertItem(16, "Every May and October");
	ui->comboBox1->insertItem(17, "Every June and December");

	ui->comboBox2->insertItem(0, "Every day");
	ui->comboBox2->insertItem(1, "Sunday");
	ui->comboBox2->insertItem(2, "Monday");
	ui->comboBox2->insertItem(3, "Tuesday");
	ui->comboBox2->insertItem(4, "Wednesday");
	ui->comboBox2->insertItem(5, "Thursday");
	ui->comboBox2->insertItem(6, "Friday");
	ui->comboBox2->insertItem(7, "Saturday");

	for(int i=1; i<=31; i++){
		ui->comboBox2->insertItem(i+8, intToQstring(i));
	}

	for(int i=1; i<5; i++){
		ui->comboBox2->insertItem(i+38, "Every "+ intToQstring(i+1) +" days");
	}

	QString ln;
	for(int i=6; i<=15; i++){
		ln="";
		for(int j=i; j<=31; j+=i){
			if(j!=i)	ln+=", ";
			ln+=intToQstring(j);
		}
		ui->comboBox2->insertItem(i+42, ln);
	}

	ui->comboBox3->insertItem(0, "Every hour");
	for(int i=1; i<=24; i++){
		ui->comboBox3->insertItem(i, intToQstring(i-1));
	}

	for(int i=1; i<4; i++){
		ui->comboBox3->insertItem(i+24, "Every "+ intToQstring(i+1) +" hours");
	}

	for(int i=5; i<24; i++){
		ln="0";
		for(int j=i; j<24; j+=i){
			ln+=", "+intToQstring(j);
		}
		ui->comboBox3->insertItem(i+60, ln);
	}

	ui->comboBox4->insertItem(0, "Every minute");
	for(int i=1; i<=60; i++){
		ui->comboBox4->insertItem(i, intToQstring(i-1));
	}

	for(int i=1; i<6; i++){
		ui->comboBox4->insertItem(i+60, "Every "+ intToQstring(i+1) +" minutes");
	}

	for(int i=7; i<60; i++){
		ln="0";
		for(int j=i; j<60; j+=i){
			ln+=", "+intToQstring(j);
		}
		ui->comboBox4->insertItem(i+60, ln);
	}

// Buttons
    QObject::connect(ui->pushButton1, SIGNAL(clicked()), this, SLOT(saveProperties()));
    QObject::connect(ui->pushButton2, SIGNAL(clicked()), this, SLOT(hideWindow()));
    QObject::connect(ui->pushButton4, SIGNAL(clicked()), this, SLOT(showLog()));
    QObject::connect(ui->pushButton5, SIGNAL(clicked()), this, SLOT(clearLog()));
    QObject::connect(ui->checkBox1, 	SIGNAL(stateChanged(int)), this, SLOT(checkBox1StateChanged(int)));
    QObject::connect(ui->checkBox7, 	SIGNAL(stateChanged(int)), this, SLOT(checkBox7StateChanged(int)));
}
//////////////////////////////////////////////////////////////////////
SyncpropertiesWidget::~SyncpropertiesWidget(){
  delete ui;
}
//////////////////////////////////////////////////////////////////////
void SyncpropertiesWidget::showLog(){
//	QString s="";
	emit SyncpropertiesWidgetShowLogs("Scheduler and quick sync log", "", logFileName);
}
//////////////////////////////////////////////////////////////////////
void SyncpropertiesWidget::clearLog(){
	if(QMessageBox::question(this, "Confirm", "Do you want to clear log?", QMessageBox::Ok, QMessageBox::No)==QMessageBox::Ok)		QFile::resize(logFileName, 0);
}
//////////////////////////////////////////////////////////////////////
void SyncpropertiesWidget::saveProperties(){
	QLineEdit *edit=ui->comboBox0->lineEdit();
	server=edit->text().toLower();
	if(server=="") server="storagemadeeasy.com";
	login					=ui->lineEdit1->text();
	password				=ui->lineEdit2->text();
	encryptPassword	=ui->lineEdit4->text();

  if(login.length()<1){
    QMessageBox::critical(this, tr("Error"), "     Enter login     ");
    return ;
  }

  if(password.length()<1){
    QMessageBox::critical(this, tr("Error"), "   Enter password   ");
    return ;
  }


	if(server.length()<1){
		QMessageBox::critical(this, tr("Error"), "   Select server   ");
		return ;
	}

	if(ui->checkBox7->checkState()==Qt::Checked){
		useProxy=true;
	}else{
		useProxy=false;
	}

	if(useProxy){
		QString xproxyhost=ui->lineEdit5->text();
		int xproxyport=ui->lineEdit6->text().toInt();
		if(xproxyhost.length()<1){
			QMessageBox::critical(this, tr("Error"), "   Enter proxy host   ");
			return ;
		}

		if(xproxyport<1){
			QMessageBox::critical(this, tr("Error"), "Proxy port must be between 1 and 65535 ");
			return ;
		}
		proxyhost	=xproxyhost;
		proxyport	=xproxyport;
		proxylogin	=ui->lineEdit7->text();
		proxypass	=ui->lineEdit8->text();
	}

	scheduleOptions = "";
	scheduleSyncType = 0;			// scheduleSyncType - 1-syncall, 2-syncup, 3-syncdown, 4-cloneup, 5-clonedown

	showLogAfterQuickSync=false;
	extendedLogs=false;
	deleteFromServerWhenDeletedFromLocal=false;
	deleteFromLocalWhenDeletedFromServer=false;
   showNotifyAfterScheduledSync=false;
	if(ui->checkBox3->checkState()==Qt::Checked) showLogAfterQuickSync=true;
	if(ui->checkBox4->checkState()==Qt::Checked) extendedLogs=true;
	if(ui->checkBox5->checkState()==Qt::Checked) deleteFromServerWhenDeletedFromLocal=true;
   if(ui->checkBox6->checkState()==Qt::Checked) deleteFromLocalWhenDeletedFromServer=true;
   if(ui->checkBox8->checkState()==Qt::Checked) showNotifyAfterScheduledSync=true;

	if(cronTaskExists && ui->checkBox1->checkState()!=Qt::Checked){			// need delete task from cron
		removeSmeFromCronTasks();
	}else if(ui->checkBox1->checkState()==Qt::Checked){
		QString res="";
		int i=ui->comboBox4->currentIndex();
		if(i>=1 && i<=60){
			res+=intToQstring(i-1)+" ";
		}else if(i>60 && i<=120){
			res+="*/"+ intToQstring(i-59) +" ";
		}else{
			res+="* ";
		}

		i=ui->comboBox3->currentIndex();
		if(i>=1 && i<=24){
			res+=intToQstring(i-1)+" ";
		}else if(i>24 && i<=48){
			res+="*/"+ intToQstring(i-23) +" ";
		}else{
			res+="* ";
		}

		QString swday="";
		i=ui->comboBox2->currentIndex();
		if(i>=1 && i<=7){
			res+="* ";
			swday=intToQstring(i-1)+" ";
		}else if(i>=8 && i<=38){
			res+=intToQstring(i-7)+" ";
			swday="* ";
		}else if(i>=38 && i<=68){
			res+="*/"+ intToQstring(i-37)+" ";
			swday="* ";
		}else{
			res+="* ";
			swday="* ";
		}

		i=ui->comboBox1->currentIndex();
		if(i>=1 && i<=12){
			res+=intToQstring(i)+" ";
		}else if(i>12 && i<=17){
			res+="*/"+ intToQstring(i-11) +" ";

		}else{
			res+="* ";
		}
//debug(res);
//return ;

		res+=swday;

		scheduleOptions = res;
		res = "";

		if(ui->radio1->isChecked()){
			scheduleSyncType = 1;			// scheduleSyncType - 1-syncall, 2-syncup, 3-syncdown, 4-cloneup, 5-clonedown
		}else if(ui->radio2->isChecked()){
			scheduleSyncType = 3;
		}else if(ui->radio3->isChecked()){
			scheduleSyncType = 2;
		}else if(ui->radio4->isChecked()){
			scheduleSyncType = 5;
		}else if(ui->radio5->isChecked()){
			scheduleSyncType = 4;
		}

		//debug("res="+res);
		debug("scheduleOptions="+scheduleOptions);
/*
		// For root user we start Sync Center by cron, because usually it is impossible to use X server from autostart
		if(qgetenv("USER")=="root"){
			QString disp=runCommand("echo $DISPLAY");
			disp.replace("\n", "");
			if(disp.length()<1) disp=":0.0";

			QString lang=runCommand("echo $LANG");
			lang.replace("\n", "");
			if(lang.length()<1) lang="uk_UA.UTF-8";

			res = "* * * * * DISPLAY="+ disp +"; export DISPLAY; LANG="+ lang +"; export LANG; /usr/bin/smesynccenter --hidden --service\n";
			saveCronTask(getCronTasks(false, false)+res);
		}
*/

	}

  emit SyncpropertiesWidgetClickOKButton();
  this->hide();
}
//////////////////////////////////////////////////////////////////////
void SyncpropertiesWidget::checkBox1StateChanged(int par){
	if(par){}
	bool s=false;
	if(ui->checkBox1->checkState()==Qt::Checked)	s=true;
	ui->groupBox->setEnabled(s);
}
//////////////////////////////////////////////////////////////////////
void SyncpropertiesWidget::checkBox7StateChanged(int par){
	if(par){}
	bool s=false;
	if(ui->checkBox7->checkState()==Qt::Checked)	s=true;
	ui->groupBox2->setEnabled(s);
}
//////////////////////////////////////////////////////////////////////
void SyncpropertiesWidget::hideWindow(){
  this->hide();

}
//////////////////////////////////////////////////////////////////////
void SyncpropertiesWidget::saveCronTask(QString s){
	if(s.indexOf("\n")==0)	s=s.mid(1);
	QString tmpFile=QDir::homePath()+"/.smesynccenter_tmp.cron";
	tmpFile.replace(QString("//"), QString("/"));

//debug("saveCronTask("+s+")");
//return ;

        QByteArray tmName=tmpFile.toUtf8();
        if(localeEncoding!=""){
                QTextCodec *codec = QTextCodec::codecForName(localeEncoding.toUtf8().data());
                tmName = codec->fromUnicode(tmpFile);
        }else{
                tmName = tmpFile.toUtf8();
        }

        FILE * pFile;
        pFile=fopen(tmName.data(), "w");
        if(!pFile && localeEncoding!=""){		// try to use UTF-8 name
                tmName = tmpFile.toUtf8();
                pFile=fopen(tmName.data(), "w");
        }

        if(pFile!=NULL){
            fputs(s.toUtf8().data(), pFile);
            fclose(pFile);

            s=runCommand("crontab -r");
            s=runCommand("crontab "+tmName);
        }
        QFile fl(tmpFile);
	fl.remove();
}
//////////////////////////////////////////////////////////////////////
void SyncpropertiesWidget::removeSmeFromCronTasks(){
	QString s=getCronTasks(false, false);
debug("s = "+s+";");
	this->saveCronTask(s);
}
//////////////////////////////////////////////////////////////////////
QString SyncpropertiesWidget::getCronTasks(bool withSme, bool onlySme, int needCheckForOldVersion){
	QString com="crontab -l";
	QString r=this->runCommand(com);
	QString r0="";

	if(needCheckForOldVersion && r.lastIndexOf("/usr/local/bin/SMESyncCenter --hidden")>-1 && r.lastIndexOf("/usr/bin/smesynccenter --hidden")<=-1){	// It is cron task from old version
		r.replace("/usr/local/bin/SMESyncCenter --hidden", "/usr/bin/smesynccenter --hidden");	
		saveCronTask(r);
		return getCronTasks(withSme, onlySme, 0);
	}


	int ss1=-1;
	if(r.lastIndexOf("\n")!=r.length()-1)	r=r+"\n";

	if(r.indexOf("# DO NOT EDIT THIS FILE")==0){
		ss1=r.indexOf("\n");
		if(ss1>0)	r=r.mid(ss1+1);

		if(r.indexOf("# (")==0){
			ss1=r.indexOf("\n");
			if(ss1>0)	r=r.mid(ss1+1);

			if(r.indexOf("# (Cron version")==0){
				ss1=r.indexOf("\n");
				if(ss1>0)	r=r.mid(ss1+1);
			}
		}
	}

	if(withSme && !onlySme) return r;
	int s=r.indexOf("smesynccenter ");
	if(s>0){
		QString r1=r.mid(0, s);
		QString r2=r.mid(s, r.length()-s);
		int s1=r1.lastIndexOf("\n");
		if(s1>0){
			r =r1.mid(0, s1);
			r0=r1.mid(s1);
		}else{
			r ="";
			r0=r1;
		}

		s1=r2.indexOf("\n");
		if(s1>0){
			r.append(r2.mid(s1+1));
			r0.append(r2.mid(0, s1));
		}else{
			r0.append(r2);
		}

//debug("r1 = "+r1+";");
//debug("r2 = "+r2+";");
	}

	cronTaskExists=false;
	if(r0.length()>1 && r0.indexOf("--hidden")>0)	cronTaskExists=true;

debug("r = "+r+";");
debug("r0= "+r0+";");

	if(r.lastIndexOf("\n")!=r.length()-1)	r=r+"\n";
	if(onlySme) return r0;
	if(!withSme) return r;
	return "";
}
//////////////////////////////////////////////////////////////////////
void SyncpropertiesWidget::initWnd(){
	ui->lineEdit1->setText(login);
	ui->lineEdit2->setText(password);
	QLineEdit *edit=ui->comboBox0->lineEdit();
	edit->setText(server);

	if(versionType==1){
      int windowW=693, windowH=515;
		setGeometry(QRect(0, 0, windowW, windowH));
		resizeEvent(NULL);
		ui->lineEdit4->setText(encryptPassword);
	}else{
      int windowW=693, windowH=491;
		setGeometry(QRect(0, 0, windowW, windowH));
		resizeEvent(NULL);
		ui->lineEdit4->setText(QString(""));
	}

	if(showLogAfterQuickSync){
		ui->checkBox3->setCheckState(Qt::Checked);
	}else{
		ui->checkBox3->setCheckState(Qt::Unchecked);
	}

	if(extendedLogs){
		ui->checkBox4->setCheckState(Qt::Checked);
	}else{
		ui->checkBox4->setCheckState(Qt::Unchecked);
	}

	if(deleteFromServerWhenDeletedFromLocal){
		ui->checkBox5->setCheckState(Qt::Checked);
	}else{
		ui->checkBox5->setCheckState(Qt::Unchecked);
	}

	if(deleteFromLocalWhenDeletedFromServer){
		ui->checkBox6->setCheckState(Qt::Checked);
	}else{
		ui->checkBox6->setCheckState(Qt::Unchecked);
	}

   if(showNotifyAfterScheduledSync){
      ui->checkBox8->setCheckState(Qt::Checked);
   }else{
      ui->checkBox8->setCheckState(Qt::Unchecked);
   }

	ui->lineEdit5->setText(proxyhost);
	ui->lineEdit6->setText(intToQstring(proxyport));
	ui->lineEdit7->setText(proxylogin);
	ui->lineEdit8->setText(proxypass);

	if(useProxy){
		ui->checkBox7->setCheckState(Qt::Checked);
	}else{
		ui->checkBox7->setCheckState(Qt::Unchecked);
	}
	ui->groupBox2->setEnabled(useProxy);

	// Schedule options
	QString r0 = "";
	if(scheduleOptions!="" && scheduleSyncType>0){
		// New way
		r0 = scheduleOptions;
		if(scheduleSyncType==1){			// scheduleSyncType - 1-syncall, 2-syncup, 3-syncdown, 4-cloneup, 5-clonedown
			ui->radio1->setChecked(true);
		}else if(scheduleSyncType==3){
			ui->radio2->setChecked(true);
		}else if(scheduleSyncType==2){
			ui->radio3->setChecked(true);
		}else if(scheduleSyncType==5){
			ui->radio4->setChecked(true);
		}else if(scheduleSyncType==4){
			ui->radio5->setChecked(true);
		}

	}else{
		// We are using this block only for compatibility with old versions
		r0=getCronTasks(false, true);
//debug("initWND => r0 = "+r0+";");
		if(r0.length()>1 && r0.indexOf("--hidden")>0){
			if(r0.indexOf("--syncall")>0){
				ui->radio1->setChecked(true);
			}else if(r0.indexOf("--syncdown")>0){
				ui->radio2->setChecked(true);
			}else if(r0.indexOf("--syncup")>0){
				ui->radio3->setChecked(true);
			}else if(r0.indexOf("--clonedown")>0){
				ui->radio4->setChecked(true);
			}else if(r0.indexOf("--cloneup")>0){
				ui->radio5->setChecked(true);
			}
			r0=r0.mid(0, r0.indexOf("smesynccenter "));
		}else{
			r0 = "";
		}
	}

	if(r0!=""){
		r0=" "+ r0 +" ";
		r0.replace(QString("   "), QString(" "));
		r0.replace(QString("  "), QString(" "));
		int j=0;
		int L=0;
		for(int m=-1; L==0 && j<10; j++){
			m=r0.indexOf(" ", m+1);
			if(m<0) L=1;
//debug("m = "+intToQstring(m)+"; ");
		}

		if(j>=7){
			QString smin=getPart(r0, " ", " ");
			r0=r0.mid(r0.indexOf(" ", 1));
			QString shour=getPart(r0, " ", " ");
			r0=r0.mid(r0.indexOf(" ", 1));
			QString smday=getPart(r0, " ", " ");
			r0=r0.mid(r0.indexOf(" ", 1));
			QString smonth=getPart(r0, " ", " ");
			r0=r0.mid(r0.indexOf(" ", 1));
			QString swday=getPart(r0, " ", " ");

//debug("smin = "+smin+"; "+"shour = "+shour+"; "+"smday = "+smday+"; "+"smonth = "+smonth+"; "+"swday = "+swday+"; ");
			int tm=0;
			if(smin.length()>0 && shour.length()>0 && smday.length()>0 && smonth.length()>0 && swday.length()>0){
				if(smin=="*"){
					ui->comboBox4->setCurrentIndex(0);
				}else if(smin.indexOf("*/")>-1){
					smin=smin.mid(2);
					tm=smin.toInt();
					if(tm>=0 && tm<=59) ui->comboBox4->setCurrentIndex(tm+59);
				}else{
					tm=smin.toInt();
					if(tm>=0 && tm<=59) ui->comboBox4->setCurrentIndex(tm+1);
				}

				if(shour=="*"){
					ui->comboBox3->setCurrentIndex(0);
				}else if(shour.indexOf("*/")>-1){
					shour=shour.mid(2);
					tm=shour.toInt();
					if(tm>=0 && tm<=23) ui->comboBox3->setCurrentIndex(tm+23);
				}else{
					tm=shour.toInt();
					if(tm>=0 && tm<=23) ui->comboBox3->setCurrentIndex(tm+1);
				}

				if(smonth=="*"){
					ui->comboBox1->setCurrentIndex(0);
				}else if(smonth.indexOf("*/")>-1){
					smonth=smonth.mid(2);
					tm=smonth.toInt();
					if(tm>=1 && tm<=12) ui->comboBox1->setCurrentIndex(tm+11);
				}else{
					tm=smonth.toInt();
					if(tm>=1 && tm<=12) ui->comboBox1->setCurrentIndex(tm);
				}

				if(smday!="*" && swday=="*"){
					if(smday.indexOf("*/")<0){
						tm=smday.toInt();
						if(tm>=1 && tm<=31) ui->comboBox2->setCurrentIndex(tm+7);
					}else{
						smday=smday.mid(2);
						tm=smday.toInt();
						if(tm>=0 && tm<=31) ui->comboBox2->setCurrentIndex(tm+37);
					}
				}else if(swday!="*"){
					tm=swday.toInt();
					if(tm>=0 && tm<=6) ui->comboBox2->setCurrentIndex(tm+1);
				}else{
					ui->comboBox2->setCurrentIndex(0);
				}

				ui->checkBox1->setCheckState(Qt::Checked);
			}
//debug("shour="+shour+";");
//return ;
		}
	}

	checkBox1StateChanged(0);
//debug("r = "+r+";");

	repaint();
}
//////////////////////////////////////////////////////////////////////
QString SyncpropertiesWidget::getPart(QString q, QString s1, QString s2){
	int s=q.indexOf(s1);
	int e=q.indexOf(s2, s+s1.length());
	if(s>-1 && s>-1 && s<e){
		return q.mid(s+s1.length(), e-s-s1.length());
	}else{
		return "";
	}

}
//////////////////////////////////////////////////////////////////////
QString SyncpropertiesWidget::runCommand(QString command){
	QString cmdQSt=command;
	int stimeout=300;		// msec
	int maxtimeout=30*1000;	// msec
	int nn0=2000000;
	char buf[nn0];
//  char bufp;

	QString buf2="";
	FILE *ptr;

	for(int i=0; i<nn0; i++){
		buf[i]=' ';
	}

	debug(cmdQSt);
        ptr =popen(cmdQSt.toUtf8().data(), "r");
	int ptrd =fileno(ptr);
	fcntl(ptrd, F_SETFL, O_NONBLOCK);
	ssize_t r =read(ptrd, buf, nn0);
	int k=0;
	while(r==-1){
		if(k*stimeout>maxtimeout)	return "";
		Cqthread::msleep(stimeout);
		r=read(ptrd, buf, nn0);
		k++;
	}

	for(int c=0; c<r; c++){
//	buf2.append(QString::fromUtf8(buf[c]));
		buf2.append(buf[c]);
	}

//	QString s_utf8=QString::fromUtf8(buf);
//	buf2.append(s_utf8);

	debug("buf2 = > "+ buf2);

	return buf2;
}
//////////////////////////////////////////////////////////////////////
void SyncpropertiesWidget::debug(QString s, int level){
        if(level<=DEBUG) printf("%s\n", s.toUtf8().data());
}
//////////////////////////////////////////////////////////////////////
void SyncpropertiesWidget::resizeEvent(QResizeEvent *e){
	int w=width(), h=height();

	int fontSize=12;
	if(ui->radio1->font().pixelSize()>8){
		fontSize=ui->radio1->font().pixelSize();
	}else if(ui->radio1->font().pointSize()>7){
		fontSize=(int) (ui->radio1->font().pointSize()*1.3);
	}

	ui->scrollArea2->setGeometry(QRect(0, 0, w, h));
	if(w<693) w=693;		// minimum width
	h=520+fontSize*10;		// height is fixed
	if(versionType==0){
		h-=29;
	}
	ui->widget->setGeometry(QRect(1, 0, w-20, h));
	w=w-20;
	int left=6;
	int h1=17, hh=0, hTextEdit=h1+7;
	int p=15;
	int w1=(int) (w/3), wTextEdit=w-w1-2*left-5, leftTextEdit=left+w1+5;
	int sh=10, hCB=20;

	if(fontSize>15) hCB+=(int) (fontSize-15)/1.5;
	if(fontSize>14) hh=fontSize-14;
	if(fontSize>14) hTextEdit+=4;

	ui->textLabel0->setGeometry(QRect(left, sh-3, w1, h1+hh));
	ui->comboBox0->setGeometry(QRect(leftTextEdit, sh-8, wTextEdit, hTextEdit));
	sh+=p+h1-3;
	ui->textLabel1->setGeometry(QRect(left, sh-3, w1, h1+hh));
	ui->lineEdit1->setGeometry(QRect(leftTextEdit, sh-8, wTextEdit, hTextEdit));
	sh+=p+h1-3;
	ui->textLabel2->setGeometry(QRect(left, sh-3, w1, h1+hh));
	ui->lineEdit2->setGeometry(QRect(leftTextEdit, sh-8, wTextEdit, hTextEdit));


	if(versionType==1){
		sh+=p+h1-3;
		ui->textLabel9->setGeometry(QRect(left, sh-3, w1, h1+hh));
		ui->lineEdit4->setGeometry(QRect(leftTextEdit, sh-8, wTextEdit, hTextEdit));
		ui->textLabel9->setVisible(true);
		ui->lineEdit4->setVisible(true);
	}else{
		ui->textLabel9->setVisible(false);
		ui->lineEdit4->setVisible(false);
	}

	sh+=p+h1-12;
	ui->checkBox8->setGeometry(QRect(left, sh, w-left*2, hCB));
	sh+=hCB;
	ui->checkBox3->setGeometry(QRect(left, sh, w-left*2, hCB));
	sh+=hCB;
	ui->checkBox4->setGeometry(QRect(left, sh, w-left*2, hCB));
	sh+=hCB;
	ui->checkBox5->setGeometry(QRect(left, sh, w-left*2, hCB));
	sh+=hCB;
	ui->checkBox6->setGeometry(QRect(left, sh, w-left*2, hCB));
	sh+=hCB;
	ui->checkBox1->setGeometry(QRect(left, sh, w-left*2, hCB));
	sh+=hCB+1;

//	ui->groupBox->setGeometry(QRect(26, sh, w-31, h-450+213));
//	ui->groupBox->setGeometry(QRect(26, sh, w-31, h-sh-32));

	int hGB=129+fontSize*8, hGB2=69+fontSize*5;
	ui->groupBox->setGeometry(QRect(26, sh, w-31, hGB-30));
	sh+=hGB+5-30;
//	int bh=168+h-450+247+5;

	ui->checkBox7->setGeometry(QRect(left, sh, w-left*2, hCB));
	sh+=hCB+1;
	ui->groupBox2->setGeometry(QRect(26, sh, w-31, hGB2));
	sh+=hGB2+9;


	ui->pushButton1->setGeometry(QRect(26, sh, 100, 29));
	ui->pushButton2->setGeometry(QRect(26+145, sh, 100, 29));

	int sh2=20, left2=6, w2=350, d2=2;
	int sh3=25, w3=175;
	//int left3=left2+w2+20;
	//int left31=left3+w3+12;
	int left31=left2+w2+10, left3=left31+55, d3=9;

	//w3=(int) ((w-25)/4);
	//left31=w-w3*2+30;
	//left3=left31+90;

	left31=w-285;
	left3=left31+75;

	ui->textLabel4->setGeometry(QRect(left31-5, sh3, w3, h1));
	sh3+=h1+d3;

	ui->comboBox1->setGeometry(QRect(left3, sh3-2, w3, h1+5));
	ui->textLabel5->setGeometry(QRect(left31, sh3, w3, h1+2));
	sh3+=h1+d3;

	ui->comboBox2->setGeometry(QRect(left3, sh3-2, w3, h1+5));
	ui->textLabel6->setGeometry(QRect(left31, sh3, w3, h1+2));
	sh3+=h1+d3;

	ui->comboBox3->setGeometry(QRect(left3, sh3-2, w3, h1+5));
	ui->textLabel7->setGeometry(QRect(left31, sh3, w3, h1+2));
	sh3+=h1+d3;

	ui->comboBox4->setGeometry(QRect(left3, sh3-2, w3, h1+5));
	ui->textLabel8->setGeometry(QRect(left31, sh3, w3, h1+2));
	sh3+=h1+d3;

	w2=w-sh3*2-20;
	sh2=20;
	h1+=fontSize-12;
	ui->radio1->setGeometry(QRect(left2, sh2, w2, h1));
	sh2+=h1+d2;
	ui->radio2->setGeometry(QRect(left2, sh2, w2, h1));
	sh2+=h1+d2;
	ui->radio3->setGeometry(QRect(left2, sh2, w2, h1));
	sh2+=h1+d2;
	ui->radio4->setGeometry(QRect(left2, sh2, w2, h1*2));
	sh2+=h1*2+d2;
	ui->radio5->setGeometry(QRect(left2, sh2, w2, h1*2));
	sh2+=h1*2+d2+4;
	ui->pushButton4->setGeometry(QRect(left2, sh2, 100, h1+5));
	ui->pushButton5->setGeometry(QRect(left2+135, sh2, 100, h1+5));

	w3=int(w/2)-20;
	left3=5;
	left31=left3+w3+3;

	sh3=25;
	ui->textLabel10->setGeometry(QRect(left3, sh3, w3, h1+2));
	ui->lineEdit5->setGeometry(QRect(left31, sh3-2, w3, h1+5));
	sh3+=h1+d3;

	ui->textLabel11->setGeometry(QRect(left3, sh3, w3, h1+2));
	ui->lineEdit6->setGeometry(QRect(left31, sh3-2, 75, h1+5));
	sh3+=h1+d3;

	ui->textLabel12->setGeometry(QRect(left3, sh3, w3, h1+2));
	ui->lineEdit7->setGeometry(QRect(left31, sh3-2, w3, h1+5));
	sh3+=h1+d3;

	ui->textLabel13->setGeometry(QRect(left3, sh3, w3, h1+2));
	ui->lineEdit8->setGeometry(QRect(left31, sh3-2, w3, h1+5));
	sh3+=h1+d3;

	QWidget::resizeEvent(e);
}
//////////////////////////////////////////////////////////////////////
void SyncpropertiesWidget::keyPressEvent(QKeyEvent *event){
	int key=event->key();
	if(key==Qt::Key_Enter || key==Qt::Key_Return){
		saveProperties();
	}else if(key==Qt::Key_Escape){
		hideWindow();
	}

}
//////////////////////////////////////////////////////////////////////


