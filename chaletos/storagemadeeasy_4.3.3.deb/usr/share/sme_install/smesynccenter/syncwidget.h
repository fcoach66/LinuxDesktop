#ifndef SYNCWIDGET_H
#define SYNCWIDGET_H

#include <QtGui/QWidget>
#include <QtGui/QSystemTrayIcon>
#include <QMenuBar>
#include <QtNetwork/QHttp>
#include <QtNetwork/QHttpRequestHeader>
#include <QtNetwork/QNetworkAccessManager>
#include <QtNetwork/QNetworkReply>
#include <QDomNode>
#include <QNetworkProxy>
#include <QSslConfiguration>
#include <QSslCipher>
#include <QSslSocket>

#include "fileclass.h"
#include "syncpropertieswidget.h"
#include "providerlogwidget.h"
#include "messagewnd.h"
#include "linkfolderswidget.h"

#undef signals						//IgnoreOnCentOS
extern "C" {		// For AppIndicator	//IgnoreOnCentOS
	#include <libappindicator/app-indicator.h>	//IgnoreOnCentOS
	#include <gtk/gtk.h>			//IgnoreOnCentOS
}                               		//IgnoreOnCentOS     
#define signals public				//IgnoreOnCentOS


namespace Ui
{
	class SyncWidget;
}


typedef struct {
	QString error;
	QList<FileClass> list;
} TFileClass;

typedef struct {
	QString error;
	FileClass file;
} TFileClass2;

typedef struct {
	int n;
} TRemove;

typedef struct {
	double id, lastid;
	QString filePath;
} TDeleteFile;

typedef struct {
	double id;
	bool addToFilelist;
   QString fullname, tmpfilename;
	QDateTime servertime;
	FileClass f;			// result
} TDownloadFile;

typedef struct {
	QString name;
	double pid;
	bool addToFilelist;
	QString path;
	FileClass f;			// result
} TUploadFile;

typedef struct {
	int SyncTaskId;
	bool filesListIsGet;
} TInitWnd;

typedef struct {
	QString name;
	double pid;
	bool addToFilelist;
	FileClass f;			// result
} TCreateFolder;

typedef struct {
	FILE *ptr;
	int error, response_maxProgress;
	QString response, restory, up_level_command, filepath;
	bool response_upload, response_download;
	QDateTime startTime;
} TRunCommand;

typedef struct {
   bool running, isPost;
   int error;
   QString response, uri, postData, up_level_command, restory, restory2;
} TrunFunction;

typedef struct {
   int statusCode;
   QString response, error;
} TrunFunction3;

typedef struct {
   int error;
   QString errorMessage;
	FileClass f;
} TUploadResponse;

typedef struct {
   int error;
   QString errorMessage;
} TDownloadResponse;

typedef struct {
	QString uri;
	bool isPost;
	QString postData;
} TgetToken;

typedef struct {
	QString folderid;
	QString sfolderid, lfolderpath, serverfoldername;
	bool needShowFileslist;
} TlinkFolders;

class SyncWidget : public QWidget
{
    Q_OBJECT

	public:
    SyncWidget(QWidget *parent = 0);
    ~SyncWidget();

		QAction *aRefresh, *aSyncAll, *aSyncUp, *aSyncDown, *aCloneUp, *aCloneDown, *aAddSyncPair, *aRemoveSyncPair, *aExpandAll, *aHideSynced, *aProperties, *aShowSchedulerLog, *aClearSchedulerLog, *aLogout, *aPause, *aQuit;
		GtkWidget *AppIndicatorPauseItem;			//IgnoreOnCentOS

		SyncpropertiesWidget propertiesWnd;
		ProviderlogWidget providerlog;			// window for enter provider login and password
		MessageWnd messageWnd;
		LinkFoldersWidget linkFoldersWnd;
//		shared_stuff_p shareArea;

		bool isHidden, isService, needCheckforoldversion, isPaused, isQuitPressed;
		int needRunSync, scheduleSyncType;	// scheduleSyncType - 1-syncall, 2-syncup, 3-syncdown, 4-cloneup, 5-clonedown

		bool isLoadedFilesList, isInited;
		QString scheduleOptions;
		FileClass *filelist;
		QString token, tmptoken, tmptoken2, encryptionKeyForPassword;
		QDateTime timeTokenLastUpdate;
		int maxCount, typeOfTrayIcon;
		QString login, password, passwordEncrypted, providerLogin, providerPassword, logFileName, serverHost, serverAPI, encryptionPhrase, localeEncoding;
		bool needShowLogAfterQuickSync, deleteFromLocalWhenDeletedFromServer, deleteFromServerWhenDeletedFromLocal;
//		QHttp *http;
		QNetworkAccessManager *http;

		QString proxyhost, proxylogin, proxypass;
		int proxyport;
		bool useProxy;

		TRunCommand SRunCommand;
		TCreateFolder SCreateFolder;
		TInitWnd SInitWnd;
		TUploadFile SUploadFile;
		TDeleteFile SDeleteFile;
		TDownloadFile SDownloadFile;
		TRemove SRemove;
		TrunFunction SrunFunction;
		TgetToken SgetToken;
		TlinkFolders SlinkFolders;

		int DEBUG, nResize, gmt_offset, versionType, countOpeningFolders;		// countOpeningFolders - this is count of folders that is opening now
		QString lastDir, fCnfName, oldFilesList;
		QList<FileClass> addFoldersList;
		bool isCanceledAction, restartSync, needHideSynced, showNotifyAfterScheduledSync, isPreparedToSync, isSyncInProcess, isRunning, canPasswordBeEncrypted;
		QString pathToIcons, logs;
		int countUploaded, countDownloaded, countDeletedFromLocal, countDeletedFromServer, detailedLogs;
		int wx, wy, ww, wh;
		QSslSocket *uploadSocket, *downloadSocket;

		QList<FileClass> cacheOfOldServerFilelist;
		double getIdFromOldServerFilelist(FileClass f, bool useCache=false);

		void showMessage(QString m, bool showButtonCancel=false, bool showProgressBar=false, bool ignoreCancel=false);
		void hideMessage();
		void clearLogs();
		QString getPathByFile(double id, QString path, bool onLocal);
		QString getLoginAndPasswordForCMD();

		void msleep(int msec);
		QString charToQstring(char* n);
		void debug(QString s, int level=5);
		QDateTime toUTC(QDateTime t);
		QDateTime toLocal(QDateTime t, int d=0);
		bool isRunningAnotherWnd(bool checkForCronOnly=false, bool onlyForCurrentUser=false);
		bool isRunningSomething(bool prepareToRun=true);
		int configureScheduleSync(bool startNow=false);

		void start();
		void preparingToSync();
		QString getPath(QString fullname, bool returnSL=false);
		bool shouldWeStartSync();

		FileClass createNewNode(QString folderName, QString fullname, double id, double pid, int type, int existsOnServer, int existsOnLocal, QDateTime localdate, QDateTime serverdate, QTreeWidgetItem *pnode=NULL, bool rootNode=false, QString serverfolderName="", bool createEmptyItem=false);
		FileClass editNode(QString folderName, QString fullname, double id, double pid, int type, int existsOnServer, int existsOnLocal, QDateTime localdate, QDateTime serverdate, QTreeWidgetItem *pnode=NULL, bool rootNode=false, int c=-1, QString serverfolderName="");  // c - number in filelist array

		FileClass* getFolderTree(QString folder="", QString fname="", double folderId=-1);
		void showFoldersTree(FileClass* ress, QTreeWidgetItem *pnode=NULL, bool rootNode=false);
		QList<FileClass> getLocalFolder(QString folder, bool includeSubfolders=false);
		FileClass* getServerFolder(double id, bool includeSubfolders=false, int countEmpty=2);
		QList<FileClass> getServerFolderRec(double id);

		QString getEncryptionKeyForPassword();
		QString encryptSMEPassword(QString password);
		QString decryptSMEPassword(QString password);

		bool removeNodeAndAllChild(QTreeWidgetItem *node, bool removeFileFromServer=false, bool removeFileFromLocal=false, bool deleteCurrentNode=false);

		QString getToken();
		void getToken2();
      bool setProviderData2();      // return true if Provider Data is success set.
      bool getProviderLoginAndPassword2(bool calledFrom2=false);
		TFileClass2 getFileFullInfo2(QString id);
		FileClass getFileFromDomNode(QDomNode n, double p_id=-1);
		TFileClass getFolderContents(QString folderid, int from=0);
		bool deleteFile3(double id, QString fullname, bool fromServer, bool fromLocal, int type);
		bool deleteFile(double id, QString fullname, bool fromServer, bool fromLocal, int type);
		void updateTrayMenu(bool enablePauseItem);

		// This MAIN function that get files list from server and compare it with local files list. It returns list of files than need to add to tree
		TFileClass compareLocalAndServerFolder(QString folder, QString fname, double folderId);

      void resume(int n);
		QList<FileClass> getOldFilesList(QString path, QString id, bool includeSubfolders=false, bool returnOnlyOneFile=false);
		void createFolder2(QString name, double pid, bool addToFilelist=true);
		void uploadFile2(QString name, QString path, double pid, double id, QDateTime localtime, bool addToFilelist=false);
		TUploadResponse doUploadFile(QString fileName, QString source, QString description, QString tags, QString fileID, QString pid, QString encryptionPhrase, QDateTime localtime);
		TDownloadResponse downloadFile(QString fullname, double id, QDateTime servertime, QDateTime oldTimestamp, bool addToFilelist=false);
		TDownloadResponse downloadFileToDisk(QString id, QString url, QString encryptionPhrase, QString localPath, QDateTime lastModify, QString name);


		QString runCommand(QString command, int maxProgress=0, bool upload=false, bool download=false, bool external=false);
		void runCommand2(QString command, int maxProgress=-1, bool upload=false, bool download=false);
      void runFunction(QString uri="", bool isPost=false, QString postData="");
		TrunFunction3 runFunction3(QString uri="", bool isPost=false, QString postData="", int attempt=0);
      int getCountFiles(FileClass *arr);
//		void getDefaultProvider();
//		void reSyncsProvider();

		// index - this is index of file in the array "filelist"
		int runSyncUp(QTreeWidgetItem *node, bool ignoreTime=false, int index=-1, bool ignoreDeleted=false);		
		int runSyncDown(QTreeWidgetItem *node, bool ignoreTime=false, int index=-1, bool ignoreDeleted=false);
		int runCloneUp(QTreeWidgetItem *node);
		int runCloneDown(QTreeWidgetItem *node);

		void openChildNodes(QTreeWidgetItem *node, bool state=true);
		void updateAllState(int n=-1);
		int updateState(QTreeWidgetItem *node, double folderId=-1, QString path="");		// return: 0 - none, 1 - up, 2 - down, 3 - need up or down sub folders
		void setStateIcon(QTreeWidgetItem *node, QIcon icon);
		int hideSynced(QTreeWidgetItem *node, bool hide=true);		// return: 0 - none, 1 - up, 2 - down, 3 - need up or down sub folders

		FileClass getFileByNode(QTreeWidgetItem *node);
		bool isRemovedOnServer(FileClass file, double pid);
		bool isRemovedOnServer(FileClass file, double pid, bool returnFilelists, QList<FileClass> &oldFilesList, QList<FileClass> &oldFilesListWithSubfolders);
		bool isRemovedOnLocal(FileClass file, QString folder);
		bool isRemovedOnLocal(FileClass file, QString folder, bool returnFilelists, QList<FileClass> &oldFilesList, QList<FileClass> &oldFilesListWithSubfolders);
		double getOldFolderId(FileClass f, double folderId);

		void setCheckStateAllChildNodes(QTreeWidgetItem *node, int state);		// state=0 - not checked, state=2 - checked
		QString getExtension(QString filename);
		QString getFileIcon(QString extension);
		QString getFolderIcon();
		void mainLoop();

		void loadConfig(bool checkForCron=false);
		void saveConfig(bool saveFoldersList=true);
		QString getNameOfUserConfigFile(QString alternativeServer="");
		void saveFilesListToFile(bool update=false);
		QString loadFilesListFromFile();

		void addToLog(QString s="", int level=0);
		int writeToFile(QString name, QString s);
		QString readFromFile(QString name);

		void refreshWnd(bool tree=false);
		void linkFolders();

		void setWindowPosition();
		void getWindowPosition();

		QSystemTrayIcon *trayIcon;
		void showTrayIcon();
		void exitWithMessage(QString mess);

      void getProviderLoginAndPassword(bool calledFrom2=false);
		bool getProviderLoginAndPassword_calledFrom2;
	private:
    Ui::SyncWidget *ui;
		virtual void resizeEvent(QResizeEvent * e);

	public
  slots:
		void slotSslErrors(QNetworkReply *reply, QList<QSslError> e0);
		void initWnd();
		void initWnd2();
		void setProviderDataResp();
		void setProviderData();

		void brefreshAll();
		void badd();
		void bremove();
		void bproperties();

		void bsyncAll();
		void bsyncUp();
		void bsyncDown();
		void bcloneUp();
		void bcloneDown();
		void syncAll();
		void syncUp();
		void syncDown();
		void cloneUp();
		void cloneDown();
		void changed(QTreeWidgetItem *node, int column);
		void refreshAll(bool clearAll=false);
		void properties();
		void saveProperties();
		void cancelAction();
		void openAll();
		void bhideSynced();
		void bPause();
		void bQuit();

		uint waitIfPaused();

		void saveProviderLog();
		void checkProviderLog();

		void runSync(QString folder, int sync, int clone, int includeSubDirs);			// sync=0 - not sync, sync=1 - sync all, sync=2 - sync up, sync=3 - sync down; clone=0 - not clone, clone=1 - clone up, clone=2 - clone down; includeSubDirs=0 - not include sub dirs, includeSubDirs=1 - include sub dirs
		void getTokenResp2();
		void createFolderResp();
//		void getDefaultProviderResp();
//		void reSyncsProviderResp();
//		void checkSyncsProvider(double id=-2);
//		void checkSyncsProviderResp();
		void uploadFileResp();
		void downloadFile2(QString fullname, double id, QDateTime servertime, bool addToFilelist=false);
		void downloadFileResp();

		void runCommandResponse2(int maxProgress=0, bool upload=false, bool download=false);
		void runFunctionResp(QNetworkReply* reply);

		void start2();
		void closeAllAndExit();
		void linkFoldersOSF(QString folderid, int from=0);
		void linkFoldersOSFResp();

		void linkAndAddtoTree(QString path="", QString id="", QString serverfoldername="", QString pid="");
		void openFolder(QTreeWidgetItem *item, bool useHideMessage=true);
		void showLogs(QString caption="", QString log="", QString filename="", bool nonModal=false);
		void clearLog();
		void logOut();
		void slotSslErrorsUpload(QList<QSslError> e0);
		void slotSslErrorsDownload(QList<QSslError> e0);
};



#endif // SYNCWIDGET_H
