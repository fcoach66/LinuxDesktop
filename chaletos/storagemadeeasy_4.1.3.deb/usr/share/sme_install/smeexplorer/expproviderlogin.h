#ifndef EXPPROVIDERLOGIN_H
#define EXPPROVIDERLOGIN_H

#include <QtGui/QWidget>
#include <QtGui/QLabel>
#include <QtGui/QCheckBox>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QWidget>
#include <Qt3Support/Q3MimeSourceFactory>
#include <QtGui/QMessageBox>
#include <QtGui/QCheckBox>
#include <QtGui/QKeyEvent>


typedef struct {
	QString id, title, ptype;
	QLabel *textLabel;
	QLineEdit *lineEdit;
	QCheckBox *checkBox;
} Tfield;

class ExpProviderLogin : public QWidget
{
    Q_OBJECT

public:
	ExpProviderLogin(QWidget *parent = 0);
	~ExpProviderLogin();
	void clear();
	void clear2();
	void initWnd();
	int addField(QString id, QString label, QString dafaultvalue, QString ptype, int y);

	bool addProvider;
	QString fieldsres;
	int countF;
	Tfield *fields;
	QWidget *widget1;
	QPushButton *pushButton1, *pushButton2;

public
  slots:
    void bOK();
    void hideWindow();

  signals:
    void baddProvider();
    void OK();

private:
	virtual void keyPressEvent(QKeyEvent * event);
	virtual void resizeEvent(QResizeEvent * e);

};

#endif // EXPPROVIDERLOGIN_H
