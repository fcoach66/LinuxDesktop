#include "stdio.h"
#include "expaddprovider.h"

ExpAddProvider::ExpAddProvider(QWidget *parent) : QWidget(parent){
	widget1 = new QWidget(this);
	widget1->setGeometry(QRect(0, 0, 300, 350));
	this->setWindowTitle("Allowed Cloud Providers (for your account)");
	this->setWindowIcon(QIcon("/usr/share/pixmaps/sme_explorer_icon_42.png"));
   widget1->setObjectName(QString::fromUtf8("widget1"));

	countP=0;
	prid="";
	int x1=5, dy=10, y=5;

	prList=new QListWidget(widget1);
	prList->setGeometry(QRect(x1, y, 290, 260));
	QFont font1=prList->font();
	font1.setPointSize(9);
	prList->setFont(font1);
	prList->setSortingEnabled(true);
	y+=dy+260;

	pushButton1 = new QPushButton(widget1);
	pushButton1->setObjectName(QString::fromUtf8("pushButton1"));
	pushButton1->setGeometry(QRect(10, y, 85, 29));
	pushButton1->setText("Add");
	pushButton2 = new QPushButton(widget1);
	pushButton2->setObjectName(QString::fromUtf8("pushButton2"));
	pushButton2->setGeometry(QRect(116, y, 85, 29));
	pushButton2->setText("Cancel");

	QObject::connect(pushButton1, SIGNAL(clicked()), this, SLOT(bgetProviderMetaFields()));
	QObject::connect(pushButton2, SIGNAL(clicked()), this, SLOT(hideWindow()));
}
//////////////////////////////////////////////////////////////////////
ExpAddProvider::~ExpAddProvider(){
}
//////////////////////////////////////////////////////////////////////
void ExpAddProvider::hideWindow(){
	clear2();
	this->hide();
}
//////////////////////////////////////////////////////////////////////
void ExpAddProvider::clear2(){
printf("clear2()\n");
	if(countP>0){
		for(int i=countP-1; i>=0; i--){
			if(providers[i].name!=""){
				providers[i].name="";
				delete providers[i].node;
			}
		}

		delete []providers;
		countP=0;
	}

	return ;
}
//////////////////////////////////////////////////////////////////////
void ExpAddProvider::clear(){
printf("clear()\n");
	clear2();
	prid="";
	countP=0;
	int maxCount=2000;
	providers=new TAddProvider[maxCount];
	for(int i=0; i<maxCount; i++){
		providers[i].id="";
		providers[i].name="";
	}

}
//////////////////////////////////////////////////////////////////////
void ExpAddProvider::initWnd(){

}
//////////////////////////////////////////////////////////////////////
bool ExpAddProvider::addToTree(QString id, QString name){
printf("addToTree()\n");
	TAddProvider elem;
	elem.id=id;
	elem.name=name;
	providers[countP]=elem;
	providers[countP].node=new QListWidgetItem(QIcon("/usr/share/smeclient/exp/rule.gif"), elem.name);
	providers[countP].node->setToolTip(elem.name);		// hint
	prList->insertItem(countP, providers[countP].node);
	countP++;

	return true;
}
//////////////////////////////////////////////////////////////////////
void ExpAddProvider::bgetProviderMetaFields(){
	if(countP<1) return ;
	for(int i=0; i<countP; i++){
		if(providers[i].name!="" && providers[i].node->isSelected()){
			prid=providers[i].id;
			emit getProviderMetaFields();
			hide();
			return ;
		}
	}

	return ;
}
//////////////////////////////////////////////////////////////////////
void ExpAddProvider::resizeEvent(QResizeEvent *e){
	int w=width(), h=height();
	if(e){}

	widget1->setGeometry(QRect(0, 0, w, h));
	prList->setGeometry(QRect(5, 6, w-10, h-49));
	pushButton1->setGeometry(QRect(10, h-33, 85, 29));
	pushButton2->setGeometry(QRect(116, h-33, 85, 29));
	return ;
}
//////////////////////////////////////////////////////////////////////
void ExpAddProvider::keyPressEvent(QKeyEvent *event){
	int key=event->key();
	if(key==Qt::Key_Escape){
		hideWindow();
	}else if(key==Qt::Key_Enter || key==Qt::Key_Return){
		bgetProviderMetaFields();
	}

}
//////////////////////////////////////////////////////////////////////



