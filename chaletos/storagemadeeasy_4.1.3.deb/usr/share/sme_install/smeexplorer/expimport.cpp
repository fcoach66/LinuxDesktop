#include "stdio.h"
#include "expimport.h"

ExpImport::ExpImport(QWidget *parent) : QWidget(parent){
	widget1 = new QWidget(this);
	widget1->setGeometry(QRect(0, 0, 500, 370));
	this->setWindowTitle("Import");
	this->setWindowIcon(QIcon("/usr/share/pixmaps/sme_explorer_icon_42.png"));
   widget1->setObjectName(QString::fromUtf8("widget1"));

	countP=0;
	countF=0;
	import=true;
	isLocked=false;
	foldername="";
	folderid="";
	providerid="";
	destinationId="";

	int x1=10, y1=18, y2=25;
	int dy=5, dx1=100, dx2=480;
	int y=10;

	textLabel1 = new QLabel(widget1);
	textLabel1->setObjectName(QString::fromUtf8("textLabel1"));
	textLabel1->setGeometry(QRect(x1, y, dx2, y1));
	textLabel1->setText("Destination Folder:");
	y+=y1+dy;
	lineEdit1 = new QLineEdit(widget1);
	lineEdit1->setObjectName(QString::fromUtf8("lineEdit1"));
	lineEdit1->setGeometry(QRect(x1, y-3, dx2, y2));
	lineEdit1->setReadOnly(true);
	comboBox1=new QComboBox(widget1);
	comboBox1->setGeometry(QRect(x1, y-3, dx2, y2));
	y+=y1+dy+11;

	comboBox1->insertItem(0, "All Folders and Files");
	comboBox1->insertItem(1, "Selected Folders");
	comboBox1->insertItem(2, "Selected Files");

	textLabel2 = new QLabel(widget1);
	textLabel2->setObjectName(QString::fromUtf8("textLabel2"));
	textLabel2->setGeometry(QRect(x1, y, dx1+30, y1));
	textLabel2->setText("Source Provider:");
	textLabel3 = new QLabel(widget1);
	textLabel3->setObjectName(QString::fromUtf8("textLabel3"));
	textLabel3->setGeometry(QRect(x1+190, y, dx1+30, y1));
	textLabel3->setText("Source Folders:");
	y+=y1+dy-2;

	prList=new QListWidget(widget1);
	prList->setGeometry(QRect(x1, y, 180, 240));
	QFont font1=prList->font();
	font1.setPointSize(9);
	prList->setFont(font1);

	dirList=new QListWidget(widget1);
	dirList->setGeometry(QRect(x1+190, y, 290, 240));
	dirList->setFont(font1);
	y+=dy+240+5;


	pushButton1 = new QPushButton(widget1);
	pushButton1->setObjectName(QString::fromUtf8("pushButton1"));
	pushButton1->setGeometry(QRect(10, y, 85, 29));
	pushButton1->setText("Import");
	pushButton2 = new QPushButton(widget1);
	pushButton2->setObjectName(QString::fromUtf8("pushButton2"));
	pushButton2->setGeometry(QRect(116, y, 85, 29));
	pushButton2->setText("Cancel");


	QObject::connect(prList, SIGNAL(itemSelectionChanged()), this, SLOT(getProviderMetaFields()));
	QObject::connect(pushButton1, SIGNAL(clicked()), this, SLOT(bimport()));
	QObject::connect(pushButton2, SIGNAL(clicked()), this, SLOT(hideWindow()));
}
//////////////////////////////////////////////////////////////////////
ExpImport::~ExpImport(){
}
//////////////////////////////////////////////////////////////////////
void ExpImport::bimport(){
printf("bimport()\n");
	if(isLocked) return ;
	lockAll();

	for(int i=0; i<countF; i++){
		if(folders[i].node->isSelected()){
			destinationId=folders[i].id;
			if(import){
				emit bImport();
			}else{
				emit bExport();
			}

			return ;
		}
	}

	unlockAll();
}
//////////////////////////////////////////////////////////////////////
void ExpImport::hideWindow(){
	if(isLocked) return ;
	clear2();
	this->hide();
}
//////////////////////////////////////////////////////////////////////
void ExpImport::clear2(){
printf("clear2()\n");
	lockAll();
	if(countP>0){
		for(int i=countP-1; i>=0; i--){
			if(providers[i].name!=""){
				providers[i].name="";
				delete providers[i].node;
			}
		}

		delete []providers;
		countP=0;
	}

	if(countF>0){
		for(int i=countF-1; i>=0; i--){
			if(folders[i].name!=""){
				folders[i].name="";
				delete folders[i].node;
			}
		}

		delete []folders;
		countF=0;
	}
	unlockAll();

	return ;
}
//////////////////////////////////////////////////////////////////////
void ExpImport::clear(){
printf("clear()\n");
	clear2();
	foldername="";
	folderid="";
	providerid="";
	destinationId="";

	countP=0;
	int maxCount=2000;
	providers=new TProvider[maxCount];
	for(int i=0; i<maxCount; i++){
		providers[i].id="";
		providers[i].name="";
	}

	countF=0;
	int maxCount2=10000;
	folders=new TFolder[maxCount2];
	for(int i=0; i<maxCount2; i++){
		folders[i].id="";
		folders[i].name="";
	}

}
//////////////////////////////////////////////////////////////////////
void ExpImport::initWnd(){
	lineEdit1->setText(foldername);
	if(import){
		this->setWindowTitle("Import");
		pushButton1->setText("Import");
		comboBox1->hide();
		lineEdit1->show();
	}else{
		this->setWindowTitle("Export");
		pushButton1->setText("Export");
		comboBox1->show();
		lineEdit1->hide();
	}
}
//////////////////////////////////////////////////////////////////////
bool ExpImport::addToTree(QString id, QString name){
printf("addToTree()\n");
	TProvider elem;
	elem.id=id;
	elem.name=name;
	providers[countP]=elem;
	providers[countP].node=new QListWidgetItem(QIcon("/usr/share/smeclient/exp/rule.gif"), elem.name);
	providers[countP].node->setToolTip(elem.name);		// hint
	prList->insertItem(countP, providers[countP].node);
	countP++;

	prList->sortItems(Qt::AscendingOrder);

	return true;
}
//////////////////////////////////////////////////////////////////////
bool ExpImport::addFolderToTree(QString id, QString name){
printf("addFolderToTree()\n");
//	if(countF<0) countF=0;
	TFolder elem;
	elem.id=id;
	elem.name=name;
//printf("z folders[countF]=%s\n", folders[countF].name.toUtf8().data());

	folders[countF]=elem;
	folders[countF].node=new QListWidgetItem(QIcon("/usr/share/smeclient/exp/files/small/folder.gif"), elem.name);
	folders[countF].node->setToolTip(elem.name);		// hint
	dirList->insertItem(countF, folders[countF].node);
	countF++;

	return true;
}
//////////////////////////////////////////////////////////////////////
void ExpImport::getProviderMetaFields(){
	if(isLocked) return ;
	lockAll();
	if(countP<1) return ;
//printf("x13 countP=%d\n", countP);
	for(int i=0; i<countP; i++){
		if(providers[i].name!="" && providers[i].node->isSelected()){
			providerid=providers[i].id;
			if(countF>0){						// remove all folders
				for(int i=countF-1; i>=0; i--){
					if(folders[i].name!=""){
						folders[i].id="";
						folders[i].name="";
						delete folders[i].node;
					}
				}
//				delete []folders;
				countF=0;
			}
			emit importGetProviderMetaFields();
			return ;
		}
	}

	unlockAll();
	return ;
}
//////////////////////////////////////////////////////////////////////
void ExpImport::lockAll(){
	isLocked=true;
	prList->setSelectionMode(QAbstractItemView::NoSelection);
	dirList->setSelectionMode(QAbstractItemView::NoSelection);

	return ;
}
//////////////////////////////////////////////////////////////////////
void ExpImport::unlockAll(){
	isLocked=false;
	prList->setSelectionMode(QAbstractItemView::SingleSelection);
	dirList->setSelectionMode(QAbstractItemView::SingleSelection);

	return ;
}
//////////////////////////////////////////////////////////////////////
void ExpImport::resizeEvent(QResizeEvent *e){
	int w=width();
	int h=height();
	widget1->setGeometry(QRect(0, 0, w, h));
	if(e){}

	int x1=3, y1=19;
	int dx1=(int) (w/2.7-5), dx2=w-dx1-2*x1-10;
	textLabel2->setGeometry(QRect(x1, 67, dx1+5, y1));
	textLabel3->setGeometry(QRect(x1+dx1+10, 67, dx2+5, y1));

	prList->setGeometry(QRect(x1, 88, dx1, h-129));
	dirList->setGeometry(QRect(x1+dx1+10, 88, dx2, h-129));
	pushButton1->setGeometry(QRect(10, h-33, 100, 29));
	pushButton2->setGeometry(QRect(126, h-33, 100, 29));
	return ;
}
//////////////////////////////////////////////////////////////////////
void ExpImport::keyPressEvent(QKeyEvent *event){
	int key=event->key();
	if(key==Qt::Key_Escape){
		hideWindow();
	}else if(key==Qt::Key_Enter || key==Qt::Key_Return){
		bimport();
	}

}
//////////////////////////////////////////////////////////////////////



