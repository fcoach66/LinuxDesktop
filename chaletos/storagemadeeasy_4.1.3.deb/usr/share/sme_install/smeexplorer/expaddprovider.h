#ifndef EXPADDPROVIDER_H
#define EXPADDPROVIDER_H

#include <QtGui/QWidget>
#include <QtGui/QPushButton>
#include <QtGui/QWidget>
#include <Qt3Support/Q3MimeSourceFactory>
#include <QtGui/QMessageBox>
#include <QListWidget>
#include <QListWidgetItem>
#include <QModelIndex>
#include <QtGui/QKeyEvent>


typedef struct {
	QString id, name;
	QListWidgetItem *node;
} TAddProvider;

class ExpAddProvider : public QWidget
{
    Q_OBJECT

public:
	ExpAddProvider(QWidget *parent = 0);
	~ExpAddProvider();
	void clear();
	void clear2();
	void initWnd();
	bool addToTree(QString id, QString name);
	QString prid;

	int countP;
	TAddProvider *providers;

	QWidget *widget1;
	QPushButton *pushButton1, *pushButton2;
	QListWidget *prList;

private:
	virtual void resizeEvent(QResizeEvent * e);

public
  slots:
	void bgetProviderMetaFields();
	void hideWindow();

  signals:
	void getProviderMetaFields();

private:
	virtual void keyPressEvent(QKeyEvent * event);


};

#endif // EXPADDPROVIDER_H
