#include "stdio.h"
#include "expaddproviderbucket.h"

ExpAddProviderBucket::ExpAddProviderBucket(QWidget *parent) : QWidget(parent){
	widget1 = new QWidget(this);
	widget1->setGeometry(QRect(0, 0, 330, 123));
	this->setWindowTitle("Provider Bucket");
	this->setWindowIcon(QIcon("/usr/share/pixmaps/sme_explorer_icon_42.png"));
   widget1->setObjectName(QString::fromUtf8("widget1"));

	int x1=5, y1=18, y2=25;
	int dy=20, dx1=50, dx2=245;
	int x2=x1+dx1+20;
	int y=20;
	textLabel1 = new QLabel(widget1);
	textLabel1->setObjectName(QString::fromUtf8("textLabel1"));
	textLabel1->setGeometry(QRect(x1, y, dx1, y1));
	textLabel1->setText("Name:");
	lineEdit1 = new QLineEdit(widget1);
	lineEdit1->setObjectName(QString::fromUtf8("lineEdit1"));
	lineEdit1->setGeometry(QRect(x2, y-3, dx2, y2));
	y+=y1+dy-5;

	checkBox1=new QCheckBox("EU Location", widget1);
	checkBox1->setObjectName(QString::fromUtf8("checkBox"));
	checkBox1->setGeometry(QRect(x2, y, 300, y2));
	checkBox1->setCheckState(Qt::Unchecked);
	y+=y2+dy-10;

	pushButton1 = new QPushButton(widget1);
	pushButton1->setObjectName(QString::fromUtf8("pushButton1"));
	pushButton1->setGeometry(QRect(120, y, 85, 29));
	pushButton1->setText("OK");
	pushButton2 = new QPushButton(widget1);
	pushButton2->setObjectName(QString::fromUtf8("pushButton2"));
	pushButton2->setGeometry(QRect(226, y, 85, 29));
	pushButton2->setText("Cancel");

// Buttons
	QObject::connect(pushButton1, SIGNAL(clicked()), this, SLOT(bOK()));
	QObject::connect(pushButton2, SIGNAL(clicked()), this, SLOT(hideWindow()));
}
//////////////////////////////////////////////////////////////////////
ExpAddProviderBucket::~ExpAddProviderBucket(){
}
//////////////////////////////////////////////////////////////////////
void ExpAddProviderBucket::bOK(){
	bucketname=lineEdit1->text();
	if(bucketname.length()<1){
		QMessageBox::critical(this, "Error", "    Enter Name    ");
		return ;
	}

	if(checkBox1->checkState()==Qt::Checked){
		EULocation=true;
	}else{
		EULocation=false;
	}

	emit addBucket();
	this->hide();
}
//////////////////////////////////////////////////////////////////////
void ExpAddProviderBucket::hideWindow(){
  this->hide();
}
//////////////////////////////////////////////////////////////////////
void ExpAddProviderBucket::initWnd(){
	bucketname="";
	EULocation=false;
	lineEdit1->setText(bucketname);
	checkBox1->setCheckState(Qt::Unchecked);
}
//////////////////////////////////////////////////////////////////////
void ExpAddProviderBucket::keyPressEvent(QKeyEvent *event){
	int key=event->key();
	if(key==Qt::Key_Escape){
		hideWindow();
	}else if(key==Qt::Key_Enter || key==Qt::Key_Return){
		bOK();
	}

}
//////////////////////////////////////////////////////////////////////
void ExpAddProviderBucket::resizeEvent(QResizeEvent *e){
	int w=width();
	int h=height();
	widget1->setGeometry(QRect(0, 0, w, h));
	if(e){}

	int x1=5, y1=18, y2=25;
	int dy=20, dx1=(int) (w/4-x1), dx2=w-dx1-2*x1-10;
	int x2=x1+dx1+5;
	int y=22;

	textLabel1->setGeometry(QRect(x1, y, dx1, y1));
	lineEdit1->setGeometry(QRect(x2, y-3, dx2, y2));
	y+=y1+dy-5;

	checkBox1->setGeometry(QRect((int) ((x1+x2)/2), y, w-2*x1-5, y2));
	y+=y2+dy-10;

	pushButton1->setGeometry(QRect(x1+3, y, 100, 29));
	pushButton2->setGeometry(QRect(x1+127, y, 100, 29));

}

