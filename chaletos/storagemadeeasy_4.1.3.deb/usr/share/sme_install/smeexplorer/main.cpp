#include <QtGui/QApplication>

#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>

#include <stdlib.h>
#include <QtXml>

#include "smestorageexplorer.h"

//#include <stdlib.h>

int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	SMEStorageExplorer w;
	if(w.initialization(argc, argv)!=0){				// get command line parameter
		return -1; // need to close program
	}

	w.show();
	return a.exec();
}
