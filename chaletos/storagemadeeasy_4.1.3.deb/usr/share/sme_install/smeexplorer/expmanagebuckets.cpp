#include "stdio.h"
#include "expmanagebuckets.h"

ExpManageBuckets::ExpManageBuckets(QWidget *parent) : QWidget(parent){
	widget1 = new QWidget(this);
	widget1->setGeometry(QRect(0, 0, 500, 350));
	this->setWindowTitle("Buckets/Containers");
	this->setWindowIcon(QIcon("/usr/share/pixmaps/sme_explorer_icon_42.png"));
   widget1->setObjectName(QString::fromUtf8("widget1"));

	countB=0;
	int x1=5;
	int dy=10, dx1=150;
	int y=5;

	tree = new QTreeWidget(widget1);
	tree->setObjectName(QString::fromUtf8("tree"));
	tree->setGeometry(QRect(x1, y, dx1, 230));
	tree->setUpdatesEnabled(true);
	tree->setColumnCount(6);
	tree->headerItem()->setHidden(false);

	QTreeWidgetItem * stateNode;
	stateNode = new QTreeWidgetItem();
	stateNode->setText(0, "Bucket/Container");
	stateNode->setText(1, "Used");
	stateNode->setText(2, "Default");
	tree->setHeaderItem(stateNode);

	tree->setColumnWidth(0, 260);
	tree->setColumnWidth(1, 58);
	tree->setColumnWidth(2, 48);
	y+=dy+180;

	pushButton1 = new QPushButton(widget1);
	pushButton1->setObjectName(QString::fromUtf8("pushButton1"));
	pushButton1->setGeometry(QRect(10, y, 85, 29));
	pushButton1->setText("Update List");
	pushButton2 = new QPushButton(widget1);
	pushButton2->setObjectName(QString::fromUtf8("pushButton2"));
	pushButton2->setGeometry(QRect(10, y, 85, 29));
	pushButton2->setText("Add Bucket...");
	pushButton3 = new QPushButton(widget1);
	pushButton3->setObjectName(QString::fromUtf8("pushButton3"));
	pushButton3->setGeometry(QRect(10, y, 85, 29));
	pushButton3->setText("Set Default");

	QObject::connect(pushButton1, SIGNAL(clicked()), this, SLOT(bsave()));
	QObject::connect(pushButton2, SIGNAL(clicked()), this, SLOT(badd()));
	QObject::connect(pushButton3, SIGNAL(clicked()), this, SLOT(bsetDefault()));
	QObject::connect(tree, SIGNAL(itemSelectionChanged()), this, SLOT(updateState()));
}
//////////////////////////////////////////////////////////////////////
ExpManageBuckets::~ExpManageBuckets(){
}
//////////////////////////////////////////////////////////////////////
void ExpManageBuckets::clear2(){
printf("clear2()\n");
	if(countB>0){
		for(int i=countB-1; i>=0; i--){
			if(buckets[i].name!=""){
				buckets[i].name="";
				delete buckets[i].node;
			}
		}

		delete []buckets;
		countB=0;
	}

	return ;
}
//////////////////////////////////////////////////////////////////////
void ExpManageBuckets::clear(){
printf("clear()\n");
	clear2();
	selectedBucketName="";
	countB=0;
	int maxCount=10000;
	buckets=new TMBucket[maxCount];
	for(int i=0; i<maxCount; i++){
		buckets[i].name="";
	}

}
//////////////////////////////////////////////////////////////////////
void ExpManageBuckets::initWnd(){
	tree->sortItems(0, Qt::AscendingOrder);
	updateState();
}
//////////////////////////////////////////////////////////////////////
bool ExpManageBuckets::addToTree(QString name, bool isDef, bool isUsed){
printf("addToTree()\n");
	if(name.length()<1) return false;
	TMBucket elem;

	elem.name=name;
	elem.isDefault=isDef;
	elem.isUsed=isUsed;

	elem.node=new QTreeWidgetItem(tree);
	buckets[countB]=elem;
	updateNode(countB);
	countB++;

	return true;
}
//////////////////////////////////////////////////////////////////////
void ExpManageBuckets::updateNode(int n){
printf("ExpProviders::updateNode(int n)\n");
	QString ipath="/usr/share/smeclient/exp/bucket.gif", def="No", used="No";
	if(buckets[n].isDefault) def="Yes";
	if(buckets[n].isUsed) used="Yes";

	buckets[n].node->setIcon(0, QIcon(ipath));
	buckets[n].node->setText(0, buckets[n].name);
	buckets[n].node->setText(1, used);
	buckets[n].node->setText(2, def);
	if(buckets[n].isUsed){
		buckets[n].node->setCheckState(0, Qt::CheckState(2));				// 0 - not checked, 2 - checked
	}else{
		buckets[n].node->setCheckState(0, Qt::CheckState(0));				// 0 - not checked, 2 - checked
	}

	return ;
}
//////////////////////////////////////////////////////////////////////
void ExpManageBuckets::bsave(){
	emit saveBuckets();
	hide();
	return ;
}
//////////////////////////////////////////////////////////////////////
void ExpManageBuckets::badd(){
	emit addBucket();
	hide();
	return ;
}
//////////////////////////////////////////////////////////////////////
void ExpManageBuckets::bsetDefault(){
	QString name="";
	if(countB>0){
		for(int i=0; i<countB; i++){
			if(buckets[i].name!="" && buckets[i].node->isSelected()){
				name=buckets[i].name;
				break;
			}
		}
	}

	if(name=="") return ;
	selectedBucketName=name;
	emit setDefault();
	hide();
	return ;
}
//////////////////////////////////////////////////////////////////////
void ExpManageBuckets::updateState(){
printf("ExpProviders::updateState()\n");
	bool updateList=true, addBucket=true, setDef=true;
	int n=-1;
	if(countB>0){
		for(int i=0; i<countB; i++){
			if(buckets[i].name!="" && buckets[i].node->isSelected()){
				n=i;
				break;
			}
		}
	}

	if(n==-1){
		setDef=false;
	}else{
		if(buckets[n].isDefault) setDef=false;
	}

	pushButton1->setEnabled(updateList);
	pushButton2->setEnabled(addBucket);
	pushButton3->setEnabled(setDef);
}
//////////////////////////////////////////////////////////////////////
void ExpManageBuckets::resizeEvent(QResizeEvent *e){
	int w=width(), h=height(), x=3;
	if(e){}
	widget1->setGeometry(QRect(0, 0, w, h));
	tree->setGeometry(QRect(3, 3, w-6, h-39));
	pushButton1->setGeometry(QRect(x, h-31, 140, 29));
	pushButton2->setGeometry(QRect(x+150, h-31, 140, 29));
	pushButton3->setGeometry(QRect(x+300, h-31, 140, 29));
	return ;
}
//////////////////////////////////////////////////////////////////////
void ExpManageBuckets::keyPressEvent(QKeyEvent *event){
	int key=event->key();
	if(key==Qt::Key_Escape){
		hide();
	}

}
//////////////////////////////////////////////////////////////////////

