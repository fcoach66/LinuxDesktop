#include "stdio.h"
#include "expautosharerule.h"

ExpAutoShareRule::ExpAutoShareRule(QWidget *parent) : QWidget(parent){
	widget1 = new QWidget(this);
	widget1->setGeometry(QRect(0, 0, 500, 390));
	this->setMinimumSize(200, 100);
	this->setWindowTitle("Auto Share File(s) with Business Group or User");
	this->setWindowIcon(QIcon("/usr/share/pixmaps/sme_explorer_icon_42.png"));
   widget1->setObjectName(QString::fromUtf8("widget1"));

	int x1=8, dx1=484, y=6;
	countR=0;
	isWaiting=false;

	tree = new QTreeWidget(widget1);
	tree->setObjectName(QString::fromUtf8("tree"));
	tree->setGeometry(QRect(x1, y, dx1, 340));
	tree->setUpdatesEnabled(true);
	tree->setColumnCount(3);
//	tree->headerItem()->setHidden(true);

	QTreeWidgetItem *stateNode;
	stateNode = new QTreeWidgetItem();
	stateNode->setText(0, "With Business Group");
	stateNode->setText(1, "Auto Share File(s)");
	stateNode->setText(2, "From Folder(s)");
	tree->setHeaderItem(stateNode);

	tree->setColumnWidth(0, 161);
	tree->setColumnWidth(1, 161);

	y+=+347;
	pushButton1 = new QPushButton(widget1);
	pushButton1->setObjectName(QString::fromUtf8("pushButton1"));
	pushButton1->setGeometry(QRect(x1, y, 135, 30));
	pushButton1->setText("New Rule");
	x1+=140;
	pushButton3 = new QPushButton(widget1);
	pushButton3->setObjectName(QString::fromUtf8("pushButton3"));
	pushButton3->setGeometry(QRect(x1, y, 135, 30));
	pushButton3->setText("Delete Rule");
	x1+=140;
	pushButton2 = new QPushButton(widget1);
	pushButton2->setObjectName(QString::fromUtf8("pushButton2"));
	pushButton2->setGeometry(QRect(x1, y, 135, 30));
	pushButton2->setText("Cancel");

// Buttons
	QObject::connect(pushButton1, SIGNAL(clicked()), this, SLOT(bAddAutoShare()));
	QObject::connect(pushButton3, SIGNAL(clicked()), this, SLOT(bDeleteAutoShare()));
	QObject::connect(pushButton2, SIGNAL(clicked()), this, SLOT(hideWindow()));
}
//////////////////////////////////////////////////////////////////////
ExpAutoShareRule::~ExpAutoShareRule(){
}
//////////////////////////////////////////////////////////////////////
void ExpAutoShareRule::hideWindow(){
  this->hide();
}
//////////////////////////////////////////////////////////////////////
void ExpAutoShareRule::clear(){
	clear2();
	isWaiting=false;
	countR=0;
	int maxCount=10000;
	ruleslist=new TshareR[maxCount];
	for(int i=0; i<maxCount; i++){
		ruleslist[i].id="";
	}

}
//////////////////////////////////////////////////////////////////////
void ExpAutoShareRule::clear2(){
	if(countR>0){
		for(int i=countR-1; i>=0; i--){
			if(ruleslist[i].id!=""){
				ruleslist[i].id="";
				delete ruleslist[i].node;
			}
		}
		delete []ruleslist;
		countR=0;
	}
}
//////////////////////////////////////////////////////////////////////
void ExpAutoShareRule::initWnd(){
	isWaiting=false;
	addFolder("", "My Cloud Files");
	addFolder("0", "My Cloud Files");
}
//////////////////////////////////////////////////////////////////////
bool ExpAutoShareRule::addToTree(QString id, QString group, QString rule, QString fromFolder, QString folderId){
	TshareR elem;
	elem.id=id;
	elem.folderId=folderId;
	ruleslist[countR]=elem;
	countR++;
	ruleslist[countR-1].node=new QTreeWidgetItem(tree);

	QString ipath="/usr/share/smeclient/exp/rule.gif";
	ruleslist[countR-1].node->setIcon(0, QIcon(ipath));
	ruleslist[countR-1].node->setText(0, group);
	ruleslist[countR-1].node->setText(1, rule);
	ruleslist[countR-1].node->setText(2, fromFolder);
	
	return true;
}
//////////////////////////////////////////////////////////////////////
bool ExpAutoShareRule::deleteFromTree(QString id){
	if(id=="") 	return false;
	int n=-1;
	for(int i=0; i<countR; i++){
		if(ruleslist[i].id==id){
			n=i;
			break;
		}
	}//for

	if(n<0) return -1;

	int i;
	delete ruleslist[n].node;
	for(i=n; i<countR-1; i++){	 	// delete from array
		ruleslist[i]=ruleslist[i+1];
	}//for

	ruleslist[i].id="";
	ruleslist[i].folderId="";

	return true;
}
//////////////////////////////////////////////////////////////////////
bool ExpAutoShareRule::addFolder(QString id, QString name){
	for(int i=0; i<countR; i++){
		if(ruleslist[i].folderId==id){
			ruleslist[i].node->setText(2, name);
		}
	}
	
	return true;
}
//////////////////////////////////////////////////////////////////////
void ExpAutoShareRule::bAddAutoShare(){
	isWaiting=true;

	emit addAutoShare();
	this->hide();
}
//////////////////////////////////////////////////////////////////////
void ExpAutoShareRule::bDeleteAutoShare(){
	bool L=false;
	for(int i=0; i<countR; i++){
		if(ruleslist[i].node->isSelected()){
			selectedid=ruleslist[i].id;
			L=true;
			break;
		}
	}

	if(!L)	return ;
	if(QMessageBox::question(this, "Confirm", "Do you want to delete?",  QMessageBox::Ok, QMessageBox::No)!=QMessageBox::Ok)	return ;

	emit deleteAutoShare();
	this->hide();
}
//////////////////////////////////////////////////////////////////////
void ExpAutoShareRule::resizeEvent(QResizeEvent *e){
	int w=width();
	int h=height();
	if(e){}

	widget1->setGeometry(QRect(0, 0, w, h));
	tree->setGeometry(QRect(3, 6, w-6, h-45));
	pushButton1->setGeometry(QRect(3, h-32, 130, 29));
	pushButton3->setGeometry(QRect(138, h-32, 130, 29));
	pushButton2->setGeometry(QRect(273, h-32, 130, 29));

}
//////////////////////////////////////////////////////////////////////
void ExpAutoShareRule::keyPressEvent(QKeyEvent *event){
	int key=event->key();
	if(key==Qt::Key_Escape){
		hideWindow();
	}

}
//////////////////////////////////////////////////////////////////////




