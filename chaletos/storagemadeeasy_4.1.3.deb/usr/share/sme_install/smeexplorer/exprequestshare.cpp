#include "stdio.h"
#include "exprequestshare.h"

ExpRequestShare::ExpRequestShare(QWidget *parent) : QWidget(parent){
	widget1 = new QWidget(this);
	widget1->setGeometry(QRect(0, 0, 430, 284));
	this->setWindowTitle("Send a Request to Share a File");
	this->setWindowIcon(QIcon("/usr/share/pixmaps/sme_explorer_icon_42.png"));
   widget1->setObjectName(QString::fromUtf8("widget1"));

	countG=0;
	countU=0;

	int x1=5, y1=18, y2=25;
	int dy=20, dx1=110, dx2=295;
	int x2=x1+dx1+10;
	int y=20;

	textLabel1 = new QLabel(widget1);
	textLabel1->setObjectName(QString::fromUtf8("textLabel1"));
	textLabel1->setGeometry(QRect(x1, y, dx1, y1));
	textLabel1->setText("To User:");
	comboBox1 = new QComboBox(widget1);
	comboBox1->setObjectName(QString::fromUtf8("comboBox1"));
	comboBox1->setGeometry(QRect(x2, y-3, dx2, y2));
	y+=y1+dy-5;

	textLabel2 = new QLabel(widget1);
	textLabel2->setObjectName(QString::fromUtf8("textLabel2"));
	textLabel2->setGeometry(QRect(x1, y, dx1, y1));
	textLabel2->setText("With Group:");
	comboBox2 = new QComboBox(widget1);
	comboBox2->setObjectName(QString::fromUtf8("comboBox2"));
	comboBox2->setGeometry(QRect(x2, y-3, dx2, y2));
	y+=y1+dy-5;

	textLabel3 = new QLabel(widget1);
	textLabel3->setObjectName(QString::fromUtf8("textLabel3"));
	textLabel3->setGeometry(QRect(x1, y, dx1, y1));
	textLabel3->setText("Comment:");
	textEdit1 = new QTextEdit(widget1);
	textEdit1->setObjectName(QString::fromUtf8("textEdit1"));
	textEdit1->setGeometry(QRect(x2, y-3, dx2, y2*6+3));
	y+=y2*6+dy-12;


	pushButton1 = new QPushButton(widget1);
	pushButton1->setObjectName(QString::fromUtf8("pushButton1"));
	pushButton1->setGeometry(QRect(122, y+5, 85, 29));
	pushButton1->setText("Share");

	pushButton2 = new QPushButton(widget1);
	pushButton2->setObjectName(QString::fromUtf8("pushButton2"));
	pushButton2->setGeometry(QRect(242, y+5, 85, 29));
	pushButton2->setText("Cancel");

// Buttons
	QObject::connect(pushButton1, SIGNAL(clicked()), this, SLOT(bshare()));
	QObject::connect(pushButton2, SIGNAL(clicked()), this, SLOT(hideWindow()));
}
//////////////////////////////////////////////////////////////////////
ExpRequestShare::~ExpRequestShare(){
}
//////////////////////////////////////////////////////////////////////
void ExpRequestShare::hideWindow(){
	clear2();
	this->hide();
}
//////////////////////////////////////////////////////////////////////
void ExpRequestShare::clear2(){
	if(countG>0){
		delete []groupslist;
		countG=0;
	}

	if(countU>0){
		delete []userslist;
		countU=0;
	}
	comboBox2->clear();
}
//////////////////////////////////////////////////////////////////////
void ExpRequestShare::clear(){
	gid="";
	uid="";
	comment="";
	int maxCount=5000;
	countG=0;
	countU=0;
	groupslist=new QString[maxCount];
	userslist=new QString[maxCount];
	for(int i=0; i<maxCount; i++){
		groupslist[i]="";
		userslist[i]="";
	}
	comboBox2->clear();

}
//////////////////////////////////////////////////////////////////////
void ExpRequestShare::initWnd(){


}
//////////////////////////////////////////////////////////////////////
void ExpRequestShare::add(bool group, QString id, QString name){
	if(group){
		for(int i=0; i<countG; i++){
			if(groupslist[i]==id) return ;
		}
		groupslist[countG]=id;
		comboBox2->insertItem(countG, name);
		countG++;
	}else{
		for(int i=0; i<countU; i++){
			if(userslist[i]==id) return ;
		}
		userslist[countU]=id;
		comboBox1->insertItem(countU, name);
		countU++;
	}

}
//////////////////////////////////////////////////////////////////////
void ExpRequestShare::bshare(){
	gid="";
	uid="";
	int i1=comboBox1->currentIndex();
	int i2=comboBox2->currentIndex();
	if(i1<0 || i1>countG-1 || i2<0 || i2>countU-1){
		return ;
	}
	gid=groupslist[i1];
	uid=userslist[i2];
	
	comment=textEdit1->toPlainText();

	emit requestShare();
	this->hide();
	clear2();
}
//////////////////////////////////////////////////////////////////////
void ExpRequestShare::keyPressEvent(QKeyEvent *event){
	int key=event->key();
	if(key==Qt::Key_Escape){
		hideWindow();
	}else if(key==Qt::Key_Enter || key==Qt::Key_Return){
		bshare();
	}

}
//////////////////////////////////////////////////////////////////////
void ExpRequestShare::resizeEvent(QResizeEvent *e){
	int w=width();
	int h=height();
	widget1->setGeometry(QRect(0, 0, w, h));
	if(e){}

	int x1=5, y1=19, y2=25;
	int dy=20, dx1=(int) (w/3-x1), dx2=w-dx1-2*x1-5;
	int x2=x1+dx1+5;
	int y=20;

	textLabel1->setGeometry(QRect(x1, y, dx1, y1));
	comboBox1->setGeometry(QRect(x2, y-3, dx2, y2));
	y+=y1+dy-5;

	textLabel2->setGeometry(QRect(x1, y, dx1, y1));
	comboBox2->setGeometry(QRect(x2, y-3, dx2, y2));
	y+=y1+dy-5;

	textLabel3->setGeometry(QRect(x1, y, dx1, y1));
	textEdit1->setGeometry(QRect(x2, y-3, dx2, h-y-35));
	y+=h-y-35+4;

	pushButton1->setGeometry(QRect(x1+5, y, 100, 29));
	pushButton2->setGeometry(QRect(x1+130, y, 100, 29));

}


