#include "stdio.h"
#include "expselectbuckets.h"

ExpSelectBuckets::ExpSelectBuckets(QWidget *parent) : QWidget(parent){
	widget1 = new QWidget(this);
	widget1->setGeometry(QRect(0, 0, 500, 350));
	this->setWindowTitle("Buckets/Containers");
	this->setWindowIcon(QIcon("/usr/share/pixmaps/sme_explorer_icon_42.png"));
   widget1->setObjectName(QString::fromUtf8("widget1"));

	countB=0;
	prid="";
	int x1=5, y1=18, y2=25;
	int dy=10, dy2=15, dx1=150, dx2=120;
	int y=5;

	textLabel0 = new QLabel(widget1);
	textLabel0->setObjectName(QString::fromUtf8("textLabel0"));
	textLabel0->setGeometry(QRect(5, y, dx1, y1));
	textLabel0->setText("Buckets/Containers:");
	y+=y1+dy+dy2;

	prList=new QListWidget(widget1);
	prList->setGeometry(QRect(x1, y, 290, 180));
	QFont font1=prList->font();
	font1.setPointSize(9);
	prList->setFont(font1);
	prList->setSortingEnabled(true);
	y+=dy+180;

	textLabel1 = new QLabel(widget1);
	textLabel1->setObjectName(QString::fromUtf8("textLabel1"));
	textLabel1->setGeometry(QRect(x1, y, dx1, y1));
	textLabel1->setText("Default bucket/container:");
	comboBox1=new QComboBox(widget1);
	comboBox1->setObjectName(QString::fromUtf8("comboBox1"));
	comboBox1->setGeometry(QRect(x1, y-3, dx2, y2));
	y+=y1+dy+dy2;

	textLabel2 = new QLabel(widget1);
	textLabel2->setObjectName(QString::fromUtf8("textLabel1"));
	textLabel2->setGeometry(QRect(x1, y, dx1, y1));
	textLabel2->setText("New bucket/container:");
	lineEdit1 = new QLineEdit(widget1);
	lineEdit1->setObjectName(QString::fromUtf8("lineEdit1"));
	lineEdit1->setGeometry(QRect(x1, y-3, dx2, y2));
	y+=y1+dy+dy2;


	pushButton1 = new QPushButton(widget1);
	pushButton1->setObjectName(QString::fromUtf8("pushButton1"));
	pushButton1->setGeometry(QRect(10, y, 85, 29));
	pushButton1->setText("OK");

	QObject::connect(pushButton1, SIGNAL(clicked()), this, SLOT(bOK()));
}
//////////////////////////////////////////////////////////////////////
ExpSelectBuckets::~ExpSelectBuckets(){
}
//////////////////////////////////////////////////////////////////////
void ExpSelectBuckets::clear2(){
printf("clear2()\n");
	if(countB>0){
		for(int i=countB-1; i>=0; i--){
			if(buckets[i].name!=""){
				buckets[i].name="";
				delete buckets[i].node;
			}
		}

		delete []buckets;
		countB=0;
	}

	return ;
}
//////////////////////////////////////////////////////////////////////
void ExpSelectBuckets::clear(){
printf("clear()\n");
	clear2();
	prid="";
	countB=0;
	int maxCount=10000;
	buckets=new TSBucket[maxCount];
	for(int i=0; i<maxCount; i++){
		buckets[i].id="";
		buckets[i].name="";
	}

}
//////////////////////////////////////////////////////////////////////
void ExpSelectBuckets::initWnd(){

}
//////////////////////////////////////////////////////////////////////
bool ExpSelectBuckets::addToTree(QString id, QString name){
printf("addToTree()\n");
	TSBucket elem;
	elem.id=id;
	elem.name=name;
	buckets[countB]=elem;
	buckets[countB].node=new QListWidgetItem(QIcon("/usr/share/smeclient/exp/bucket.gif"), elem.name);
	buckets[countB].node->setToolTip(elem.name);		// hint
	buckets[countB].node->setCheckState(Qt::Unchecked);
	prList->insertItem(countB, buckets[countB].node);
	countB++;

	comboBox1->insertItem(countB, name);

	return true;
}
//////////////////////////////////////////////////////////////////////
void ExpSelectBuckets::bOK(){
	emit setBuckets();
	hide();
	return ;
}
//////////////////////////////////////////////////////////////////////
void ExpSelectBuckets::resizeEvent(QResizeEvent *e){
	int w=width(), h=height();
	widget1->setGeometry(QRect(0, 0, w, h));
	if(e){}

	textLabel0->setGeometry(QRect(5, 4, w-10, 19));
	prList->setGeometry(QRect(5, 26, w-10, h-131));

	int dx1=(int) (w/2-5+30), dx2=w-dx1-12, x2=dx1+5+2;
	textLabel1->setGeometry(QRect(5, h-95, dx1, 18));
	comboBox1->setGeometry(QRect(x2, h-99, dx2, 25));
	textLabel2->setGeometry(QRect(5, h-65, dx1, 18));
	lineEdit1->setGeometry(QRect(x2, h-68, dx2, 23));

	pushButton1->setGeometry(QRect(10, h-33, 85, 29));
	return ;
}
//////////////////////////////////////////////////////////////////////
void ExpSelectBuckets::keyPressEvent(QKeyEvent *event){
	int key=event->key();
	if(key==Qt::Key_Enter || key==Qt::Key_Return){
		bOK();
	}

}
//////////////////////////////////////////////////////////////////////



