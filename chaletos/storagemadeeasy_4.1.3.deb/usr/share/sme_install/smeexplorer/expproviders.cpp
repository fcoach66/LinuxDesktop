#include "stdio.h"
#include "expproviders.h"

ExpProviders::ExpProviders(QWidget *parent) : QWidget(parent){
	widget1 = new QWidget(this);
	widget1->setGeometry(QRect(0, 0, 582, 300));
	this->setMinimumSize(200, 100);
	this->setWindowTitle("Cloud Providers");
	this->setWindowIcon(QIcon("/usr/share/pixmaps/sme_explorer_icon_42.png"));
   widget1->setObjectName(QString::fromUtf8("widget1"));

	int x1=20, dy=2, dy2=15, dx1=460, y=16;
	countP=0;
	countA=0;

	tree = new QTreeWidget(widget1);
	tree->setObjectName(QString::fromUtf8("tree"));
	tree->setGeometry(QRect(x1, y, dx1, 230));
	tree->setUpdatesEnabled(true);
	tree->setColumnCount(6);
	tree->headerItem()->setHidden(false);

	QTreeWidgetItem * stateNode;
	stateNode = new QTreeWidgetItem();
	stateNode->setText(0, "Provider");
	stateNode->setText(1, "Account");
	stateNode->setText(2, "Files");
	stateNode->setText(3, "Default");
	stateNode->setText(4, "Master");
	stateNode->setText(5, "Backup");
	tree->setHeaderItem(stateNode);

	tree->setColumnWidth(0, 150);
	tree->setColumnWidth(1, 62);
	tree->setColumnWidth(2, 60);
	tree->setColumnWidth(3, 62);
	tree->setColumnWidth(4, 62);
	tree->setColumnWidth(5, 60);
	y+=230+dy+dy2;

	pushButton1 = new QPushButton(widget1);
	pushButton1->setObjectName(QString::fromUtf8("pushButton1"));
	pushButton1->setGeometry(QRect(x1, y, 85, 29));
	pushButton1->setText("Add Provider");
	x1+=100;
	pushButton2 = new QPushButton(widget1);
	pushButton2->setObjectName(QString::fromUtf8("pushButton2"));
	pushButton2->setGeometry(QRect(x1, y, 85, 29));
	pushButton2->setText("Set Default");
	x1+=100;
	pushButton3 = new QPushButton(widget1);
	pushButton3->setObjectName(QString::fromUtf8("pushButton3"));
	pushButton3->setGeometry(QRect(x1, y, 85, 29));
	pushButton3->setText("Sync Now");
	x1+=100;
	pushButton4 = new QPushButton(widget1);
	pushButton4->setObjectName(QString::fromUtf8("pushButton4"));
	pushButton4->setGeometry(QRect(x1, y, 85, 29));
	pushButton4->setText("Sync Task");
	x1+=100;
	pushButton5 = new QPushButton(widget1);
	pushButton5->setObjectName(QString::fromUtf8("pushButton5"));
	pushButton5->setGeometry(QRect(x1, y, 85, 29));
	pushButton5->setText("Manage Buckets");
	x1+=100;
	pushButton6 = new QPushButton(widget1);
	pushButton6->setObjectName(QString::fromUtf8("pushButton6"));
	pushButton6->setGeometry(QRect(x1, y, 85, 29));
	pushButton6->setText("Change Password");

	QFont font1=pushButton1->font();
	font1.setPointSize(9);
	pushButton1->setFont(font1);
	pushButton2->setFont(font1);
	pushButton3->setFont(font1);
	pushButton4->setFont(font1);
	pushButton5->setFont(font1);
	pushButton6->setFont(font1);

// Buttons
	QObject::connect(pushButton1, SIGNAL(clicked()), this, SLOT(baddProvider()));
	QObject::connect(pushButton2, SIGNAL(clicked()), this, SLOT(bsetDefault()));
	QObject::connect(pushButton3, SIGNAL(clicked()), this, SLOT(bsyncNow()));
	QObject::connect(pushButton4, SIGNAL(clicked()), this, SLOT(bsyncTask()));
	QObject::connect(pushButton5, SIGNAL(clicked()), this, SLOT(bmanageBuckets()));
	QObject::connect(pushButton6, SIGNAL(clicked()), this, SLOT(bchangePassword()));
	QObject::connect(tree, SIGNAL(itemSelectionChanged()), this, SLOT(updateState()));
//	QObject::connect(pushButton2, SIGNAL(clicked()), this, SLOT(changePassword2()));
	QObject::connect(&changePasswordWnd, SIGNAL(wchangePassword()), this, SLOT(bchangePassword2()));
	QObject::connect(&addProviderWnd, SIGNAL(getProviderMetaFields()), this, SLOT(bgetProviderMetaFields()));

}
//////////////////////////////////////////////////////////////////////
ExpProviders::~ExpProviders(){
}
//////////////////////////////////////////////////////////////////////
void ExpProviders::baddProvider(){
//printf("ExpProviders::baddProvider()\n");
	addProviderWnd.clear();
	for(int i=0; i<countA; i++){
		if(aproviderslist[i].pr_name!=""){
			addProviderWnd.addToTree(aproviderslist[i].prid, aproviderslist[i].pr_name);
		}
	}
	addProviderWnd.setWindowModality(Qt::ApplicationModal);
	addProviderWnd.move(QPoint((int) (x()+150), y()));
	addProviderWnd.initWnd();
	addProviderWnd.show();
//	this->hide();
}
//////////////////////////////////////////////////////////////////////
void ExpProviders::bgetProviderMetaFields(){
//printf("ExpProviders::bgetProviderMetaFields()\n");
	if(addProviderWnd.prid==""){
//		QMessageBox::critical(this, "Error", "First select provider");
		return ;
	}
	
	newProviderId=addProviderWnd.prid;
	emit getProviderMetaFields();
	this->hide();
}
//////////////////////////////////////////////////////////////////////
void ExpProviders::bsetDefault(){
//printf("ExpProviders::bsetDefault()\n");
	bool L=false;
	for(int i=0; i<countP; i++){
		if(providerslist[i].node->isSelected()){
			L=true;
			break;
		}
	}

	if(!L){
		QMessageBox::critical(this, "Error", "First select provider");
		return ;
	}
	emit setDefaultProvider();
	this->hide();
}
//////////////////////////////////////////////////////////////////////
void ExpProviders::bsyncNow(){
//printf("ExpProviders::bsyncNow()\n");
	bool L=false;
	for(int i=0; i<countP; i++){
		if(providerslist[i].node->isSelected()){
			L=true;
			break;
		}
	}

	if(!L){
		QMessageBox::critical(this, "Error", "First select provider");
		return ;
	}
	emit syncNow();
	this->hide();
}
//////////////////////////////////////////////////////////////////////
void ExpProviders::bsyncTask(){
//printf("ExpProviders::bsyncTask()\n");
	bool L=false;
	for(int i=0; i<countP; i++){
		if(providerslist[i].node->isSelected()){
			L=true;
			break;
		}
	}

	if(!L){
		QMessageBox::critical(this, "Error", "First select provider");
		return ;
	}
	emit syncTask();
	this->hide();
}
//////////////////////////////////////////////////////////////////////
void ExpProviders::bchangePassword(){
//printf("ExpProviders::bchangePassword()\n");
	bool L=false;
	for(int i=0; i<countP; i++){
		if(providerslist[i].node->isSelected()){
			L=true;
			break;
		}
	}

	if(!L){
		QMessageBox::critical(this, "Error", "First select provider");
		return ;
	}

	changePasswordWnd.setWindowModality(Qt::ApplicationModal);
	changePasswordWnd.move(QPoint((int) (x()+100), y()+40));
	changePasswordWnd.initWnd();
	changePasswordWnd.show();
}
//////////////////////////////////////////////////////////////////////
void ExpProviders::bchangePassword2(){
//printf("ExpProviders::bchangePassword2()\n");
	if(changePasswordWnd.password=="") return ;

	newPassword=changePasswordWnd.password;
	emit changePassword();
}
//////////////////////////////////////////////////////////////////////
void ExpProviders::bmanageBuckets(){
//printf("ExpProviders::bmanageBuckets()\n");
	for(int i=0; i<countP; i++){
		if(providerslist[i].node->isSelected()){
			providerId=providerslist[i].pi_id;
			providerType=2;		// 1 - Amazon S3, 2 - Mosso (RacksSpace)
			if(providerslist[i].prid=="1") providerType=1;
			break;
		}
	}

	if(providerId=="") return ;
	emit manageBuckets();
}
//////////////////////////////////////////////////////////////////////
void ExpProviders::clear(){
//printf("ExpProviders::clear()\n");
	clear2();

	providerId="";
	newPassword="";
	newProviderId="";

	int maxCount=5000;
	countP=0;
	countA=0;
	providerslist=new TNProvider[maxCount];
	for(int i=0; i<maxCount; i++){
		providerslist[i].pi_master="";
		providerslist[i].pi_login="";
		providerslist[i].defaultfolder="";
		providerslist[i].defaultfolderid="";
		providerslist[i].pi_id="";
		providerslist[i].prid="";
		providerslist[i].pr_name="";
		providerslist[i].cf="";
		providerslist[i].pi_master=false;
		providerslist[i].isDefault=false;
	}

	aproviderslist=new TNProvider[maxCount];
	for(int i=0; i<maxCount; i++){
		aproviderslist[i].prid="";
		aproviderslist[i].pr_name="";
	}
}
//////////////////////////////////////////////////////////////////////
void ExpProviders::clear2(){
//printf("ExpProviders::clear2()\n");
	if(countP>0){

		for(int i=countP-1; i>=0; i--){
			if(providerslist[i].pr_name!=""){
				providerslist[i].pr_name="";		// don't delete this!
				delete providerslist[i].node;
			}
		}

		delete []providerslist;
		countP=0;
	}

	if(countA>0){
//		for(int i=countA-1; i>=0; i--){
//			if(aproviderslist[i].pr_name!="")	delete aproviderslist[i].node;
//		}

		delete []aproviderslist;
		countA=0;
	}
}
//////////////////////////////////////////////////////////////////////
void ExpProviders::initWnd(){
//printf("ExpProviders::initWnd(int n)\n");
	updateState();

}
//////////////////////////////////////////////////////////////////////
void ExpProviders::upateNode(int n){
//printf("ExpProviders::upateNode(int n)\n");
	QString ipath="/usr/share/smeclient/exp/rule.gif", def="No", master="No", backup="No";
	if(providerslist[n].isDefault) def="Yes";
	if(providerslist[n].pi_master) master="Yes";
	if(providerslist[n].isDefault) backup="Yes";

	providerslist[n].node->setIcon(0, QIcon(ipath));
	providerslist[n].node->setText(0, providerslist[n].pr_name);
	providerslist[n].node->setText(1, providerslist[n].pi_login);
	providerslist[n].node->setText(2, providerslist[n].cf);
	providerslist[n].node->setText(3, def);
	providerslist[n].node->setText(4, master);
	providerslist[n].node->setText(5, backup);

	return ;
}
//////////////////////////////////////////////////////////////////////
bool ExpProviders::addToTree(TNProvider elem){
//printf("ExpProviders::addToTree()\n");
	if(elem.pr_name.length()<1) return false;
	elem.node=new QTreeWidgetItem(tree);
	providerslist[countP]=elem;
	upateNode(countP);
	countP++;
	return true;
}
//////////////////////////////////////////////////////////////////////
bool ExpProviders::addAllowedPr(TNProvider elem){
//printf("ExpProviders::addAllowedPr()\n");
	if(elem.pr_name.length()<1) return false;
	aproviderslist[countA]=elem;
	countA++;

//printf("ExpProviders::addAllowedPr => +\n");
	return true;
}
//////////////////////////////////////////////////////////////////////
void ExpProviders::updateState(){
//printf("ExpProviders::updateState()\n");
	bool addPr=true, setDef=true, syncNow=true, syncTask=true, manageBuckets=true, changePass=true;
	int n=-1;
	int count=0;
	if(countP>0){
		for(int i=0; i<countP; i++){
			if(providerslist[i].pr_name!="" && providerslist[i].node->isSelected()){
				n=i;
				count++;
				break;
			}
		}
	}

	if(count==0){
		setDef=false;
		syncNow=false;
		syncTask=false;
		manageBuckets=false;
		changePass=false;
	}else if(count==1 && n>-1){
		if(providerslist[n].isDefault){
			setDef=false;
			changePass=false;
		}
		if(providerslist[n].pi_id=="0"){
			syncNow=false;
			syncTask=false;
		}

		if(providerslist[n].prid!="1" && providerslist[n].prid!="5") manageBuckets=false;

		//!!!!!!!!!!!!!!!!!!!!!     ?????
	}

	pushButton1->setEnabled(addPr);
	pushButton2->setEnabled(setDef);
	pushButton3->setEnabled(syncNow);
	pushButton4->setEnabled(syncTask);
	pushButton5->setEnabled(manageBuckets);
	pushButton6->setEnabled(changePass);

}
//////////////////////////////////////////////////////////////////////
void ExpProviders::keyPressEvent(QKeyEvent *event){
	int key=event->key();
	if(key==Qt::Key_Escape){
		hide();
	}

}
//////////////////////////////////////////////////////////////////////
void ExpProviders::resizeEvent(QResizeEvent *e){
	int w=width();
	int h=height();
	if(e){}

	widget1->setGeometry(QRect(0, 0, w, h));
	int x=7, dx=87, dx2=5;
	int ow=0, nw=0, dw=0;
	ow=tree->width();
	nw=w-2*x;
	dw=nw-ow;
	
	tree->setGeometry(QRect(x, 9, w-2*x, h-32-12-8));

	pushButton1->setGeometry(QRect(x, h-33, dx, 29));
	x+=dx+dx2;
	pushButton2->setGeometry(QRect(x, h-33, dx, 29));
	x+=dx+dx2;
	pushButton3->setGeometry(QRect(x, h-33, dx-13, 29));
	x+=dx+dx2-13;
	pushButton4->setGeometry(QRect(x, h-33, dx-13, 29));
	x+=dx+dx2-13;
	pushButton5->setGeometry(QRect(x, h-33, dx+21, 29));
	x+=dx+dx2+21;
	pushButton6->setGeometry(QRect(x, h-33, dx+27, 29));

	if(tree->columnWidth(0)+dw>20){
		tree->setColumnWidth(0, tree->columnWidth(0)+dw);
	}

	QWidget::resizeEvent(e);
}
//////////////////////////////////////////////////////////////////////

