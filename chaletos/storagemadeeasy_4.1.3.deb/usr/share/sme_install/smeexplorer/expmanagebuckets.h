#ifndef EXPMANAGEBUCKETS_H
#define EXPMANAGEBUCKETS_H

#include <QtGui/QWidget>
#include <QtGui/QPushButton>
#include <QtGui/QWidget>
#include <Qt3Support/Q3MimeSourceFactory>
#include <QtGui/QMessageBox>
#include <QTreeWidget>
#include <QTreeWidgetItem>
#include <QModelIndex>
#include <QtGui/QKeyEvent>

typedef struct {
	QString name;
	bool isDefault, isUsed;
	QTreeWidgetItem *node;
} TMBucket;

class ExpManageBuckets : public QWidget
{
    Q_OBJECT

public:
	ExpManageBuckets(QWidget *parent = 0);
	~ExpManageBuckets();
	void clear();
	void clear2();
	void initWnd();
	bool addToTree(QString name, bool isDef, bool isUsed);
	void updateNode(int n);
	QString selectedBucketName;

	int countB;
	TMBucket *buckets;

	QWidget *widget1;
	QPushButton *pushButton1, *pushButton2, *pushButton3;
	QTreeWidget *tree;

private:
	virtual void resizeEvent(QResizeEvent * e);

public
  slots:
	void bsave();
	void badd();
	void bsetDefault();
	void updateState();

  signals:
	void saveBuckets();
	void addBucket();
	void setDefault();

private:
	virtual void keyPressEvent(QKeyEvent * event);


};

#endif // EXPMANAGEBUCKETS_H
