#include "stdio.h"
#include "expcreatefolder.h"

ExpCreateFolder::ExpCreateFolder(QWidget *parent) : QWidget(parent){
	widget1 = new QWidget(this);
	widget1->setGeometry(QRect(0, 0, 430, 139));
	this->setWindowTitle("Create Folder");
	this->setWindowIcon(QIcon("/usr/share/pixmaps/sme_explorer_icon_42.png"));
   widget1->setObjectName(QString::fromUtf8("widget1"));

	int x1=3, y1=18, y2=25;
	int dy=20, dx1=120, dx2=279;
	int x2=x1+dx1+20;
	int y=7;

	textLabel1 = new QLabel(widget1);
	textLabel1->setObjectName(QString::fromUtf8("textLabel1"));
	textLabel1->setGeometry(QRect(x1, y, dx1, y1));
	textLabel1->setText("Name:");
	lineEdit1 = new QLineEdit(widget1);
	lineEdit1->setObjectName(QString::fromUtf8("lineEdit1"));
	lineEdit1->setGeometry(QRect(x2, y-3, dx2, y2));
	y+=y1+dy-5;
	textLabel2 = new QLabel(widget1);
	textLabel2->setObjectName(QString::fromUtf8("textLabel2"));
	textLabel2->setGeometry(QRect(x1, y, dx1, y1));
	textLabel2->setText("Description:");
	lineEdit2 = new QLineEdit(widget1);
	lineEdit2->setObjectName(QString::fromUtf8("lineEdit2"));
	lineEdit2->setGeometry(QRect(x2, y-3, dx2, y2));
	y+=y1+dy-5;

	textLabel3 = new QLabel(widget1);
	textLabel3->setObjectName(QString::fromUtf8("textLabel3"));
	textLabel3->setGeometry(QRect(x1, y, dx1, y1));
	textLabel3->setText("Tags:");
	lineEdit3 = new QLineEdit(widget1);
	lineEdit3->setObjectName(QString::fromUtf8("lineEdit3"));
	lineEdit3->setGeometry(QRect(x2, y-3, dx2, y2));

	checkBox1=new QCheckBox("Organization Folder", widget1);
	checkBox1->setObjectName(QString::fromUtf8("checkBox"));
	checkBox1->setGeometry(QRect(x1+20, y, 300, y2));
	checkBox1->setCheckState(Qt::Unchecked);
	checkBox2=new QCheckBox("All users can submit", widget1);
	checkBox2->setObjectName(QString::fromUtf8("checkBox2"));
	checkBox2->setGeometry(QRect(x1+20, y, 300, y2));
	checkBox2->setCheckState(Qt::Unchecked);
	y+=y2+dy-10;

	pushButton1 = new QPushButton(widget1);
	pushButton1->setObjectName(QString::fromUtf8("pushButton1"));
	pushButton1->setGeometry(QRect(220, y, 85, 29));
	pushButton1->setText("Create");
	pushButton2 = new QPushButton(widget1);
	pushButton2->setObjectName(QString::fromUtf8("pushButton2"));
	pushButton2->setGeometry(QRect(326, y, 85, 29));
	pushButton2->setText("Cancel");



// Buttons
	QObject::connect(pushButton1, SIGNAL(clicked()), this, SLOT(bcreateFolder()));
	QObject::connect(pushButton2, SIGNAL(clicked()), this, SLOT(hideWindow()));
}
//////////////////////////////////////////////////////////////////////
ExpCreateFolder::~ExpCreateFolder(){
}
//////////////////////////////////////////////////////////////////////
void ExpCreateFolder::bcreateFolder(){
	foldername=lineEdit1->text();
	folderdesc=lineEdit2->text();
	foldertags=lineEdit3->text();

	if(checkBox1->checkState()==Qt::Checked){
		isOrg=true;
	}else{
		isOrg=false;
	}

	if(checkBox2->checkState()==Qt::Checked){
		allUserCanSubmits=true;
	}else{
		allUserCanSubmits=false;
	}

	if(foldername.length()<1){
		QMessageBox::critical(this, "Error", "    Enter Name    ");
		return ;
	}

	if(createwnd){
		if(type==0 || type==1){
			emit createFolder();
		}else if(type==3){
			emit createGroup();
		}
	}else{
		if(type==0){
			emit renameFile();
		}else if(type==1){
			emit renameFolder();
		}else if(type==2){
										// not supported
		}else if(type==3){
			emit renameGroup();
		}

	}

	this->hide();
}
//////////////////////////////////////////////////////////////////////
void ExpCreateFolder::hideWindow(){
  this->hide();
}
//////////////////////////////////////////////////////////////////////
void ExpCreateFolder::clear(){
	isOrg=false;
	createwnd=true;
	uploadfolder=false;
	gprivate=false;
	allUserCanSubmits=true;
	foldername="";
	folderdesc="";
	foldertags="";
	pid="";
	lastid="";
	type=0;
	sx=0;
	sy=0;
	checkBox1->setEnabled(false);
	checkBox1->hide();
	checkBox2->hide();
	textLabel3->hide();
	lineEdit3->hide();

}
//////////////////////////////////////////////////////////////////////
void ExpCreateFolder::initWnd(){
	lineEdit1->setText(foldername);
	lineEdit2->setText(folderdesc);
	lineEdit3->setText(foldertags);

	if(isOrg)	checkBox1->setCheckState(Qt::Checked);
	if(allUserCanSubmits)	checkBox2->setCheckState(Qt::Checked);

	QString eName="Folder";
	if(type==0){
		textLabel3->show();
		lineEdit3->show();
		eName="File";
	}else if(type==1){
		eName="Folder";
	}else if(type==2){
		eName="User";
	}else if(type==3){
		eName="Group";
	}

	if(!createwnd){
		this->setWindowTitle("Rename "+ eName);
		pushButton1->setText("Rename");
	}else{
		this->setWindowTitle("Create "+ eName);
		pushButton1->setText("Create");
		if(type==1)	checkBox1->show();
	}
	if(type==3)	checkBox2->show();

	if(sx<0) sx=0;
	if(sy<0) sy=0;
	move(QPoint(sx, sy));
}
//////////////////////////////////////////////////////////////////////
void ExpCreateFolder::keyPressEvent(QKeyEvent *event){
	int key=event->key();
	if(key==Qt::Key_Escape){
		hideWindow();
	}else if(key==Qt::Key_Enter || key==Qt::Key_Return){
		bcreateFolder();
	}

}
//////////////////////////////////////////////////////////////////////






