#include "expdownload.h"

ExpDownload::ExpDownload(QWidget *parent) : QWidget(parent){
	widget1 = new QWidget(this);
	widget1->setGeometry(QRect(0, 0, 430, 146));
	this->setWindowTitle("Download");
	this->setWindowIcon(QIcon("/usr/share/pixmaps/sme_explorer_icon_42.png"));
   widget1->setObjectName(QString::fromUtf8("widget1"));

	int x1=3, y1=18, y2=25;
	int dy=10, dx1=100, dx2=300;
	int x2=x1+dx1+20;
	int y=3;

	textLabel1 = new QLabel(widget1);
	textLabel1->setObjectName(QString::fromUtf8("textLabel1"));
	textLabel1->setGeometry(QRect(x1, y, x2+dx2-x1, (int) (y1*2.6+3)));
   textLabel1->setWordWrap(true);
	textLabel1->setText("This file is encrypted.<br> Please enter decryption phrase (password) below");
	y+=(int) (y1*2.6+3)+3;

	textLabel2 = new QLabel(widget1);
	textLabel2->setObjectName(QString::fromUtf8("textLabel2"));
	textLabel2->setGeometry(QRect(x1, y, dx1, y1));
	textLabel2->setText("Password:");
	lineEdit1 = new QLineEdit(widget1);
	lineEdit1->setObjectName(QString::fromUtf8("lineEdit1"));
	lineEdit1->setGeometry(QRect(x2, y-3, dx2, y2));
	lineEdit1->setEchoMode(QLineEdit::Password);
	y+=y1+dy;

	checkBox1=new QCheckBox("Remember", widget1);
	checkBox1->setObjectName(QString::fromUtf8("checkBox"));
	checkBox1->setGeometry(QRect(x1+20, y, 300, y2));
	checkBox1->setCheckState(Qt::Unchecked);
	y+=y2+dy-5;

	pushButton1 = new QPushButton(widget1);
	pushButton1->setObjectName(QString::fromUtf8("pushButton1"));
	pushButton1->setGeometry(QRect(x1, y, 110, 29));
	pushButton1->setText("Download");
	pushButton2 = new QPushButton(widget1);
	pushButton2->setObjectName(QString::fromUtf8("pushButton2"));
	pushButton2->setGeometry(QRect(x1+130, y, 110, 29));
	pushButton2->setText("Cancel");

// Buttons
	QObject::connect(pushButton1, SIGNAL(clicked()), this, SLOT(OK()));
	QObject::connect(pushButton2, SIGNAL(clicked()), this, SLOT(hideWindow()));
}
//////////////////////////////////////////////////////////////////////
ExpDownload::~ExpDownload(){
}
//////////////////////////////////////////////////////////////////////
void ExpDownload::OK(){
	if(lineEdit1->text().length()<1){
		QMessageBox::critical(this, "Error", "    Enter password    ");
		return ;
	}

	isCanceled = false;
//	emit downloadFile();

	this->hide();
}
//////////////////////////////////////////////////////////////////////
void ExpDownload::hideWindow(){
  this->hide();
}
//////////////////////////////////////////////////////////////////////
void ExpDownload::initWnd(){
	if(checkBox1->checkState()!=Qt::Checked){
		lineEdit1->setText("");
	}
	isCanceled = true;
}
//////////////////////////////////////////////////////////////////////
void ExpDownload::hide(){
	emit closed();
	this->setHidden(true);
}
//////////////////////////////////////////////////////////////////////
void ExpDownload::close(){
	emit closed();
}
//////////////////////////////////////////////////////////////////////
void ExpDownload::keyPressEvent(QKeyEvent *event){
	int key=event->key();
	if(key==Qt::Key_Escape){
		hideWindow();
	}else if(key==Qt::Key_Enter || key==Qt::Key_Return){
		OK();
	}

}
//////////////////////////////////////////////////////////////////////

