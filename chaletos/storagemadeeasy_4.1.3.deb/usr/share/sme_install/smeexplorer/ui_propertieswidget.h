#ifndef UI_PROPERTIESWIDGET_H
#define UI_PROPERTIESWIDGET_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
//#include <QtGui/QButtonGroup>
#include <QtGui/QLabel>
#include <QtGui/QCheckBox>
//#include <QtGui/QRadioButton>
#include <QtGui/QGroupBox>
//#include <QtGui/QVBoxLayout>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QComboBox>
#include <QtGui/QWidget>

#include <Qt3Support/Q3MimeSourceFactory>
#include <QtGui/QMessageBox>

class Ui_propertiesWidget
{
public:
	QWidget *widget;
	QLabel *textLabel0, *textLabel1, *textLabel2, *textLabel3, *textLabel4, *textLabel5, *textLabel6;
	QPushButton *pushButton1, *pushButton2;
	QLineEdit *lineEdit1, *lineEdit2, *lineEdit3, *lineEdit4, *lineEdit5, *lineEdit6;
	QComboBox *comboBox1;

	QCheckBox *checkBox1;
	QGroupBox *groupBox;

	void setupUi(QWidget *propertiesWidget)
	{
		if(propertiesWidget->objectName().isEmpty())
		propertiesWidget->setObjectName(QString::fromUtf8("propertiesWidget"));
		int windowW=472;
		int windowH=312;
		propertiesWidget->resize(windowW, windowH);
		propertiesWidget->setWindowIcon(QIcon("/usr/share/pixmaps/sme_explorer_icon_42.png"));

      widget=new QWidget(propertiesWidget);
      widget->setObjectName(QString::fromUtf8("widget"));
      widget->setGeometry(QRect(0, 0, windowW+20, windowH+20));

		int left=6, leftTextEdit=left+150;
		int h=19, hTextEdit=h+5;
		int p=10;
		int w=135, wTextEdit=w+175;
		int sh=7;

		textLabel0=new QLabel(widget);
		textLabel0->setObjectName(QString::fromUtf8("textLabel0"));
		textLabel0->setGeometry(QRect(left, sh, w, h));
		comboBox1=new QComboBox(widget);
		comboBox1->setGeometry(QRect(leftTextEdit, sh-5, wTextEdit, hTextEdit));
		comboBox1->setEditable(true);
		comboBox1->insertItem(0, "");
		comboBox1->insertItem(1, "storagemadeeasy.com");
		comboBox1->insertItem(2, "eu.storagemadeeasy.com");
		comboBox1->insertItem(3, "https://storagemadeeasy.com");
		comboBox1->insertItem(4, "https://eu.storagemadeeasy.com");
		QLineEdit *edit=new QLineEdit();
		comboBox1->setLineEdit(edit);
		sh+=p+h+10;

		textLabel1=new QLabel(widget);
		textLabel1->setObjectName(QString::fromUtf8("textLabel1"));
		textLabel1->setGeometry(QRect(left, sh, w, h));
		lineEdit1=new QLineEdit(widget);
		lineEdit1->setObjectName(QString::fromUtf8("lineEdit1"));
		lineEdit1->setGeometry(QRect(leftTextEdit, sh-5, wTextEdit, hTextEdit));
		sh+=p+h;

		textLabel2=new QLabel(widget);
		textLabel2->setObjectName(QString::fromUtf8("textLabel2"));
		textLabel2->setGeometry(QRect(left, sh, w, h));
		lineEdit2=new QLineEdit(widget);
		lineEdit2->setObjectName(QString::fromUtf8("lineEdit2"));
		lineEdit2->setGeometry(QRect(leftTextEdit, sh-5, wTextEdit, hTextEdit));
		lineEdit2->setEchoMode(QLineEdit::Password);
		sh+=p+h+15;




		checkBox1=new QCheckBox(QString::fromUtf8("Use Proxy"), widget);
		checkBox1->setGeometry(QRect(left, sh, windowW-2*left, h));
		checkBox1->setCheckState(Qt::Unchecked);
		sh+=20;

		int gw=windowW-2*left-10;
		groupBox=new QGroupBox(QString::fromUtf8("Proxy Options"), widget);
		groupBox->setGeometry(QRect(left+10, sh, gw, 128));
		sh+=128+5;

		int gy=22, gx=3, gw1=int(gw/3-2*gx), gw2=gw-gw1-2*gx-5, gh=h;
		left+=6;
		textLabel3=new QLabel(groupBox);
		textLabel3->setGeometry(QRect(gx, gy, gw1, gh));
		textLabel3->setText("Proxy host:");
		lineEdit3=new QLineEdit(groupBox);
		lineEdit3->setGeometry(QRect(gx+gw1+5, gy-2, gw2, gh+4));
		gy+=gh+7;

		textLabel4=new QLabel(groupBox);
		textLabel4->setGeometry(QRect(gx, gy, gw1, gh));
		textLabel4->setText("Proxy port:");
		lineEdit4=new QLineEdit(groupBox);
		lineEdit4->setGeometry(QRect(gx+gw1+5, gy-2, 75, gh+4));
		gy+=gh+7;

		textLabel5=new QLabel(groupBox);
		textLabel5->setGeometry(QRect(gx, gy, gw1, gh));
		textLabel5->setText("Proxy login:");
		lineEdit5=new QLineEdit(groupBox);
		lineEdit5->setGeometry(QRect(gx+gw1+5, gy-2, gw2, gh+4));
		gy+=gh+7;

		textLabel6=new QLabel(groupBox);
		textLabel6->setGeometry(QRect(gx, gy, gw1, gh));
		textLabel6->setText("Proxy password:");
		lineEdit6=new QLineEdit(groupBox);
		lineEdit6->setGeometry(QRect(gx+gw1+5, gy-2, gw2, gh+4));
		lineEdit6->setEchoMode(QLineEdit::Password);
		gy+=gh+7;


		sh+=3;
		left=25;
		pushButton1=new QPushButton(widget);
		pushButton1->setObjectName(QString::fromUtf8("pushButton1"));
		pushButton1->setGeometry(QRect(left, sh, 100, h+11));
		pushButton2=new QPushButton(widget);
		pushButton2->setObjectName(QString::fromUtf8("pushButton2"));
		pushButton2->setGeometry(QRect(left+140, sh, 100, h+11));

		retranslateUi(propertiesWidget);

		QMetaObject::connectSlotsByName(propertiesWidget);
    } // setupUi

    void retranslateUi(QWidget *propertiesWidget)
    {

		propertiesWidget->setWindowTitle(QApplication::translate("propertiesWidget", " Properties", 0, QApplication::UnicodeUTF8));
		textLabel0->setText("Server: ");
		textLabel1->setText("Login: ");
		textLabel2->setText("Password: ");

		pushButton1->setText(QApplication::translate("Dialog", "OK", 0, QApplication::UnicodeUTF8));
		pushButton2->setText(QApplication::translate("Dialog", "Cancel", 0, QApplication::UnicodeUTF8));

		Q_UNUSED(propertiesWidget);
    }// retranslateUi

};

namespace Ui {
    class propertiesWidget: public Ui_propertiesWidget {};
} // namespace Ui

#endif // UI_PROPERTIESWIDGET_H
