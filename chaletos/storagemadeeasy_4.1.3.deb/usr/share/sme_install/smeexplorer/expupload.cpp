#include "stdio.h"
#include "expupload.h"

ExpUpload::ExpUpload(QWidget *parent) : QWidget(parent){
	widget1 = new QWidget(this);
	widget1->setGeometry(QRect(0, 0, 460, 285));
	this->setWindowTitle("Upload File");
	this->setWindowIcon(QIcon("/usr/share/pixmaps/sme_explorer_icon_42.png"));
   widget1->setObjectName(QString::fromUtf8("widget1"));

	int x1=3, y1=18, y2=25;
	int dy=15, dx1=135, dx2=270;
	int x2=x1+dx1+15;
	int y=5;

	textLabel1 = new QLabel(widget1);
	textLabel1->setObjectName(QString::fromUtf8("textLabel1"));
	textLabel1->setGeometry(QRect(x1, y, dx1, y1));
	textLabel1->setText("Name:");
	lineEdit1 = new QLineEdit(widget1);
	lineEdit1->setObjectName(QString::fromUtf8("lineEdit1"));
	lineEdit1->setGeometry(QRect(x2, y-3, dx2, y2));
	y+=y1+dy-5;
	textLabel2 = new QLabel(widget1);
	textLabel2->setObjectName(QString::fromUtf8("textLabel2"));
	textLabel2->setGeometry(QRect(x1, y, dx1, y1));
	textLabel2->setText("Description:");
	lineEdit2 = new QLineEdit(widget1);
	lineEdit2->setObjectName(QString::fromUtf8("lineEdit2"));
	lineEdit2->setGeometry(QRect(x2, y-3, dx2, y2));
	y+=y1+dy-5;

	textLabel3 = new QLabel(widget1);
	textLabel3->setObjectName(QString::fromUtf8("textLabel3"));
	textLabel3->setGeometry(QRect(x1, y, dx1, y1));
	textLabel3->setText("Tags:");
	lineEdit3 = new QLineEdit(widget1);
	lineEdit3->setObjectName(QString::fromUtf8("lineEdit3"));
	lineEdit3->setGeometry(QRect(x2, y-3, dx2, y2));
	y+=y1+dy+5;

	textLabel4 = new QLabel(widget1);
	textLabel4->setObjectName(QString::fromUtf8("textLabel4"));
	textLabel4->setGeometry(QRect(x1, y, dx1, y1));
	textLabel4->setText("Encryption phrase:");
	lineEdit4 = new QLineEdit(widget1);
	lineEdit4->setObjectName(QString::fromUtf8("lineEdit4"));
	lineEdit4->setGeometry(QRect(x2, y-3, dx2, y2));
	lineEdit4->setEchoMode(QLineEdit::Password);
	y+=y1+dy-5;

	textLabel5 = new QLabel(widget1);
	textLabel5->setObjectName(QString::fromUtf8("textLabel5"));
	textLabel5->setGeometry(QRect(x1, y, dx1, y1));
	textLabel5->setText("Repeat please:");
	lineEdit5 = new QLineEdit(widget1);
	lineEdit5->setObjectName(QString::fromUtf8("lineEdit5"));
	lineEdit5->setGeometry(QRect(x2, y-3, dx2, y2));
	lineEdit5->setEchoMode(QLineEdit::Password);
	y+=y1+dy-8;

	textLabel01 = new QLabel(widget1);
	textLabel01->setObjectName(QString::fromUtf8("textLabel01"));
	textLabel01->setGeometry(QRect(x1+20, y, x2+dx2-x1*2, y1*2-5));
   textLabel01->setWordWrap(true);
	textLabel01->setText("Warning.  If you forget the encryption phrase, decryption will be impossible!");
	y+=y1*2+dy+5;

	textLabel6 = new QLabel(widget1);
	textLabel6->setObjectName(QString::fromUtf8("textLabel6"));
	textLabel6->setGeometry(QRect(x1, y, dx1, y1));
	textLabel6->setText("File(s):");
	lineEdit6 = new QLineEdit(widget1);
	lineEdit6->setObjectName(QString::fromUtf8("lineEdit6"));
	lineEdit6->setGeometry(QRect(x2, y-3, dx2, y2));
	lineEdit6->setReadOnly(true);
	y+=y1+dy+4;

	pushButton1 = new QPushButton(widget1);
	pushButton1->setObjectName(QString::fromUtf8("pushButton1"));
	pushButton1->setGeometry(QRect(220, y, 85, 29));
	pushButton1->setText("Upload");
	pushButton2 = new QPushButton(widget1);
	pushButton2->setObjectName(QString::fromUtf8("pushButton2"));
	pushButton2->setGeometry(QRect(326, y, 85, 29));
	pushButton2->setText("Cancel");


// Buttons
	QObject::connect(pushButton1, SIGNAL(clicked()), this, SLOT(bupload()));
	QObject::connect(pushButton2, SIGNAL(clicked()), this, SLOT(hideWindow()));
}
//////////////////////////////////////////////////////////////////////
ExpUpload::~ExpUpload(){
}
//////////////////////////////////////////////////////////////////////
void ExpUpload::bupload(){
	name=lineEdit1->text();
	desc=lineEdit2->text();
	tags=lineEdit3->text();
	encrypt=lineEdit4->text();

	if(name.length()<1){
		QMessageBox::critical(this, "Error", "    Enter file name    ");
		return ;
	}

	if(encrypt!=lineEdit5->text()){
		QMessageBox::critical(this, "Error", "Encryption phrase is not repeated correct.");
		return ;
	}

	emit uploadFile();
	this->hide();
}
//////////////////////////////////////////////////////////////////////
void ExpUpload::hideWindow(){
	emit hideUploadWindow();
	this->hide();
}
//////////////////////////////////////////////////////////////////////
void ExpUpload::clear(){
	name="";
	desc="";
	tags="";
	path="";
	encrypt="";
	lineEdit1->setReadOnly(false);
}
//////////////////////////////////////////////////////////////////////
void ExpUpload::initWnd(){
	lineEdit1->setText(name);
	lineEdit2->setText(desc);
	lineEdit3->setText(tags);
	lineEdit4->setText(encrypt);
	lineEdit5->setText("");
	lineEdit6->setText(path);
}
//////////////////////////////////////////////////////////////////////
void ExpUpload::keyPressEvent(QKeyEvent *event){
	int key=event->key();
	if(key==Qt::Key_Escape){
		hideWindow();
	}else if(key==Qt::Key_Enter || key==Qt::Key_Return){
		bupload();
	}

}
//////////////////////////////////////////////////////////////////////
void ExpUpload::resizeEvent(QResizeEvent *e){
	int w=width();
	int h=height();
	widget1->setGeometry(QRect(0, 0, w, h));
	if(e){}

	int x1=3, y1=19, y2=25;
	int dy=15, dx1=(int) (w/2.4-x1), dx2=w-dx1-2*x1-2;
	int x2=x1+dx1+2;
	int y=5;

	textLabel1->setGeometry(QRect(x1, y, dx1, y1));
	lineEdit1->setGeometry(QRect(x2, y-3, dx2, y2));
	y+=y1+dy-5;

	textLabel2->setGeometry(QRect(x1, y, dx1, y1));
	lineEdit2->setGeometry(QRect(x2, y-3, dx2, y2));
	y+=y1+dy-5;

	textLabel3->setGeometry(QRect(x1, y, dx1, y1));
	lineEdit3->setGeometry(QRect(x2, y-3, dx2, y2));
	y+=y1+dy+5;

	textLabel4->setGeometry(QRect(x1, y, dx1, y1));
	lineEdit4->setGeometry(QRect(x2, y-3, dx2, y2));
	y+=y1+dy-5;

	textLabel5->setGeometry(QRect(x1, y, dx1, y1));
	lineEdit5->setGeometry(QRect(x2, y-3, dx2, y2));
	y+=y1+dy-8;

	textLabel01->setGeometry(QRect(x1+20, y, x2+dx2-x1*2, y1*2+13));
	y+=y1*2+dy+5;

	textLabel6->setGeometry(QRect(x1, y, dx1, y1));
	lineEdit6->setGeometry(QRect(x2, y-3, dx2, y2));
	y+=y1+dy+3;

	pushButton1->setGeometry(QRect(x1, y, 100, 29));
	pushButton2->setGeometry(QRect(x1+120, y, 100, 29));

}



