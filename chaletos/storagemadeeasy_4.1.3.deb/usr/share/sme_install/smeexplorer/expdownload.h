#ifndef EXPDOWNLOAD_H
#define EXPDOWNLOAD_H

#include <QtGui/QWidget>
#include <QtGui/QLabel>
#include <QtGui/QCheckBox>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QWidget>
#include <Qt3Support/Q3MimeSourceFactory>
#include <QtGui/QMessageBox>
#include <QtGui/QCheckBox>
#include <QtGui/QKeyEvent>


class ExpDownload : public QWidget
{
    Q_OBJECT

public:
	ExpDownload(QWidget *parent = 0);
	~ExpDownload();
	void initWnd();
	bool isCanceled;

	QWidget *widget1;
	QLabel *textLabel1, *textLabel2, *textLabel3;
	QPushButton *pushButton1, *pushButton2;
	QLineEdit *lineEdit1;
	QCheckBox *checkBox1;

public
  slots:
    void OK();
    void hideWindow();

  signals:
//    void downloadFile();
    void closed();

private:
	virtual void keyPressEvent(QKeyEvent * event);
	virtual void close();
	virtual void hide();

};

#endif // EXPDOWNLOAD_H
