#ifndef EXPSENDEMAIL_H
#define EXPSENDEMAIL_H

#include <QtGui/QWidget>
#include <QtGui/QLabel>
#include <QtGui/QCheckBox>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QWidget>
#include <Qt3Support/Q3MimeSourceFactory>
#include <QtGui/QMessageBox>
#include <QtGui/QCheckBox>
#include <QtGui/QTextEdit>
#include <QDateTime>
#include <QTreeWidget>
#include <QTreeWidgetItem>
#include <QtGui/QKeyEvent>


class ExpSendEmail : public QWidget
{
    Q_OBJECT

public:
	ExpSendEmail(QWidget *parent = 0);
	~ExpSendEmail();
	void clear();
	void clear2();
	void initWnd();

	QString name;
	int type;				// 0 - file, 1 - folder
	int countDays;

	QString username, email, message;
	bool expiredEnable;

	QWidget *widget1;
	QTextEdit *textEdit1;
	QLabel *textLabel1, *textLabel2, *textLabel3, *textLabel4, *textLabel5;
	QPushButton *pushButton1, *pushButton2;
	QLineEdit *lineEdit1, *lineEdit2, *lineEdit3, *lineEdit4;
	QCheckBox *checkBox1, *checkBox2;

public
  slots:
	void hideWindow();
	void checkBox1StateChanged(int n);
	void bOK();

  signals:
    void sendToEmail();

private:
	virtual void keyPressEvent(QKeyEvent * event);
	virtual void resizeEvent(QResizeEvent * e);


};

#endif // EXPSENDEMAIL_H
