#ifndef SMESTORAGEEXPLORER_H
#define SMESTORAGEEXPLORER_H

#include <QtGui/QWidget>
#include <QtNetwork/QHttp>
#include <QtNetwork/QHttpRequestHeader>
#include <QtNetwork/QNetworkAccessManager>
#include <QtNetwork/QNetworkReply>

#include <QtGui/QKeyEvent>
#include <QUrl>
#include <QMenuBar>
#include <QListWidgetItem>
#include <QDateTime>
#include <QDomNode>
#include <QFile>
#include <QProcess>
#include <QSslSocket>


#include "propertieswidget.h"
#include "providerlogwidget.h"
#include "expcreatefolder.h"
#include "expproperties.h"
#include "expshare.h"
#include "expautoshare.h"
#include "expupload.h"
#include "expdownload.h"
#include "expsendemail.h"
#include "expsendtwitter.h"
#include "exptinyurl.h"
#include "exprequestshare.h"
#include "expautosharerule.h"
#include "expabout.h"
#include "expimport.h"
#include "expproviderlogin.h"
#include "expsearch.h"
#include "expproviders.h"
#include "expselectbuckets.h"
#include "expmanagebuckets.h"
#include "expaddproviderbucket.h"
#include "expinformationwindow.h"

namespace Ui
{
	class SMEStorageExplorer;
}


typedef struct {
	QString name, description, tags;
//	QDateTime lastmodify;
	QString created, lastmodify, lastaccess;
	QString id, pid, size;
	int type;					// 0 - file, 1 - folder, 2 - user, 3 - group
	bool encrypted, isPublic, isFavorite;
	QString uid, extension;
	QString provider, orgid, orgfolderid, lockedby;
	QString us_name, shareGrId, shareUsId, shareFolderId;
	QString gpermissions, gprivate, link, path, lpath;
//	bool isProcessed;
	QListWidgetItem *node;
} Tfile;

typedef struct {
	QString path, lpath;
	Tfile file;
} TgetFileByPath;

typedef struct {
	QString shareGrId, shareUsId, shareFolderId;
} TgetSharedByGroup;

typedef struct {
	QString uri;
	bool isPost;
	QString postData;
} TgetToken;

typedef struct {
	int n;
	bool import;
} TbImpExp;

typedef struct {
	QString uri;
	bool inPublic;
} Tsearch;

typedef struct {
	QString id;
	int countG;
} TbAutoSharingRules;

typedef struct {
	QString id;
} TbRename;

typedef struct {
	QString id;
} TbSendToEmail;

typedef struct {
	QString id;
} TbSendToTwitter;

typedef struct {
	int n;
} TbTinyURL;

typedef struct {
	QList<Tfile> filelist;
	int status, n, itemNumForOpen;
	QString encrPhrase, filepath, folder;
	bool needOpen, wasEncrPhraseEntered;
	qint64 size, countDownloadedBytes;
	FILE *file;
	QDateTime lastModify;
	QHttp *http;
	QSslSocket *socket;
	bool multidownload, http_created, isCompleated;
} TbDownload;

typedef struct {
	QList<Tfile> filelist;
	QStringList files;
	int status;
	qint64 size;
	QString source, filepath, uploadcode, realName, pid;		// filepath - tmp file
	QFile *file;
	QHttp *http;
	QSslSocket *socket;
	bool multiupload, http_created, isSentDoCompleteUpload;
} TbUpload;

typedef struct {
	bool state;
} TFavourite;

typedef struct {
	bool needSyncNow;
	QString taskid;
	int countSec;
} TSyncProviderTask;

typedef struct {
	int n;
} TPasteFromClipboard;

typedef struct {
	bool state;
} TPublic;

typedef struct {
	bool state;
} TLock;

typedef struct {
	QString id;
	bool deleteAllfiles;
} TdeleteFiles;

typedef struct {
	int current;
	Tfile *history;
} Thistory;

typedef struct {
	bool running, isPost;
	int error, attempt;
	QString uri, response, postData, up_level_command, restory, restory2;			// SrunFunction.response
} TrunFunction;

class SMEStorageExplorer : public QWidget
{
    Q_OBJECT

	public:
		SMEStorageExplorer(QWidget *parent = 0);
		~SMEStorageExplorer();

//		QHttp *http;
		QNetworkAccessManager *http;
		int nResize, gmt_offset;
		int DEBUG;
		bool isActionCanceled;
		int wx, wy, ww, wh;
//QProcess process;
//QProcess *process2;

		ProviderlogWidget providerlog;			// window for enter provider login and password
		propertiesWidget propertiesWnd;
		ExpCreateFolder createFolderWnd;
		ExpProperties filePropertiesWnd;
		ExpShare shareWithGroupUserWnd;
		ExpAutoShare autoShareWithGroupUserWnd;
		ExpUpload uploadFileWnd;
		ExpDownload downloadFileWnd;
		ExpSendEmail sendEmailWnd;
		ExpSendTwitter sendToTwitterWnd;
		ExpTinyurl tinyurlWnd;
		ExpRequestShare requestShareWnd;
		ExpAutoShareRule autoShareRuleWnd;
		ExpAbout aboutWnd;
		ExpImport importWnd;
		ExpProviderLogin expProviderLoginWnd;
		ExpSearch searchWnd;
		ExpProviders providersWnd;
		ExpSelectBuckets selectBucketsWnd;
		ExpManageBuckets manageBucketsWnd;
		ExpAddProviderBucket addProviderBucketWnd;
		ExpInformationWindow *expInformationWnd;

		Tfile *filelist, *clipboardfilelist;
		Tfile emptyFile;
		Tfile *SLocation;


		QMenu *contextMenu, *viewMenu, *uploadMenu, *sharingMenu, *importExportMenu;
		QAction *aDownload, *aRename, *aPublic, *aLock, *aUnlock, *aShare, *aEmail, *aTwitter, *aTinyURL, *aDelete, *aRestore, *aProperties, *aLogout;
		QAction *avIcons, *avList;
		QAction *uplFiles, *uplFolder;
		QAction *asPublic, *asShareWithGroupUser, *asSendToEmail, *asSendToTwitter, *asGetTinyUrl, *asAutoShareWithGroupUser, *asAutoSharingRules, *asRequestShare;
		QAction *amsPublic, *amsShareWithGroupUser, *amsSendToEmail, *amsSendToTwitter, *amsGetTinyUrl, *amsAutoShareWithGroupUser, *amsAutoSharingRules, *amsRequestShare;
		QAction *amfProperties, *amfCloudExp, *amfPublicExp, *amfFavouriteExp, *amfSearchExp, *amfClipboardExp, *amfGroupsExp, *amfTrashExp;
		QAction *aieImport, *aieExport;
		QAction *ahAbout;

		int viewType;			// 0 - list, 1 - icons
		int explorerType;		// 0 - Cloud, 1 - Public, 2 - Favourite, 3 - Search, 4 - Clipboard, 5 - Groups, 6 - Trash

		QString smehost, token, tmptoken, userId;
		bool isOrganizationAdmin;
		QString login, password, providerLogin, providerPassword, fCnfName, pathToIcons;
		QString proxyhost, proxylogin, proxypass;
		int proxyport;
		bool useProxy;

		QString lastDir, localeEncoding, encryptionKeyForPassword;

		int countAllowedProviders;
		bool isRunning, canPasswordBeEncrypted;
		int maxCount, maxCountClipboard;
		Tfile currentFolder;
//		QString currentFolderId, currentFolderName;
//		int currentFolderType;
		bool isGetFilesList, isGetUserInfo, isRunningInKDE;
		TrunFunction SrunFunction;
		TgetToken SgetToken;
		Thistory Shistory;
		TbRename SbRename;
		TdeleteFiles SdeleteFiles;
		TFavourite SFavourite;
		TPublic SPublic;
		TLock SLock;
		TPasteFromClipboard SPasteFromClipboard;
		TbDownload SbDownload;
		TbUpload SbUpload;
		TbSendToEmail SendToEmail;
		TbSendToTwitter SendToTwitter;
		TbTinyURL STinyURL;
		TbAutoSharingRules SbAutoSharingRules;
		TbImpExp SbImpExp;
		TgetSharedByGroup SgetSharedByGroup;
		Tsearch Ssearch;
		TSyncProviderTask SSyncProviderTask;
		TgetFileByPath SgetFileByPath;

		void resume(int n);
		int initialization(int argc, char *argv[]);
		int getCountFiles(Tfile *arr);
		int addToFileslist(Tfile file, bool needShow=false);
		int editNode(int n);
		int deleteFileAndNode(int n=-1, QString id="");
		QString getFileIcon(int type, QString name="", QString extension="");
		void clearList(bool deleteFromArray=false);
		Tfile getFileFromDomNode(QDomNode n, QString pid="");
		Tfile getPublicFileFromDomNode(QDomNode n);
		Tfile getGroupFromDomNode(QDomNode n);

		QString charToQstring(char* n);
		QString intToQstring(int n);
		QString floatToQstring(double n);
		QString boolToQstring(bool n);
		QByteArray qstringToQByteArray(QString s);
		QString base64(QString t);
		QString decodeBase64(QString t);
		QString getPartQString(QString s, QString from, QString to);
		void setWindowPosition();
		void getWindowPosition();
		QDateTime toLocal(QDateTime t, int d=0);
		QDateTime toUTC(QDateTime t);

		void loadConfig();
		void saveConfig();
		int writeToFile(QString name, QString s, bool append=false);
		QString readFromFile(QString name);

		void debug(QString s, int level=5);
		void showMessage(QString m, bool showButtonCancel=false, bool showProgressBar=false);
		void refreshWnd(bool tree=false);
		void repaintAllIcons();
		void refreshAll(bool clearAll, bool changeExplorerType=false);
		QString runCommand(QString command);
		void runFunction(QString uri="", bool isPost=false, QString postData="");
		void getToken();
		void openFile(int itemNumForOpen);
		int bDownload1();
		int downloadFileToDisk(QString id, QString url, QString encryptionPhrase, QString localPath, QDateTime lastModify, QString name);

		QString getEncryptionKeyForPassword();
		QString encryptSMEPassword(QString password);
		QString decryptSMEPassword(QString password);

		void clearHistory();
		bool tryRunning();
		void getFilesList(Tfile folder);
//		void getFilesList(QString folderid, int type=1, QString shareGrId="", QString shareUsId="", QString shareFolderId="");
		void getMyInfo();
		void doFavourite(bool state);
		void doPublic(bool state);
		void doLock(bool state);
		void getFileByPath(QString path, QString lpath);
		QStringList scanDir(QString folder, bool includeSubfolders);
		QString getPID(QList<Tfile> filelist, QString fpath);

		void getProviderLoginAndPassword();
		void setProviderData();
//		void addToHistory(QString id, QString name, int type=1);
		void addToHistory(Tfile file);
		void addLocation(Tfile file);
		QString setHistory(int n);
		void blockSelection();
		void unBlockSelection();
		void bAutoSharingRules2(QString ids);
		void impExpStart(bool import);
		void getSharedByGroup(QString groupid, QString userid="", QString folderid="", QString subfolderid="");
		bool isKDE();
		void checkForOldVersion();
		QString commandLineEscape(QString s);
		FILE* openFile(QString path, QString mode);
//QHttp	*httpX0;

	private:
    Ui::SMEStorageExplorer *ui;
		virtual void resizeEvent(QResizeEvent * e);
		virtual void contextMenuEvent(QContextMenuEvent* event);
		virtual void keyPressEvent(QKeyEvent * event);
		virtual void closeEvent(QCloseEvent * event);

	public
  slots:
		void slotSslErrors(QNetworkReply *reply, QList<QSslError> e0);
		void slotSslErrorsUpload(QList<QSslError> e0);
		void slotSslErrorsDownload(QList<QSslError> e0);

		void hideMessage(bool leaveText=false);
//		void runFunctionResp();
		void runFunctionResp(QNetworkReply* reply);

		void getTokenResp();
		void setProviderDataResp();
		void cancelCurrentAction();

		void initWnd();
		void bView();
		void bViewList();
		void bViewIcons();
		void bRefresh();
		void bPrevious();
		void bNext();
		void bCreate();
		void bDelete();
		void bRename();
		void bFavourite();
		void bPublic();
		void bLock();
		void bUnlock();
		void bSharing();
		void bProperties();
		void bShareWithGroupUser();
		void bCopy();
		void bPaste();
		void properties();
		void bPropertiesGlobal();
		void saveProperties();
		void saveProviderLoginAndPassword();
		void getFilesListResp();
		void getGroupsListResp();
		void bDoubleClicked(QListWidgetItem *item);
		void getMyInfoResp();

		void createFolder2();
		void createFolder2Resp();
		void renameFolder2();
		void renameFolder2Resp();
		void renameFile2();
		void renameFile2Resp();
		void renameGroup2();
		void renameGroup2Resp();

		void createGroup();
		void createGroupResp();

		void deleteFiles();
		void deleteFilesResp();
		void doFavouriteResp();
		void doPublicResp();
		void doLockResp();
		void bCopyResp();
		void bPasteResp();
//		void bPasteResp2();
		void bPasteFromClipboard();
		void bPasteFromClipboardResp();
		void updateMenus();
		void bShareWithGroupUserResp();
		void bshareWithGroupOrUser();
		void bshareWithGroupOrUserResp();
		void bDownload();
		void bDownload0();
		void downloadFile();
		void bUpload();
		void bUploadFiles();
		void bUploadFolder();
		void uploadFolder1();
		void bUpload1();
		void bUpload2();
		void bUpload2Resp();
		void bUpload4Resp();
		void updateProgressBar(int, int);
		void bSendToEmail();
		void bSendToEmailResp();
		void bSendToEmail2Resp();
		void bSendToTwitter();
		void bSendToTwitterResp();
		void bSendToTwitter2Resp();
		void bTinyURL();
		void bTinyURLResp();
		void bRequestShare();
		void bRequestShareResp();
		void bRequestShare2();
		void bRequestShare2Resp();
		void bAutoShareWithGroupUser();
		void bAutoShareWithGroupUserResp();
		void bAutoShareWithGroupUser2();
		void bAutoShareWithGroupUser2Resp();
		void bAutoSharingRules();
		void bAutoSharingRulesResp();
		void bAutoSharingRules2Resp();
		void bDeleteAutoShare();
		void bDeleteAutoShareResp();
		void bAbout();
		void bImportExport();
		void bImport();
		void bExport();
		void bImportResp();
		void importGetProviderMetaFields();
		void importGetProviderMetaFieldsResp();
		void importSetProviderLogin();
		void importSetProviderLoginResp();
		void importSetProviderLoginResp2();
		void runImport();
		void runImportResp();
		void runImportResp2();
		void runImportResp3();
		void runExport();
		void runExportResp();
		void runExportResp2();
		void runExportResp3();
		void bSearch();
		void search2();
		void search2Resp();

		void changeExplorerTypeToCloud();
		void changeExplorerTypeToPublic();
		void changeExplorerTypeToFavourite();
		void changeExplorerTypeToSearch();
		void changeExplorerTypeToClipboard();
		void changeExplorerTypeToGroups();
		void changeExplorerTypeToTrash();

		void getSharedByGroupResp();
		void bCloudProviders();
		void cloudProvidersResp();
		void setDefaultProvider();
		void setDefaultProviderResp();
		void changeProviderPassword();
		void changeProviderPasswordResp();
		void syncProviderNow();
		void bsyncProviderTask();
		void syncProviderTask();
		void syncProviderTaskResp();
		void syncProviderNowResp2();
		void syncProviderNowResp();
		void syncProviderNowTimer();
		void addProviderGetMetaFields();
		void addProviderGetMetaFieldsResp();
		void addProviderSetMetaFields();
		void addProviderSetMetaFieldsResp();
		void addProviderSetBuckets();
		void addProviderSetBucketsResp();
		void addProviderSave();
		void addProviderSaveResp();
		void addProviderStep3();
		void addProviderStep3Resp();
		void bmanageBuckets();
		void bmanageBucketsResp();
		void bsetDefaultBucket();
		void bsetDefaultBucketResp();
		void bupdateProviderBucket();
		void bupdateProviderBucketResp();
		void baddProviderBucket();
		void addProviderBucket();
		void addProviderBucketResp();
		void deleteOldTmpFiles();
//		void changeLocation(int index);
		void changeLocation();
		void changeLocationResp();
		void getFileByPathResp();
		void bRestore();
		void restoreFilesResp();
		void logOut();

	signals:

};



#endif // SMESTORAGEEXPLORER_H
