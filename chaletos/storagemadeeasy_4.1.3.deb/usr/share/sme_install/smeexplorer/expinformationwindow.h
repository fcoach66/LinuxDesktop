#ifndef EXPINFORMATIONWINDOW_H
#define EXPINFORMATIONWINDOW_H

#include <QtGui/QWidget>
#include <QtGui/QLabel>
#include <QtGui/QPushButton>
#include <QtGui/QTextEdit>
#include <QtGui/QWidget>
#include <Qt3Support/Q3MimeSourceFactory>
#include <QtGui/QMessageBox>
#include <QtGui/QKeyEvent>

class ExpInformationWindow : public QWidget
{
    Q_OBJECT
public:
	ExpInformationWindow(QWidget *parent = 0);
	~ExpInformationWindow();

	QWidget *widget1;
	QTextEdit *textEdit1;
	QPushButton *pushButton1;

public
  slots:
	void hideWindow();
  signals:
	void closed();

private:
	virtual void keyPressEvent(QKeyEvent * event);
	virtual void resizeEvent(QResizeEvent * e=NULL);
	virtual void closeEvent(QCloseEvent *event);


};

#endif // EXPINFORMATIONWINDOW_H
