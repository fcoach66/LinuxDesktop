#ifndef ASKFORENCRYPTIONPHRASE_H
#define ASKFORENCRYPTIONPHRASE_H

#include <QtGui/QWidget>
#include <QtGui/QLabel>
#include <QtGui/QCheckBox>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QWidget>
#include <Qt3Support/Q3MimeSourceFactory>
#include <QtGui/QMessageBox>
#include <QtGui/QCheckBox>
#include <QtGui/QKeyEvent>
#include <QDateTime>


class AskForEncryptionPhrase : public QWidget
{
    Q_OBJECT

public:
	AskForEncryptionPhrase(QWidget *parent = 0);
	~AskForEncryptionPhrase();
	void initWnd(QString title, QString message);

	QString encryptionPhrase;
	bool save, encryptionPhraseChanged, timeout, dontAskAgain;

	QDateTime startDate;		// Date and time when we showed window. If user don't entered encryption phrase after 30 sec. then we should close a window.

	QWidget *widget1;
	QLabel *textLabel1, *textLabel2, *textLabel3;
	QCheckBox *checkBox1;
	QPushButton *pushButton1, *pushButton2, *pushButton3, *pushButton4;
	QLineEdit *lineEdit1;

public
  slots:
    void bOK();
    void bCancel();
    void updateTimer();
    void textChanged(QString text);
    void bDontAskAnyMore();
    void bMoreInfo();

  signals:
    void wOK();
    void wCancel();

private:
	virtual void keyPressEvent(QKeyEvent * event);
	virtual void resizeEvent(QResizeEvent * e);


};

#endif // ASKFORENCRYPTIONPHRASE_H
