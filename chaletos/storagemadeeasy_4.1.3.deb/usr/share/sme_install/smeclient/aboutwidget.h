#ifndef ABOUTWIDGET_H
#define ABOUTWIDGET_H

#include <QtGui/QWidget>

namespace Ui
{
    class AboutWidget;
}

class AboutWidget : public QWidget
{
    Q_OBJECT

public:
    AboutWidget(QWidget *parent = 0);
    ~AboutWidget();

private:
	Ui::AboutWidget *ui;
	virtual void resizeEvent(QResizeEvent * e=NULL);
public slots:
	void hideWindow();

};

#endif // ABOUTWIDGET_H
