#ifndef MAINWIDGET_H
#define MAINWIDGET_H

#include <QtGui/QWidget>
#include <QtGui/QSystemTrayIcon>

#include "advancedwidget.h"
#include "ui_advancedwidget.h"
#include "aboutwidget.h"
#include "ui_aboutwidget.h"
#include "providerlogwidget.h"
#include "ui_providerlogwidget.h"
#include "askforencryptionphrase.h"

namespace Ui
{
    class MainWidget;
}

class MainWidget : public QWidget
{
  Q_OBJECT

public:
  MainWidget(QWidget *parent = 0);
  ~MainWidget();
/*
	// share struct. Need for corect close all proccess
	typedef struct{
		int countProcess;
		int countProcessClosed;
	}forkedProcesses;
	int shmid_forkedProcesses;
*/
	void loadConfig();
	void saveConfig();
	bool isMount(QString folder);
	void updateMenu();
	int DEBUG;
	void debug(QString s, int level=5);
	int checkOptions(bool clogin, bool cpassword, bool cfolder);
	QString base64(QString t);
	QString decodeBase64(QString t);
	QString intToQstring(int n);

	void getProviderLoginAndPassword();
	QString getPartQString(QString s, QString from, QString to);
	int writeToFile(QString name, QString s);
	QString readFromFile(QString name);
	void openSyncWnd(int command);

	QString getEncryptionKeyForPassword();
	QString encryptSMEPassword(QString password);
	QString decryptSMEPassword(QString password);

	QSystemTrayIcon *trayIcon;
	QMenu *trayIconMenu;
	void setTrayIcon(QSystemTrayIcon *trayIcon);

	QString login, password, providerLogin, providerPassword, server, curentFolder, localeEncoding, encryptionKeyForPassword;
	int cacheLiveTime;
	bool shareDrive, canPasswordBeEncrypted, showEncryptedFiles;
	QString proxyhost, proxylogin, proxypass, defaultEncryptionPhrase;
	int proxyport;
	bool useProxy;


	bool needToAskForEncryptionPhrase;
	QString AskForEncryptionPhrase_title, AskForEncryptionPhrase_message;

	QString fCnfName, fLogName;
	QString *fileMen;

	ProviderlogWidget providerlog;

	AboutWidget *aw;
//	AdvancedWidget *ad;
	AdvancedWidget ad;

	QString runCommand(QString command);
	QStringList getCommandForMount(bool runCheckOptions=true, int type=0);	// type=0 - with "--DEBUG --al"
	void init();

private:
	Ui::MainWidget *ui;
	virtual void resizeEvent(QResizeEvent * e=NULL);

public slots:
  void selectFolder();
  void openFolder();
  void mount();
  void unMount();
  void hideInTray();
  void showFromTray();
  void hideTrayIcon();
  void saveAdvanced();
  void saveProviderLog();
  void clearCache();

//  void bCopyMountCommandToClipboard();
  void bshowCommandForMount();
  void askForEncryptionPhrase();

  void exit();
  void sync();
  void quickSyncAll();
  void quickSyncUp();
  void quickSyncDown();

  void advanced();
  void about();
  void logOut();

};

#endif // MAINWIDGET_H
