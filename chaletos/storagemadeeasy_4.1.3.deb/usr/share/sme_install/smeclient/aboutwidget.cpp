#include "aboutwidget.h"
#include "ui_aboutwidget.h"

AboutWidget::AboutWidget(QWidget *parent) : QWidget(parent), ui(new Ui::AboutWidget){
    ui->setupUi(this);

// Buttons
    QObject::connect(ui->pushButton1, SIGNAL(clicked()), this, SLOT(hideWindow()));
}
//////////////////////////////////////////////////////////////////////
AboutWidget::~AboutWidget(){
    delete ui;
}
//////////////////////////////////////////////////////////////////////
void AboutWidget::hideWindow(){
    this->hide();
}
//////////////////////////////////////////////////////////////////////
void AboutWidget::resizeEvent(QResizeEvent *e){
	int w=width();
	int h=height();
	if(e){}
	ui->widget->setGeometry(QRect(0, 0, w, h));

	int fontSize=12;
	if(ui->textLabel1->font().pixelSize()>8){
		fontSize=ui->textLabel1->font().pixelSize();
	}else if(ui->textLabel1->font().pointSize()>7){
		fontSize=(int) (ui->textLabel1->font().pointSize()*1.3);
	}

	int y=1;
	ui->textLabel1->setGeometry(QRect(0, y, w, fontSize+10));
	y+=fontSize+10+2;
	ui->textLabel2->setGeometry(QRect(0, y, w, fontSize+6));
	y+=fontSize+6+3;
	ui->textLabel4->setGeometry(QRect(0, y, w, fontSize+12));
	y+=fontSize+12+3;
	ui->textLabel3->setGeometry(QRect((int) (w/2-64), y, 128, 128));
	y+=128+3;
	ui->textLabel5->setGeometry(QRect(0, y, w, fontSize+43));
	y+=fontSize+43+3;
	ui->pushButton1->setGeometry(QRect((int) (w/2-50), y, 100, 27));
}

