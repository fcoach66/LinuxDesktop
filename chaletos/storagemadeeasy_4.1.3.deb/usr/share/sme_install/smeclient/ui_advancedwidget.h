#ifndef UI_ADVANCEDWIDGET_H
#define UI_ADVANCEDWIDGET_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
// #include <QtGui/QButtonGroup>
#include <QtGui/QLabel>
#include <QtGui/QCheckBox>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QGroupBox>
#include <QtGui/QWidget>

#include <QtGui/QFileDialog>
// #include <QFile>

#include <Qt3Support/Q3MimeSourceFactory>
// #include <QtGui/QDialog>
// #include <QtGui/QMenu>
// #include <QtGui/QMenuBar>
#include <QtGui/QMessageBox>

class Ui_AdvancedWidget
{
public:
	QWidget *widget;
	QCheckBox *checkBox, *checkBox2, *checkBox3;
	QLabel *textLabel1, *textLabel2, *textLabel3, *textLabel4, *textLabel5, *textLabel6, *textLabel7;
	QLineEdit *lineEdit1, *lineEdit2, *lineEdit3, *lineEdit4, *lineEdit5, *lineEdit6;
	QGroupBox *groupBox1;
	QPushButton *pushButton1, *pushButton2;

    void setupUi(QWidget *AdvancedWidget)
    {
      if (AdvancedWidget->objectName().isEmpty())
          AdvancedWidget->setObjectName(QString::fromUtf8("AdvancedWidget"));
      AdvancedWidget->resize(585, 370);
      AdvancedWidget->setWindowIcon(QIcon("/usr/share/smeclient/smeclient.png"));

      widget = new QWidget(AdvancedWidget);
      widget->setObjectName(QString::fromUtf8("widget"));
      widget->setGeometry(QRect(0, 0, 500, 285));

      checkBox = new QCheckBox(widget);
      checkBox->setObjectName(QString::fromUtf8("checkBox"));
      checkBox->setGeometry(QRect(10, 10, 480, 15));
      textLabel1 = new QLabel(widget);
      textLabel1->setObjectName(QString::fromUtf8("textLabel1"));
      textLabel1->setGeometry(QRect(30, 32, 460, 120));
      textLabel1->setWordWrap(true);
      textLabel1->setOpenExternalLinks(true);
//		textLabel1->setAlignment(Qt::AlignTop);

      lineEdit1 = new QLineEdit(widget);
      lineEdit1->setObjectName(QString::fromUtf8("lineEdit1"));
      lineEdit1->setGeometry(QRect(10, 10, 480, 15));
      textLabel2 = new QLabel(widget);
      textLabel2->setObjectName(QString::fromUtf8("textLabel2"));
      textLabel2->setGeometry(QRect(30, 32, 460, 120));
		textLabel2->setText("Time to live for cache (in seconds).");

		checkBox3=new QCheckBox(QString::fromUtf8("Show encrypted files"), widget);
		checkBox3->setCheckState(Qt::Unchecked);

		lineEdit6 = new QLineEdit(widget);
		lineEdit6->setGeometry(QRect(10, 10, 480, 15));
		lineEdit6->setEchoMode(QLineEdit::Password);
		textLabel7 = new QLabel(widget);
		textLabel7->setText("Encryption phrase (for download encrypted files)");
		textLabel7->setGeometry(QRect(30, 32, 460, 120));


		checkBox2=new QCheckBox(QString::fromUtf8("Use Proxy"), widget);
		checkBox2->setCheckState(Qt::Unchecked);

		groupBox1=new QGroupBox(QString::fromUtf8("Proxy Options"), widget);

		textLabel3=new QLabel(groupBox1);
		textLabel3->setText("Proxy host:");
		lineEdit2=new QLineEdit(groupBox1);

		textLabel4=new QLabel(groupBox1);
		textLabel4->setText("Proxy port:");
		lineEdit3=new QLineEdit(groupBox1);

		textLabel5=new QLabel(groupBox1);
		textLabel5->setText("Proxy login:");
		lineEdit4=new QLineEdit(groupBox1);

		textLabel6=new QLabel(groupBox1);
		textLabel6->setText("Proxy password:");
		lineEdit5=new QLineEdit(groupBox1);
		lineEdit5->setEchoMode(QLineEdit::Password);

      pushButton1 = new QPushButton(widget);
      pushButton1->setObjectName(QString::fromUtf8("pushButton1"));
      pushButton1->setGeometry(QRect(275, 180, 75, 27));
      pushButton2 = new QPushButton(widget);
      pushButton2->setObjectName(QString::fromUtf8("pushButton2"));
      pushButton2->setGeometry(QRect(370, 180, 75, 27));

      retranslateUi(AdvancedWidget);

      QMetaObject::connectSlotsByName(AdvancedWidget);
    } // setupUi

    void retranslateUi(QWidget *AdvancedWidget)
    {

      AdvancedWidget->setWindowTitle(QApplication::translate("AdvancedWidget", "Advanced", 0, QApplication::UnicodeUTF8));

      checkBox->setText(QApplication::translate("Dialog", "Share your drive", 0, QApplication::UnicodeUTF8));
      textLabel1->setText("Check this box if you want users other than the owner to access the mounted directory. This will mount the directory with fuse \"allow_other\" option. This is necessary if you want to share the directory using samba or similar file sharing technology. You will also need to edit or create /etc/fuse.conf and add the line user_allow_other.<br>For reference see:<br><a href='http://sourceforge.net/apps/mediawiki/fuse/index.php?title=Fuse.conf'>http://sourceforge.net/apps/mediawiki/fuse/index.php?title=Fuse.conf</a>");

      pushButton1->setText(QApplication::translate("Dialog", "OK", 0, QApplication::UnicodeUTF8));
      pushButton2->setText(QApplication::translate("Dialog", "Cancel", 0, QApplication::UnicodeUTF8));

      Q_UNUSED(AdvancedWidget);
    }// retranslateUi

};

namespace Ui {
    class AdvancedWidget: public Ui_AdvancedWidget {};
} // namespace Ui

#endif // UI_ADVANCEDWIDGET_H
