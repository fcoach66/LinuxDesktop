#include <QtGui/QApplication>
#include "mainwidget.h"
#include "advancedwidget.h"
#include "aboutwidget.h"
#include <QString>
#include <QTimer>

int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	MainWidget w;

	bool needToAskForEncryptionPhrase=false;	// If true then user try to open encrypted file and we should ask for encryption phrase for this file.
	QString com="", aTitle="", aMessage="";
	for(int i=0; i<argc; i++){
		com = QString(argv[i]);
		if(com=="--askForEncryptionPhrase"){
			needToAskForEncryptionPhrase = true;
		}else if(com.indexOf("--title=")==0){
			aTitle = w.decodeBase64(com.mid(8));
			//w.debug("Title=\""+aTitle+"\"");
		}else if(com.indexOf("--message=")==0){
			aMessage = w.decodeBase64(com.mid(10));
			//w.debug("Message=\""+aMessage+"\"");
		}
	}


	if(needToAskForEncryptionPhrase){
		w.needToAskForEncryptionPhrase = needToAskForEncryptionPhrase;
		w.AskForEncryptionPhrase_title = aTitle;
		w.AskForEncryptionPhrase_message = aMessage;
		QTimer::singleShot(1, &w, SLOT(askForEncryptionPhrase()));
		w.hide();
	}else{
		w.show();
		w.init();
	}

	QObject::connect(&a, SIGNAL(lastWindowClosed()), &w, SLOT(exit()));
	return a.exec();
}
