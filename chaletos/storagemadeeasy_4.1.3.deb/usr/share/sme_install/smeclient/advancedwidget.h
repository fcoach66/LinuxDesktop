#ifndef ADVANCEDWIDGET_H
#define ADVANCEDWIDGET_H

#include <QtGui/QWidget>

namespace Ui
{
    class AdvancedWidget;
}

class AdvancedWidget : public QWidget
{
    Q_OBJECT

public:
	AdvancedWidget(QWidget *parent = 0);
	~AdvancedWidget();
	int cacheLiveTime;
	QString proxyhost, proxylogin, proxypass, encryptionPhrase;
	int proxyport;
	bool useProxy, showEncrypted;
	bool isInitwnd;

	void initWnd();
	bool shareDrive;
	QString intToQstring(int n);
	void debug(QString s);

public
  slots:
	void saveAdvanced();
	void hideWindow();
	void checkBox2StateChanged(int par);
	void checkBox3StateChanged(int par);

  signals:
	void clickOKButton();

private:
	Ui::AdvancedWidget *ui;
	virtual void resizeEvent(QResizeEvent * e=NULL);
};

#endif // ADVANCEDWIDGET_H
