#ifndef UI_MYWIDGET_H
#define UI_MYWIDGET_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QWidget>
#include <QtGui/QComboBox>

#include <QtGui/QFileDialog>
#include <QFile>
#include <QTextStream>

#include <Qt3Support/Q3MimeSourceFactory>
#include <QtGui/QDialog>
#include <QtGui/QMenu>
#include <QtGui/QMenuBar>
#include <QtGui/QMessageBox>



class Ui_MainWidget
{
	public:
		QAction *fileExitAction, *fileSyncAction, *helpAboutAction, *fileMountAction, *filenew_itemAction, *fileOpen_folderAction, *fileUnmountAction, *fileClearCacheAction, *fileAdvancedAction, *fileQuickSyncAll, *fileQuickSyncUp, *fileQuickSyncDown, *logout, *showCommandForMount;
		//, *copyMountCommandToClipboard
		QWidget *widget;
		QLineEdit *lineEdit1, *lineEdit2, *lineEdit3;
		QLabel *textLabel2, *textLabel3, *textLabel4, *textLabel5;
		QPushButton *pushButton1, *pushButton11, *pushButton2, *pushButton21, *pushButton3, *pushButton4;
		QComboBox *comboBox1;
		QMenuBar *MenuBar;
		QMenu *fileMenu, *syncMenu, *helpMenu;

    void setupUi(QWidget *MainWidget)
    {
      if (MainWidget->objectName().isEmpty())
          MainWidget->setObjectName(QString::fromUtf8("MainWidget"));
      MainWidget->resize(390, 367);
      MainWidget->setWindowIcon(QIcon("/usr/share/smeclient/smeclient.png"));
		MainWidget->setWindowTitle(QApplication::translate("MainWidget", "Linux Cloud Tools", 0, QApplication::UnicodeUTF8));

      fileExitAction = new QAction(MainWidget);
      fileExitAction->setObjectName(QString::fromUtf8("fileExitAction"));
      helpAboutAction = new QAction(MainWidget);
      helpAboutAction->setObjectName(QString::fromUtf8("helpAboutAction"));
      fileMountAction = new QAction(MainWidget);
      fileMountAction->setObjectName(QString::fromUtf8("fileMountAction"));
      filenew_itemAction = new QAction(MainWidget);
      filenew_itemAction->setObjectName(QString::fromUtf8("filenew_itemAction"));
      fileOpen_folderAction = new QAction(MainWidget);
      fileOpen_folderAction->setObjectName(QString::fromUtf8("fileOpen_folderAction"));
      fileUnmountAction = new QAction(MainWidget);
      fileUnmountAction->setObjectName(QString::fromUtf8("fileUnmountAction"));
      fileSyncAction = new QAction(MainWidget);
      fileSyncAction->setObjectName(QString::fromUtf8("fileSyncAction"));
      fileClearCacheAction = new QAction(MainWidget);
      fileClearCacheAction->setObjectName(QString::fromUtf8("fileClearCacheAction"));

      fileAdvancedAction = new QAction(MainWidget);
      fileAdvancedAction->setObjectName(QString::fromUtf8("fileAdvancedAction"));

      fileQuickSyncAll=new QAction(MainWidget);
      fileQuickSyncAll->setObjectName(QString::fromUtf8("fileQuickSyncAll"));
      fileQuickSyncUp = new QAction(MainWidget);
      fileQuickSyncUp->setObjectName(QString::fromUtf8("fileQuickSyncUp"));
      fileQuickSyncDown = new QAction(MainWidget);
      fileQuickSyncDown->setObjectName(QString::fromUtf8("fileQuickSyncDown"));
      logout = new QAction(MainWidget);
      logout->setObjectName(QString::fromUtf8("logout"));
      //copyMountCommandToClipboard = new QAction(MainWidget);
      showCommandForMount = new QAction(MainWidget);

      widget = new QWidget(MainWidget);
      widget->setObjectName(QString::fromUtf8("widget"));
      widget->setGeometry(QRect(0, 27, 410, 440));

		int y=0, y1=0, y2=0;
      textLabel5 = new QLabel(widget);
      textLabel5->setObjectName(QString::fromUtf8("textLabel2"));
      textLabel5->setGeometry(QRect(20, y, 74, 30));
      textLabel5->setWordWrap(false);
      textLabel5->setText(QApplication::translate("Dialog", "Server", 0, QApplication::UnicodeUTF8));
		comboBox1=new QComboBox(widget);
		comboBox1->setGeometry(QRect(140, y, 240, 31));
		comboBox1->setEditable(true);
		comboBox1->insertItem(0, "");
		comboBox1->insertItem(1, "storagemadeeasy.com");
		comboBox1->insertItem(2, "eu.storagemadeeasy.com");
		comboBox1->insertItem(3, "https://storagemadeeasy.com");
		comboBox1->insertItem(4, "https://eu.storagemadeeasy.com");
//		QLineEdit *edit=new QLineEdit();
//		comboBox1->setLineEdit(edit);
		y+=46;

      textLabel2 = new QLabel(widget);
      textLabel2->setObjectName(QString::fromUtf8("textLabel2"));
      textLabel2->setGeometry(QRect(20, y, 74, 30));
      textLabel2->setWordWrap(false);
      textLabel2->setText(QApplication::translate("Dialog", "Login", 0, QApplication::UnicodeUTF8));
      lineEdit1 = new QLineEdit(widget);
      lineEdit1->setObjectName(QString::fromUtf8("lineEdit1"));
      lineEdit1->setGeometry(QRect(140, y, 240, 31));
		y+=40;

      textLabel3 = new QLabel(widget);
      textLabel3->setObjectName(QString::fromUtf8("textLabel3"));
      textLabel3->setGeometry(QRect(20, y, 81, 30));
      textLabel3->setWordWrap(false);
      textLabel3->setText(QApplication::translate("Dialog", "Password", 0, QApplication::UnicodeUTF8));
      lineEdit2 = new QLineEdit(widget);
      lineEdit2->setObjectName(QString::fromUtf8("lineEdit2"));
      lineEdit2->setGeometry(QRect(140, y, 240, 31));
		lineEdit2->setEchoMode(QLineEdit::Password);
		y+=45;

      textLabel4 = new QLabel(widget);
      textLabel4->setObjectName(QString::fromUtf8("textLabel4"));
      textLabel4->setGeometry(QRect(20, y, 111, 30));
      textLabel4->setWordWrap(false);
      textLabel4->setText(QApplication::translate("Dialog", "Curent folder", 0, QApplication::UnicodeUTF8));
      lineEdit3 = new QLineEdit(widget);
      lineEdit3->setObjectName(QString::fromUtf8("lineEdit3"));
      lineEdit3->setGeometry(QRect(20, y+25, 360, 31));
		y+=65;

      pushButton1 = new QPushButton(widget);
      pushButton1->setObjectName(QString::fromUtf8("pushButton1"));
      pushButton1->setGeometry(QRect(280, y+y1, 100, 35));
      pushButton1->setText(QApplication::translate("Dialog", "Folder", 0, QApplication::UnicodeUTF8));
      pushButton2 = new QPushButton(widget);
      pushButton2->setObjectName(QString::fromUtf8("pushButton2"));
      pushButton2->setGeometry(QRect(20, y+y1, 160, 80));
      pushButton2->setText(QApplication::translate("Dialog", "Mount", 0, QApplication::UnicodeUTF8));

      pushButton11 = new QPushButton(widget);
      pushButton11->setObjectName(QString::fromUtf8("pushButton11"));
      pushButton11->setGeometry(QRect(280, y+y2, 100, 35));
      pushButton11->setText(QApplication::translate("Dialog", "Open folder", 0, QApplication::UnicodeUTF8));
      pushButton21 = new QPushButton(widget);
      pushButton21->setObjectName(QString::fromUtf8("pushButton21"));
      pushButton21->setGeometry(QRect(20, y+y2, 160, 80));
      pushButton21->setText(QApplication::translate("Dialog", "Unmount", 0, QApplication::UnicodeUTF8));
		y+=93;

      pushButton3 = new QPushButton(widget);
      pushButton3->setObjectName(QString::fromUtf8("pushButton3"));
      pushButton3->setGeometry(QRect(150, y, 110, 30));
      pushButton3->setText(QApplication::translate("Dialog", "Hide in tray", 0, QApplication::UnicodeUTF8));
      pushButton4 = new QPushButton(widget);
      pushButton4->setObjectName(QString::fromUtf8("pushButton4"));
      pushButton4->setGeometry(QRect(280, y, 100, 30));
      pushButton4->setText(QApplication::translate("Dialog", "Exit", 0, QApplication::UnicodeUTF8));


      MenuBar = new QMenuBar(MainWidget);
      MenuBar->setObjectName(QString::fromUtf8("MenuBar"));
      MenuBar->setGeometry(QRect(0, 0, 418, 30));
      fileMenu = new QMenu(MenuBar);
      fileMenu->setObjectName(QString::fromUtf8("fileMenu"));
      syncMenu = new QMenu(MenuBar);
      syncMenu->setObjectName(QString::fromUtf8("syncMenu"));
      helpMenu = new QMenu(MenuBar);
      helpMenu->setObjectName(QString::fromUtf8("helpMenu"));
      
      MenuBar->addAction(fileMenu->menuAction());
      MenuBar->addAction(syncMenu->menuAction());
      MenuBar->addAction(helpMenu->menuAction());
      MenuBar->addSeparator();

      fileMenu->addAction(fileMountAction);
      fileMenu->addAction(fileUnmountAction);
      fileMenu->addSeparator();
//      fileMenu->addAction(copyMountCommandToClipboard);
      fileMenu->addAction(showCommandForMount);
      fileMenu->addSeparator();
      fileMenu->addAction(filenew_itemAction);
      fileMenu->addAction(fileOpen_folderAction);
      fileMenu->addSeparator();
      fileMenu->addAction(fileClearCacheAction);
      fileMenu->addSeparator();
      fileMenu->addAction(fileAdvancedAction);
      fileMenu->addSeparator();
      fileMenu->addAction(logout);
      fileMenu->addSeparator();
      fileMenu->addAction(fileExitAction);

      syncMenu->addAction(fileSyncAction);
      syncMenu->addSeparator();
      syncMenu->addAction(fileQuickSyncAll);
      syncMenu->addAction(fileQuickSyncDown);
      syncMenu->addAction(fileQuickSyncUp);
      syncMenu->addSeparator();

      helpMenu->addSeparator();
      helpMenu->addAction(helpAboutAction);
  
      retranslateUi(MainWidget);
  
      QMetaObject::connectSlotsByName(MainWidget);
    } // setupUi

    void retranslateUi(QWidget *MainWidget)
    {

      fileExitAction->setText(QApplication::translate("Dialog", "E&xit", 0, QApplication::UnicodeUTF8));
      fileExitAction->setIconText(QApplication::translate("Dialog", "Exit", 0, QApplication::UnicodeUTF8));
      fileExitAction->setShortcut(QString());
      fileExitAction->setProperty("name", QVariant(QApplication::translate("Dialog", "fileExitAction", 0, QApplication::UnicodeUTF8)));
      helpAboutAction->setText(QApplication::translate("Dialog", "&About", 0, QApplication::UnicodeUTF8));
      helpAboutAction->setIconText(QApplication::translate("Dialog", "About", 0, QApplication::UnicodeUTF8));
      helpAboutAction->setShortcut(QString());

      fileClearCacheAction->setText(QApplication::translate("Dialog", "Clear cache", 0, QApplication::UnicodeUTF8));
      fileClearCacheAction->setIconText(QApplication::translate("Dialog", "Clear cache", 0, QApplication::UnicodeUTF8));
      fileClearCacheAction->setProperty("name", QVariant(QApplication::translate("Dialog", "fileClearCacheAction", 0, QApplication::UnicodeUTF8)));

      fileAdvancedAction->setText(QApplication::translate("Dialog", "&Advanced", 0, QApplication::UnicodeUTF8));
      fileAdvancedAction->setIconText(QApplication::translate("Dialog", "Advanced", 0, QApplication::UnicodeUTF8));
      fileAdvancedAction->setProperty("name", QVariant(QApplication::translate("Dialog", "fileAdvancedAction", 0, QApplication::UnicodeUTF8)));

      fileSyncAction->setText(QApplication::translate("Dialog", "&Sync Center", 0, QApplication::UnicodeUTF8));
      fileSyncAction->setIconText(QApplication::translate("Dialog", "Sync Center", 0, QApplication::UnicodeUTF8));
      fileSyncAction->setProperty("name", QVariant(QApplication::translate("Dialog", "fileAdvancedAction", 0, QApplication::UnicodeUTF8)));

      fileQuickSyncAll->setText(QApplication::translate("Dialog", "Quick Sync All", 0, QApplication::UnicodeUTF8));
      fileQuickSyncAll->setIconText(QApplication::translate("Dialog", "Sync Center", 0, QApplication::UnicodeUTF8));
      fileQuickSyncAll->setProperty("name", QVariant(QApplication::translate("Dialog", "fileQuickSyncAll", 0, QApplication::UnicodeUTF8)));
      fileQuickSyncDown->setText(QApplication::translate("Dialog", "Quick Sync Down", 0, QApplication::UnicodeUTF8));
      fileQuickSyncDown->setIconText(QApplication::translate("Dialog", "Sync Center", 0, QApplication::UnicodeUTF8));
      fileQuickSyncDown->setProperty("name", QVariant(QApplication::translate("Dialog", "fileQuickSyncDown", 0, QApplication::UnicodeUTF8)));
      logout->setText(QApplication::translate("Dialog", "Logout", 0, QApplication::UnicodeUTF8));
      logout->setIconText(QApplication::translate("Dialog", "Sync Center", 0, QApplication::UnicodeUTF8));
      logout->setProperty("name", QVariant(QApplication::translate("Dialog", "Logout", 0, QApplication::UnicodeUTF8)));
      //copyMountCommandToClipboard->setText(QApplication::translate("Dialog", "Copy command for mount to clipboard", 0, QApplication::UnicodeUTF8));
      //copyMountCommandToClipboard->setIconText(QApplication::translate("Dialog", "Sync Center", 0, QApplication::UnicodeUTF8));
      showCommandForMount->setText(QApplication::translate("Dialog", "Show mount command", 0, QApplication::UnicodeUTF8));
      showCommandForMount->setIconText(QApplication::translate("Dialog", "Sync Center", 0, QApplication::UnicodeUTF8));

      fileQuickSyncUp->setText(QApplication::translate("Dialog", "Quick Sync Up", 0, QApplication::UnicodeUTF8));
      fileQuickSyncUp->setIconText(QApplication::translate("Dialog", "Sync Center", 0, QApplication::UnicodeUTF8));
      fileQuickSyncUp->setProperty("name", QVariant(QApplication::translate("Dialog", "fileQuickSyncUp", 0, QApplication::UnicodeUTF8)));

      helpAboutAction->setProperty("name", QVariant(QApplication::translate("Dialog", "helpAboutAction", 0, QApplication::UnicodeUTF8)));
      fileMountAction->setText(QApplication::translate("Dialog", "&Mount", 0, QApplication::UnicodeUTF8));
      fileMountAction->setIconText(QApplication::translate("Dialog", "Mount", 0, QApplication::UnicodeUTF8));
      fileMountAction->setProperty("name", QVariant(QApplication::translate("Dialog", "fileMountAction", 0, QApplication::UnicodeUTF8)));
      filenew_itemAction->setText(QApplication::translate("Dialog", "&Select folder", 0, QApplication::UnicodeUTF8));
      filenew_itemAction->setIconText(QApplication::translate("Dialog", "Select folder", 0, QApplication::UnicodeUTF8));
      filenew_itemAction->setProperty("name", QVariant(QApplication::translate("Dialog", "filenew_itemAction", 0, QApplication::UnicodeUTF8)));
      fileOpen_folderAction->setText(QApplication::translate("Dialog", "&Open folder", 0, QApplication::UnicodeUTF8));
      fileOpen_folderAction->setIconText(QApplication::translate("Dialog", "Open folder", 0, QApplication::UnicodeUTF8));
      fileOpen_folderAction->setProperty("name", QVariant(QApplication::translate("Dialog", "fileOpen_folderAction", 0, QApplication::UnicodeUTF8)));
      fileUnmountAction->setText(QApplication::translate("Dialog", "&Unmount", 0, QApplication::UnicodeUTF8));
      fileUnmountAction->setIconText(QApplication::translate("Dialog", "Unmount", 0, QApplication::UnicodeUTF8));
      fileUnmountAction->setProperty("name", QVariant(QApplication::translate("Dialog", "fileUnmountAction", 0, QApplication::UnicodeUTF8)));

      QFont font;
      font.setFamily(QString::fromUtf8("Serif"));
      font.setPointSize(22);
      pushButton2->setFont(font);
      pushButton21->setFont(font);

      fileMenu->setTitle(QApplication::translate("Dialog", "&File", 0, QApplication::UnicodeUTF8));
      syncMenu->setTitle(QApplication::translate("Dialog", "&Sync", 0, QApplication::UnicodeUTF8));
      helpMenu->setTitle(QApplication::translate("Dialog", "&Help", 0, QApplication::UnicodeUTF8));


      Q_UNUSED(MainWidget);
    } // retranslateUi
};

namespace Ui {
    class MainWidget: public Ui_MainWidget {};
} // namespace Ui

#endif // UI_MYWIDGET_H
