#include "utils.h"
#include "cqthread.h"
#include "fileclass.h"
#include "syncwidget.h"
#include "ui_syncwidget.h"
#include <stdlib.h>

#include <stdio.h>
#include <QtXml>
#include <md5.h>

#include <fcntl.h>
#include <unistd.h>

SyncWidget::SyncWidget(QWidget *parent) : QWidget(parent), ui(new Ui::SyncWidget){
	ui->setupUi(this);

	DEBUG=100;

	isRunning=false;
	timeTokenLastUpdate=QDateTime::currentDateTime();
	timeTokenLastUpdate.addDays(-10);
	countOpeningFolders=0;
	SInitWnd.filesListIsGet=false;
	isLoadedFilesList=false;
	showNotifyAfterScheduledSync=true;
	isPreparedToSync=false;
	isSyncInProcess=false;

	SrunFunction.running=false;
	SRunCommand.error=0;
	SRunCommand.response="";
	SRunCommand.restory="";
	SRunCommand.up_level_command="";
	SRunCommand.response_maxProgress=-1;
	SRunCommand.response_upload=false;
	SRunCommand.response_download=false;
	SRunCommand.filepath="";

//	QMenu *trayIconMenu;
//	trayIconMenu=new QMenu(this);
	trayIcon=new QSystemTrayIcon(this);
//	trayIcon->setContextMenu(trayIconMenu);

//	QObject::connect(trayIcon, SIGNAL(activated(QSystemTrayIcon::ActivationReason)), this, SLOT(showFromTray()));

	needCheckforoldversion=false;
	needHideSynced=true;
	isHidden=false;
	needRunSync=0;

	password = "";
	passwordEncrypted = "";


	encryptPassword="";
	isCanceledAction=false;
	SRunCommand.error=0;

	maxCount=100000;

	wx=0;
	wy=0;
	ww=0;
	wh=0;
	nResize=0;
	versionType=0;		// 0 - haljavna, 1 - platna
	propertiesWnd.versionType=versionType;
	serverHost="storagemadeeasy.com";
	serverAPI="";
	providerLogin="";
	providerPassword="";
	lastDir="";
	needShowLogAfterQuickSync=false;
	deleteFromServerWhenDeletedFromLocal=false;
	deleteFromLocalWhenDeletedFromServer=false;

	logFileName=QDir::homePath() +"/.SMESyncCenter.log";
	pathToIcons="/usr/share/smeclient/";

	token="*";
	filelist=new FileClass[maxCount];

	useProxy=false;
	proxyport=80;
	proxyhost="";
	proxylogin="";
	proxypass="";

	gmt_offset=-100000;
	detailedLogs=1;

	canPasswordBeEncrypted = true;
	encryptionKeyForPassword = getEncryptionKeyForPassword();
	if(decryptSMEPassword(encryptSMEPassword("12345"))!="12345"){
		canPasswordBeEncrypted = false;
	}

	localeEncoding=runCommand("locale charmap", 0, false, false, true);
	if(localeEncoding.indexOf("utf8", 0, Qt::CaseInsensitive)>-1 || localeEncoding.indexOf("utf-8", 0, Qt::CaseInsensitive)>-1){
		localeEncoding="";
	}else if(localeEncoding!=""){
		localeEncoding.replace(QRegExp("[ \t\r\n]+"), "");
	}else{
		localeEncoding="";
	}
	if(localeEncoding!="")	debug("localeEncoding="+localeEncoding +";");
		  propertiesWnd.localeEncoding=localeEncoding;

	fCnfName=QDir::homePath() + "/.StorageMadeEasy.cnf";
	QString fCnfNameOld=QDir::homePath() + "/.SMEStorage.cnf";
	if(!QFile::exists(fCnfName) && QFile::exists(fCnfNameOld)) QFile::rename(fCnfNameOld, fCnfName);

	QDir confDir;
	if(!confDir.exists(QDir::homePath() + "/.storagemadeeasy") && confDir.exists(QDir::homePath() + "/.smestorage"))
		confDir.rename(QDir::homePath() + "/.smestorage", QDir::homePath() + "/.storagemadeeasy");

	clearLogs();

	// Add action to menu File
	aRefresh = ui->fileMenu->addAction(tr("Refresh list of files"));
	ui->fileMenu->addSeparator();
	aAddSyncPair = ui->fileMenu->addAction(tr("Add sync pair"));
	aRemoveSyncPair = ui->fileMenu->addAction(tr("Remove sync pair"));
	ui->fileMenu->addSeparator();
	aExpandAll = ui->fileMenu->addAction(tr("Expand/Collapse folder and subfolders"));
	aHideSynced = ui->fileMenu->addAction(tr("Hide/Show synced files and folders"));
	ui->fileMenu->addSeparator();
	aProperties = ui->fileMenu->addAction(tr("Properties"));
	ui->fileMenu->addSeparator();
	aLogout = ui->fileMenu->addAction(tr("Logout"));

	// Add action to menu Sync
	aSyncAll = ui->syncMenu->addAction(tr("Sync All"));
	ui->syncMenu->addSeparator();
	aSyncDown = ui->syncMenu->addAction(tr("Sync Down"));
	aSyncUp = ui->syncMenu->addAction(tr("Sync Up"));
	ui->syncMenu->addSeparator();
	aCloneDown = ui->syncMenu->addAction(tr("Clone Down"));
	aCloneUp = ui->syncMenu->addAction(tr("Clone Up"));
	ui->syncMenu->addSeparator();
	ui->syncMenu->addSeparator();
	aShowSchedulerLog = ui->syncMenu->addAction(tr("Show scheduler log"));
	aClearSchedulerLog = ui->syncMenu->addAction(tr("Clear scheduler log"));


// Buttons
	QObject::connect(ui->pushButton0, SIGNAL(clicked()),   this, SLOT(brefreshAll()));
	QObject::connect(aRefresh, SIGNAL(triggered()),        this, SLOT(brefreshAll()));
	QObject::connect(ui->pushButton1, SIGNAL(clicked()),   this, SLOT(bsyncAll()));
	QObject::connect(aSyncAll, SIGNAL(triggered()),        this, SLOT(bsyncAll()));
	QObject::connect(ui->pushButton2, SIGNAL(clicked()),   this, SLOT(bsyncUp()));
	QObject::connect(aSyncUp, SIGNAL(triggered()),         this, SLOT(bsyncUp()));
	QObject::connect(ui->pushButton3, SIGNAL(clicked()),   this, SLOT(bsyncDown()));
	QObject::connect(aSyncDown, SIGNAL(triggered()),       this, SLOT(bsyncDown()));
	QObject::connect(ui->pushButton4, SIGNAL(clicked()),   this, SLOT(bcloneUp()));
	QObject::connect(aCloneUp, SIGNAL(triggered()),        this, SLOT(bcloneUp()));
	QObject::connect(ui->pushButton5, SIGNAL(clicked()),   this, SLOT(bcloneDown()));
	QObject::connect(aCloneDown, SIGNAL(triggered()),      this, SLOT(bcloneDown()));
	QObject::connect(ui->pushButton6, SIGNAL(clicked()),   this, SLOT(badd()));
	QObject::connect(aAddSyncPair, SIGNAL(triggered()),    this, SLOT(badd()));
	QObject::connect(ui->pushButton7, SIGNAL(clicked()),   this, SLOT(bremove()));
	QObject::connect(aRemoveSyncPair, SIGNAL(triggered()), this, SLOT(bremove()));
	QObject::connect(ui->pushButton8, SIGNAL(clicked()),   this, SLOT(bproperties()));
	QObject::connect(aProperties, SIGNAL(triggered()),     this, SLOT(bproperties()));
	QObject::connect(ui->pushButton10,SIGNAL(clicked()),   this, SLOT(openAll()));
	QObject::connect(aExpandAll, SIGNAL(triggered()),      this, SLOT(openAll()));
	QObject::connect(ui->pushButton11,SIGNAL(clicked()),   this, SLOT(bhideSynced()));
	QObject::connect(aHideSynced, SIGNAL(triggered()),     this, SLOT(bhideSynced()));
	QObject::connect(ui->pushButton9, SIGNAL(clicked()),   this, SLOT(cancelAction()));

	QObject::connect(aShowSchedulerLog, SIGNAL(triggered()),     this, SLOT(showLogs()));
	QObject::connect(aClearSchedulerLog, SIGNAL(triggered()),    this, SLOT(clearLog()));
	QObject::connect(aLogout, SIGNAL(triggered()),					 this, SLOT(logOut()));

	QObject::connect(ui->tree, SIGNAL(itemChanged(QTreeWidgetItem * , int)), this, SLOT(changed(QTreeWidgetItem * , int)));
	QObject::connect(ui->tree, SIGNAL(itemExpanded(QTreeWidgetItem *)), this, SLOT(openFolder(QTreeWidgetItem *)));

	QObject::connect(&propertiesWnd, SIGNAL(SyncpropertiesWidgetClickOKButton()), this, SLOT(saveProperties()));
	QObject::connect(&propertiesWnd, SIGNAL(SyncpropertiesWidgetShowLogs(QString, QString, QString)), this, SLOT(showLogs(QString, QString, QString)));
	QObject::connect(&providerlog, SIGNAL(saveProviderLog()), this, SLOT(saveProviderLog()));
	QObject::connect(&linkFoldersWnd, SIGNAL(openServerFolder(QString)), this, SLOT(linkFoldersOSF(QString)));
	QObject::connect(&linkFoldersWnd, SIGNAL(link(QString, QString, QString, QString)), this, SLOT(linkAndAddtoTree(QString, QString, QString, QString)));

	propertiesWnd.getCronTasks(false, true, 1);			// This is need for update cron task (from old version to new version)

	loadConfig();
}
//////////////////////////////////////////////////////////////////////
SyncWidget::~SyncWidget(){
	delete ui;
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::bsyncAll(){
debug("bsyncAll()");
	if(isRunningSomething())	return ;
	preparingToSync();
	addToLog("["+ QDateTime::currentDateTime().toString()+"] Sync All\n", 0);
	showMessage("Sync All", true);
	syncAll();
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::bsyncUp(){
	if(isRunningSomething())	return ;
	preparingToSync();
	addToLog("["+ QDateTime::currentDateTime().toString()+"] Sync Up\n", 0);
	showMessage("Sync Up", true);
	syncUp();
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::bsyncDown(){
	if(isRunningSomething())	return ;
	preparingToSync();
	addToLog("["+ QDateTime::currentDateTime().toString()+"] Sync Down\n", 0);
	showMessage("Sync Down", true);
	syncDown();
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::bcloneUp(){
	if(isRunningSomething(false))	return ;
	if(!isHidden && QMessageBox::warning(this, "Warning", "Cloning up (from Desktop to Cloud), will delete non-existent files on Cloud.\nAre you sure you want to continue?",  QMessageBox::Ok, QMessageBox::No)!=QMessageBox::Ok){
		return ;
	}
	isRunningSomething(true);	// This will prepare program

	preparingToSync();
	addToLog("["+ QDateTime::currentDateTime().toString()+"] Clone Up\n", 0);
	showMessage("Clone Up", true);
	cloneUp();
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::bcloneDown(){
	if(isRunningSomething(false))	return ;
	if(!isHidden && QMessageBox::warning(this, "Warning", "Cloning down (from Cloud to Desktop), will delete non-existent files on Desktop.\nAre you sure you want to continue?",  QMessageBox::Ok, QMessageBox::No)!=QMessageBox::Ok){
		return ;
	}
	isRunningSomething(true);	// This will prepare program

	preparingToSync();
	addToLog("["+ QDateTime::currentDateTime().toString()+"] Clone Down\n", 0);
	showMessage("Clone Down", true);
	cloneDown();
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::syncAll(){
debug("syncAll()");
	SrunFunction.running=true;
	SRunCommand.up_level_command="";
	SRunCommand.up_level_command.append(SLOT(syncAll()));
	runSync("", 1, 0, 0);
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::syncUp(){
	SrunFunction.running=true;
	SRunCommand.up_level_command="";
	SRunCommand.up_level_command.append(SLOT(syncUp()));
	runSync("", 2, 0, 0);
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::syncDown(){
	SrunFunction.running=true;
	SRunCommand.up_level_command="";
	SRunCommand.up_level_command.append(SLOT(syncDown()));
	runSync("", 3, 0, 0);
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::cloneUp(){
	SrunFunction.running=true;
	SRunCommand.up_level_command="";
	SRunCommand.up_level_command.append(SLOT(cloneUp()));
	runSync("", 0, 1, 0);
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::cloneDown(){
	SrunFunction.running=true;
	SRunCommand.up_level_command="";
	SRunCommand.up_level_command.append(SLOT(cloneDown()));
	runSync("", 0, 2, 0);
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::removeNodeAndAllChild(QTreeWidgetItem *node, bool removeFileFromServer, bool removeFileFromLocal, bool deleteCurrentNode){
	int count=node->childCount()-1;

	for(int j=count; j>=0; j--){
		QTreeWidgetItem *cnode = node->child(j);
		int c=cnode->childCount();
		if(c>0)	removeNodeAndAllChild(cnode);

		int num=getCountFiles(filelist)-1;
		for(int i=0; i<maxCount && filelist[i].name.length()>0; i++){		// remove child nodes
			if(filelist[i].node==cnode){
//debug("remove"+ filelist[i].name);
				QTreeWidgetItem *n = node->child(j);
				delete n;
				
				if(filelist[i].existsOnServer==1 && removeFileFromServer){
					showMessage("Removing from server", false);
//debug("need delete from server >"+ filelist[i].name);
					deleteFile(filelist[i].id, filelist[i].path+"/"+filelist[i].name, true, false, filelist[i].type);
					filelist[i].existsOnServer=0;
				}

				if(filelist[i].existsOnLocal==1 && removeFileFromLocal){
//debug("need delete from local >"+ filelist[i].name);
					deleteFile(filelist[i].id, filelist[i].path+"/"+filelist[i].name, false, true, filelist[i].type);
					filelist[i].existsOnLocal=0;
				}
				filelist[i]=filelist[num];
				filelist[num]=FileClass("","");			
				num--;
				break;
			}	
		}//for
	}


	if(deleteCurrentNode){
		int num=getCountFiles(filelist)-1;
		for(int i=0; i<maxCount && filelist[i].name.length()>0; i++){		// delete child node
			if(filelist[i].node==node){
//debug("remove"+ filelist[i].name);
				delete filelist[i].node;
				
				if(filelist[i].existsOnServer==1 && removeFileFromServer){
					showMessage("Removing from server", false);
					deleteFile(filelist[i].id, filelist[i].path+"/"+filelist[i].name, true, false, filelist[i].type);
					filelist[i].existsOnServer=0;
				}

				if(filelist[i].existsOnLocal==1 && removeFileFromLocal){
					deleteFile(filelist[i].id, filelist[i].path+"/"+filelist[i].name, false, true, filelist[i].type);
					filelist[i].existsOnLocal=0;
				}

				filelist[i]=filelist[num];
				filelist[num]=FileClass("","");			
				break;
			}	
		}//for
	}

	return ;
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::bremove(){
//debug("bremove()");
	if(isRunningSomething())	return ;
	SrunFunction.running=true;

	if(!ui->tree->currentItem()){
		hideMessage();
		SrunFunction.running=false;
		return ;
	}

	QTreeWidgetItem *parent2;
	parent2=ui->tree->currentItem();

	int numb=-1;
	for(int i=0; i<maxCount && filelist[i].name.length()>0; i++){
		if(filelist[i].node==parent2){
			numb=i;
			break;
		}	
	}//for

	if(numb<0 || filelist[numb].type!=1){
		hideMessage();
		SrunFunction.running=false;
		return ;
	}

	if(!isHidden && QMessageBox::question(this, "Confirm", "Do you want to remove this Sync Pair from this list?",  QMessageBox::Ok, QMessageBox::No)!=QMessageBox::Ok){
		hideMessage();
		return ;
	}

	showMessage("Removing sync pair...", false);

	if(!parent2){
		hideMessage();
		return ;
	}

	while(parent2->parent()){
		parent2=parent2->parent();
	}

	removeNodeAndAllChild(parent2, false, false);

	for(int i=0; i<maxCount && filelist[i].name!=""; i++){		// need get numb again, because files can be shifted after the removing
		if(filelist[i].node==parent2){
			delete filelist[i].node;
			int num=getCountFiles(filelist)-1;
			filelist[i]=filelist[num];
			filelist[num]=FileClass("","");			
			break;
		}
	}

	SrunFunction.running=false;
	hideMessage();
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::start(){
	setWindowPosition();
	QTimer::singleShot(300, this, SLOT(start2()));
//	this->hide();
	return ;
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::start2(){
	if(needCheckforoldversion){ // we are checking in constructor
		QApplication::exit();
		return ;
	}

	if(isHidden && isRunningAnotherWnd()){			// exit if hidden program already run
debug("another window is running! => EXIT");
		QApplication::exit();
		return ;
	}

	if(isHidden) showTrayIcon();
	loadConfig();
	if(!isHidden){
		setWindowPosition();
		if(QFile::exists("/usr/local/bin/smestorage")){		// need show window with information about deleting old version
			QProcess *process2=new QProcess();
			if(!process2->startDetached("smeexplorer --onlycheckforoldversion=1")) debug("Can't show window with information about deleting old version");	
		}
	}

	if(!isHidden) this->show();
	initWnd();
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::bhideSynced(){
debug("bhideSynced()");
	
	if(needHideSynced){
		for(int j=0; j<maxCount && filelist[j].name.length()>0; j++){
//debug("name="+filelist[j].name+";");
			if(!filelist[j].node->parent()){
				debug("hideSynced("+filelist[j].name+")");
				if(hideSynced(filelist[j].node, needHideSynced)==0 && filelist[j].existsOnServer==1 && filelist[j].existsOnLocal==1){
					if(filelist[j].type==1 || (filelist[j].type==0 && filelist[j].localdate==filelist[j].serverdate)){
						filelist[j].node->setHidden(needHideSynced);
					}
				}
			}
		}//for
	}else{
		for(int j=0; j<maxCount && filelist[j].name.length()>0; j++){
			if(filelist[j].node->isHidden()) filelist[j].node->setHidden(needHideSynced);
		}
	}

	if(needHideSynced){
		needHideSynced=false;
	}else{
		needHideSynced=true;
	}
	return ;
}
//////////////////////////////////////////////////////////////////////
int SyncWidget::hideSynced(QTreeWidgetItem *node, bool hide){		// return: 0 - none, 1 - up, 2 - down, 3 - need up or down sub folders
debug("hideSynced()");
	int res=0;
	int count=node->childCount();
	if(count==0) return 0;

	for(int j=0; j<count; j++){
		QTreeWidgetItem *cnode = node->child(j);
		FileClass f=getFileByNode(cnode);
		int L=-1;
		if(f.existsOnLocal==1 && f.existsOnServer==1){
			if((f.type==1 && f.isOpened) || (f.type==0 && f.localdate==f.serverdate))
				L=0;
		}

		int st=0;
		if(f.type==1 && f.isOpened) st=hideSynced(f.node, hide);
		if(st==0 && L==0){
			f.node->setHidden(hide);
			if(res!=1) res=0;
		}else{
			res=1;
		}
	}

	return res;
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::initWnd(){
debug(" initWnd()");
	SrunFunction.running=true;
	SRunCommand.up_level_command="";
	SRunCommand.up_level_command.append(SLOT(initWnd()));

	refreshWnd();
	loadConfig();

	if(login.length()<1 || password.length()<1){
		if(isHidden)	QApplication::exit();
		properties();
		hideMessage();
		SrunFunction.running=false;
		return;
	}

	refreshWnd();
	if(token.length()<2){
		getToken();
		if(token.length()<2){
			hideMessage();
			if(isHidden)	QApplication::exit();
			SrunFunction.running=false;
			return ;
		}
	}

	if(!isHidden && addFoldersList.size()==0){		// Folders list is empty, so need show window for adding folder
		linkFolders();

		SRunCommand.up_level_command="";
		return ;
	}

	oldFilesList=loadFilesListFromFile();

	SRunCommand.error=0;
	SRunCommand.up_level_command="";
	SrunFunction.running=false;

	linkAndAddtoTree("", "0", "");	// build tree
	return ;
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::initWnd2(){
	debug("initWnd2()");
	SrunFunction.running=true;
	SRunCommand.up_level_command="";
//	SRunCommand.up_level_command.append(SLOT(initWnd2()));

	hideMessage();
debug("needRunSync="+intToQstring(needRunSync));
	if(needRunSync!=0){
		if(needRunSync==1){
			bsyncAll();
		}else if(needRunSync==2){
			bsyncUp();
		}else if(needRunSync==3){
			bsyncDown();
		}else if(needRunSync==4){
			bcloneUp();
		}else if(needRunSync==5){
			bcloneDown();
		}
	}

	SRunCommand.error=0;
}
//////////////////////////////////////////////////////////////////////
QList<FileClass> SyncWidget::getLocalFolder(QString folder, bool includeSubfolders){
	QList<FileClass> reslist;
//debug(" getLocalFolder("+folder+", ?)");
	if(folder=="") return reslist;
	folder.replace("//", "/");

	QDir dir(folder);
	int n=0;

	QStringList lstDirs =dir.entryList(QDir::Dirs  |		// get folders
											  QDir::AllDirs |
											  QDir::NoDotAndDotDot);
	QStringList lstFiles=dir.entryList(QDir::Files | QDir::Hidden);		// get files

	foreach (QString entry, lstFiles){
		QString entryAbsPath=folder + "/" + entry;
		entryAbsPath.replace("//", "/");

		QFileInfo absFile(entryAbsPath);
		QDateTime lm=absFile.lastModified();

		FileClass fres;
		fres.name=entry;
//debug("entry = "+entry);
		fres.path=folder;
		fres.type=0;
		if(absFile.isDir()) fres.type=1;			// this need because QDir::Hidden return hidden files and folders.
		fres.pid=-1;
		fres.id=-1;
		fres.localdate=lm;

		fres.existsOnServer=-1;
		fres.existsOnLocal=1;
		reslist << fres;

		if(n % 250 == 1) Cqthread::msleep(50);
		n++;
	}

	foreach(QString entry, lstDirs){
		QString entryAbsPath = folder + "/" + entry;
		entryAbsPath.replace("//", "/");

		//QFileInfo absFile(entryAbsPath);
		//QDateTime lm=absFile.lastModified();

		FileClass fres;
		fres.name=entry;
		fres.path=folder;
		fres.type=1;
		fres.pid=-1;
		fres.id=-1;
		//fres.localdate=lm;

		fres.existsOnServer=-1;
		fres.existsOnLocal=1;
		reslist << fres;
		n++;

		if(n % 250 == 1) Cqthread::msleep(50);
		if(includeSubfolders){
			QList<FileClass> resslist;
			resslist=getLocalFolder(entryAbsPath, includeSubfolders);
			reslist=reslist+resslist;
		}
	}
	return reslist;
}
//////////////////////////////////////////////////////////////////////
QList<FileClass> SyncWidget::getServerFolderRec(double id){		// return all folders/files that is in folder and all subfolders
	QList<FileClass> res;
	if(id<0) return res;

	for(int i=0; i<maxCount && filelist[i].name.length()>0; i++){
		if(filelist[i].pid==id) res << filelist[i];
	}//for

	for(int i=0, sz=res.size(); i<sz; i++){
		if(res.at(i).type==1){
			QList<FileClass> l=getServerFolderRec(res.at(i).id);
			res=res+l;
		}
	}

	return res;
}
///////////////////////////////////////////////////////////////////////
// sync=1 - not sync, sync=1 - sync all, sync=2 - sync up, sync=3 - sync down
// clone=0 - not clone, clone=1 - clone up, clone=2 - clone down
// includeSubDirs=0 - not include sub dirs, includeSubDirs=1 - include sub dirs
void SyncWidget::runSync(QString folder, int sync, int clone, int includeSubDirs){
debug("runSync("+ folder +", "+ QString::number(sync) +", "+ QString::number(clone) +")");
	isSyncInProcess=true;
	if(!isCanceledAction){
		if(!isPreparedToSync){		// Need to open all folders that will be synced
			for(int i=0; (i<maxCount) && (filelist[i].name.length()>0); i++){
				if(!filelist[i].isOpened && filelist[i].type==1 && filelist[i].node->checkState(0)==Qt::CheckState(2)){
					openFolder(filelist[i].node, false);
					if(isCanceledAction){
						hideMessage();
						return ;
					}
				}
			}

			isPreparedToSync=true;
		}

		QString folderName="";
		if(folder==""){
			folderName="";
		}else{
			QDir dr(folder);
			folderName=dr.dirName();
		}

		if(includeSubDirs){}

		int r=0;
		for(int i=0; i<maxCount && filelist[i].name!=""; i++){
			if(((folderName.length()>0 && filelist[i].name==folderName) || folderName.length()<1) && filelist[i].servername!=""){
				if(sync==1 || sync==2){
					//if(filelist[i].isSyncedUp) continue;
					r=runSyncUp(filelist[i].node, false, i);
					if(r==1){
						return ;
					}else if(r==2){
						i=-1;
						continue;
					}else if(r==0){
						filelist[i].isSyncedUp = true;
					}
				}
				if(sync==1 || sync==3){
					//if(filelist[i].isSyncedDown) continue;
					r=runSyncDown(filelist[i].node, false, i);
					if(r==1){
						return ;
					}else if(r==2){
						i=-1;
						continue;
					}else if(r==0){
						filelist[i].isSyncedDown = true;
					}
				}
				if(clone==1){
					r=runCloneUp(filelist[i].node);
					if(r==1){
						return ;
					}else if(r==2){
						i=-1;
						continue;
					}
					r=runSyncUp(filelist[i].node, true, i);
					if(r==1){
						return ;
					}else if(r==2){
						i=-1;
						continue;
					}
				}
				if(clone==2){
					r=runCloneDown(filelist[i].node);
					if(r==1){
						return ;
					}else if(r==2){
						i=-1;
						continue;
					}
					r=runSyncDown(filelist[i].node, true, i);
					if(r==1){
						return ;
					}else if(r==2){
						i=-1;
						continue;
					}
				}
			}	
		}//for

		if(clone==1 || clone==2){
			for(int i=0; i<maxCount && filelist[i].name.length()>0; i++){
				filelist[i].isProcessed=false;
				filelist[i].isSyncedUp=false;
				filelist[i].isSyncedDown=false;
			}
		}
	}else{
		isCanceledAction=false;
	}

	SRunCommand.up_level_command="";

	if(countUploaded<0)		countUploaded=0;
	if(countDownloaded<0)	countDownloaded=0;
	if(countDeletedFromLocal<0)	countDeletedFromLocal=0;
	if(countDeletedFromServer<0)	countDeletedFromServer=0;

	addToLog("Uploaded "+ intToQstring(countUploaded) +" file", 1);
	if(countUploaded!=1) addToLog("s", 1);
	addToLog("\n", 1);

	addToLog("Downloaded "+ intToQstring(countDownloaded) +" file", 1);
	if(countDownloaded!=1) addToLog("s", 1);
	addToLog("\n", 1);

	addToLog("Deleted "+ intToQstring(countDeletedFromServer) +" files/folders from cloud\n", 1);
	addToLog("Deleted "+ intToQstring(countDeletedFromLocal) +" files/folders from local drive\n", 1);
	if(!isHidden && logs.length()>0)	showLogs("", logs);

	if(isHidden && needShowLogAfterQuickSync){
		showLogs("", logs, "", true);
	}

	if(isHidden) writeToFile(logFileName, readFromFile(logFileName)+logs+"\n\n");	// save logs to file

	clearLogs();
	hideMessage();
	SrunFunction.running=false;

debug("saveFilesListToFile()", 101);
	saveFilesListToFile();
debug("saved", 101);


	if(isHidden){
		exitWithMessage(QString("Synchronization completed"));
	}

	return ;
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::preparingToSync(){
	if(!isHidden)	clearLogs();
	saveConfig();

	for(int i=0; (i<maxCount) && (filelist[i].name.length()>0); i++){
		filelist[i].isProcessed = false;
		filelist[i].isSyncedUp = false;
		filelist[i].isSyncedDown = false;
	}
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::clearLogs(){
	countDeletedFromLocal=0;
	countDeletedFromServer=0;
	countUploaded=0;
	countDownloaded=0;
	logs="";
}
//////////////////////////////////////////////////////////////////////
bool SyncWidget::isRemovedOnServer(FileClass file, double pid){
	if(!deleteFromLocalWhenDeletedFromServer) return false;
	if(file.existsOnServer==1) return false;

	QList<FileClass> rs = getOldFilesList("", floatToQstring(pid));

	bool L=false;
	for(int j=0, size=rs.size(); j<size; j++){
		if(rs.at(j).name==file.name && rs.at(j).type==file.type && (file.type==1 || rs.at(j).serverdate==file.localdate)){
			L=true;
			break;
		}
	}

	if(L && file.type==1){
		QString path=file.path+"/"+file.name;
		path.replace("//", "/");

		QList<FileClass> ls=getLocalFolder(path, true);
		QList<FileClass> ls2 = getOldFilesList(path, "", true);

		int sz=ls.size(), sz2=ls2.size();
		for(int i=0; i<sz; i++){
			bool L2=false;
			for(int j=0; j<sz2; j++){
				if(ls.at(i).name==ls2.at(j).name && ls.at(i).path==ls2.at(j).path && ls.at(i).type==ls2.at(j).type && (ls.at(i).type==1 || ls.at(i).localdate==ls2.at(j).localdate)){
					L2=true;
					break;
				}
			}

			if(!L2){
				debug("file "+ ls.at(i).path+"/"+ls.at(i).name +" are created on local!!!");
				L=false;
				break;
			}

		}//for
	}

	return L;
}
//////////////////////////////////////////////////////////////////////
bool SyncWidget::isRemovedOnServer(FileClass file, double pid, bool returnFilelists, QList<FileClass> &oldFilesList, QList<FileClass> &oldFilesListWithSubfolders){
	if(!deleteFromLocalWhenDeletedFromServer) return false;
	if(file.existsOnServer==1) return false;

	QList<FileClass> rs;
	if(oldFilesList.size()==0){
		rs = getOldFilesList("", floatToQstring(pid));
	}else{
		rs = oldFilesList;
	}

	if(returnFilelists && oldFilesList.size()==0){
		oldFilesList = rs;
		if(oldFilesList.size()==0)
			oldFilesList << FileClass(); // We add this empty element, because in this folder is no files. So, without this element we will don't know if list of files is taken
	}

	bool L=false;
	for(int j=0, size=rs.size(); j<size; j++){
		if(rs.at(j).name==file.name && rs.at(j).type==file.type && (file.type==1 || rs.at(j).serverdate==file.localdate)){
			L=true;
			break;
		}
	}

	if(L && file.type==1){
		QString path=file.path+"/"+file.name;
		path.replace("//", "/");

		QList<FileClass> ls=getLocalFolder(path, true);
		QList<FileClass> ls2;
		if(oldFilesListWithSubfolders.size()>0){
			ls2 = oldFilesListWithSubfolders;
			debug("isRemovedOnServer() use filelist 2 from cache", 101);
		}else{
			ls2 = getOldFilesList(path, "", true);
		}

		if(returnFilelists && oldFilesListWithSubfolders.size()==0){
			oldFilesListWithSubfolders = ls2;
			if(oldFilesListWithSubfolders.size()==0)
				oldFilesListWithSubfolders << FileClass(); // We add this empty element, because in this folder is no files. So, without this element we will don't know if list of files is taken
		}

		int sz=ls.size(), sz2=ls2.size();
		for(int i=0; i<sz; i++){
			bool L2=false;
			for(int j=0; j<sz2; j++){
				if(ls.at(i).name==ls2.at(j).name && ls.at(i).path==ls2.at(j).path && ls.at(i).type==ls2.at(j).type && (ls.at(i).type==1 || ls.at(i).localdate==ls2.at(j).localdate)){
					L2=true;
					break;
				}
			}

			if(!L2){
				debug("file "+ ls.at(i).path+"/"+ls.at(i).name +" are created on local!!!");
				L=false;
				break;
			}

		}//for
	}

	return L;
}
//////////////////////////////////////////////////////////////////////
// if return 0 - all is ok, if return 1 - some function is running (need wait), 2 - some files from filelist have been removed
int SyncWidget::runSyncUp(QTreeWidgetItem *node, bool ignoreTime, int index){
debug(" runSyncUp("+ QString::number(index) +") ");
	int i=0;
	if(index>=0){
		i = index;
	}

	double pid=-1;
	for(; i<maxCount && filelist[i].name!=""; i++){
		if(filelist[i].node==node){
			if(filelist[i].node->checkState(0)!=Qt::CheckState(2))	return 0;

			if(isRemovedOnServer(filelist[i], filelist[i].pid)){	// need remove from local
				FileClass fileEl=filelist[i];
				if(filelist[i].type==1){		// need remove subfolders and subfiles from local and from tree
					removeNodeAndAllChild(filelist[i].node);
				}

				deleteFile(fileEl.id, fileEl.path+"/"+fileEl.name, false, true, fileEl.type);
				delete fileEl.node;
				int num=getCountFiles(filelist)-1;
				fileEl=filelist[num];
				filelist[num]=FileClass("","");			
				return 2;
			}

			if(filelist[i].type==0 && filelist[i].existsOnServer!=1){
				if(filelist[i].localdate>filelist[i].serverdate || ignoreTime){
					if(SUploadFile.f.name==filelist[i].name && SUploadFile.f.pid==filelist[i].pid && SUploadFile.f.id>0){
						filelist[i].id=SUploadFile.f.id;
						filelist[i].serverdate=SUploadFile.f.serverdate;
						filelist[i].existsOnServer=SUploadFile.f.existsOnServer;
						if(isCanceledAction) return 0;
					}else{
						if(isCanceledAction) return 0;
						if(filelist[i].isSyncedUp) return 0;
						filelist[i].isSyncedUp=true;
						uploadFile2(filelist[i].name, filelist[i].path+"/"+filelist[i].name, filelist[i].pid, filelist[i].id, filelist[i].localdate, false);
						return 1;
					}
					editNode(filelist[i].name, filelist[i].path+"/"+filelist[i].name, filelist[i].id, filelist[i].pid, filelist[i].type, filelist[i].existsOnServer, filelist[i].existsOnLocal, filelist[i].localdate, filelist[i].serverdate, filelist[i].node, false, i, filelist[i].servername);
				}
				return 0;
			}

			if(filelist[i].type==1 && filelist[i].existsOnServer!=1){
//debug(SCreateFolder.f.name+"=="+filelist[i].name);
				if(SCreateFolder.f.name==filelist[i].name && SCreateFolder.f.pid==filelist[i].pid && SCreateFolder.f.id>0){
					filelist[i].id=SCreateFolder.f.id;
					filelist[i].serverdate=SCreateFolder.f.serverdate;
					filelist[i].existsOnServer=SCreateFolder.f.existsOnServer;
					if(isCanceledAction) return 0;
//debug("pid1="+floatToQstring(SCreateFolder.f.id));
				}else{
					if(isCanceledAction) return 0;
					if(filelist[i].isSyncedUp) return 0;
					filelist[i].isSyncedUp=true;
					createFolder2(filelist[i].name, filelist[i].pid, false);
					return 1;
				}

				editNode(filelist[i].name, filelist[i].path+"/"+filelist[i].name, filelist[i].id, filelist[i].pid, filelist[i].type, filelist[i].existsOnServer, filelist[i].existsOnLocal, filelist[i].localdate, filelist[i].serverdate, filelist[i].node, false, i, filelist[i].servername);
			}

			pid=filelist[i].id;
			break;
		}	
	}//for

	if(pid<0)	return 0;
	Cqthread::msleep(40);

	int count=node->childCount();
	for(int j=0; j<count; j++){
		QTreeWidgetItem *cnode=node->child(j);
		if(j % 500 == 1) Cqthread::msleep(30);
		for(i=0; i<maxCount && filelist[i].name!=""; i++){
			if(filelist[i].node==cnode){
				if(!filelist[i].isSyncedUp){
					if(filelist[i].node->checkState(0)!=Qt::CheckState(2)) break;

					if(isRemovedOnServer(filelist[i], pid)){	// need remove from local
						debug("file => "+filelist[i].name+" is removed from server need remove it from local");
						FileClass fileEl=filelist[i];
						if(filelist[i].type==1){		// need remove subfolders and files from local and from tree
							removeNodeAndAllChild(filelist[i].node);
						}

						deleteFile(fileEl.id, fileEl.path+"/"+fileEl.name, false, true, fileEl.type);

						for(int k=0; k<maxCount && filelist[k].name.length()>0; k++){
							if(filelist[k].node==fileEl.node){
								delete filelist[k].node;
								int num=getCountFiles(filelist)-1;
								filelist[k]=filelist[num];
								filelist[num]=FileClass("","");
								break;
							}
						}

						j=-1; // restart
						break;
					}
				}

				if(filelist[i].type==1){		// folder
					if(filelist[i].existsOnServer!=1){
//debug("name2="+filelist[i].name);
						if(SCreateFolder.f.name==filelist[i].name && SCreateFolder.f.pid==pid && SCreateFolder.f.id>0){
							filelist[i].id=SCreateFolder.f.id;
							filelist[i].pid=pid;
							filelist[i].serverdate=SCreateFolder.f.serverdate;
							filelist[i].existsOnServer=SCreateFolder.f.existsOnServer;
							editNode(filelist[i].name, filelist[i].path+"/"+filelist[i].name, filelist[i].id, filelist[i].pid, filelist[i].type, filelist[i].existsOnServer, filelist[i].existsOnLocal, filelist[i].localdate, filelist[i].serverdate, filelist[i].node, false, i, filelist[i].servername);
							if(isCanceledAction) return 0;
						}else{
							if(isCanceledAction) return 0;
							if(filelist[i].isSyncedUp) break;
							filelist[i].isSyncedUp=true;
							createFolder2(filelist[i].name, pid, false);
							return 1;
						}
					}

//					runSyncUp(filelist[i].node, ignoreTime);
					if(filelist[i].id>0){
						int r=runSyncUp(filelist[i].node, ignoreTime, i);
						if(r==1){
							return 1;
						}else if(r==2){
							j=-1; // restart
						}
					}
					break;
				}else{					// file
					if(filelist[i].localdate>filelist[i].serverdate || ignoreTime){
						if(SUploadFile.f.name==filelist[i].name && SUploadFile.f.pid==pid && SUploadFile.f.id>0){
							filelist[i].id=SUploadFile.f.id;
							filelist[i].pid=pid;
							filelist[i].serverdate=SUploadFile.f.serverdate;
							filelist[i].existsOnServer=SUploadFile.f.existsOnServer;
							if(isCanceledAction) return 0;
						}else{
							if(isCanceledAction) return 0;
							if(filelist[i].isSyncedUp) break;
							filelist[i].isSyncedUp=true;
							uploadFile2(filelist[i].name, filelist[i].path+"/"+filelist[i].name, pid, filelist[i].id, filelist[i].localdate, false);
							return 1;
						}
						editNode(filelist[i].name, filelist[i].path+"/"+filelist[i].name, filelist[i].id, filelist[i].pid, filelist[i].type, filelist[i].existsOnServer, filelist[i].existsOnLocal, filelist[i].localdate, filelist[i].serverdate, filelist[i].node, false, i, filelist[i].servername);
					}else{
						filelist[i].isSyncedUp=true;			// This file is up to date, so we mark it as processed 
					}
				}
				break;
			}	
		}//for
	}//for

	return 0;
}
//////////////////////////////////////////////////////////////////////
QList<FileClass> SyncWidget::getOldFilesList(QString path, QString id, bool includeSubfolders, bool returnOnlyOneFile){
	// returnOnlyOneFile - mean return only file with the same id as in parameter "id"
//debug("getOldFilesList("+path+", "+id+")");
	QList<FileClass> reslist;
	if(oldFilesList.length()<1) return reslist;

	QDomDocument doc("response");
	doc.setContent(oldFilesList, true);

	QDomElement root=doc.documentElement();
	QDomNode n=root.firstChild();
	for(; !n.isNull(); n=n.nextSibling()){
		QDomElement e=n.toElement();
		if(!e.isNull()){
			if(e.tagName()=="f"){
				QString fid="", pid="", name="", fpath="", type="", lmodify="", smodify="";
				QDomNode nf=n.firstChild();
				QDomElement eid=nf.toElement();
				if(eid.tagName()=="id")	fid=eid.text();

				nf = nf.nextSibling();
				QDomElement epid=nf.toElement();
				if(epid.tagName()=="pid") pid=epid.text();

				nf = nf.nextSibling();
				QDomElement ename=nf.toElement();
				if(ename.tagName()=="name")	name=decodeBase64(ename.text());

				nf = nf.nextSibling();
				QDomElement epath=nf.toElement();
				if(epath.tagName()=="path") fpath=decodeBase64(epath.text());

				nf = nf.nextSibling();
				QDomElement elmodify=nf.toElement();
				if(elmodify.tagName()=="lmodify")	lmodify=elmodify.text();

				nf = nf.nextSibling();
				elmodify=nf.toElement();
				if(elmodify.tagName()=="smodify")	smodify=elmodify.text();

				nf = nf.nextSibling();
				QDomElement etype = nf.toElement();
				if(etype.tagName()=="type")	type=etype.text();

				uint uld=lmodify.toInt(), usd=smodify.toInt();
				if(path!=""){
					if(!includeSubfolders && fpath!=path) continue;
					if(includeSubfolders && fpath.indexOf(path)!=0) continue;
				}else if(id!=""){
					if(id!=pid) continue;
//				}else{
//					continue;
				}

				FileClass fres;
				fres.name=name;
				fres.type=type.toInt();
				fres.pid=pid.toDouble();
				fres.id=fid.toDouble();
				fres.path=fpath;
				fres.localdate=QDateTime::fromTime_t(uld);
				fres.serverdate=QDateTime::fromTime_t(usd);

				fres.existsOnServer=-1;
				fres.existsOnLocal=-1;
				if(fid!="") fres.existsOnServer=1;
				if(fpath!="") fres.existsOnServer=1;

				if(returnOnlyOneFile){
					if(id!="" && id==pid){		// We need to return only this file
						reslist << fres;
						return reslist;
					}
				}else{
					reslist << fres;
				}

				if(includeSubfolders && path=="" && id!="" && fres.type==1){
					reslist+=getOldFilesList(fres.path, floatToQstring(fres.id), includeSubfolders);
				}
			}
		}
	}//for

	return reslist;
}
//////////////////////////////////////////////////////////////////////
bool SyncWidget::isRemovedOnLocal(FileClass file, QString folder){
	if(!deleteFromServerWhenDeletedFromLocal) return false;
	if(file.existsOnLocal==1) return false;
//debug("isRemovedOnLocal("+file.name+", "+folder+") => id= "+floatToQstring(file.id)+ ";  file.name= "+file.name);
	folder.replace("//", "/");

	bool L=false;
	QList<FileClass> ls = getOldFilesList(folder, "");

	QString fullname=getCorrectFilePath(folder+"/"+file.name);
	int sz=ls.size();
	for(int i=0; i<sz; i++){
		QString f=folder+"/"+ls.at(i).name;
		f.replace("//", "/");
		if(f==fullname && ls.at(i).type==file.type && (file.type==1 || ls.at(i).localdate==file.serverdate)){
//			debug("Looks like removed from local => "+ls.at(i).name);
			L=true;
			break;
		}
	}

	if(L && file.type==1){	// cheking, maybe user created new file in this folder
		QList<FileClass> ls=getServerFolderRec(file.id);
		QList<FileClass> ls2 = getOldFilesList("", floatToQstring(file.id), true);

		int sz=ls.size(), sz2=ls2.size();
		for(int i=0; i<sz; i++){
			bool L2=false;
			for(int j=0; j<sz2; j++){
				if(ls.at(i).id==ls2.at(j).id && (ls.at(i).type==1 || ls.at(i).serverdate==ls2.at(j).serverdate)){
					L2=true;
					break;
				}
			}

			if(!L2){
				debug("file "+ ls.at(i).path+"/"+ls.at(i).name +" are created on server!!!");
				L=false;
				break;
			}
		}//for
	}

	if(L) debug("Removed from local => "+fullname);
	return L;
}
//////////////////////////////////////////////////////////////////////
bool SyncWidget::isRemovedOnLocal(FileClass file, QString folder, bool returnFilelists, QList<FileClass> &oldFilesList, QList<FileClass> &oldFilesListWithSubfolders){
	if(!deleteFromServerWhenDeletedFromLocal) return false;
	if(file.existsOnLocal==1) return false;
//debug("isRemovedOnLocal("+file.name+", "+folder+") => id= "+floatToQstring(file.id)+ ";  file.name= "+file.name);
	folder.replace("//", "/");

	bool L=false;
	QList<FileClass> ls;
	if(returnFilelists && oldFilesList.size()>0){
		ls = oldFilesList;
	}else{
		ls = getOldFilesList(folder, "");
	}

	if(returnFilelists && oldFilesList.size()==0){
		oldFilesList = ls;
		if(oldFilesList.size()==0)
			oldFilesList << FileClass(); // We add this empty element, because in this folder is no files. So, without this element we will don't know if list of files is taken
	}

	QString fullname=getCorrectFilePath(folder+"/"+file.name);
	int sz=ls.size();
	for(int i=0; i<sz; i++){
		QString f=folder+"/"+ls.at(i).name;
		f.replace("//", "/");
		if(f==fullname && ls.at(i).type==file.type && (file.type==1 || ls.at(i).localdate==file.serverdate)){
//			debug("Looks like removed from local => "+ls.at(i).name);
			L=true;
			break;
		}
	}

	if(L && file.type==1){	// cheking, maybe user created new file in this folder
		QList<FileClass> ls=getServerFolderRec(file.id);
		QList<FileClass> ls2;
		if(returnFilelists && oldFilesListWithSubfolders.size()>0){
			ls2 = oldFilesListWithSubfolders;
			debug("isRemovedOnLocal() use filelist 2 from cache", 101);
		}else{
			ls2 = getOldFilesList("", floatToQstring(file.id), true);
		}

		if(returnFilelists && oldFilesListWithSubfolders.size()){
			oldFilesListWithSubfolders = ls2;
			if(oldFilesListWithSubfolders.size()==0)
				oldFilesListWithSubfolders << FileClass(); // We add this empty element, because in this folder is no files. So, without this element we will don't know if list of files is taken
		}

		int sz=ls.size(), sz2=ls2.size();
		for(int i=0; i<sz; i++){
			bool L2=false;
			for(int j=0; j<sz2; j++){
				if(ls.at(i).id==ls2.at(j).id && (ls.at(i).type==1 || ls.at(i).serverdate==ls2.at(j).serverdate)){
					L2=true;
					break;
				}
			}

			if(!L2){
				debug("file "+ ls.at(i).path+"/"+ls.at(i).name +" are created on server!!!");
				L=false;
				break;
			}
		}//for
	}

	if(L) debug("Removed from local => "+fullname);
	return L;
}
//////////////////////////////////////////////////////////////////////
// if return 0 - all is ok, if return 1 - some function is running (need wait), 2 - some files from filelist have been removed
int SyncWidget::runSyncDown(QTreeWidgetItem *node, bool ignoreTime, int index){
debug(" runSyncDown() ");
	int i=0;
	if(index>=0){
		i = index;
	}

	QString path="";
	for(; i<maxCount && filelist[i].name.length()>0; i++){
		if(filelist[i].node==node){
			if(filelist[i].node->checkState(0)!=Qt::CheckState(2))	return -1;
			if(isRemovedOnLocal(filelist[i], filelist[i].path)){	// need remove from server
debug("file => "+filelist[i].name+" is removed from local need remove it from server");
				if(isCanceledAction) return 0;
				//if(filelist[i].isSyncedDown) break;
				//filelist[i].isSyncedDown=true;
				bool rs=deleteFile3(filelist[i].id, filelist[i].path+"/"+filelist[i].name, true, false, filelist[i].type);
				if(rs){
					FileClass fileEl=filelist[i];
					if(filelist[i].type==1){			// need remove subfolders and files from tree
						removeNodeAndAllChild(filelist[i].node);
						for(int k=0; k<maxCount && filelist[k].name!=""; k++){
							if(filelist[k].node==fileEl.node){
								delete filelist[k].node;
								int num=getCountFiles(filelist)-1;
								filelist[k]=filelist[num];
								filelist[num]=FileClass("","");
								break;
							}
						}
					}else{
						delete filelist[i].node;
						int num=getCountFiles(filelist)-1;
						filelist[i]=filelist[num];
						filelist[num]=FileClass("","");
					}
					return 2;
				}
			}

			if(filelist[i].type==0){
				if(filelist[i].localdate<filelist[i].serverdate || ignoreTime){
					if(SDownloadFile.id==filelist[i].id){
						filelist[i].path=SDownloadFile.f.path;
						filelist[i].localdate=SDownloadFile.f.localdate;

						filelist[i].existsOnLocal=SDownloadFile.f.existsOnLocal;
					}else{
						if(isCanceledAction) return 0;
						if(filelist[i].isSyncedDown) return 0;
						filelist[i].isSyncedDown=true;
						downloadFile2(filelist[i].path+"/"+filelist[i].name, filelist[i].id, filelist[i].serverdate);
						return 1;
					}
					editNode(filelist[i].name, filelist[i].path+"/"+filelist[i].name, filelist[i].id, filelist[i].pid, filelist[i].type, filelist[i].existsOnServer, filelist[i].existsOnLocal, filelist[i].localdate, filelist[i].serverdate, filelist[i].node, false, i, filelist[i].servername);
					if(isCanceledAction) return 0;
				}
				return 0;
			}

			if(filelist[i].type==1 && filelist[i].existsOnLocal!=1){
				if(filelist[i].isSyncedDown) return 0;
				filelist[i].isSyncedDown=true;
				QDir dr(filelist[i].path);
				dr.mkdir(filelist[i].name);
				filelist[i].localdate=filelist[i].serverdate;
				filelist[i].existsOnLocal=1;

				editNode(filelist[i].name, filelist[i].path+"/"+filelist[i].name, filelist[i].id, filelist[i].pid, filelist[i].type, filelist[i].existsOnServer, filelist[i].existsOnLocal, filelist[i].localdate, filelist[i].serverdate, filelist[i].node, false, i, filelist[i].servername);
			}

			path=filelist[i].path +"/"+ filelist[i].name;
			path.replace("//", "/");
			break;
		}	
	}//for

	Cqthread::msleep(40);

	int j=0;
	int count=node->childCount();
	for(; j<count; j++){
		QTreeWidgetItem *cnode = node->child(j);
		if(j % 500 == 1) Cqthread::msleep(30);
		for(i=0; i<maxCount && filelist[i].name.length()>0; i++){
			if(filelist[i].node==cnode){
				if(!filelist[i].isSyncedDown){
					if(filelist[i].node->checkState(0)!=Qt::CheckState(2))	break;

					if(isRemovedOnLocal(filelist[i], path)){	// need remove from server
						debug("file => "+filelist[i].name+" is removed from local need remove it from server");
						if(isCanceledAction) return 0;
						if(filelist[i].isSyncedDown) break;
						filelist[i].isSyncedDown=true;
						bool rs=deleteFile3(filelist[i].id, filelist[i].path+"/"+filelist[i].name, true, false, filelist[i].type);
						if(rs){
							FileClass fileEl=filelist[i];
							if(filelist[i].type==1){			// need remove subfolders and files from tree
								removeNodeAndAllChild(filelist[i].node);
								for(int k=0; k<maxCount && filelist[k].name!=""; k++){
									if(filelist[k].node==fileEl.node){
										delete filelist[k].node;
										int num=getCountFiles(filelist)-1;
										filelist[k]=filelist[num];
										filelist[num]=FileClass("","");
										break;
									}
								}
								count=node->childCount();
							}else{
								delete filelist[i].node;
								int num=getCountFiles(filelist)-1;
								filelist[i]=filelist[num];
								filelist[num]=FileClass("","");
							}
							j=-1;		// restart
							break;
						}
					}
				}

				if(filelist[i].type==1){		// folder
					if(filelist[i].existsOnLocal!=1){
						if(filelist[i].isSyncedDown) break;
						filelist[i].isSyncedDown=true;
						QDir dr(path);
						dr.mkdir(filelist[i].name);
						filelist[i].path=path;
						filelist[i].localdate=filelist[i].serverdate;
						filelist[i].existsOnLocal=1;

						editNode(filelist[i].name, filelist[i].path+"/"+filelist[i].name, filelist[i].id, filelist[i].pid, filelist[i].type, filelist[i].existsOnServer, filelist[i].existsOnLocal, filelist[i].localdate, filelist[i].serverdate, filelist[i].node, false, i, filelist[i].servername);
					}
					if(runSyncDown(filelist[i].node, ignoreTime, i)==1) return 1;
				}else{					// file
					if(filelist[i].localdate<filelist[i].serverdate || ignoreTime){
						if(SDownloadFile.id==filelist[i].id){
							filelist[i].path=SDownloadFile.f.path;
							filelist[i].localdate=SDownloadFile.f.localdate;
							filelist[i].existsOnLocal=SDownloadFile.f.existsOnLocal;
						}else{
							if(isCanceledAction) return 0;
							if(filelist[i].isSyncedDown) break;
							filelist[i].isSyncedDown=true;

							downloadFile2(path+"/"+filelist[i].name, filelist[i].id, filelist[i].serverdate);
							return 1;
						}

						editNode(filelist[i].name, path+"/"+filelist[i].name, filelist[i].id, filelist[i].pid, filelist[i].type, filelist[i].existsOnServer, filelist[i].existsOnLocal, filelist[i].localdate, filelist[i].serverdate, filelist[i].node, false, i, filelist[i].servername);
						if(isCanceledAction) return 0;
					}else{
						filelist[i].isSyncedDown=true;			// This file is up to date, so we mark it as processed 
					}
				}
				break;
			}
		}//for
	}//for

	return 0;
}
//////////////////////////////////////////////////////////////////////
int SyncWidget::runCloneUp(QTreeWidgetItem *node){
debug(" runCloneUp() ");
	int count=node->childCount();
	for(int j=count-1; j>=0; j--){
		QTreeWidgetItem *cnode = node->child(j);
		if(runCloneUp(cnode)==1) return 1;
	}

	for(int i=0; i<maxCount && filelist[i].name!=""; i++){
		if(filelist[i].node==node){
			if(filelist[i].node->checkState(0)!=Qt::CheckState(2))	return -1;

			if(filelist[i].existsOnServer==1 && filelist[i].existsOnLocal!=1){
				if(filelist[i].existsOnServer==1){
					if(isCanceledAction) return 0;
					if(filelist[i].isProcessed) break;
					filelist[i].isProcessed=true;
					bool rs=deleteFile3(filelist[i].id, filelist[i].path+"/"+filelist[i].name, true, false, filelist[i].type);
					if(rs){
						if(filelist[i].type==1){			// need remove subfolders and files from tree
							removeNodeAndAllChild(filelist[i].node);
							for(int k=0; k<maxCount && filelist[k].name!=""; k++){
								if(filelist[k].node==filelist[i].node){
									delete filelist[k].node;
									int num=getCountFiles(filelist)-1;
									filelist[k]=filelist[num];
									filelist[num]=FileClass("","");
									break;
								}
							}
						}else{
							QTreeWidgetItem *pnode=node->parent();			// remove node from tree
							if(pnode){
								bool isExpanded=pnode->isExpanded();
								pnode->setExpanded(true);
								delete filelist[i].node;
								pnode->setExpanded(isExpanded);
							}else{
								delete filelist[i].node;
							}

							int num=getCountFiles(filelist)-1;
							filelist[i]=filelist[num];
							filelist[num]=FileClass("","");
						}
					}

				}
			}
			break;
		}	
	}//for

	return 0;
}
//////////////////////////////////////////////////////////////////////
int SyncWidget::runCloneDown(QTreeWidgetItem *node){
//debug(" runCloneDown() ");
	int count=node->childCount();
	for(int j=count-1; j>=0; j--){
		QTreeWidgetItem *cnode = node->child(j);
		if(runCloneDown(cnode)==1) return 1;
	}

	int num=getCountFiles(filelist)-1;
	for(int i=0; i<maxCount && filelist[i].name.length()>0; i++){
		if(filelist[i].node==node){
			if(filelist[i].node->checkState(0)!=Qt::CheckState(2))	return -1;

			if(filelist[i].existsOnLocal==1 && filelist[i].existsOnServer!=1){
				if(filelist[i].existsOnLocal==1)	deleteFile(filelist[i].id, filelist[i].path+"/"+filelist[i].name, false, true, filelist[i].type);

				if(filelist[i].type==1){			// need remove subfolders and files from tree
					removeNodeAndAllChild(filelist[i].node);
					for(int k=0; k<maxCount && filelist[k].name!=""; k++){
						if(filelist[k].node==filelist[i].node){
							delete filelist[k].node;
							filelist[k]=filelist[num];
							filelist[num]=FileClass("","");
							num--;
							break;
						}
					}
				}else{
					QTreeWidgetItem *pnode=node->parent();
					if(pnode){
						bool isExpanded=pnode->isExpanded();
						pnode->setExpanded(true);
						delete filelist[i].node;
						pnode->setExpanded(isExpanded);
					}else{
						delete filelist[i].node;
					}
					filelist[i]=filelist[num];
					filelist[num]=FileClass("","");			
					num--;
					break;
				}
			}
			break;
		}	
	}//for

	return 0;
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::deleteFile(double id, QString fullname, bool fromServer, bool fromLocal, int type){
debug("deleteFile(id, "+fullname+", fromServer, fromLocal, type)");
	QString mess="";
	if(type==0){
		mess+="file ";
	}else{
		mess+="folder ";
	}

	mess+=getPathByFile(id, fullname, !fromServer);
	if(fromLocal && fromServer){
		mess+=" from local drive and from cloud ";
	}else if(fromServer){
		mess+=" from cloud ";
	}else if(fromLocal){
		mess+=" from local drive";
	}

	showMessage("Deleting a "+ mess, true, false);
	addToLog("Delete a "+ mess +"\n", 2);

	if(fromServer){
		QString com="deletefile "+ getLoginAndPasswordForCMD() +" \""+ token +"\" "+ floatToQstring(id) +" "+ floatToQstring(type) +" --sync";

		QString list=runCommand(com);
		refreshWnd();

		if(list=="<response>Success</response>"){
			countDeletedFromServer++;
		}else{
//			QMessageBox::critical(this, tr("Error"), "File not deleted");
		}

	}

	if(fromLocal){
		fullname.replace("//", "/");

		if(type==0){
			QFile fl(fullname);
			fl.remove();
		}else{
			fullname.replace("\\", "\\\\");
			fullname.replace("\"", "\\\"");
			fullname.replace("$", "\\$");
			QString command="rm -rf \""+fullname+"\"";
debug(command);

			QByteArray tmCommand;
			if(localeEncoding!=""){
				QTextCodec *codec = QTextCodec::codecForName(localeEncoding.toUtf8().data());
				tmCommand = codec->fromUnicode(command);
			}else{
				tmCommand = command.toUtf8();
			}

			bool LL0=true;
			if(system(tmCommand.data())!=0 && localeEncoding!=""){		// try to use UTF-8 name
				tmCommand = command.toUtf8();
				if(system(tmCommand.data())==0)  LL0=false;
			}else{
				LL0=false;
			}

			if(LL0){
debug("Can't remove folder. Try another method");
				QDir fr(fullname);
				fr.rmdir(fullname);		// This method remove only empty folder
			}
		}

		if(QFile::exists(fullname)){
			addToLog("Error. Cannot delete file from local "+ fullname +"\n", 0);
		}else{
			countDeletedFromLocal++;
		}
	}

}
//////////////////////////////////////////////////////////////////////
QString SyncWidget::getPathByFile(double id, QString path, bool onLocal){
//debug("getPathByFile("+floatToQstring(id)+", "+path+", "+intToQstring(onLocal)+");");
	path=path.replace("//", "/");
	QString res="";
	if(onLocal){
		if(path.length()>1) res=path;
	}else{
		for(int i=0; i<maxCount && filelist[i].name.length()>0; i++){
			if(filelist[i].id==id){
				if(filelist[i].node->parent()){
					res=getPathByFile(filelist[i].pid, path, onLocal) +"/"+ filelist[i].name;
				}else{
					if(filelist[i].servername!="") return filelist[i].servername;
					return "/";
				}
				break;
			}
		}
	}

	return res.replace("//", "/");
}
//////////////////////////////////////////////////////////////////////
bool SyncWidget::deleteFile3(double id, QString fullname, bool fromServer, bool fromLocal, int type){
debug("deleteFile3()");
	if(fromLocal){
		deleteFile(id, fullname, fromServer, fromLocal, type);
	}

	if(fromServer){
		QString mess="", path=getPathByFile(id, fullname, !fromServer);
		if(type==0){
			mess+="file ";
		}else{
			mess+="folder ";
		}

		mess+=path;
		if(fromLocal && fromServer){
			mess+=" from local drive and from cloud ";
		}else if(fromServer){
			mess+=" from cloud ";
		}else if(fromLocal){
			mess+=" from local drive";
		}

		showMessage("Deleting a "+ mess, true, false);
		addToLog("Delete a "+ mess +"\n", 2);

		QString uri=(type==0) ? ("doDeleteFile") : ("doDeleteFolder");
		uri+="/"+ base64(floatToQstring(id));

		TrunFunction3 response1=runFunction3(uri);

		QString status=getPartQString(response1.response, "<status>", "</status>");
		QString statusmessage=getPartQString(response1.response, "<statusmessage>", "</statusmessage>");
		if(status!="ok"){
			if(statusmessage.length()<5) statusmessage="";
			addToLog("Error. Cannot delete file from cloud "+ SDeleteFile.filePath +"   "+statusmessage+"\n", 0);
			return false;
		}
		countDeletedFromServer++;
	}
debug("Success deleted", 0);
	return true;
}
//////////////////////////////////////////////////////////////////////
QString SyncWidget::runCommand(QString command, int maxProgress, bool upload, bool download, bool external){
	QString cmdQSt="";
	if(!external){
		cmdQSt="smemount --server=\""+serverAPI+"\" ";
		if(isHidden)	cmdQSt="perl /usr/bin/smemount --server=\""+serverAPI+"\" ";
	}

	QDateTime startTime=QDateTime::currentDateTime();
	QString tokenCopy=token;

	cmdQSt.append(command);
	int stimeout=35;
//	int maxtimeout=30;
	int nn0=20000;
	char buf[nn0];

	QString buf2="";
	FILE *ptr;
	for(int i=0; i<nn0; i++){
		buf[i]=' ';
	}

	if(command.indexOf("openssl ")==-1 && command.indexOf("gettoken")==-1 && command.indexOf("dmidecode")==-1){
		debug(cmdQSt);
	}

	ptr = popen(cmdQSt.toUtf8().data(), "r");
	int ptrd = fileno(ptr);
	fcntl(ptrd, F_SETFL, O_NONBLOCK);
	if(!upload && !download){
		ssize_t r = read(ptrd, buf, nn0);
		while(r==-1){
			Cqthread::msleep(stimeout);
			r=read(ptrd, buf, nn0);
		}

		QString s_utf8=QString::fromUtf8(buf);
		buf2.append(s_utf8);
		buf2=buf2.mid(0, nn0-1);

		int s01=buf2.lastIndexOf(">");
		if(buf2.length()>0 && s01>-1){
			buf2=buf2.mid(0, s01+1);
		}else{
			s01=buf2.lastIndexOf("]");
			if(buf2.length()>0 && s01>-1){
				buf2=buf2.mid(0, s01+1);
			}else{
				buf2=buf2.mid(0, 500);
			}
		}

		int lngt=buf2.length();
		for(; lngt>0; lngt--){
			if(buf2.mid(lngt-1, 1)!=" "){
				if(lngt>10000){
					if(buf2.mid(lngt-1, 1)==">")	break;
				}else{
					break;
				}
			}

			buf2=buf2.mid(0, lngt-1);
		}

		if(command.indexOf("openssl ")==-1 && command.indexOf("gettoken")==-1 && command.indexOf("dmidecode")==-1){
			debug("lngt="+ intToQstring(lngt)+"; response => "+ buf2+";");
		}

		(void) pclose(ptr);
		int s=buf2.indexOf("|");
//		debug(buf2, 10);
		if(buf2.length()>0 && buf2.mid(0, 1)!="<" && s>-1){
			token=buf2.mid(0, s);
			buf2=buf2.mid(s+1);
		}
	}else{
		int i=0;
		int progress=0;
		ui->progressBar1->setMinimum(0);
		ui->progressBar1->setMaximum(maxProgress);
		ui->progressBar1->setValue(0);
		int L=0;
		while(true){
			ssize_t r=read(ptrd, buf, nn0);
			while(r==-1){
				Cqthread::msleep(stimeout);
				if(L>0){
					refreshWnd(true);
					L=0;
				}else{
					refreshWnd();
					L++;
				}

				r=read(ptrd, buf, nn0);
			}
		
			buf2="";
			for(int c=0; c<r; c++){
				buf2.append(buf[c]);
			}

			if(buf2.indexOf("<")>-1){
				ui->progressBar1->setValue(maxProgress);
				break;
			}else{
				if(download){
					int s=buf2.indexOf("{");
					int e=buf2.indexOf("}");

					if(s>-1 && e>1){
						QString spr=buf2.mid(s+1, e-s-1);
						maxProgress=spr.toInt();
						if(maxProgress>=0)	ui->progressBar1->setMaximum(maxProgress);
						buf2="";
					}
				}

				int s=buf2.lastIndexOf("[");
				int e=buf2.lastIndexOf("]");
				if(s>-1 && e>1 && s<e){
					QString spr=buf2.mid(s+1, e-s-1);
					progress=spr.toInt();
					if(progress>=0 && progress<=maxProgress){
						ui->progressBar1->setValue(progress);
					}
					buf2="";
				}
			}
			i++;
		}

		(void) pclose(ptr);

		int s=buf2.indexOf("|<response>")-32;
		if(buf2.length()>0 && s>-1){
			QString t=buf2.mid(s, 32);
			if(t.indexOf(" ")==-1 && t.indexOf("	")==-1 && t.indexOf("\n")==-1){
			  token=t;
				buf2=buf2.mid(s+33);
			}
		}

		s=buf2.indexOf("<response>");
		if(buf2.length()>0 && s>0)	buf2=buf2.mid(s);
	}

	if(tokenCopy!=token) timeTokenLastUpdate=startTime;
	return buf2;
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::runCommand2(QString command, int maxProgress, bool upload, bool download){
//debug(SRunCommand.restory);
	if(upload || download || maxProgress>-1){
		ui->progressBar1->setMinimum(0);
		ui->progressBar1->setMaximum(maxProgress);
		if(maxProgress<=0)	ui->progressBar1->setMaximum(1);
		ui->progressBar1->setValue(0);
	}

	if(QDateTime::currentDateTime() > QDateTime(timeTokenLastUpdate).addSecs(3000)){			// token expiried
		getToken();
	}

	SrunFunction.running=true;
	SRunCommand.response="";
	SRunCommand.error=0;
	SRunCommand.startTime=QDateTime::currentDateTime();
	QString fol="/tmp/StorageMadeEasy/";
	QDir dir(fol);
	if(SRunCommand.filepath==""){
		if(!dir.exists()){
			dir.mkpath(fol);

			QFile f1(fol);
			f1.setPermissions(QFile::ReadOwner | QFile::WriteOwner | QFile::ReadUser | QFile::WriteUser | QFile::ReadGroup | QFile::WriteGroup | QFile::ReadOther |QFile::WriteOther | QFile::ExeOwner | QFile::ExeUser | QFile::ExeGroup | QFile::ExeOther);
			debug("Created  "+ fol);
		}
		
		QDateTime pdate=QDateTime::currentDateTime();
		pdate=pdate.addDays(-2);

		QString tfpath="";						// removing old files
		tfpath=fol+"smesynccenter_0.tmp";
		for(int i=1; i<50; i++){
			if(!QFile::exists(tfpath)) continue;
			QFileInfo finfo(tfpath);
			if(finfo.lastModified()<pdate){
				QFile fl(tfpath);
				fl.remove();
			}
			tfpath=fol+"smesynccenter_"+ intToQstring(i) +".tmp";
		}
 
		SRunCommand.filepath=fol+"smesynccenter_0.tmp";
		for(int i=1; QFile::exists(SRunCommand.filepath); i++){
			QFileInfo finfo(SRunCommand.filepath);
			if(finfo.lastModified()<pdate){
				writeToFile(SRunCommand.filepath, "");
				break;
			}
			SRunCommand.filepath=fol+"smesynccenter_"+ intToQstring(i) +".tmp";
		}
		writeToFile(SRunCommand.filepath, "");
	}

	QString cmdQSt="smemount --server=\""+serverHost+"\" ";
	if(isHidden)	cmdQSt="perl /usr/bin/smemount --server=\""+serverHost+"\" ";
	cmdQSt.append(command);
	cmdQSt.append(" --tofile=\""+ SRunCommand.filepath +"\"");

	debug(cmdQSt);
	SRunCommand.ptr=popen(cmdQSt.toUtf8().data(), "r");

	SRunCommand.response_maxProgress=maxProgress;
	SRunCommand.response_upload=upload;
	SRunCommand.response_download=download;

	if(gmt_offset<-86400){	// 86400=24h			// Retrieving gmt offset while waiting response
		toLocal(QDateTime::currentDateTime());
	}

	runCommandResponse2(maxProgress, upload, download);

	return ;
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::runCommandResponse2(int maxProgress, bool upload, bool download){
//debug("runCommandResponse2()");
	maxProgress=SRunCommand.response_maxProgress;
	upload=SRunCommand.response_upload;
	download=SRunCommand.response_download;
	QString tokenCopy=token;
	QFile f01(SRunCommand.filepath);
	if(f01.size()<=0){
		QTimer::singleShot(200, this, SLOT(runCommandResponse2()));
		return ;
	}

	if(!upload && !download) Cqthread::msleep(300);
	QString buf2=readFromFile(SRunCommand.filepath);

	for(int i=buf2.length()-1; i>=0; i--){
		QString w=buf2.mid(i, 1);
		if(w==" " || w=="\r" || w=="\n"){
			buf2=buf2.mid(0, i);
		}else{
			break;
		}
	}

	int lngt=buf2.length();
	if(!SRunCommand.response_upload && !SRunCommand.response_download){
		int s04=buf2.lastIndexOf("</response>");
		int c01=0;
		while(s04==-1 && c01<=10){
debug("\nbuf2 = "+ buf2 +";");
debug("</response> NOT FOUND!!!!! Try read more bytes");
			c01++;
			Cqthread::msleep(1000);
			buf2=readFromFile(SRunCommand.filepath);
		}

		for(int i=buf2.length()-1; i>=0; i--){
			QString w=buf2.mid(i, 1);
			if(w==" " || w=="\r" || w=="\n"){
				buf2=buf2.mid(0, i);
			}else{
				break;
			}
		}
	}else{
		int s=-1, e=-1;
		bool L=false;
		if(buf2.indexOf("<")>-1){
			ui->progressBar1->setValue(maxProgress);
			if(buf2.length()>0 && buf2.indexOf("<")>0)	buf2=buf2.mid(buf2.indexOf("<"));
		}else{
			if(download){
				s=buf2.indexOf("{");
				e=buf2.indexOf("}");
				if(s>-1 && e>1 && s<e){
					QString spr=buf2.mid(s+1, e-s-1);
					maxProgress=spr.toInt();
					SRunCommand.response_maxProgress=maxProgress;
					if(maxProgress>=0)	ui->progressBar1->setMaximum(maxProgress);
					L=true;
				}
			}

			s=buf2.lastIndexOf("[");
			e=buf2.lastIndexOf("]");
			if(s>-1 && e>1 && s<e){
				QString spr=buf2.mid(s+1, e-s-1);
				int progress=spr.toInt();
				if(progress>=0 && progress<=maxProgress)	ui->progressBar1->setValue(progress);
				buf2="";
				L=true;
			}
			if(L){
				QTimer::singleShot(200, this, SLOT(runCommandResponse2()));
				return ;
			}
		}
	}

	(void) pclose(SRunCommand.ptr);
	writeToFile(SRunCommand.filepath, "");
	QFile f001(SRunCommand.filepath);
	if(f001.remove()){
		SRunCommand.filepath="";
	}else{
		debug("Can't delete file  "+ SRunCommand.filepath);
	}

	debug("lngt => "+ intToQstring(lngt) +"\nresponse => "+ buf2+";");

	int s=buf2.indexOf("|");
	if(buf2.length()>0 && buf2.mid(0, 1)!="<" && s>-1){
		token=buf2.mid(0, s);
		buf2=buf2.mid(s+1);
	}

	if(tokenCopy!=token) timeTokenLastUpdate=SRunCommand.startTime;
	SRunCommand.response=buf2;
	if(SRunCommand.restory.length()>0)				QTimer::singleShot(1, this, SRunCommand.restory.toUtf8().data());
	if(SRunCommand.up_level_command.length()>0)	QTimer::singleShot(10, this, SRunCommand.up_level_command.toUtf8().data());

	return ;
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::runFunction(QString uri, bool isPost, QString postData){
if(token!="*") debug("runFunction("+uri+")");
	SrunFunction.uri=uri;
	SrunFunction.isPost=isPost;
	SrunFunction.postData=postData;
	QString host=serverHost;

	bool HTTPS = false;
	int ss01 = host.indexOf("://");
	if(ss01>0){
		int ss02 = host.indexOf("https://", 0, Qt::CaseInsensitive);
		if(ss02>=0 && ss02<ss01) HTTPS=true;
		host = host.mid(ss01+3);
	}

//	if(uri.indexOf("gettoken/", -1, Qt::CaseInsensitive)==0){		// For gettoken we use HTTPS to protect password
//		HTTPS = true;
//	}

	http = new QNetworkAccessManager(this);
	QNetworkRequest request1;

	if(useProxy){
		debug("useProxy=1");
		quint16 xport = proxyport;
		http->setProxy(QNetworkProxy(QNetworkProxy::HttpProxy, proxyhost, xport, proxylogin, proxypass));
	}

	QSslConfiguration SSLconf(QSslSocket().sslConfiguration());
	SSLconf.setProtocol(QSsl::TlsV1);
	request1.setSslConfiguration(SSLconf);
	request1.setRawHeader("User-Agent", "Mozilla/4.0 (Linux Tools SyncCenter)");
	request1.setRawHeader("Accept", "*/*");
	request1.setRawHeader("Accept-Encoding", "deflate");
	request1.setRawHeader("Connection", "Keep-Alive");

	connect(http, SIGNAL(sslErrors(QNetworkReply *, QList<QSslError>)), this, SLOT(slotSslErrors(QNetworkReply *, QList<QSslError>)));

	if(host.indexOf("://")<0){
		if(HTTPS){
			host = "https://" + host;
		}else{
			host = "http://" + host;
		}
	}

	QNetworkReply *reply;
	if(token.length()<2) token="*";
	if(!isPost){
		QString url01 = host + "/api/"+token+"/"+uri;
		request1.setUrl(QUrl(url01));

		reply = http->get(request1);
		if(uri.indexOf("gettoken/", -1, Qt::CaseInsensitive)==0){
			debug("REQUEST => " + url01);
		}
	}else{
		debug("postData: "+postData.mid(0, 250));

		if(postData!="") postData+="&";
		postData+="token="+ token;

		QString url01 = host + "/api/rpc.php";
		request1.setUrl(QUrl(url01));

		reply = http->post(request1, postData.toUtf8());
	}

	QEventLoop eventLoop;
	QObject::connect(http, SIGNAL(finished(QNetworkReply*)), &eventLoop, SLOT(quit()));
	eventLoop.exec();
	runFunctionResp(reply);
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::runFunctionResp(QNetworkReply* reply){
debug("runFunctionResp()");
	QString res=QString::fromUtf8(reply->readAll());

	if(res.indexOf("<response>")>1){
		debug(res.mid(res.indexOf("<response>"), 280) +"\n");
	}else{
		debug(res.mid(0, 420) +"\n");
	}

	QString mess="";
	if(res==""){
		if(reply->error()!=QNetworkReply::NoError){
			mess="Cannot connect to server";
			debug("Error => "+ mess);

			if(reply->error()==QNetworkReply::NoError){
				debug("QNetworkReply::NoError");
			}else if(reply->error()==QNetworkReply::RemoteHostClosedError){
				debug("QNetworkReply::RemoteHostClosedError");
			}else if(reply->error()==QNetworkReply::HostNotFoundError){
				debug("QNetworkReply::HostNotFoundError");
				mess="Error. Check your Internet connection.";
			}else if(reply->error()==QNetworkReply::TimeoutError){
				debug("QNetworkReply::TimeoutError");
			}else if(reply->error()==QNetworkReply::OperationCanceledError){
				debug("QNetworkReply::OperationCanceledError");
			}else if(reply->error()==QNetworkReply::ProxyAuthenticationRequiredError){
				debug("QNetworkReply::SslHandshakeFailedError");
			}else if(reply->error()==QNetworkReply::ProxyConnectionRefusedError){
				debug("QNetworkReply::ProxyConnectionRefusedError");
			}else if(reply->error()==QNetworkReply::ProxyConnectionClosedError){
				debug("QNetworkReply::ProxyConnectionClosedError");
			}else if(reply->error()==QNetworkReply::ProxyNotFoundError){
				debug("QNetworkReply::ProxyNotFoundError");
			}else if(reply->error()==QNetworkReply::ProxyTimeoutError){
				debug("QNetworkReply::ProxyTimeoutError");
			}else if(reply->error()==QNetworkReply::ProxyAuthenticationRequiredError){
				debug("QNetworkReply::ProxyAuthenticationRequiredError");
			}else if(reply->error()==QNetworkReply::ContentAccessDenied){
				debug("QNetworkReply::ContentAccessDenied");
			}else if(reply->error()==QNetworkReply::ContentOperationNotPermittedError){
				debug("QNetworkReply::ContentOperationNotPermittedError");
			}else if(reply->error()==QNetworkReply::ContentNotFoundError){
				debug("QNetworkReply::ContentNotFoundError");
			}else if(reply->error()==QNetworkReply::AuthenticationRequiredError){
				debug("QNetworkReply::AuthenticationRequiredError");
			}else if(reply->error()==QNetworkReply::ContentReSendError){
				debug("QNetworkReply::ContentReSendError");
			}else if(reply->error()==QNetworkReply::ProtocolUnknownError){
				debug("QNetworkReply::ProtocolUnknownError");
			}else if(reply->error()==QNetworkReply::ProtocolInvalidOperationError){
				debug("QNetworkReply::ProtocolInvalidOperationError");
			}else if(reply->error()==QNetworkReply::UnknownNetworkError){
				debug("QNetworkReply::UnknownNetworkError");
			}else if(reply->error()==QNetworkReply::UnknownProxyError){
				debug("QNetworkReply::UnknownProxyError");
			}else if(reply->error()==QNetworkReply::UnknownContentError){
				debug("QNetworkReply::UnknownContentError");
			}else if(reply->error()==QNetworkReply::ProtocolFailure){
				debug("QNetworkReply::ProtocolFailure");
			}else{
				debug("QNetworkReply -> unknown network error");
			}
		}
	}

	if(res!=""){
		int s=res.indexOf("<response>");
		if(s>0) res=res.mid(s);
		s=res.indexOf("</response>");
		if(s<0) res="";
	}

	if(res.indexOf("<status>login_token_expired</status>")>0){
		QDomDocument doc("response");
		doc.setContent(res, true);

		QDomElement root=doc.documentElement();
		QDomNode n=root.firstChild();
		while(!n.isNull()){
			QDomElement e=n.toElement();
			if(!e.isNull()){
				if(e.tagName()=="status"){
					if(e.text()=="login_token_expired"){
						SgetToken.uri=SrunFunction.uri;
						SgetToken.isPost=SrunFunction.isPost;
						SgetToken.postData=SrunFunction.postData;
						getToken2();
						return ;
					}
					break;
				}
			}
			n=n.nextSibling();
		}

	}

	if(mess!="") SrunFunction.error=1;
	SrunFunction.response=res;

	resume(0);
	return ;
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::slotSslErrors(QNetworkReply *reply, QList<QSslError> e0){
	if(e0.size()>0 && (
			e0.at(0).errorString()=="The root certificate of the certificate chain is self-signed, and untrusted"
			|| e0.at(0).errorString()=="The issuer certificate of a locally looked up certificate could not be found"
			|| e0.at(0).errorString()=="The root CA certificate is not trusted for this purpose"
		)){
		reply->ignoreSslErrors();
	}else{
		if(e0.size()>0){
			QMessageBox::critical(this, "Error", "  "+e0.at(0).errorString()+"  ");
		}
	}

	qDebug() << "SSL Error:" << e0;
	return ;	
}
//////////////////////////////////////////////////////////////////////
TrunFunction3 SyncWidget::runFunction3(QString uri, bool isPost, QString postData, int attempt){
	TrunFunction3 response;
	response.statusCode=0;
	response.response="";
	response.error="";
	isRunning=true;

	if(token!="*"){
		debug("runFunction3("+uri+" , "+ boolToQstring(isPost) +")");
	}else{
		debug("runFunction3()");
	}

	SrunFunction.uri=uri;
	SrunFunction.isPost=isPost;
	SrunFunction.postData=postData;
	QString host=serverHost;

	bool HTTPS = false;
	int ss01 = host.indexOf("://");
	if(ss01>0){
		int ss02 = host.indexOf("https://", 0, Qt::CaseInsensitive);
		if(ss02>=0 && ss02<ss01) HTTPS=true;
		host = host.mid(ss01+3);
	}

//	if(uri.indexOf("gettoken/", -1, Qt::CaseInsensitive)==0){		// For gettoken we use HTTPS to protect password
//		HTTPS = true;
//	}

	QNetworkAccessManager *HTTP0 = new QNetworkAccessManager(this);
	QNetworkRequest request1;

	if(useProxy){
		debug("useProxy=1");
		quint16 xport = proxyport;
		HTTP0->setProxy(QNetworkProxy(QNetworkProxy::HttpProxy, proxyhost, xport, proxylogin, proxypass));
	}

	QSslConfiguration SSLconf(QSslSocket().sslConfiguration());
	SSLconf.setProtocol(QSsl::TlsV1);
	request1.setSslConfiguration(SSLconf);
	request1.setRawHeader("User-Agent", "Mozilla/4.0 (Linux Tools SyncCenter)");
	request1.setRawHeader("Accept", "*/*");
	request1.setRawHeader("Accept-Encoding", "deflate");
	request1.setRawHeader("Connection", "Keep-Alive");

	connect(HTTP0, SIGNAL(sslErrors(QNetworkReply *, QList<QSslError>)), this, SLOT(slotSslErrors(QNetworkReply *, QList<QSslError>)));

	if(host.indexOf("://")<0){
		if(HTTPS){
			host = "https://" + host;
		}else{
			host = "http://" + host;
		}
	}

	QNetworkReply *reply;
	if(token.length()<2) token="*";
	if(!isPost){
		QString url01 = host + "/api/"+token+"/"+uri;
		request1.setUrl(QUrl(url01));

		reply = HTTP0->get(request1);
		if(uri.indexOf("gettoken/", -1, Qt::CaseInsensitive)==0){
			debug("REQUEST => " + url01);
		}
	}else{
		debug("postData: "+postData.mid(0, 250));

		if(postData!="") postData+="&";
		postData+="token="+ token;

		QString url01 = host + "/api/rpc.php";
		request1.setUrl(QUrl(url01));

		reply = HTTP0->post(request1, postData.toUtf8());
	}

	QEventLoop eventLoop;
	QObject::connect(HTTP0, SIGNAL(finished(QNetworkReply*)), &eventLoop, SLOT(quit()));
	eventLoop.exec();

	response.response = QString::fromUtf8(reply->readAll());

	if(response.response.indexOf("<response>")>1){
		debug(response.response.mid(response.response.indexOf("<response>"), 280) +"\n");
	}else{
		debug(response.response.mid(0, 420) +"\n");
	}

	QString mess="";
	if(response.response==""){
		if(reply->error()!=QNetworkReply::NoError){
			mess="Cannot connect to server";
			debug("Error => "+ mess);

			if(reply->error()==QNetworkReply::NoError){
				debug("QNetworkReply::NoError");
			}else if(reply->error()==QNetworkReply::RemoteHostClosedError){
				debug("QNetworkReply::RemoteHostClosedError");
			}else if(reply->error()==QNetworkReply::HostNotFoundError){
				debug("QNetworkReply::HostNotFoundError");
				mess="Error. Check your Internet connection.";
			}else if(reply->error()==QNetworkReply::TimeoutError){
				debug("QNetworkReply::TimeoutError");
			}else if(reply->error()==QNetworkReply::OperationCanceledError){
				debug("QNetworkReply::OperationCanceledError");
			}else if(reply->error()==QNetworkReply::ProxyAuthenticationRequiredError){
				debug("QNetworkReply::SslHandshakeFailedError");
			}else if(reply->error()==QNetworkReply::ProxyConnectionRefusedError){
				debug("QNetworkReply::ProxyConnectionRefusedError");
			}else if(reply->error()==QNetworkReply::ProxyConnectionClosedError){
				debug("QNetworkReply::ProxyConnectionClosedError");
			}else if(reply->error()==QNetworkReply::ProxyNotFoundError){
				debug("QNetworkReply::ProxyNotFoundError");
			}else if(reply->error()==QNetworkReply::ProxyTimeoutError){
				debug("QNetworkReply::ProxyTimeoutError");
			}else if(reply->error()==QNetworkReply::ProxyAuthenticationRequiredError){
				debug("QNetworkReply::ProxyAuthenticationRequiredError");
			}else if(reply->error()==QNetworkReply::ContentAccessDenied){
				debug("QNetworkReply::ContentAccessDenied");
			}else if(reply->error()==QNetworkReply::ContentOperationNotPermittedError){
				debug("QNetworkReply::ContentOperationNotPermittedError");
			}else if(reply->error()==QNetworkReply::ContentNotFoundError){
				debug("QNetworkReply::ContentNotFoundError");
			}else if(reply->error()==QNetworkReply::AuthenticationRequiredError){
				debug("QNetworkReply::AuthenticationRequiredError");
			}else if(reply->error()==QNetworkReply::ContentReSendError){
				debug("QNetworkReply::ContentReSendError");
			}else if(reply->error()==QNetworkReply::ProtocolUnknownError){
				debug("QNetworkReply::ProtocolUnknownError");
			}else if(reply->error()==QNetworkReply::ProtocolInvalidOperationError){
				debug("QNetworkReply::ProtocolInvalidOperationError");
			}else if(reply->error()==QNetworkReply::UnknownNetworkError){
				debug("QNetworkReply::UnknownNetworkError");
			}else if(reply->error()==QNetworkReply::UnknownProxyError){
				debug("QNetworkReply::UnknownProxyError");
			}else if(reply->error()==QNetworkReply::UnknownContentError){
				debug("QNetworkReply::UnknownContentError");
			}else if(reply->error()==QNetworkReply::ProtocolFailure){
				debug("QNetworkReply::ProtocolFailure");
			}else{
				debug("QNetworkReply -> unknown network error");
			}
		}
	}

	delete HTTP0;
	int LL0=0;
	if(response.response!=""){
		int s1=response.response.indexOf("<response>");
		int s2=response.response.lastIndexOf("</response>");
		if(s1>=0 && s2>=0 && s1<s2){
			response.response=response.response.mid(s1);
		}else{
			LL0=1;
			response.response="";
		}
	}

	if(response.response.indexOf("<status>login_token_expired</status>")>0){
		QDomDocument doc("response");
		doc.setContent(response.response, true);

		QDomElement root=doc.documentElement();
		QDomNode n=root.firstChild();
		while(!n.isNull()){
			QDomElement e=n.toElement();
			if(!e.isNull()){
				if(e.tagName()=="status"){
					if(e.text()=="login_token_expired") LL0=2;
					break;
				}
			}
			n=n.nextSibling();
		}
	}


	if(LL0!=0 && attempt<=2){
		debug("Request failed. Try to send again.");
		bool L=false;
		if(uri.indexOf("gettoken/", 0, Qt::CaseInsensitive)>-1){
			L=true;
		}else{
			if(getToken().length()<=2) L=true;
		}

		if(L){		// we have tried to get new token. But, server don't returned token. Need to stop to prevent getToken in loop.
			response.statusCode=0;
			response.response="";
			response.error="Unable to authenticate. Check your Internet connection or login and password.";
			return response;
		}
		return runFunction3(uri, isPost, postData, attempt+1);
	}
	return response;
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::getToken2(){
debug("getToken2()");
	if(isCanceledAction){
		hideMessage();
		return ;
	}

	SrunFunction.restory2="";
	SrunFunction.restory2.append(SLOT(getTokenResp2()));

	token="*";
	QString uri="gettoken/"+ base64(login) +","+ base64(password);
	showMessage("Retrieving user info", true);
	runFunction(uri);
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::getTokenResp2(){
debug("getTokenResp2()");
//debug("getTokenResp("+SrunFunction.response+")");

	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory2="";

	token="*";

	QString l1, l4, statusmessage;
	l1=getPartQString(res, "<token>", "</token>");
	l4=getPartQString(res, "<notice>", "</notice>");
	statusmessage=getPartQString(res, "<statusmessage>", "</statusmessage>");

	if(l1!=""){
		token=l1;
		if(l4=="1"){  // need get provider login and provider password
			tmptoken2=token;
			token="*";
			if(providerLogin=="" || providerPassword==""){
				getProviderLoginAndPassword();
			}else{
				setProviderData();
			}
			return ;
		}
	}else{		// error
		isCanceledAction=true;
		if(statusmessage=="") statusmessage="Check Password or Internet connection!";
		QMessageBox::critical(this, "Error", "Unable to authenticate. "+ statusmessage);
		hideMessage();
		return ;
	}

//debug("token="+token);
	if(isCanceledAction) hideMessage();
	if(SgetToken.uri!="" || (SgetToken.isPost==true && SgetToken.postData!="")){
		runFunction(SgetToken.uri, SgetToken.isPost, SgetToken.postData);
		SgetToken.uri="";
		return ;
	}
	timeTokenLastUpdate=QDateTime::currentDateTime();

	resume(1);
}
//////////////////////////////////////////////////////////////////////
QString SyncWidget::getToken(){
debug("getToken()");
	if(isCanceledAction){
		hideMessage();
		return "*";
	}

	token="*";
	QString uri="gettoken/"+ base64(login) +","+ base64(password);
	showMessage("Retrieving user info", true);
	TrunFunction3 response1=runFunction3(uri);
	QString res=response1.response;
	response1.response="";

	token="*";
	QString l1, l4, statusmessage;
	l1=getPartQString(res, "<token>", "</token>");
	l4=getPartQString(res, "<notice>", "</notice>");
	statusmessage=getPartQString(res, "<statusmessage>", "</statusmessage>");

	if(l1!=""){
		token=l1;
		if(l4=="1"){  // need get provider login and provider password
			tmptoken2=token;
			token="*";
			if(!getProviderLoginAndPassword2()) return "";
			setProviderData2();				// This function can change token!
			timeTokenLastUpdate=QDateTime::currentDateTime();
			return token;
		}
	}else{		// error
		isCanceledAction=true;
		if(statusmessage=="") statusmessage="Check Password or Internet connection!";
		QMessageBox::critical(this, "Error", "Unable to authenticate. "+ statusmessage);
		hideMessage();
		return "*";
	}

debug("token="+token);
	timeTokenLastUpdate=QDateTime::currentDateTime();
	return token;
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::setProviderData(){
debug("setProviderData()");
	SrunFunction.restory2="";
	SrunFunction.restory2.append(SLOT(setProviderDataResp()));

	QString uri="setProviderData/"+ base64(providerLogin) +","+ base64(providerPassword);
	showMessage("Set Provider Data", true);

	if(token.length()<2 && tmptoken.length()>2) token=tmptoken;
	runFunction(uri);
	tmptoken="";
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::setProviderDataResp(){
debug("setProviderDataResp()");
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SrunFunction.restory2="";

	QString status=getPartQString(res, "<status>", "</status>");
	QString statusmessage=getPartQString(res, "<statusmessage>", "</statusmessage>");
	if(status!="ok"){
		if(statusmessage=="") statusmessage="Check Provider login and password!";
		QMessageBox::critical(this, "Error", statusmessage);
		getProviderLoginAndPassword();
		return ;
	}else{
		if(token.length()<2 && tmptoken.length()>2) token=tmptoken;
		tmptoken="";
	}

	timeTokenLastUpdate=QDateTime::currentDateTime();

	resume(1);
	return ;
}
//////////////////////////////////////////////////////////////////////
bool SyncWidget::setProviderData2(){		// return true if Provider Data is success set.
debug("setProviderData2()");

	QString uri="setProviderData/"+ base64(providerLogin) +","+ base64(providerPassword);
	showMessage("Set Provider Data", true);

	if(token.length()<2 && tmptoken.length()>2) token=tmptoken;
	TrunFunction3 response1=runFunction3(uri);
	QString res=response1.response;
	response1.response="";

	QString status=getPartQString(res, "<status>", "</status>");
	QString statusmessage=getPartQString(res, "<statusmessage>", "</statusmessage>");
	if(status!="ok"){
		if(statusmessage=="") statusmessage="Check Provider login and password!";
		QMessageBox::critical(this, "Error", statusmessage);
		if(!getProviderLoginAndPassword2()){
			return false;
		}
		return setProviderData2();
	}else{
		if(token.length()<2 && tmptoken.length()>2){
			token=tmptoken;
			tmptoken="";
			return true;
		}
	}

	tmptoken="";
	return false;
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::resume(int n){
debug("resume("+ intToQstring(n) +")");
	if(n<=0 && SrunFunction.restory2.length()>0){
		QTimer::singleShot(1, this, SrunFunction.restory2.toUtf8().data());
		SrunFunction.restory2="";
	}else if(n<=1 && SRunCommand.restory.length()>0){
		QTimer::singleShot(1, this, SRunCommand.restory.toUtf8().data());
		SRunCommand.restory="";
	}else	if(n<=2 && SRunCommand.up_level_command.length()>0){
		QTimer::singleShot(1, this, SRunCommand.up_level_command.toUtf8().data());
		SRunCommand.up_level_command="";
	}else{
		hideMessage();
	}

}
//////////////////////////////////////////////////////////////////////
int SyncWidget::getCountFiles(FileClass *arr){
	int n=maxCount;
	QString name="";

	int i=0;
	for(; i<n; i++){
		if(i<n && arr[i].name.length()<1)	return i;

		if(i*10		<n && arr[i*10].name.length()>0)		i=i*10;
		if(i*2		<n && arr[i*2].name.length()>0)			i=i*2;
		if(i+10000<n && arr[i+10000].name.length()>0)	i=i+10000;
		if(i+1000	<n && arr[i+1000].name.length()>0)	i=i+1000;
		if(i+100	<n && arr[i+100].name.length()>0)		i=i+100;
		if(i+20		<n && arr[i+20].name.length()>0)		i=i+20;
		if(i+5		<n && arr[i+5].name.length()>0)			i=i+5;
	}
	delete []arr;

	return i;
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::createFolder2(QString name, double pid, bool addToFilelist){
	SRunCommand.restory="";
	SRunCommand.restory.append(SLOT(createFolderResp()));

	QString lgname=name;
	QString sId=floatToQstring(pid);
	QString descr="";
	QString structType="g";

	FileClass f;
	SCreateFolder.name=name;
	SCreateFolder.pid=pid;
	SCreateFolder.addToFilelist=addToFilelist;
	SCreateFolder.f=f;			// result

	if(name=="My Syncs" && pid==0){
		structType="s";
		descr="My Synchronized Folders";
	}

	showMessage("Creating folder  "+ lgname, false);

	name=base64(name);
	descr=base64("_"+ descr);

	QString com="createfolder "+ getLoginAndPasswordForCMD() +" \""+ token +"\" "+ name +" "+ sId +" "+ structType +" "+ descr +" --sync";
	runCommand2(com);
	return ;
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::createFolderResp(){
	QString list=SRunCommand.response;
	QString name=SCreateFolder.name;
	SCreateFolder.f.id=-5;

	QString lgname=name;
	if(list.length()<1){
		addToLog("Error. Folder  "+ lgname +"  is not created\n", 0);
		return ;
	}

	QDomDocument doc("fileslist");
	doc.setContent(list, true);
	
	int L=0;
	QDomElement root=doc.documentElement();
	QDomNode n=root.firstChild();
	while(!n.isNull()){
		QDomElement e = n.toElement();
		if(!e.isNull()){
		  if(e.tagName()=="f"){
				QString id="", pid="", name="", type="", lmodify="";
				QDomNode nf = n.firstChild();
				QDomElement eid = nf.toElement();
				if(eid.tagName()=="id")	id=eid.text();

				nf = nf.nextSibling();
				QDomElement epid = nf.toElement();
				if(epid.tagName()=="pid")	pid=epid.text();

				nf = nf.nextSibling();
				QDomElement ename = nf.toElement();
				if(ename.tagName()=="name")	name=ename.text();

				nf = nf.nextSibling();
				QDomElement etype = nf.toElement();
				if(etype.tagName()=="type")	type=etype.text();

				nf = nf.nextSibling();
				QDomElement elmodify = nf.toElement();
				if(elmodify.tagName()=="lmodify")	lmodify=elmodify.text();

				if(id.length()<1 || pid.length()<1 || name.length()<1 || type.length()<1 || lmodify.length()<5){
					addToLog("Error. Folder "+ lgname +" is not created\n", 0);
					return ;
				}

				uint uld=lmodify.toInt();
				QDateTime ld=QDateTime::fromTime_t(uld);
				ld=toLocal(ld);

				SCreateFolder.f.name=SCreateFolder.name;

				SCreateFolder.f.type=type.toInt();
				SCreateFolder.f.pid=pid.toDouble();
				SCreateFolder.f.id=id.toDouble();
				SCreateFolder.f.serverdate=ld;
				SCreateFolder.f.existsOnServer=1;
				SCreateFolder.f.existsOnLocal=-1;
				if(SCreateFolder.addToFilelist){
					int count=getCountFiles(filelist);
					filelist[count].name=SCreateFolder.f.name;
					filelist[count].type=type.toInt();
					filelist[count].pid=pid.toDouble();
					filelist[count].id=id.toDouble();
					filelist[count].serverdate=ld;
					filelist[count].existsOnServer=1;
					filelist[count].existsOnLocal=-1;
					SCreateFolder.f=filelist[count];
					SCreateFolder.f.id=id.toDouble();
				}

				double elid=getOldFolderId(SCreateFolder.f, SCreateFolder.f.pid);
				if(elid>0 && SCreateFolder.f.id>0 && elid!=SCreateFolder.f.id){ // need update folderid in oldServerFilelist
					oldFilesList=oldFilesList.replace("<id>"+ floatToQstring(elid) +"</", "<id>"+ floatToQstring(SCreateFolder.f.id) +"</");
					saveFilesListToFile(true);
				}

				L=1;
		  }
		}
		n = n.nextSibling();
	}

	if(L!=1){
		addToLog("Error. Folder "+ lgname +" is not created\n", 0);
		return ;
	}

	return ;
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::uploadFile2(QString name, QString path, double pid, double id, QDateTime localtime, bool addToFilelist){
	SRunCommand.restory="";
	SRunCommand.restory.append(SLOT(uploadFileResp()));
	SUploadFile.path=path.replace("//", "/");

	QString mess=path;
	showMessage("Uploading file  "+ mess, true, true);
	addToLog("Upload file  "+ mess +"\n", 2);

	FileClass f;
	SUploadFile.f=f;			// result
	SUploadFile.f.name=name;
	SUploadFile.f.type=0;
	SUploadFile.f.pid=pid;
	SUploadFile.f.id=-1;
	SUploadFile.f.localdate=localtime;
	SUploadFile.f.existsOnServer=-1;
	SUploadFile.f.existsOnLocal=1;
	SUploadFile.addToFilelist=addToFilelist;

	QFile file_(path);
	QString sId=floatToQstring(pid);
//debug("name = "+name);
	name=base64(name);
	path=base64(path);
	QDateTime utcLDate=toUTC(localtime);
	uint ulocaltime = utcLDate.toTime_t();

	QString com="uploadfile "+ getLoginAndPasswordForCMD() +" \""+ token +"\" "+ name +" "+ path +" "+ intToQstring(ulocaltime) +" "+ sId +" "+ floatToQstring(id) +" ef="+base64(encryptPassword) +" --sync";
	
	Cqthread::msleep(100);
	runCommand2(com, file_.size(), true);

	return ;
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::uploadFileResp(){
debug("uploadFileResp()");
	QString list=SRunCommand.response;

	QString mess=SUploadFile.path;
	if(list=="<response>permission=0</response>"){
		addToLog("Error. You do not have permission to read file "+ mess +"\n", 0);
		return ;
	}

	bool L01=true;
	if(list=="" || list.indexOf("<name>")<0) L01=false;

	if(L01){
		QDomDocument doc("fileslist");
		doc.setContent(list, true);
		QDomElement root=doc.documentElement();
		QDomNode n=root.firstChild();
		while(!n.isNull()){
			QDomElement e = n.toElement();
			if(!e.isNull()){
				if(e.tagName()=="f"){
					QString id="", pid="", name="", type="", lmodify="";
					QDomNode nf = n.firstChild();
					QDomElement eid = nf.toElement();
					if(eid.tagName()=="id")	id=eid.text();

					nf = nf.nextSibling();
					QDomElement epid = nf.toElement();
					if(epid.tagName()=="pid")	pid=epid.text();

					nf = nf.nextSibling();
					QDomElement ename = nf.toElement();
					if(ename.tagName()=="name")	name=ename.text();

					nf = nf.nextSibling();
					QDomElement etype = nf.toElement();
					if(etype.tagName()=="type")	type=etype.text();

					nf = nf.nextSibling();
					QDomElement elmodify = nf.toElement();
					if(elmodify.tagName()=="lmodify")	lmodify=elmodify.text();

					if(id.length()<1 || pid.length()<1 || name.length()<1 || type.length()<1 || lmodify.length()<5){
						addToLog("Error. File  "+ mess +"  is not uploaded\n", 0);
						return ;
					}

					uint uld=lmodify.toInt();
					QDateTime ld=QDateTime::fromTime_t(uld);
					ld=toLocal(ld);

					SUploadFile.f.type=type.toInt();
					SUploadFile.f.pid=pid.toDouble();
					SUploadFile.f.id=id.toDouble();
					SUploadFile.f.serverdate=SUploadFile.f.localdate;
					SUploadFile.f.existsOnServer=1;
					SUploadFile.f.existsOnLocal=1;
					if(SUploadFile.addToFilelist){
						int count=getCountFiles(filelist);
						filelist[count].name=name;
						filelist[count].type=type.toInt();
						filelist[count].pid=pid.toDouble();
						filelist[count].id=id.toDouble();
						filelist[count].serverdate=SUploadFile.f.localdate;
						filelist[count].existsOnServer=1;
						filelist[count].existsOnLocal=1;
					}
/*
QDateTime ld1=toUTC(ld);
QDateTime ld2=toLocal(ld1);
debug(ld.toString("yyyy MM dd hh:mm:ss") +" UTC=> "+ ld1.toString("yyyy MM dd hh:mm:ss") +" Local=> "+ ld2.toString("yyyy MM dd hh:mm:ss"));
debug("id = "+ floatToQstring(filelist[count].id) + "; pid = " + floatToQstring(filelist[count].pid) + "; name = " + filelist[count].name + "; type = " + intToQstring(filelist[count].type) + "; serverdate = " + ld.toString("yyyy MM dd hh:mm:ss"));
*/
				}
			}
			n = n.nextSibling();
		}//while
	}

	if(L01){
		countUploaded++;
		return ;
	}else{
		addToLog("Error. File  "+mess+"  is not uploaded\n", 0);
		return ;
	}
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::downloadFile2(QString fullname, double id, QDateTime servertime, bool addToFilelist){
	SRunCommand.restory="";
	SRunCommand.restory.append(SLOT(downloadFileResp()));

	fullname.replace("//", "/");
debug("downloadFile2("+ fullname +", "+ floatToQstring(id) +", servertime, addToFilelist)");
	SDownloadFile.fullname=fullname;
	SDownloadFile.id=id;
	SDownloadFile.servertime=servertime;
	SDownloadFile.addToFilelist=addToFilelist;

	QString mess=fullname;
	showMessage("Downloading file  "+ mess, true, true);
	addToLog("Download file  "+ mess +"\n", 2);

	uint uservertime = servertime.toTime_t();

	if(SDownloadFile.tmpfilename!="" && QFile::exists(SDownloadFile.tmpfilename)) QFile::remove(SDownloadFile.tmpfilename);
	SDownloadFile.tmpfilename="";
	QString fol="/tmp/StorageMadeEasy/";
	QDir dir(fol);
	if(!dir.exists()){
		dir.mkpath(fol);

		QFile f1(fol);
		f1.setPermissions(QFile::ReadOwner | QFile::WriteOwner | QFile::ReadUser | QFile::WriteUser | QFile::ReadGroup | QFile::WriteGroup | QFile::ReadOther |QFile::WriteOther | QFile::ExeOwner | QFile::ExeUser | QFile::ExeGroup | QFile::ExeOther);
		f1.close();
		debug("Created  "+ fol);
	}

	QDateTime pdate=QDateTime::currentDateTime();
	pdate=pdate.addDays(-2);

	QDir dir_2(fol);						 // Removing old temp files
	QStringList lstFiles=dir_2.entryList(QDir::Files | QDir::Hidden);
	foreach (QString entry, lstFiles){
		QString entryAbsPath=getCorrectFilePath(fol + "/" + entry);
		QFileInfo absFile(entryAbsPath);
		//debug("old file => "+entryAbsPath);
		if(getPartQString(entryAbsPath, "synccenter_tmp_", ".sfl")!="" && absFile.lastModified()<pdate){
			if(!QFile::remove(entryAbsPath)) debug("Can't delete file "+entryAbsPath);
		}
	}

	QString tfl="";
	for(int i=1; i<100000; i++){
		tfl=fol+"synccenter_tmp_" +intToQstring(i) +".sfl";
		if(!QFile::exists(tfl)){
			QFile tmpFile(tfl);
			if(tmpFile.open(QIODevice::WriteOnly)){
				tmpFile.close();
				break;
			}
		}
	}

	debug("tmp file => "+tfl);
	if(!QFile::exists(tfl)){
		debug("Can not create temp file. Maybe, you don't have permissions to write to folder "+fol);
		if(!isHidden){
			QMessageBox::critical(this, tr("Error"), "Can not create temp file. Maybe, you don't have permissions to write to folder "+fol);
		}else{
			addToLog("Error. Can not create temp file. Maybe, you don't have permissions to write to folder "+fol+"\n", 0);
		}
		return ;
	}
	SDownloadFile.tmpfilename=tfl;

	QString com="downloadfile "+ getLoginAndPasswordForCMD() +" \""+ token +"\" "+ base64(SDownloadFile.tmpfilename) +" "+ floatToQstring(id) +" "+ intToQstring(uservertime) +" ef="+base64(encryptPassword) +" --sync";
	Cqthread::msleep(100);
	runCommand2(com, 0, false, true);
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::downloadFileResp(){
	QString fullname=SDownloadFile.fullname;
	double id=SDownloadFile.id;
	QDateTime servertime=SDownloadFile.servertime;
	bool addToFilelist=SDownloadFile.addToFilelist;
	QString list=SRunCommand.response;
	QString mess=fullname;

debug("downloadFileResp() list="+list);
	if(list.length()<1 || list.indexOf("<response>Success</response>")<0){
		QFile::remove(SDownloadFile.tmpfilename);
		if(list=="<response>permission=0</response>"){
			addToLog("Error. You do not have permission to write to file "+ mess +"\n", 0);
			return ;
		}else if(list=="<response>wrong_password</response>"){
			if(encryptPassword!=""){
				addToLog("Error. File is encrypted "+ mess +"\n", 0);
			}else{
				addToLog("Error. Wrong encryption password for file "+ mess +"\n", 0);
			}
			return ;
		}


		if(list=="<response>access=0</response>"){
			QString mess2=mess;
			if(mess2.mid(mess2.length()-1, 1)=="/")	mess2 = mess2.mid(0, mess2.length()-1);
			
			mess2 = mess2.mid(0, mess2.lastIndexOf("/"));
			if(mess2.length()<1)	mess2="/";
			addToLog("Error. You do not have permissions to create file on folder "+ mess2 +"\n", 0);
			return ;
		}

		addToLog("Error. File  "+ mess +"  is not downloaded\n", 0);
		return ;
	}

	if(!QFile::exists(SDownloadFile.tmpfilename)){
		addToLog("Error. File  "+ mess +"  is not downloaded\n", 0);
		return ;
	}

	QString mv1=SDownloadFile.tmpfilename, mv2=SDownloadFile.fullname;				// File downloaded successfully, need to move it to correct folder
	mv1.replace("\\", "\\\\");
	mv1.replace("\"", "\\\"");
	mv1.replace("$", "\\$");
	mv2.replace("\\", "\\\\");
	mv2.replace("\"", "\\\"");
	mv2.replace("$", "\\$");
	QString command="mv -f \""+mv1+"\" \""+mv2+"\"";
debug(command);

	QByteArray tmCommand;
	if(localeEncoding!=""){
		QTextCodec *codec = QTextCodec::codecForName(localeEncoding.toUtf8().data());
		tmCommand = codec->fromUnicode(command);
	}else{
		tmCommand = command.toUtf8();
	}

	int L01=system(tmCommand.data());
	if(L01!=0 && localeEncoding!=""){		// try to use UTF-8 name
		tmCommand = command.toUtf8();
		L01=system(tmCommand.data());
	}

	if(L01!=0){
		if(QFile::exists(SDownloadFile.tmpfilename) || !QFile::exists(SDownloadFile.fullname)){
			addToLog("Error. Can't move file '"+SDownloadFile.tmpfilename +"' to "+ SDownloadFile.fullname +"\n", 0);
			debug("ERROR. Can't move file '"+SDownloadFile.tmpfilename +"' to "+ SDownloadFile.fullname);
			return ;
		}
	}


	if(addToFilelist){
		addToLog("Error 893\n", 0);
	}else{
		int s=fullname.lastIndexOf("/");
		if(fullname.length()>1 && s>0){
			SDownloadFile.f.path=fullname.mid(0, s);
		}else{
			SDownloadFile.f.path="";
		}

		SDownloadFile.f.id=id;
		SDownloadFile.f.localdate=servertime;
		SDownloadFile.f.existsOnServer=1;
		SDownloadFile.f.existsOnLocal=1;
		countDownloaded++;
	}

	return ;
}
//////////////////////////////////////////////////////////////////////
QDateTime SyncWidget::toUTC(QDateTime t){
	if(gmt_offset<-86400){	// 86400=24h
		QString com="get_gmt_offset --sync";

		QString list=runCommand(com);
		if(list.length()>0){
			gmt_offset=list.toInt();
		}else{
			gmt_offset=0;
		}
	}

	uint ut=t.toTime_t();
	ut=ut-gmt_offset;
	t.setTime_t(ut);

	return t;
}
//////////////////////////////////////////////////////////////////////
QDateTime SyncWidget::toLocal(QDateTime t, int d){
	if(gmt_offset<-86400){	// 86400=24h
		QString com="get_gmt_offset --sync";

		QString list=runCommand(com);
		if(list.length()>0){
			gmt_offset=list.toInt();
		}else{
			gmt_offset=0;
		}
	}

	uint ut=t.toTime_t();
	ut=ut+gmt_offset + d;
	t.setTime_t(ut);

	return t;
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::debug(QString s, int level){
	if(level<=DEBUG) printf("%s\n", s.toUtf8().data());
}
//////////////////////////////////////////////////////////////////////
FileClass SyncWidget::createNewNode(QString folderName, QString fullname, double id, double pid, int type, int existsOnServer, int existsOnLocal,
				QDateTime localdate, QDateTime serverdate, QTreeWidgetItem *pnode, bool rootNode, QString serverfolderName, bool createEmptyItem){
//debug("createNewNode("+folderName+", "+fullname+", "+floatToQstring(id)+", "+floatToQstring(pid)+", "+intToQstring(type)+", "+boolToQstring(existsOnServer)+", "+boolToQstring(existsOnLocal)+", "+localdate.toString(Qt::ISODate)+", "+serverdate.toString(Qt::ISODate)+", *pnode, "+boolToQstring(rootNode)+", "+serverfolderName+", "+boolToQstring(createEmptyItem)+"){");
	int c=getCountFiles(filelist);

	QString fpath=getFileInfo(fullname).at(1);

	filelist[c].name=folderName;
	filelist[c].servername=serverfolderName;
	filelist[c].path=fpath;
	filelist[c].type=type;
	filelist[c].pid=pid;
	filelist[c].id=id;

	filelist[c].localdate=localdate;
	filelist[c].serverdate=serverdate;

	filelist[c].existsOnServer=existsOnServer;
	filelist[c].existsOnLocal=existsOnLocal;

	if(filelist[c].path=="" && filelist[c].existsOnLocal==1 && rootNode){
		filelist[c].path="/";
	}

	QString L="X";
	if(existsOnLocal==1 && existsOnServer==1){
		L="X";
		if(type==0){
			if(filelist[c].localdate>filelist[c].serverdate){
				L=">";
			}else if(filelist[c].localdate<filelist[c].serverdate){
				L="<";
			}
		}else{
			L="0";
		}
	}else if(existsOnLocal==1 && existsOnServer!=1){
		L=">";
	}else if(existsOnLocal!=1 && existsOnServer==1){
		L="<";
	}

	QString basePath=pathToIcons;
	if(L=="X"){
		L=basePath +"none.gif";
	}else if(L==">"){
		L=basePath +"upload.gif";
	}else if(L=="<"){
		L=basePath +"download.gif";
	}else if(L=="0"){
		L=basePath +"mid.gif";
	}

	if(!pnode || rootNode){
		filelist[c].node=new QTreeWidgetItem(ui->tree);
	}else{
		filelist[c].node=new QTreeWidgetItem(pnode);
	}

	QString wldate="", wsdate="";
	if(filelist[c].type==0){
		wldate=filelist[c].localdate.toString("yyyy MM dd hh:mm:ss");
		wsdate=filelist[c].serverdate.toString("yyyy MM dd hh:mm:ss");
	}

	QIcon icon;
	if(filelist[c].type==0){
		icon=QIcon(getFileIcon(getExtension(filelist[c].name)));
	}else{
		icon=QIcon(getFolderIcon());
	}

	QString wservername=filelist[c].servername;
	if(!pnode || rootNode){
		QString wpath=filelist[c].path+"/"+filelist[c].name;
		wpath.replace("//", "/");
		filelist[c].node->setText(0, wpath);
	}else{
		filelist[c].node->setText(0, filelist[c].name);
		wservername="";
	}

	filelist[c].node->setText(1, wservername);
	filelist[c].node->setText(2, wldate);
	filelist[c].node->setIcon(3, QIcon(L));

	filelist[c].node->setText(4, wsdate);
	filelist[c].node->setIcon(0, icon);

	filelist[c].node->setCheckState(0, Qt::CheckState(2));				// 0 - not checked, 2 - checked
	filelist[c].node->setFlags(Qt::ItemIsSelectable | Qt::ItemIsEnabled);		// this make node not checkable

	if(createEmptyItem && filelist[c].type==1){
		QTreeWidgetItem *emptyItem=new QTreeWidgetItem(filelist[c].node);	// We add this item to folder. Without this item will be impossible to open folder. It must be removed when folder will be opened
		if(!emptyItem) debug("Cannot create emptyItem");
	}

	return filelist[c];
}
//////////////////////////////////////////////////////////////////////
FileClass SyncWidget::editNode(QString folderName, QString fullname, double id, double pid, int type, int existsOnServer, int existsOnLocal,
									 QDateTime localdate, QDateTime serverdate, QTreeWidgetItem *pnode, bool rootNode, int c, QString serverfolderName){
//debug("editNode => fullname="+fullname+"; folderName="+folderName+";");
	QString fpath=fullname;
	if(fullname!=""){
		int s=fpath.lastIndexOf("/");
		if(fpath.length()>1 && s>0){
			fpath=fpath.mid(0, s);
		}else{
			fpath="";
		}
	}else{
		fpath="";
	}

	if((!pnode || rootNode) && fpath=="") fpath="/";

//debug(" xx "+ localdate.toString("yyyy MM dd hh:mm:ss"));
	filelist[c].name=folderName;
	filelist[c].servername=serverfolderName;
	filelist[c].path=fpath;
	filelist[c].type=type;
	filelist[c].pid=pid;
	filelist[c].id=id;
	filelist[c].localdate=localdate;
	filelist[c].serverdate=serverdate;

	filelist[c].existsOnServer=existsOnServer;
	filelist[c].existsOnLocal=existsOnLocal;
/*
if(type==0){
//debug("x2 "+ intToQstring(filelist[c].localdate.toTime_t()));
	if(filelist[c].serverdate.toTime_t()-filelist[c].localdate.toTime_t() == gmt_offset){
//debug("x3");

		filelist[c].realserverdate=filelist[c].serverdate;
		filelist[c].serverdate=filelist[c].localdate;
	}
}
*/


	QString L="X";
	if(existsOnLocal==1 && existsOnServer==1){
		L="X";
		if(type==0){
			if(filelist[c].localdate>filelist[c].serverdate){
				L=">";
			}else if(filelist[c].localdate<filelist[c].serverdate){
				L="<";
			}
		}
	}else if(existsOnLocal==1 && existsOnServer!=1){
		L=">";
	}else if(existsOnLocal!=1 && existsOnServer==1){
		L="<";
	}


	QString basePath=pathToIcons;
	if(L=="X"){
		L=basePath +"none.gif";
	}else if(L==">"){
		L=basePath +"upload.gif";
	}else if(L=="<"){
		L=basePath +"download.gif";
	}

	QString wldate="";
	QString wsdate="";
	if(filelist[c].type==0){
		wldate=filelist[c].localdate.toString("yyyy MM dd hh:mm:ss");
		wsdate=filelist[c].serverdate.toString("yyyy MM dd hh:mm:ss");
	}

	QIcon icon;
	if(filelist[c].type==0){
		icon=QIcon(getFileIcon(getExtension(filelist[c].name)));
	}else{
		icon=QIcon(getFolderIcon());
	}

	if(filelist[c].servername==""){
		filelist[c].node->setText(0, filelist[c].name);
	}else{
		QString wpath=filelist[c].path+"/"+filelist[c].name;
		wpath.replace("//", "/");
		filelist[c].node->setText(0, wpath);
	}

	filelist[c].node->setText(1, filelist[c].servername);
	filelist[c].node->setText(2, wldate);
	filelist[c].node->setIcon(3, QIcon(L));
	filelist[c].node->setText(4, wsdate);
	filelist[c].node->setIcon(0, icon);

//	filelist[c].node->setCheckState(0, checked);				// 0 - not checked, 2 - checked

	return filelist[c];
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::showFoldersTree(FileClass* ress, QTreeWidgetItem *pnode, bool rootNode){
	if(rootNode){
	}

	bool L=true;
	for(int j=0; L && j<maxCount && ress[j].name.length()>0; j++){			// sorting files and folders
		L=false;
//debug("j="+intToQstring(j) +" >>> "+ress[j].name);
		for(int i=0; i<maxCount && ress[i+1].name.length()>0; i++){
			if(ress[i].name=="" || ress[i+1].name=="") continue;
//debug(ress[i].name+" VS "+ress[i+1].name+"     ");
			if(ress[i].type<ress[i+1].type || (ress[i].type==ress[i+1].type && ress[i].name.toLower()>ress[i+1].name.toLower())){
				FileClass f=ress[i+1];
				ress[i+1]=ress[i];
				ress[i]=f;
				L=true;
			}
		}		
	}


	for(int j=0; j<maxCount && ress[j].name.length()>0; j++){			// show folders
		if(ress[j].type==1)
			createNewNode(ress[j].name, ress[j].path+"/"+ress[j].name, ress[j].id, ress[j].pid, ress[j].type, ress[j].existsOnServer, ress[j].existsOnLocal, ress[j].localdate, ress[j].serverdate, pnode, false, ress[j].servername);
	}
	
	for(int j=0; j<maxCount && ress[j].name.length()>0; j++){			// show files
		if(ress[j].type==0)
			createNewNode(ress[j].name, ress[j].path+"/"+ress[j].name, ress[j].id, ress[j].pid, ress[j].type, ress[j].existsOnServer, ress[j].existsOnLocal, ress[j].localdate, ress[j].serverdate, pnode, false, ress[j].servername);
	}
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::changed(QTreeWidgetItem *node, int column){
	if(column!=0)	return ;

	if(node->checkState(0)==Qt::CheckState(0)){				// 0 - not check, 2 - check
		if(node->childCount()==0)	return ;
		setCheckStateAllChildNodes(node, 0);
	}

	if(node->checkState(0)==Qt::CheckState(2)){				// 0 - not check, 2 - check
		while(node){
			node->setCheckState(0, Qt::CheckState(2));
			node=node->parent();
		}
	}

	return ;
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::setCheckStateAllChildNodes(QTreeWidgetItem *node, int state){
//	debug("setCheckStateAllChildNodes( "+ intToQstring(state) +" )");
	int count=node->childCount()-1;
	for(int j=count; j>=0; j--){
		QTreeWidgetItem *cnode = node->child(j);
		int c=cnode->childCount();
		if(c>0)	setCheckStateAllChildNodes(cnode, state);

		cnode->setCheckState(0, Qt::CheckState(state));
	}

	return ;
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::brefreshAll(){
//	if(SrunFunction.running) return ;
	if(isRunningSomething())	return ;
	refreshAll();
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::badd(){
//	if(SrunFunction.running) return ;
	if(versionType!=1 && (ui->tree->topLevelItemCount()>=3 || addFoldersList.size()>=3)){
		QMessageBox::critical(this, "Error", "You can add only 3 folders!");
		return ;
	}

	if(isRunningSomething())	return ;

	linkFolders();
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::bproperties(){
//	if(SrunFunction.running) return ;
	if(isRunningSomething())	return ;
	properties();
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::logOut(){
debug("logOut()");
	if(isRunningSomething())	return ;
	if(QMessageBox::question(this, "Confirm", "Do you want Logout?", QMessageBox::Ok, QMessageBox::No)!=QMessageBox::Ok){
		return ;
	}

	login = "";
	password = "";
	passwordEncrypted = "";

	saveConfig(false);
	refreshAll(true);
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::refreshAll(bool clearAll){
	showMessage("Refreshing", false);
	isLoadedFilesList=false;

	for(int j=0, cnr=ui->tree->topLevelItemCount(); j<cnr; j++){							// delete all not root nodes
		QTreeWidgetItem *nd=ui->tree->topLevelItem(j);
		if(nd->childCount()>0)	removeNodeAndAllChild(nd);
	}

	refreshWnd();
	addFoldersList.clear();
	for(int i=0; i<maxCount && filelist[i].name.length()>0; i++){
		if(filelist[i].type==1) addFoldersList << filelist[i];

		delete filelist[i].node;
		filelist[i]=FileClass("","");
	}

	if(clearAll){
		token="*";
//		addFoldersList.clear();
		saveConfig(false);
		loadConfig();	// need to get files list 
	}

	SRemove.n=-1;

	SDeleteFile.id=0;
	SDeleteFile.lastid=0;

	SDownloadFile.id=0;
	SDownloadFile.addToFilelist=false;
	SDownloadFile.fullname="";

	SUploadFile.name="";
	SUploadFile.pid=0;
	SUploadFile.addToFilelist=false;
	SUploadFile.path="";


	SInitWnd.SyncTaskId=-1;
	SInitWnd.filesListIsGet=false;


	SCreateFolder.name="";
	SCreateFolder.pid=0;
	SCreateFolder.addToFilelist=false;
	SCreateFolder.f=FileClass();

	SrunFunction.running=false;
	SRunCommand.error=0;
	SRunCommand.response="";
	SRunCommand.restory="";
	SRunCommand.up_level_command="";
	SRunCommand.response_maxProgress=-1;
	SRunCommand.response_upload=false;
	SRunCommand.response_download=false;

	isLoadedFilesList=false;

	initWnd();
//	hideMessage();
}
//////////////////////////////////////////////////////////////////////
QString SyncWidget::getExtension(QString filename){
	QString ext="";

	int s=filename.lastIndexOf("/");
	if(s>0)	filename=filename.mid(s+1, filename.length()-s-1);

	s=filename.lastIndexOf(".");
	if(s>0)	ext=filename.mid(s+1, filename.length()-s-1);

	return ext;
}
//////////////////////////////////////////////////////////////////////
QString SyncWidget::getFileIcon(QString extension){
	QString path=pathToIcons +"files/";

	if(extension=="mp3"){
		path+="mp3";
	}else if(extension=="avi"){
		path+="avi";
	}else if(extension=="doc"){
		path+="doc";
	}else if(extension=="exe"){
		path+="exe";
	}else if(extension=="htm"){
		path+="htm";
	}else if(extension=="jpg"){
		path+="jpg";
	}else if(extension=="pdf"){
		path+="pdf";

	}else if(extension=="rar"){
		path+="rar";
	}else if(extension=="zip"){
		path+="zip";
	}else if(extension=="txt"){
		path+="txt";
	}else if(extension=="gz" || extension=="tar"){
		path+="zip";
	}else if(extension=="jpeg"){
		path+="jpg";
	}else if(extension=="jpe"){
		path+="jpg";
	}else if(extension=="bmp" || extension=="tiff" || extension=="psd" || extension=="gif" || extension=="png" || extension=="tga"){
		path+="jpg";
	}else if(extension=="html" || extension=="shtm" || extension=="xhtml" || extension=="shtml" || extension=="php" || extension=="php3" || extension=="php4" || extension=="php5" || extension=="css" || extension=="cgi" || extension=="xml" || extension=="asp"){
		path+="htm";
	}else if(extension=="java" || extension=="js" || extension=="pl"){
		path+="txt";

	}else{
		path+="file";
	}
	return path+".gif";
}
//////////////////////////////////////////////////////////////////////
QString SyncWidget::getFolderIcon(){
	QString path=pathToIcons +"files/";
	path+="folder.gif";
	return path;
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::properties(){
	propertiesWnd.setWindowModality(Qt::ApplicationModal);
//  ad.shareDrive=shareDrive;

	propertiesWnd.login=login;
	propertiesWnd.password=password;
	propertiesWnd.server=serverHost;
	propertiesWnd.logFileName=logFileName;
	propertiesWnd.showLogAfterQuickSync=needShowLogAfterQuickSync;
	propertiesWnd.deleteFromLocalWhenDeletedFromServer=deleteFromLocalWhenDeletedFromServer;
	propertiesWnd.deleteFromServerWhenDeletedFromLocal=deleteFromServerWhenDeletedFromLocal;
	propertiesWnd.showNotifyAfterScheduledSync=showNotifyAfterScheduledSync;

	propertiesWnd.useProxy=useProxy;
	propertiesWnd.proxyhost=proxyhost;
	propertiesWnd.proxyport=proxyport;
	propertiesWnd.proxylogin=proxylogin;
	propertiesWnd.proxypass=proxypass;

	if(detailedLogs==2){
		propertiesWnd.extendedLogs=true;
	}else{
		propertiesWnd.extendedLogs=false;
	}

	if(versionType==1){
		propertiesWnd.encryptPassword=encryptPassword;
	}


	propertiesWnd.initWnd();
	propertiesWnd.move(QPoint((int) (x()+5), (int) (y()+5)));
	propertiesWnd.show();

	hideMessage();
	saveConfig();
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::saveProperties(){
	QString tlogin=propertiesWnd.login;
	QString tpassword=propertiesWnd.password;
	QString tserver=propertiesWnd.server;

	QString tproxyhost	=propertiesWnd.proxyhost;
	QString tproxylogin	=propertiesWnd.proxylogin;
	QString tproxypass	=propertiesWnd.proxypass;
	int tproxyport			=propertiesWnd.proxyport;
	bool tuseProxy			=propertiesWnd.useProxy;

	if(versionType==1){
		encryptPassword=propertiesWnd.encryptPassword;
	}else{
		encryptPassword="";
	}

	bool L=false;
	if(tlogin!=login || tpassword!=password || tserver!=serverHost || tuseProxy!=useProxy || tproxyhost!=proxyhost || tproxyport!=proxyport || tproxylogin!=proxylogin || tproxypass!=proxypass){
		token="*";
		providerLogin="";
		providerPassword="";
		L=true;
	}

	serverHost=tserver;
	login=tlogin;
	password=tpassword;
	passwordEncrypted = encryptSMEPassword(password);
	proxyhost=tproxyhost;
	proxylogin=tproxylogin;
	proxypass=tproxypass;
	proxyport=tproxyport;
	useProxy=tuseProxy;

	deleteFromLocalWhenDeletedFromServer=propertiesWnd.deleteFromLocalWhenDeletedFromServer;
	deleteFromServerWhenDeletedFromLocal=propertiesWnd.deleteFromServerWhenDeletedFromLocal;
	needShowLogAfterQuickSync=propertiesWnd.showLogAfterQuickSync;
	showNotifyAfterScheduledSync=propertiesWnd.showNotifyAfterScheduledSync;
	if(propertiesWnd.extendedLogs){
		detailedLogs=2;
	}else{
		detailedLogs=1;
	}

	saveConfig();

	if(L)	refreshAll(true);

//	hideMessage();
//	saveConfig();
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::loadConfig(){
	if(fCnfName.length()<1)	return ;

	if(QFile::exists(fCnfName)==false){
		saveConfig();
		return ;
	}

	QString conf="";
	conf=readFromFile(fCnfName);

	conf="\n"+ conf + "\n";
	conf.replace("\n\n", "\n");

  if(conf.indexOf("<sync>")<0 || conf.length()<=1){		// try old method
		QFile file(fCnfName);
		file.open(QIODevice::ReadOnly | QIODevice::Text);
		QDataStream in(&file);

		in >> conf;
		file.close();
	}

	QString proxyConf=getPartQString(conf, "<proxy>", "</proxy>");
	conf=getPartQString(conf, "<sync>", "</sync>");

	if(conf.length()<=1){
		saveConfig();
		return ;
	}

	login=getPartQString(conf, "<blogin>", "</blogin>");
	if(login.length()>0){
		login=decodeBase64(login);
	}else{
		login=getPartQString(conf, "<login>", "</login>");
		if(login.length()<1)	login="";
	}

	serverHost=getPartQString(conf, "<server>", "</server>");
	if(serverHost.length()>0){
		serverHost=decodeBase64(serverHost);
	}else{
		serverHost="storagemadeeasy.com";
	}

	password=getPartQString(conf, "<apassword>", "</apassword>");
	if(password.length()>0){
		password=decryptSMEPassword(password);
	}else{
		password=getPartQString(conf, "<bpassword>", "</bpassword>");
		if(password.length()>0){
			password=decodeBase64(password);
		}else{
			password=getPartQString(conf, "<password>", "</password>");
			if(password.length()<1)	password="";
		}
	}

	passwordEncrypted = encryptSMEPassword(password);

	providerLogin=getPartQString(conf, "<providerLogin>", "</providerLogin>");
	if(providerLogin.length()>0){
		providerLogin=decodeBase64(providerLogin);
	}else{
		providerLogin="";
	}

	providerPassword=getPartQString(conf, "<providerPassword>", "</providerPassword>");
	if(providerPassword.length()>0){
		providerPassword=decodeBase64(providerPassword);
	}else{
		providerPassword="";
	}


	QString el="";
	el=getPartQString(conf, "<detailedLogs>", "</detailedLogs>");
	if(el.length()>0){
		detailedLogs=el.toInt();
	}else{
		detailedLogs=1;
	}

	el=getPartQString(conf, "<showlog>", "</showlog>");
	if(el=="1"){
		needShowLogAfterQuickSync=true;
	}else{
		needShowLogAfterQuickSync=false;
	}

	el=getPartQString(conf, "<deleteFromServerWhenDeletedFromLocal>", "</deleteFromServerWhenDeletedFromLocal>");
	if(el=="1"){
		deleteFromServerWhenDeletedFromLocal=true;
	}else{
		deleteFromServerWhenDeletedFromLocal=false;
	}

	el=getPartQString(conf, "<deleteFromLocalWhenDeletedFromServer>", "</deleteFromLocalWhenDeletedFromServer>");
	if(el=="1"){
		deleteFromLocalWhenDeletedFromServer=true;
	}else{
		deleteFromLocalWhenDeletedFromServer=false;
	}

	if(versionType==1){
		encryptPassword=getPartQString(conf, "<encryptPassword>", "</encryptPassword>");
		if(encryptPassword.length()>0){
			encryptPassword=decodeBase64(encryptPassword);
		}else{
			encryptPassword="";
		}
	}


	QString foldersList="";
	el=getPartQString(conf, "<foldersList2>", "</foldersList2>");
	if(el.length()>0){
		QString tfolders=decodeBase64(el);

		QString bl="user="+base64(login);
		el=getPartQString(tfolders, "<"+bl+">\n", "\n</"+bl+">");
		if(el.length()>0){
			addFoldersList.clear();
			el=decodeBase64(el)+"\n";
			QString dir="";
			for(dir=el.mid(0, el.indexOf("\n")); dir!=""; dir=el.mid(0, el.indexOf("\n"))){
				el=el.mid(el.indexOf("\n")+1);
				FileClass f=FileClass();
				f.id=getPartQString(dir, "<id>", "</id>").toDouble();
				f.servername=decodeBase64(getPartQString(dir, "<spath>", "</spath>"));
				f.path=decodeBase64(getPartQString(dir, "<path>", "</path>"));
				QDir d1=QDir(f.path);
				f.name=d1.dirName();
				f.path=getPath(f.path);
				addFoldersList << f;
				if(versionType!=1 && addFoldersList.size()>=3) break;
			}
		}
	}

	el=getPartQString(conf, "<showNotifyAfterScheduledSync>", "</showNotifyAfterScheduledSync>");
	if(el=="" || el!="0"){
		showNotifyAfterScheduledSync=true;
	}else{
		showNotifyAfterScheduledSync=false;
	}

	el=getPartQString(conf, "<wx>", "</wx>");
	if(el.length()>0)	wx=el.toInt();

	el=getPartQString(conf, "<wy>", "</wy>");
	if(el.length()>0)	wy=el.toInt();

	el=getPartQString(conf, "<ww>", "</ww>");
	if(el.length()>0)	ww=el.toInt();

	el=getPartQString(conf, "<wh>", "</wh>");
	if(el.length()>0)	wh=el.toInt();

	el=getPartQString(proxyConf, "<useproxy>", "</useproxy>");
	if(el.length()>0)	useProxy=el.toInt();

	el=getPartQString(proxyConf, "<proxyhost>", "</proxyhost>");
	proxyhost=(el=="")?(""):(decodeBase64(el));

	el=getPartQString(proxyConf, "<proxyport>", "</proxyport>");
	proxyport=(el=="")?(80):(decodeBase64(el).toInt());
	if(proxyport<1) proxyport=80;

	el=getPartQString(proxyConf, "<proxylogin>", "</proxylogin>");
	proxylogin=(el=="")?(""):(decodeBase64(el));

	el=getPartQString(proxyConf, "<proxypass>", "</proxypass>");
	proxypass=(el=="")?(""):(decodeBase64(el));

	return ;
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::saveConfig(bool saveFoldersList){
	if(fCnfName.length()<1)	return ;

	getWindowPosition();
	QString tfolders="", foldersList2="";
	QString conf="", lconf="", oldSyncConf="";
	if(QFile::exists(fCnfName)){
		lconf=readFromFile(fCnfName);

		if(lconf.length()<=1 || (lconf.indexOf("<mainWinget>")<0 && lconf.indexOf("<sync>")<0)){			// try old method
			QFile file2(fCnfName);
			file2.open(QIODevice::ReadOnly | QIODevice::Text);
			QDataStream in(&file2);
			in >> lconf;
			file2.close();
		}

		QString lconfNew="";
		QString tlconf=getPartQString(lconf, "<mainWinget>", "</mainWinget>");
		if(lconf.length()>0) lconfNew+="<mainWinget>"+ tlconf +"</mainWinget>";

		tlconf=getPartQString(lconf, "<explorer>", "</explorer>");
		if(lconf.length()>0) lconfNew+="<explorer>"+ tlconf +"</explorer>";

		tlconf=getPartQString(lconf, "<sync>", "</sync>");
		oldSyncConf="<sync>"+ tlconf +"</sync>";
		if(tlconf.length()>0){
			tlconf=getPartQString(tlconf, "<foldersList2>", "</foldersList2>");
			foldersList2=tlconf;
			if(tlconf.length()>0){
				tfolders=tlconf;
				QString bl="user="+base64(login);
				tfolders=decodeBase64(tfolders);
				if(saveFoldersList && tfolders.indexOf("<"+bl+">\n")>-1 && tfolders.indexOf("\n</"+bl+">")>-1){		// removing old folders list for this user
					QString x="\n</"+bl+">";
					tfolders=tfolders.mid(0, tfolders.indexOf("<"+bl+">\n")) +"\n"+ tfolders.mid(tfolders.indexOf("\n</"+bl+">")+x.length());
				}
			}
		}
		lconf=lconfNew;
		lconfNew="";
		tlconf="";
  }

	QFile::resize(fCnfName, 0);

	QString foldersList="";
	if(isLoadedFilesList && saveFoldersList){		// if list of files is not get then need don't change  foldersList
		addFoldersList.clear();
		for(int i=0; i<maxCount && filelist[i].name!=""; i++){
			if(filelist[i].servername!="" && filelist[i].existsOnServer==1 && filelist[i].type==1){
				addFoldersList << filelist[i];
			}
		}
		if(saveFoldersList){
			foreach(FileClass f, addFoldersList){
				QString fn=f.path+"/"+f.name;
				fn.replace("//", "/");
				foldersList+="<path>"+base64(fn)+"</path><spath>"+base64(f.servername)+"</spath><id>"+floatToQstring(f.id)+"</id>\n";
			}
			tfolders+="\n<user="+base64(login)+">\n"+base64(foldersList)+"\n</user="+base64(login)+">\n";
		}

		tfolders.replace("\n\n", "\n");
		tfolders=base64(tfolders);
	}else{
		tfolders=foldersList2;
	}

	QString iShowLogAfterQuickSync="0", sdeleteFromServerWhenDeletedFromLocal="0", sdeleteFromLocalWhenDeletedFromServer="0", sshowNotifyAfterScheduledSync="0";
	if(needShowLogAfterQuickSync) iShowLogAfterQuickSync="1";
	if(deleteFromServerWhenDeletedFromLocal) sdeleteFromServerWhenDeletedFromLocal="1";
	if(deleteFromLocalWhenDeletedFromServer) sdeleteFromLocalWhenDeletedFromServer="1";
	if(showNotifyAfterScheduledSync) sshowNotifyAfterScheduledSync="1";

	conf=lconf;
	if(!isHidden){
		conf.append("<sync>");
		conf.append("<blogin>"+ base64(login) +"</blogin>");
		conf.append("<apassword>"+ encryptSMEPassword(password) +"</apassword>");
		conf.append("<server>"+ base64(serverHost) +"</server>");
		conf.append("<showlog>"+ iShowLogAfterQuickSync +"</showlog>");
		conf.append("<deleteFromServerWhenDeletedFromLocal>"+ sdeleteFromServerWhenDeletedFromLocal +"</deleteFromServerWhenDeletedFromLocal>");
		conf.append("<deleteFromLocalWhenDeletedFromServer>"+ sdeleteFromLocalWhenDeletedFromServer +"</deleteFromLocalWhenDeletedFromServer>");
		conf.append("<providerLogin>"+ base64(providerLogin) +"</providerLogin>");
		conf.append("<providerPassword>"+ base64(providerPassword) +"</providerPassword>");
		conf.append("<showNotifyAfterScheduledSync>"+ sshowNotifyAfterScheduledSync +"</showNotifyAfterScheduledSync>");
		conf.append("<detailedLogs>"+ intToQstring(detailedLogs) +"</detailedLogs>");
		conf.append("<foldersList2>"+ tfolders +"</foldersList2>");
		conf.append("<wx>"+ intToQstring(wx) +"</wx>");
		conf.append("<wy>"+ intToQstring(wy) +"</wy>");
		conf.append("<ww>"+ intToQstring(ww) +"</ww>");
		conf.append("<wh>"+ intToQstring(wh) +"</wh>");
		if(versionType==1){
			conf.append("<encryptPassword>"+ base64(encryptPassword) +"</encryptPassword>");
		}
		conf.append("</sync>");
	}else{
		conf.append("<sync>");
		QString t1=getPartQString(oldSyncConf, "<sync>", "<foldersList2>");
		conf.append(t1);
		conf.append("<foldersList2>"+ tfolders +"</foldersList2>");
		t1=getPartQString(oldSyncConf, "</foldersList2>", "</sync>");
		conf.append(t1);
		conf.append("</sync>");
	}

	QString sUseProxy="0";
	if(useProxy) sUseProxy="1";
	conf.append("<proxy>");
	conf.append("<useproxy>"+ sUseProxy +"</useproxy>");
	conf.append("<proxyhost>"+ base64(proxyhost) +"</proxyhost>");
	conf.append("<proxyport>"+ base64(intToQstring(proxyport)) +"</proxyport>");
	conf.append("<proxylogin>"+ base64(proxylogin) +"</proxylogin>");
	conf.append("<proxypass>"+ base64(proxypass) +"</proxypass>");
	conf.append("</proxy>");

	if(writeToFile(fCnfName, conf)!=0){
		//	error
	}

// save proxy settings for perl script
	lconf="";
	QString cfName=QDir::homePath() + "/.storagemadeeasy.conf";
	QString cfNameOld=QDir::homePath() + "/.smestorage.conf";
	if(!QFile::exists(cfName) && QFile::exists(cfNameOld)) QFile::rename(cfNameOld, cfName);
	if(QFile::exists(cfName)) lconf=readFromFile(cfName);

	if(lconf==""){
		lconf+="host=storagemadeeasy.com\n";
		lconf+="SMALL_FILE_SIZE=1048576\n";
	}else{
		for(int j=0; lconf.lastIndexOf("\n")==lconf.length()-1 && j<100; j++){
			lconf=lconf.mid(0, lconf.length()-1);
		}
		lconf+="\n";
	}

	QString s=getPartQString(lconf, "useproxy=", "\n");
	if(s!="" || lconf.indexOf("useproxy=\n")>-1){
		lconf.replace("useproxy="+s+"\n", "useproxy="+sUseProxy+"\n");
	}else{
		lconf+="useproxy="+sUseProxy+"\n";
	}

	s=getPartQString(lconf, "proxyhost=", "\n");
	if(s!="" || lconf.indexOf("proxyhost=\n")>-1){
		lconf.replace("proxyhost="+s+"\n", "proxyhost="+proxyhost+"\n");
	}else{
		lconf+="proxyhost="+proxyhost+"\n";
	}

	s=getPartQString(lconf, "proxyport=", "\n");
	if(s!="" || lconf.indexOf("proxyport=\n")>-1){

		lconf.replace("proxyport="+s+"\n", "proxyport="+intToQstring(proxyport)+"\n");
	}else{
		lconf+="proxyport="+intToQstring(proxyport)+"\n";
	}

	s=getPartQString(lconf, "proxylogin=", "\n");
	if(s!="" || lconf.indexOf("proxylogin=\n")>-1){
		lconf.replace("proxylogin="+s+"\n", "proxylogin="+proxylogin+"\n");
	}else{
		lconf+="proxylogin="+proxylogin+"\n";
	}

	s=getPartQString(lconf, "proxypass=", "\n");
	if(s!="" || lconf.indexOf("proxypass=\n")>-1){
		lconf.replace("proxypass="+s+"\n", "proxypass="+proxypass+"\n");
	}else{
		lconf+="proxypass="+proxypass+"\n";
	}

	if(writeToFile(cfName, lconf)!=0){
		//	error
	}

	return ;
}
//////////////////////////////////////////////////////////////////////
QString SyncWidget::readFromFile(QString name){
	if(name=="")	return "";
	if(!QFile::exists(name))	return "";

	QString res="";
	char *buf =new char[1];
	buf[0]=' ';
	FILE * pFile;

	QByteArray tmName;
	if(localeEncoding!=""){
		QTextCodec *codec = QTextCodec::codecForName(localeEncoding.toUtf8().data());
		tmName = codec->fromUnicode(name);
	}else{
		tmName = name.toUtf8();
	}

	pFile=fopen(tmName.data(), "r");
	if(!pFile && localeEncoding!=""){		// try to use UTF-8 name
		tmName = name.toUtf8();
		pFile=fopen(tmName.data(), "r");
	}

//	pFile=fopen(name.toUtf8().data(), "r");
	if(!pFile)	return 0;
	while(!feof(pFile)){
		if(fread(buf, 1, 1, pFile)==1){
			res.append(buf[0]);
		}else{
			break;
		}
	}

	QByteArray b;					// convert  to UTF8
	b.append(res);
	res=QString::fromUtf8(b);
	fclose(pFile);
	return res;
}
//////////////////////////////////////////////////////////////////////
int SyncWidget::writeToFile(QString name, QString s){
	if(name=="")	return -1;

	FILE *pFile;
	QString rwMode="w";
	QByteArray tmName;
	if(localeEncoding!=""){
		QTextCodec *codec = QTextCodec::codecForName(localeEncoding.toUtf8().data());
		tmName = codec->fromUnicode(name);
	}else{
		tmName = name.toUtf8();
	}

	pFile=fopen(tmName.data(), rwMode.toUtf8().data());
	if(!pFile && localeEncoding!=""){		// try to use UTF-8 name
		tmName = name.toUtf8();
		pFile=fopen(tmName.data(), rwMode.toUtf8().data());
	}
	
//	pFile=fopen(name.toUtf8().data(), "w");
	if(!pFile)	return 0;

	int leng=s.length();
	for(int i3=0; i3<=leng; i3=i3+100){
		int l1=100;
		if(i3+l1>leng)	l1=leng-i3;
		QString sa =s.mid(i3, l1);
		if(sa=="")	break;
//		char *buf2=sa.toLatin1().data();
		QByteArray b="";					// convert  to UTF8
		b.append(sa.toUtf8());
		char *buf2=b.data();
		size_t wsize=size_t (b.length());
		size_t ws001=fwrite(buf2, 1, wsize, pFile);
		if(ws001!=wsize){
			// error
		}
	}

	fclose(pFile);
	return 0;
}
//////////////////////////////////////////////////////////////////////
/*
void SyncWidget::getDefaultProvider(){
debug(" getDefaultProvider()", 5);
	SRunCommand.restory="";
	SRunCommand.restory.append(SLOT(getDefaultProviderResp()));

	defaultProvider=-1;
	QString com="getdefaultprovider "+ getLoginAndPasswordForCMD() +" \""+ token +"\" --sync";
	showMessage("Retrieving Providers", false);
	runCommand2(com);
	return ;
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::getDefaultProviderResp(){
debug(" getDefaultProviderResp()", 5);
	QString list=SRunCommand.response;

	if(list.length()>0){
		int s=list.indexOf("<response>")+10;
		int e=list.indexOf("</response>");
		if(s>0 && e>0){
			list=list.mid(s, e-s);
			defaultProvider=list.toInt();
		}
	}
	if(defaultProvider<0) defaultProvider=0;

	return ;
}
*/
//////////////////////////////////////////////////////////////////////
/*
void SyncWidget::reSyncsProvider(){
	SRunCommand.restory="";
	SRunCommand.restory.append(SLOT(reSyncsProviderResp()));

	if(defaultProvider<0){
		if(!isHidden){
			QMessageBox::critical(this, tr("Error"), "Providers list is not got.");
		}else{
			addToLog("Error. Providers list is not got.\n", 0);
		}
		SRunCommand.restory="";
		initWnd();
		return ;
	}

	SRunCommand.up_level_command="";

	QString com="doprovidersyncinbackground "+ getLoginAndPasswordForCMD() +" "+ token  +" "+ floatToQstring(defaultProvider) +" --sync";
	runCommand2(com);
	return ;
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::reSyncsProviderResp(){
	QString list=SRunCommand.response;
	double taskId=-1;
	if(list.length()>0){
		int s=list.indexOf("<response>")+10;
		int e=list.indexOf("</response>");
		if(s>0 && e>0){
			list=list.mid(s, e-s);
			taskId=list.toInt();
		}
	}

	if(taskId<0){
		initWnd();
		return ;
	}
	SInitWnd.SyncTaskId=taskId;
	checkSyncsProvider(taskId);
	hideMessage();
	saveConfig();
	return ;
}
*/
//////////////////////////////////////////////////////////////////////
void SyncWidget::checkSyncsProvider(double id){
	if(id){}
	SRunCommand.restory="";
	SRunCommand.restory.append(SLOT(checkSyncsProviderResp()));
	showMessage("Retrieving background tasks", false);

	QString com="getuserbackgroundtasks "+ getLoginAndPasswordForCMD() +" \""+ token +"\" --sync";
	runCommand2(com);
	return ;
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::checkSyncsProviderResp(){
	double id=SInitWnd.SyncTaskId;
	QString list=SRunCommand.response;
	QString taskStatus="";
	
	if(list.length()>1){
		QDomDocument doc("taskslist");
		doc.setContent(list, true);

		QDomElement root=doc.documentElement();
		QDomNode n=root.firstChild();
		while(!n.isNull()){
			QDomElement e = n.toElement();
			if(!e.isNull()){
				if(e.tagName()=="t"){
				  QString tid="";
				  QString status="";

					QDomNode nf=n.firstChild();
					QDomElement eid=nf.toElement();
					if(eid.tagName()=="id")	tid=eid.text();

					nf = nf.nextSibling();
					QDomElement estatus = nf.toElement();
					if(estatus.tagName()=="status")	status=estatus.text();
					if(id==tid.toDouble()){
						taskStatus=status;
						break;
					}
				}
			}

			n = n.nextSibling();
		}

		if(taskStatus==""){
			if(!isHidden){
				QMessageBox::critical(this, tr("Error"), "Background task not found!");
			}else{
				addToLog("Error. Background task not found!\n", 0);
			}
		}else{
			if(taskStatus!="c"){
				debug("NOT  COMPLETE");
				showMessage("Waiting for background synchronisation to complete. Waiting for 5 seconds...", false);
				QTimer::singleShot(5000, this, SLOT(checkSyncsProvider()));
				return ;
			}
		}

	}

	hideMessage();
	saveConfig();
	initWnd();
	return ;
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::showMessage(QString m, bool showButtonCancel, bool showProgressBar){
debug("Action: "+ m);
	ui->textLabel1->setText("Action: "+ m);
	ui->textLabel1->show();
	ui->progressBar1->hide();

	if(showButtonCancel) ui->pushButton9->show();
	if(showProgressBar)	ui->progressBar1->show();

	refreshWnd();
	isCanceledAction=false;

	return ;
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::hideMessage(){
debug("hideMessage()");
	isRunning=false;
	isSyncInProcess=false;
	isPreparedToSync=false;
	updateAllState();
debug("all state updated");

	SCreateFolder.f=FileClass("","");
	SCreateFolder.name="";
	SCreateFolder.pid=-1;

	SDeleteFile.id=-1;
	SDeleteFile.lastid=-1;

	SDownloadFile.id=-1;
	SDownloadFile.fullname="";
	SDownloadFile.f=FileClass("","");

	SUploadFile.name="";
	SUploadFile.pid=-1;
	SUploadFile.path="";
	SUploadFile.f=FileClass("","");

	SrunFunction.running=false;
	SRunCommand.error=0;
	SRunCommand.response_maxProgress=0;

	linkFoldersWnd.unblockAll();

	ui->textLabel1->setText("");
	ui->textLabel1->hide();
	ui->progressBar1->hide();
	ui->pushButton9->hide();
	saveConfig();
debug("Config saved");

	for(int j=0; j<maxCount && filelist[j].name!=""; j++){		// need test
		filelist[j].node->setFlags(Qt::ItemIsSelectable | Qt::ItemIsUserCheckable | Qt::ItemIsEnabled);
	}
debug("Flags updated");

	return ;
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::cancelAction(){
	isCanceledAction=true;

	return ;
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::resizeEvent(QResizeEvent *e){
//	debug("MyWidget::resizeEvent  width "+ intToQstring(width()) + "  height "+ intToQstring(height()) );
	int w=width();
	int h=height();

	int fontSize=12;
	if(ui->pushButton0->font().pixelSize()>8){
		fontSize=ui->pushButton0->font().pixelSize();
	}else if(ui->pushButton0->font().pointSize()>7){
		fontSize=(int) (ui->pushButton0->font().pointSize()*1.3);
	}

	int w1=98;
	int sw=2, w_small=w1-59, w_big=w1+20;
	int h1=43, p=5, p_big=14, y=0;

	if(fontSize>12) w_big+=(fontSize-12)*4;

	ui->MenuBar->setGeometry(QRect(0, 0, w, 28));
	y+=25;		// This is need for menu

	ui->pushButton0->setGeometry(QRect(sw, y, w_small, h1));
	sw+=w_small+p_big;
	ui->pushButton1->setGeometry(QRect(sw, y, w_big-20, h1));
	sw+=w_big-20+p;
	ui->pushButton3->setGeometry(QRect(sw, y, w_big+3, h1));
	sw+=w_big+3+p;
	ui->pushButton2->setGeometry(QRect(sw, y, w_big-20, h1));
	sw+=w_big-20+p_big;
	ui->pushButton5->setGeometry(QRect(sw, y, w_big+5, h1));
	sw+=w_big+5+p;
	ui->pushButton4->setGeometry(QRect(sw, y, w_big-20, h1));
	sw+=w_big-20+p_big;

	ui->pushButton10->setGeometry(QRect(sw, y, w_small, h1));
	sw+=w_small+p+2;

	ui->pushButton11->setGeometry(QRect(sw, y, w_small, h1));
	sw+=w_small+p+2;

	ui->pushButton6->setGeometry(QRect(sw, y, w_small, h1));
	sw+=w_small+p;
	ui->pushButton7->setGeometry(QRect(sw, y, w_small, h1));
	sw+=w_small+p_big;
	ui->pushButton8->setGeometry(QRect(sw, y, w_small, h1));
	sw+=w_small+p;

	ui->widget->setGeometry(QRect(0, 0, w, h));
	ui->tree->setGeometry(QRect(3, y+48, w-3-3, h-48-32-y));
	ui->textLabel1->setGeometry(QRect(3, h-22, w-310, 21));
	ui->progressBar1->setGeometry(QRect(w-300, h-23, 200, 20));
	ui->pushButton9->setGeometry(QRect(w-90, h-25, 80, 23));

	QWidget::resizeEvent(e);
	if(nResize!=0)	saveConfig(false);

	nResize=1;
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::refreshWnd(bool tree){
	repaint();
	tree=true;

	if(tree){
		QTreeWidgetItem * stateNode;
		stateNode = new QTreeWidgetItem();
		stateNode->setText(0, "Local Folder");
		stateNode->setText(1, "Cloud Folder");
		stateNode->setText(2, "Local Date");
		stateNode->setIcon(3, QIcon(pathToIcons +"state.gif"));
		stateNode->setText(4, "Cloud Date");
		ui->tree->setHeaderItem(stateNode);
	}
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::openAll(){
	if(!ui->tree->currentItem()){
//		hideMessage();
		return ;
	}

	isCanceledAction = false;	// If isCanceledAction==true then it mean that was canceled previous action. So, we can set up it to false.

	bool state=true;
	if(ui->tree->currentItem()->isExpanded()){
		state=false;
	}else{
		state=true;
	}

	openChildNodes(ui->tree->currentItem(), state);

	return ;
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::openChildNodes(QTreeWidgetItem *node, bool state){
	node->setExpanded(state);
	if(isCanceledAction) return ;
	int count=node->childCount();
	for(int j=0; j<count; j++){
		QTreeWidgetItem *cnode = node->child(j);
		node->setExpanded(state);
		if(isCanceledAction) return ;
		int c=cnode->childCount();
		if(c>0)	openChildNodes(cnode, state);
	}

	return ;
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::updateAllState(int n){
	if(isHidden) return ;
debug("updateAllState("+QString::number(n)+")", 101);
	QIcon noneIcon=QIcon(pathToIcons +"none.gif");
	QIcon midIcon=QIcon(pathToIcons +"mid.gif");
	QIcon upIcon=QIcon(pathToIcons +"upload.gif");
	QIcon downIcon=QIcon(pathToIcons +"download.gif");
	QIcon deleteFromLocal=QIcon(pathToIcons +"deletel.gif");
	QIcon deleteFromServer=QIcon(pathToIcons +"deletes.gif");

	int j=0, cf=getCountFiles(filelist);
	if(n>-1){
		j=n;
		cf=n+1;
	}

	for(; j<cf; j++){
		if(filelist[j].node->checkState(0)!=Qt::CheckState(2)) continue;
		if(filelist[j].servername!=""){
//			QIcon icon = filelist[j].node->icon(3);
			FileClass f=filelist[j];
//=getFileByNode(filelist[j].node);

			QString L="X";
			if(f.existsOnLocal==1 && f.existsOnServer==1){
				if(f.type==0){
					if(f.localdate>f.serverdate){
						L=">";
					}else if(f.localdate<f.serverdate){
						L="<";
					}
				}
			}else if(f.existsOnLocal==1 && f.existsOnServer!=1){
				L=">";
			}else if(f.existsOnLocal!=1 && f.existsOnServer==1){
				L="<";
			}

			//debug("isRemovedOnServer("+f.name+", "+floatToQstring(f.pid)+")");
			//debug("isRemovedOnLocal("+f.name+", "+path+")");
			if(isRemovedOnServer(f, filelist[j].pid)){
				L="[";
			}else if(isRemovedOnLocal(f, filelist[j].path)){
				L="]";
			}

			if(L==">"){
				f.node->setIcon(3, upIcon);
			}else if(L=="<"){
				f.node->setIcon(3, downIcon);
			}else if(L=="["){
				setStateIcon(f.node, deleteFromServer);
			}else if(L=="]"){
				setStateIcon(f.node, deleteFromLocal);
			}

			if(L!="[" && L!="]"){
				QString ph="";
				if(filelist[j].path!="") ph=filelist[j].path+"/"+filelist[j].name;
				int st=0;
				if(f.type==1 && !f.isOpened && f.existsOnLocal==1 && f.existsOnServer==1){
					st=3;
				}else{
					st = updateState(f.node, filelist[j].id, ph);
				}

				if(L!="<" && L!=">" && L!="[" && L!="]"){
					if(st==0){
						f.node->setIcon(3, noneIcon);
					}else if(st==1){
						f.node->setIcon(3, upIcon);
					}else if(st==2){
						f.node->setIcon(3, downIcon);
					}else if(st==3){
						f.node->setIcon(3, midIcon);
					}
				}
			}

		}
	}

	return ;
}
//////////////////////////////////////////////////////////////////////
double SyncWidget::getOldFolderId(FileClass f, double folderId){
	if(folderId<0) return -1;
debug("getOldFolderId("+ f.name +", "+ floatToQstring(folderId) +")", 101);
	double r=-1;
	QList<FileClass> rs=getOldFilesList("", floatToQstring(folderId), false, true);

	for(int j=0, size=rs.size(); j<size; j++){
		if(rs.at(j).name==f.name && rs.at(j).type==f.type && (f.type==1 || rs.at(j).serverdate==f.localdate)){
			r=rs.at(j).id;
			break;
		}
	}
debug("getOldFolderId("+ f.name +", "+ floatToQstring(folderId) +") => "+ floatToQstring(r), 101);
	return r;
}
//////////////////////////////////////////////////////////////////////
int SyncWidget::updateState(QTreeWidgetItem *node, double folderId, QString path){		// return: 0 - none, 1 - up, 2 - down, 3 - need up or down sub folders
debug("updateState("+floatToQstring(folderId)+", "+ path +")", 101);
	path.replace("//", "/");
	int res=0;
	QIcon noneIcon=QIcon(pathToIcons +"none.gif"), midIcon=QIcon(pathToIcons +"mid.gif"), upIcon=QIcon(pathToIcons +"upload.gif"), downIcon=QIcon(pathToIcons +"download.gif"), deleteFromLocal=QIcon(pathToIcons +"deletel.gif"), deleteFromServer=QIcon(pathToIcons +"deletes.gif");

	QList<FileClass> oldFilesList_forServer, oldFilesList_forServer_withSubFolders;
	QList<FileClass> oldFilesList_forLocal, oldFilesList_forLocal_withSubFolders;

	int count=node->childCount();
	for(int j=0; j<count; j++){
		QTreeWidgetItem *cnode = node->child(j);
		FileClass f=getFileByNode(cnode);
		QString L="X";
		if(f.existsOnLocal==1 && f.existsOnServer==1){
			if(f.type==0){
				if(f.localdate>f.serverdate){
					L=">";
				}else if(f.localdate<f.serverdate){
					L="<";
				}
			}
		}else if(f.existsOnLocal==1 && f.existsOnServer!=1){
			L=">";
		}else if(f.existsOnLocal!=1 && f.existsOnServer==1){
			L="<";
		}

		QString pt1="", pt2="";
		if(path!="") pt1=path+"/"+f.name;

		if(f.path!=""){
			pt2=f.path+"/"+f.name;
		}else if(path!=""){
			pt2=path+"/"+f.name;
		}

		if(f.existsOnServer!=1 && isRemovedOnServer(f, folderId, true, oldFilesList_forServer, oldFilesList_forServer_withSubFolders)){
			L="[";
		}else if(f.existsOnLocal!=1 && isRemovedOnLocal(f, path, true, oldFilesList_forLocal, oldFilesList_forLocal_withSubFolders)){
			L="]";
		}

		if(L==">"){
			f.node->setIcon(3, upIcon);
		}else if(L=="<"){
			f.node->setIcon(3, downIcon);
		}else if(L=="["){
			setStateIcon(f.node, deleteFromServer);
		}else if(L=="]"){
			setStateIcon(f.node, deleteFromLocal);
		}else if(L=="X"){
			setStateIcon(f.node, noneIcon);
		}

		int st=0;
		if(L!="[" && L!="]" && f.type==1 && f.isOpened && cnode->childCount()>0){
			double elid=f.id;
			if(elid<0){		// this folder are removed, so need try get id from oldFilesList
				elid=getOldFolderId(f, folderId);
			}

			st=updateState(f.node, elid, pt2);
			if(L!="<" && L!=">" && L!="[" && L!="]"){
				if(st==0){
					f.node->setIcon(3, noneIcon);
				}else if(st==1){
					f.node->setIcon(3, upIcon);
				}else if(st==2){
					f.node->setIcon(3, downIcon);
				}else if(st==3){
					f.node->setIcon(3, midIcon);
				}
			}
		}

		if(f.type==1 && !f.isOpened && f.existsOnLocal==1 && f.existsOnServer==1){
			res=3;
			f.node->setIcon(3, midIcon);
		}
		if(st>0 || L!="X")	res=3;
	}

	return res;
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::setStateIcon(QTreeWidgetItem *node, QIcon icon){
	node->setIcon(3, icon);

	int count=node->childCount();
	for(int j=0; j<count; j++){
		node->child(j)->setIcon(3, icon);
		if(node->child(j)->childCount()>0) setStateIcon(node->child(j), icon);
	}

	return ;
}
//////////////////////////////////////////////////////////////////////
FileClass SyncWidget::getFileByNode(QTreeWidgetItem *node){
	FileClass f;
	int cf=getCountFiles(filelist);
	for(int j=0; j<cf; j++){
		if(filelist[j].node==node) return filelist[j];
	}

	return f;
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::setWindowPosition(){
	if(isHidden) return ;

	if(wx>0 && wy>0)	move(QPoint(wx, wy));
	if(ww>0 && wh>0)	resize(QSize(ww, wh));
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::getWindowPosition(){
	if(isHidden) return ;
	QSize sz=size();
	ww=sz.width();
	wh=sz.height();
	wx=x();
	wy=y();
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::saveProviderLog(){
	providerLogin=providerlog.plogin;
	providerPassword=providerlog.ppass;

	if(getProviderLoginAndPassword_calledFrom2){
		setProviderData();
		return ;
	}

	SrunFunction.running=true;
	SRunCommand.restory="";
	SRunCommand.up_level_command="";
	SRunCommand.up_level_command.append(SLOT(checkProviderLog()));

	QString com="setproviderdata "+ getLoginAndPasswordForCMD() +" \""+ tmptoken +"\" --sync";
	runCommand2(com);
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::checkProviderLog(){
	QString list=SRunCommand.response;
	QString taskStatus="";
	if(list=="<response>success</response>"){
		saveConfig();
		token=tmptoken;
		refreshAll(true);
	}else{
		tmptoken=token;
		token="";
		if(!isHidden){
			QMessageBox::critical(this, tr("Error"), "Check your Provider login and Provider password!");
		}else{
			addToLog("Error. Check your Provider login and Provider password!\n", 0);
		}
		SrunFunction.running=false;
		getProviderLoginAndPassword();
	}
	hideMessage();
	return ;
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::showLogs(QString caption, QString log, QString filename, bool nonModal){
//	if(caption=="") caption = "";
	if(filename=="") filename = logFileName;

	if(log=="" && filename!="")	log=readFromFile(filename);		// need show log from file

	if(nonModal){
		messageWnd.setWindowModality(Qt::NonModal);
	}else{
		messageWnd.setWindowModality(Qt::ApplicationModal);
	}

	if(log.length()>0){
		messageWnd.logs=log;
	}else{
		messageWnd.logs=logs;
	}

	messageWnd.caption=caption;
	messageWnd.initWnd();
	messageWnd.move(QPoint((int) (x()+5), (int) (y()+5)));
	messageWnd.show();

}
//////////////////////////////////////////////////////////////////////
void SyncWidget::clearLog(){
	if(QMessageBox::question(this, "Confirm", "Do you want to Clear scheduler log?", QMessageBox::Ok, QMessageBox::No)==QMessageBox::Ok){
		QFile::resize(logFileName, 0);
	}
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::getProviderLoginAndPassword(bool calledFrom2){
	providerlog.setWindowModality(Qt::ApplicationModal);
	providerlog.plogin=providerLogin;
	providerlog.ppass=providerPassword;

	getProviderLoginAndPassword_calledFrom2=calledFrom2;

	providerlog.initWnd();
	providerlog.move(QPoint((int) (x()+5), (int) (y()+5)));
	providerlog.show();
}
//////////////////////////////////////////////////////////////////////
bool SyncWidget::getProviderLoginAndPassword2(bool calledFrom2){
	providerlog.setWindowModality(Qt::ApplicationModal);
	providerlog.plogin=providerLogin;
	providerlog.ppass=providerPassword;
	providerlog.useAlternativeExit=1;
	getProviderLoginAndPassword_calledFrom2=calledFrom2;

	providerlog.initWnd();
	providerlog.move(QPoint((int) (x()+5), (int) (y()+5)));
	providerlog.show();
debug("Waiting for login and password from provider.");
	QEventLoop eventLoop;
	QObject::connect(&providerlog, SIGNAL(saveProviderLog2()), &eventLoop, SLOT(quit()));
	eventLoop.exec();

	if(providerlog.plogin=="" || providerlog.ppass==""){
		providerLogin="";
		providerPassword="";
		return false;
	}

	providerLogin=providerlog.plogin;
	providerPassword=providerlog.ppass;
	return true;
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::addToLog(QString s, int level){
	if(level>detailedLogs)	return ;
	if(s=="")	return ;
	logs+=s;
}
//////////////////////////////////////////////////////////////////////
bool SyncWidget::isRunningAnotherWnd(){
	QString cmdQSt="ps ax -o pid,ppid,args | grep smesynccenter"; // Notice. We use this command in regexp!
	//debug(cmdQSt);
	int nn0=20000;
	char buf[nn0];

	QString buf2="";
	FILE *ptr;
	for(int i=0; i<nn0; i++)
		buf[i]=' ';

	ptr = popen(cmdQSt.toUtf8().data(), "r");
	int ptrd = fileno(ptr);
	fcntl(ptrd, F_SETFL);
	ssize_t r = read(ptrd, buf, nn0);
	while(r==-1){
		r=read(ptrd, buf, nn0);
	}

	QString s_utf8=QString::fromUtf8(buf);
	buf2.append(s_utf8);

	buf2=buf2.mid(0, nn0-1);
	int lngt=buf2.length();

	for(; lngt>0; lngt--){
		if(buf2.mid(lngt-1, 1)!=" ")	break;
		buf2=buf2.mid(0, lngt-1);
	}

	int lt=-1;
	for(; lt!=buf2.length();){
		lt=buf2.length();
		buf2.replace("   ", " ");
		buf2.replace("  ", " ");
	}

	(void) pclose(ptr);

	buf2 = "\n"+ buf2 +"\n";
	for(int j=0; j<5; j++){
		buf2 = buf2.replace("export LANG; /usr/bin/smesynccenter", "");
	}

	QString curProcessID="";
	QStringList ls = buf2.split("\n");
	for(int k=0, sz=ls.length(); k<sz; k++){
		QString line=ls.value(k);
		//debug("line = "+line);
		QString rs0;
		QRegExp rx0("^ *([0-9]+)[^0-9]*([0-9]+)[^0-9](.*)ps ax \\-o pid,ppid,args \\| grep smesynccenter");
		int pos01 = rx0.indexIn(line);
		if(pos01>-1){
			curProcessID=rx0.cap(2);
		}
	}

	if(curProcessID==""){
		debug("Error. Cannot get cID of current process.\n"+buf2);
	}else{
		debug("curProcessID = "+curProcessID);
	}
	
	for(int k=0, sz=ls.length(); k<sz; k++){
		QString line=ls.value(k);
		QString rs0;
		QRegExp rx("^ *([0-9]+)[^0-9]*([0-9]+)[^0-9](.*)smesynccenter --hidden");
		int pos01 = rx.indexIn(line);
		if(pos01>-1){
			if(curProcessID==rx.cap(1)){
				continue;	// This is cuerrent process
			}else{
				return true;
			}
		}
	}
	return false;
}
//////////////////////////////////////////////////////////////////////
bool SyncWidget::isRunningSomething(bool prepareToRun){
	if(login==""){
		properties();
		return true;
	}

	if(SrunFunction.running || isRunning) return true;
	if(prepareToRun){
		for(int j=0; j<maxCount && filelist[j].name!=""; j++){		// this makes all nodes not checkable
			filelist[j].node->setFlags(Qt::ItemIsSelectable | Qt::ItemIsEnabled);
		}
	}
	return false;
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::showTrayIcon(){
	QString trayIconPath="/usr/share/pixmaps/sme_synccenter_icon_42.png";
	QString cmdQSt="gconftool -g /desktop/gnome/interface/gtk_theme";
	char buf[BUFSIZ];
	QString buf2="";
	FILE *ptr;

	ptr=popen(cmdQSt.toUtf8().data(), "r");
	if(fgets(buf, BUFSIZ, ptr)!=NULL) buf2.append(buf);
	(void) pclose(ptr);

	for(int i=buf2.length(); i>=0; i--){
		if(buf2.mid(i)=="\n" || buf2.mid(i)=="\r" || buf2.mid(i)==" "){
			buf2=buf2.mid(0, i);
			i--;
		}
	}

	debug("Theme = "+ buf2 +";");
	if(buf2.toLower()=="ambiance") trayIconPath="/usr/share/smeclient/sme_synccenter_icon_22_mono.png";
	trayIcon->setIcon(QIcon(trayIconPath));

	trayIcon->setToolTip("SME Sync Center. Syncing...");
	trayIcon->show();
	hide();
	
	return ;
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::exitWithMessage(QString mess){
	int t=8000;		// 1000 = 1sec.
	if(showNotifyAfterScheduledSync){
		trayIcon->showMessage(QString("SME Sync Center"), mess, QSystemTrayIcon::NoIcon, t);
	}else{
		if(needShowLogAfterQuickSync){
			QApplication::exit();				// we don't show any windows/messages. So, we can exit now.
			return ;
		}
		t=1;
	}
	QTimer::singleShot(t, this, SLOT(closeAllAndExit()));
	return ;
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::closeAllAndExit(){
	if(needShowLogAfterQuickSync && !messageWnd.isHidden()){ 	 // user close window with log?
		QTimer::singleShot(300, this, SLOT(closeAllAndExit()));
		return ;
	}

	QApplication::exit();
	return ;
}
//////////////////////////////////////////////////////////////////////
double SyncWidget::getIdFromOldServerFilelist(FileClass f, bool useCache){
// If you want to use "useCache" then you should keep control on this cache cacheOfOldServerFilelist (clear it once before ussing)
//debug("getIdFromOldServerFilelist(name="+f.name+", path="+f.path+", id="+floatToQstring(f.id)+")");
	QString pt=f.path+"/"+f.name;
	double oldid=-1;

	if(useCache && cacheOfOldServerFilelist.size()>0){
		for(int j=0, sz=cacheOfOldServerFilelist.size(); j<sz; j++){
			if(cacheOfOldServerFilelist.at(j).path==f.path && cacheOfOldServerFilelist.at(j).name==f.name){
				return cacheOfOldServerFilelist.at(j).id;
			}
		}
	}else{
		QList<FileClass> ls = getOldFilesList("", "", false);
		if(useCache){
			cacheOfOldServerFilelist = ls;
		}

		for(int j=0, sz=ls.size(); j<sz; j++){
			if(ls.at(j).path==f.path && ls.at(j).name==f.name){
				return ls.at(j).id;
			}
		}
	}

	return oldid;
}
//////////////////////////////////////////////////////////////////////
QString SyncWidget::getNameOfUserConfigFile(QString alternativeServer){
	QString res="";
	QString us="";
	for(int i=0; i<3; i++){
		if(i==0){
			us=((alternativeServer!="") ? (alternativeServer) : (serverHost))+"_"+base64(login);		// old format
		}else if(i==1){						// String have lower case symbols and first symbol have upper case
			QString llogin=login.toLower();
			QString f=llogin.mid(0, 1).toUpper();
			llogin=f+llogin.mid(1);
			us=((alternativeServer!="") ? (alternativeServer) : (serverHost))+"_"+base64(llogin);
		}else{									// New format
			QString llogin=login.toLower();
			us=((alternativeServer!="") ? (alternativeServer) : (serverHost))+"_"+base64(llogin);
		}
		std::string utf8_text=us.toUtf8().constData(); 
		MD5 cx=MD5(utf8_text);
		us=QString::fromUtf8(cx.getResult().c_str());
		res=QDir::homePath() + "/.storagemadeeasy/._"+us+".cnf";
		if(QFile::exists(res)) break;
	}

	if(res==""){
		QString llogin=login.toLower();
		us=((alternativeServer!="") ? (alternativeServer) : (serverHost))+"_"+base64(llogin);
		std::string utf8_text=us.toUtf8().constData(); 
		MD5 cx=MD5(utf8_text);
		us=QString::fromUtf8(cx.getResult().c_str());
		res=QDir::homePath() + "/.storagemadeeasy/._"+us+".cnf";
	}

	if(!QFile::exists(res) && alternativeServer=="" && serverHost.indexOf("storagemadeeasy.com")>-1){
		QString altServer=serverHost;
		altServer.replace("storagemadeeasy.com", "smestorage.com");
		QString res2=getNameOfUserConfigFile(altServer);
		if(QFile::exists(res2)){
			QFile::rename(res2, res);
		}
	}

	return res;
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::saveFilesListToFile(bool update){
	QString fln=getNameOfUserConfigFile();

	QDir confDir;
	if(!confDir.exists(QDir::homePath() + "/.storagemadeeasy"))	confDir.mkdir(QDir::homePath() + "/.storagemadeeasy");

	cacheOfOldServerFilelist.clear();	// This is need for a function getIdFromOldServerFilelist()

	QString res="";
	if(!update){
		res="<r>";
		for(int j=0; j<maxCount && filelist[j].name!=""; j++){
			if(!filelist[j].isOpened && filelist[j].type==1){   // Need to add all files/subfolders again
debug("ps4 "+filelist[j].path+"/"+filelist[j].name, 101);
				QList<FileClass> ls=getOldFilesList(getCorrectFilePath(filelist[j].path+"/"+filelist[j].name), floatToQstring(filelist[j].id), true);
debug("ps41", 101);
				for(int k=0, sz=ls.size(); k<sz; k++){
					QString r01="", tPath=ls.at(k).path;
					if(ls.at(k).existsOnLocal==1 && tPath=="") tPath="/";

					r01+="<f>"\
						"<id>"+ floatToQstring(ls.at(k).id) +"</id>"\
						"<pid>"+ floatToQstring(ls.at(k).pid) +"</pid>"\
						"<name>"+ base64(ls.at(k).name) +"</name>"\
						"<path>"+ base64(tPath) +"</path>"\
						"<lmodify>"+floatToQstring(ls.at(k).localdate.toTime_t())+"</lmodify>"\
						"<smodify>"+floatToQstring(ls.at(k).serverdate.toTime_t())+"</smodify>"\
						"<type>"+ QString::number(ls.at(k).type) +"</type>"\
						"</f>";
					res+=r01;
				}
			}
debug("ps5", 101);

			// This file have been removed from local, but syncs don't remove it from server. So need add this file to oldLocalFileList.
			if(filelist[j].existsOnLocal!=1 && filelist[j].existsOnServer==1){
				QString p="<id>"+ floatToQstring(filelist[j].id) +"</id>";
				int s0=oldFilesList.indexOf(p);
				if(s0>0){
debug("need add this file again.  p="+p);
					int s1=oldFilesList.lastIndexOf("<f>", s0), s2=oldFilesList.indexOf("</f>", s0);
					if(s1>-1 && s2>-1 && s1<s2){
						QString f=oldFilesList.mid(s1, s2-s1+4);
						res+=f;
					}
				}

				continue;
			}
debug("ps6", 101);

			// This file have been removed from server, but syncs don't removed it from local. So need add this file to oldServerFileList.
			if(filelist[j].existsOnLocal==1 && filelist[j].existsOnServer!=1){
				double oldId=getIdFromOldServerFilelist(filelist[j], true);
				if(oldId<0) continue;
				QString p="<id>"+ floatToQstring(oldId) +"</id>";
				int s0=oldFilesList.indexOf(p);
				if(s0>0){
debug("need add this file again.  p="+p);
					int s1=oldFilesList.lastIndexOf("<f>", s0);
					int s2=oldFilesList.indexOf("</f>", s0);
					if(s1>-1 && s2>-1 && s1<s2){
						QString f=oldFilesList.mid(s1, s2-s1+4);
debug("f="+f+";");
						res+=f;
					}
				}
				continue;
			}
debug("ps7", 101);

			QString r="";
			if(filelist[j].existsOnLocal==1 && filelist[j].path=="") filelist[j].path="/";
			r+="<f>"\
				"<id>"+ floatToQstring(filelist[j].id) +"</id>"\
				"<pid>"+ floatToQstring(filelist[j].pid) +"</pid>"\
				"<name>"+ base64(filelist[j].name) +"</name>"\
				"<path>"+ base64(filelist[j].path) +"</path>"\
				"<lmodify>"+floatToQstring(filelist[j].localdate.toTime_t())+"</lmodify>"\
				"<smodify>"+floatToQstring(filelist[j].serverdate.toTime_t())+"</smodify>"\
				"<type>"+ QString::number(filelist[j].type) +"</type>"\
				"</f>";
			res+=r;
		}
		res+="</r>";
	}
debug("ps8", 101);

	if(update){
		if(writeToFile(fln, oldFilesList)!=0){}
	}else{
		if(writeToFile(fln, res)!=0){}
		oldFilesList=res;
	}
debug("ps9", 101);
}
//////////////////////////////////////////////////////////////////////
QString SyncWidget::loadFilesListFromFile(){
	QString fl=getNameOfUserConfigFile();

	if(!QFile::exists(fl)) return "";
	return readFromFile(fl);
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::linkFolders(){
	linkFoldersWnd.setWindowModality(Qt::ApplicationModal);
	linkFoldersWnd.clear();
	linkFoldersWnd.move(QPoint((int) (x()+ww/2-280), y()));
	linkFoldersWnd.initWnd();
	linkFoldersWnd.show();
	return ;
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::linkFoldersOSF(QString folderid, int from){		// need to Open Server Folder in Link window
debug("linkFoldersOSF()");
	linkFoldersWnd.blockAll();
	showMessage("Retrieving Folders List", true);
	SRunCommand.restory="";
	SRunCommand.restory.append(SLOT(linkFoldersOSFResp()));
	SlinkFolders.folderid=folderid;
	QString count="1000";
	QString uri="getFolderContents/"+ base64(folderid) +","+ base64(intToQstring(from)) +","+ base64(count) +","+ base64("1")+","+ base64("n") +",,,,"+ base64("y") +","+ base64("s") +",,,,"+ base64("filelist|fi_encrypted|fi_name|fi_id|fi_pid");

	runFunction(uri);
	tmptoken="";
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::linkFoldersOSFResp(){
debug("linkFoldersOSFResp()");
	QString res=SrunFunction.response;
	SrunFunction.response="";
	SRunCommand.restory="";

	if(res.indexOf("<response>")<0 || res.indexOf("</response>")<0){
		QMessageBox::critical(this, "Error", "Can't get folders list.");
		hideMessage();
		return ;
	}

	int from=-1, count=-1, total=-1;
	QDomDocument doc("response");
	doc.setContent(res, true);
	bool L=false;
	QDomElement root=doc.documentElement();
	QDomNode filelist;
	QDomNode n=root.firstChild();
	while(!n.isNull()){
		QDomElement e = n.toElement();
		if(!e.isNull()){
			if(e.tagName()=="filelist"){
				filelist=n.firstChild();
				L=true;
			}else if(e.tagName()=="from"){
				from=e.text().toInt();
			}else if(e.tagName()=="count"){
				count=e.text().toInt();
			}else if(e.tagName()=="total"){
				total=e.text().toInt();
			}

		}
		n=n.nextSibling();
	}

	if(from<0 || count<0 || total<0){
		QMessageBox::critical(this, "Error", "Can't get folders list.");
		hideMessage();
		return ;
	}

	if(L){
		n=filelist;
		filelist.clear();
		for(int i=0; !n.isNull(); i++){
			QDomElement e=n.toElement();
			if(!e.isNull() && e.tagName()=="n"+intToQstring(i)){
				QString fid="", pid="", name="";
				QDomNode nf=n.firstChild();
				do{
					QDomElement el=nf.toElement();
					if(el.tagName()=="fi_id"){
						fid=el.text();
					}else if(el.tagName()=="fi_pid"){
						pid=el.text();
					}else if(el.tagName()=="fi_name"){
						name=el.text();
					}
					nf=nf.nextSibling();
				}while(!nf.isNull());

				if(fid.length()>0 && name.length()>0){
					Tsfolder f;
					f.id=fid;
					f.pid=pid;
					f.name=name;
					linkFoldersWnd.addToSTree(f);
				}

				n=n.nextSibling();
			}
		}// for
	}// if

	if(from+count<total){
		linkFoldersOSF(SlinkFolders.folderid, from+count);
		return ;
	}

	linkFoldersWnd.unblockAll();
	resume(1);
	return ;
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::linkAndAddtoTree(QString path, QString id, QString serverfoldername, QString pid){
debug("linkAndAddtoTree("+path+", "+id+","+serverfoldername+", "+ pid +")");

	bool L0=true;
	if(id=="") id="0";
	if(pid=="") pid="0";
	if(path=="" && id=="0"){				// Need to show all linked folders
		isRunning=true;
		int k=0, size=addFoldersList.size();
		for(; k<size; k++){
			FileClass f=addFoldersList.at(k);
			QString path0=getCorrectFilePath(addFoldersList.at(k).path+"/"+addFoldersList.at(k).name);
			if(!QFile::exists(path0)){	  // Local folder don't exists
				debug("Local folder don't exists "+ path0);
				addFoldersList.removeAt(k);
				size--;
				k--;
				continue;
			}

			TFileClass2 file0=getFileFullInfo2(floatToQstring(f.id));
			FileClass f0=file0.file;
			if(file0.error!=""){			// request failed
				L0=false;
				if(!isHidden){
					QMessageBox::critical(this, tr("Error"), "Error 73. Cannot get information from server about the folder "+floatToQstring(f.id));
				}else{
					QApplication::exit();
					addToLog("Error 73. Cannot get information from server about the folder "+floatToQstring(f.id)+"\n", 0);
					isRunning=false;
					return ;
				}
			}else{
				if(f.id==f0.id && f0.servername!="" && f0.existsOnServer==1 && f0.pid>-1){
					debug("Preparing to show folder in tree");
					f.pid=f0.pid;										// preparing to show folder in tree
					f.servername=f0.servername;
					addFoldersList.replace(k, f);

					QDateTime localdate, serverdate;				// show folder in tree
					QList<QString> finfo=getFileInfo(path0);
					FileClass bFolder=createNewNode(finfo.at(0), path0, f.id, f.pid, 1, 1, 1, localdate, serverdate, NULL, true, f.servername, true);
					if(bFolder.id){}
				}else{		// this folder have been removed on server
					debug("Server folder don't exists "+ floatToQstring(f.id));
					addFoldersList.removeAt(k);
					k--;
					size--;
				}
			}
		}
	}else{				// Need to show folder that have been linked from Link Window
debug("Adding folder to tree => "+ serverfoldername);
		linkFoldersWnd.hide();
		QDateTime localdate, serverdate;				// show folder in tree
		QList<QString> finfo=getFileInfo(path);
		FileClass f;
		f.id=id.toDouble();
		f.pid=pid.toDouble();
		f.servername=serverfoldername;
		f.name=finfo.at(0);
		f.path=finfo.at(1);
		f.isOpened=false;
		addFoldersList << f;
		FileClass bFolder=createNewNode(f.name, getCorrectFilePath(f.path+"/"+f.name), f.id, f.pid, 1, 1, 1, localdate, serverdate, NULL, true, f.servername, true);
		if(bFolder.type>-1){}
	}

	if(L0) isLoadedFilesList=true;

	if(!isHidden){
		hideMessage();
	}else{
		initWnd2();
	}
	return ;
}
//////////////////////////////////////////////////////////////////////
void SyncWidget::openFolder(QTreeWidgetItem *item, bool useHideMessage){
	if(isSyncInProcess && useHideMessage) return ;		// sync in process, so user cannot open any folders in this time.
	if(item->childCount()!=1) return ;			// This folder have been opened previously
	if(item->child(0)->text(0)!="") return ;
	QTreeWidgetItem *temporaryItem=item->child(0);

	int n=-1;											// Searching for folder and checking if list of files is loaded
	for(int j=0; j<maxCount && filelist[j].name!=""; j++){
		if(filelist[j].node==item){
			if(filelist[j].isOpened) return ;			// list of files is already loaded
			n=j;
			break;
		}
	}

	if(n==-1) return ;
	countOpeningFolders++;
	showMessage("Retrieving list of files  "+filelist[n].name, true);
	filelist[n].isOpened=true;

	// Need to load list of files
	TFileClass r=compareLocalAndServerFolder(filelist[n].path, filelist[n].name, filelist[n].id);
	if(r.error==""){			// List of local and server files is received. Need to show files/folders in tree
		QTreeWidgetItem *parentNode=filelist[n].node;
		for(int k=0, sz=r.list.count(); k<sz; k++){				// Add to tree
			FileClass ff=r.list.at(k);
			createNewNode(ff.name, getCorrectFilePath(ff.path+"/"+ff.name), ff.id, ff.pid, ff.type, ff.existsOnServer, ff.existsOnLocal, ff.localdate, ff.serverdate, parentNode, false, ff.servername, true);
		}
		delete temporaryItem;			// remove temporary item
	}
	filelist[n].isOpened=true;
	countOpeningFolders--;

	if(useHideMessage){
		if(countOpeningFolders==0) hideMessage();
	}else{
		if(!isHidden) updateAllState();
	}
	return ;
}
//////////////////////////////////////////////////////////////////////
// if file/folder don't exists then .name and .servername will be empty
// if request is failed then .id will be -1
TFileClass2 SyncWidget::getFileFullInfo2(QString id){
debug("getFileFullInfo2("+id+")");
	showMessage("Searching folder", true);

	FileClass file=FileClass();
	file.id=-1;
	file.existsOnServer=0;
	file.name="";
	file.servername="";
	TFileClass2 res;
	res.error="";
	res.file=file;

	TrunFunction3 response1=runFunction3("getFileFullInfo/"+ base64(id));

	int s0=response1.response.indexOf("<file>");
	int e0=response1.response.lastIndexOf("</file>");
	QString statusmessage=getPartQString(response1.response, "<statusmessage>", "</statusmessage>");
	if(response1.response.indexOf("<response>")<0 || response1.response.indexOf("</response>")<0){
		res.error="Cannot get information from server about the folder "+id;
		return res;
	}

	if(s0<0 || e0<0 || s0>e0 || statusmessage=="File not found"){
		res.error="";
		return res;
	}

	QString deletingtime="";
	QDomDocument doc("response");
	doc.setContent(response1.response, true);
	QDomElement root=doc.documentElement();
	QDomNode n=root.firstChild();
	while(!n.isNull()){
		QDomElement e=n.toElement();
		if(!e.isNull() && e.tagName()=="file"){
			QString fid="", pid="", name="";
			QDomNode nf=n.firstChild();
			do{
				QDomElement el=nf.toElement();
				if(el.tagName()=="fi_id"){
					fid=el.text();
				}else if(el.tagName()=="fi_pid"){

					pid=el.text();
				}else if(el.tagName()=="fi_name"){
					name=el.text();
				}else if(el.tagName()=="deletingtime"){
					deletingtime=el.text();
				}
				nf=nf.nextSibling();
			}while(!nf.isNull());

			if(fid.length()>0 && name.length()>0){
				file.id=fid.toDouble();
				file.pid=pid.toDouble();
			}
		}
		if(!e.isNull() && e.tagName()=="filepath"){
			file.servername=e.text();
		}
		n=n.nextSibling();
	}// for

	if(deletingtime!=""){	 // file is deleted. So, need to clear name and servername
		file.name="";
		file.servername="";
	}else{
		file.existsOnServer=1;
	}

	file.id=id.toDouble();
	res.file=file;
	return res;
}
//////////////////////////////////////////////////////////////////////
QString SyncWidget::getPath(QString fullname, bool returnSL){
	int s=fullname.lastIndexOf("/");
	if(fullname.length()>1 && s>0){
		return fullname.mid(0, s);
	}else{
		if(returnSL){
			return QString("/");
		}else{
			return QString("");
		}
	}

}
//////////////////////////////////////////////////////////////////////
TFileClass SyncWidget::getFolderContents(QString folderid, int from){
debug("getFolderContents("+ folderid +", "+ intToQstring(from) +")");
	TFileClass Response;
	Response.error="";
	QList<FileClass> resp;

	if(folderid=="-1"){
		return Response;
	}

//	showMessage("Retrieving Folders List", true);
	QString uri="getFolderContents/"+ base64(folderid) +","+ base64(intToQstring(from)) +","+ base64("1000") +",,"+ base64("n") +",,,,"+ base64("y") +","+ base64("s") +",,,,"+ base64("filelist|fi_encrypted|fi_name|fi_id|fi_modified|fi_size|fi_type|fi_localtime|fi_size");

	TrunFunction3 response1=runFunction3(uri);

	if(response1.response.indexOf("<response>")<0 || response1.response.indexOf("</response>")<0){
		Response.error="Can't get files list";
		return Response;
	}

	from=-1;
	int count=-1, total=-1;
	QDomDocument doc("response");
	doc.setContent(response1.response, true);
	bool L=false;
	QDomElement root=doc.documentElement();
	QDomNode filelist, n=root.firstChild();
	while(!n.isNull()){
		QDomElement e = n.toElement();
		if(!e.isNull()){
			if(e.tagName()=="filelist"){
				filelist=n.firstChild();
				L=true;
//				break;
			}else if(e.tagName()=="from"){
				from=e.text().toInt();
			}else if(e.tagName()=="count"){
				count=e.text().toInt();
			}else if(e.tagName()=="total"){
				total=e.text().toInt();
			}

		}
		n=n.nextSibling();
	}

	if(from<0 || count<0 || total<0){
		Response.error="Can't get files list";
		return Response;
	}

	if(L){
		n=filelist;
		filelist.clear();
		for(int i=0; !n.isNull(); i++){
			QDomElement e=n.toElement();
			if(!e.isNull() && e.tagName()=="n"+intToQstring(i)){
				FileClass f0=getFileFromDomNode(n, folderid.toDouble());
				f0.serverdate=toLocal(f0.serverdate);
				if(f0.id>0 && f0.name!=""){
					resp << f0;
				}

				n=n.nextSibling();
			}
		}// for
	}// if

	if(from+count<total){
		TFileClass resp2=getFolderContents(folderid, from+count);
		if(resp2.error!="") return resp2;

		for(int i=0, sz=resp2.list.count(); i<sz; i++){
			resp << resp2.list.at(i);
		}
	}

	Response.list=resp;
	return Response;
}
//////////////////////////////////////////////////////////////////////
FileClass SyncWidget::getFileFromDomNode(QDomNode n, double p_id){
//debug("getFileFromDomNode()");
	QString fid="", name="", type="", lastmodify="", localtime="", serverSize="";		//  encrypted="", size="", pid=""
	FileClass f;
	QDomNode nf=n.firstChild();
	do{
		QDomElement el=nf.toElement();
		if(el.tagName()=="fi_id"){
			fid=el.text();
		}else if(el.tagName()=="fi_name"){
			name=el.text();
		}else if(el.tagName()=="fi_type"){
			type=el.text();
		}else if(el.tagName()=="fi_modified"){
			lastmodify=el.text();
		}else if(el.tagName()=="fi_localtime"){
			localtime=el.text();
		}else if(el.tagName()=="fi_size"){
			serverSize=el.text();
		}

		nf=nf.nextSibling();
	}while(!nf.isNull());

	if(type!="0" && type!="1") type="";
	if(fid.length()>0 && name.length()>0 && type.length()>0){
		if(localtime=="0000-00-00 00:00:00" || localtime=="") localtime=lastmodify;
		QDateTime serverdate=QDateTime::fromString(localtime, Qt::ISODate);
		f.name=name;
		f.serverdate=serverdate;
		f.realserverdate=serverdate;
		f.id=fid.toDouble();
		f.serverSize=serverSize.toLongLong();
		f.pid=p_id;
		f.type=type.toInt();					// 0 - file, 1 - folder
		f.existsOnServer=1;
		f.isProcessed=false;
		f.isSyncedUp=false;
		f.isSyncedDown=false;
		f.isOpened=false;
	}
	return f;
}
//////////////////////////////////////////////////////////////////////
// This function get files list from server and compare it with local files list
// It returns list of files than need to add to tree
TFileClass SyncWidget::compareLocalAndServerFolder(QString folder, QString fname, double folderId){
debug("compareLocalAndServerFolder("+folder+", "+fname+", "+ floatToQstring(folderId)+")");
	QString path=getCorrectFilePath(folder+"/"+fname);

	QList<FileClass> reslocal=getLocalFolder(path, false);
	QList<FileClass> res;
	TFileClass response=getFolderContents(floatToQstring(folderId));
	if(response.error!=""){
		if(!isHidden){
			QMessageBox::critical(this, tr("Error"), "Can't get list of files.");
		}else{
			addToLog("Error. Can't get list of files.\n", 0);
		}
		return response;
	}

	res=response.list;

	for(int j=0, sz=res.count(); j<sz; j++){
		res[j].path=path;
		for(int i=0; i<reslocal.size(); i++){
			if(res[j].name==reslocal.at(i).name && res[j].type==reslocal.at(i).type){
				FileClass f=res.at(j);
				f.localdate=reslocal.at(i).localdate;
				f.path=reslocal.at(i).path;
				f.existsOnLocal=1;

				if(f.localdate!=f.serverdate){		// This is fix for wrong time zone (and summer time)
					if(toLocal(f.localdate)==f.serverdate || toLocal(f.localdate, 3600)==f.serverdate || toLocal(f.localdate, -3600)==f.serverdate
						|| f.localdate.addSecs(3600)==f.serverdate || f.localdate==f.serverdate.addSecs(3600)
					){
						QFile file01(getCorrectFilePath(f.path + "/" + f.name));
						if(f.serverSize==file01.size()){
							f.localdate=f.serverdate;
						}
					}
				}

				res.replace(j, f);
				reslocal.removeAt(i);
				break;
			}

			if(res[j].existsOnLocal!=1){
				FileClass f=res.at(j);
				f.existsOnLocal=0;
				res.replace(j, f);
			}
		}
	}

	for(int i=0; i<reslocal.size(); i++){
		FileClass f=reslocal.at(i);
		f.existsOnServer=0;
		res << f;
	}

	bool L=true;			// sorting files and folders
	for(int i=0, sz=res.size(); i<sz && L; i++){
		L=false;
		for(int j=0; j<sz-1; j++){
			if(res.at(j).name=="" || res.at(j+1).name=="") continue;
			if(res.at(j).type<res.at(j+1).type || (res.at(j).type==res.at(j+1).type && res.at(j).name.toLower()>res.at(j+1).name.toLower())){
				FileClass f=res.at(j+1);
				res.replace(j+1, res.at(j));
				res.replace(j, f);
				L=true;
			}
		}
	}

	response.error="";
	response.list=res;
	return response;
}
//////////////////////////////////////////////////////////////////////
QString SyncWidget::getEncryptionKeyForPassword(){
	return "def1pa2s2swor44de5e56seu1jai3kd7";		// Temporary will be used static
/*
	// dmidecode 2>/dev/null | grep "Serial Number" | grep -v "Not Specified" |  grep -v "None" || /usr/sbin/dmidecode 2>/dev/null | grep "Serial Number" | grep -v "Not Specified" |  grep -v "None" || cat  /sys/class/dmi/id/[bios]* 2>/dev/null | grep -v "cat: " | grep -v "Permission denied"
	QString command = "dmidecode 2>/dev/null | grep \"Serial Number\" | grep -v \"Not Specified\" |  grep -v \"None\" || /usr/sbin/dmidecode 2>/dev/null | grep \"Serial Number\" | grep -v \"Not Specified\" |  grep -v \"None\" || cat  /sys/class/dmi/id/[bios]* 2>/dev/null | grep -v \"cat: \" | grep -v \"Permission denied\"";

	QString s = runCommand(command, 0, false, false, true);
	s = s.replace("\r", "");
	if(s.indexOf("\n")>2){
		if(s.indexOf("Serial Number:")>-1){		// Take only first line
			s = s.mid(0, s.indexOf("\n"));
		}

		std::string utf8_text = base64(s).toUtf8().constData(); 
		MD5 cx = MD5(utf8_text);
		s = QString::fromUtf8(cx.getResult().c_str());
		return s;
	}else{
		return "def1pa2s2swor44de5e56seu1jai3kd7";
	}
*/
}
//////////////////////////////////////////////////////////////////////
QString SyncWidget::encryptSMEPassword(QString password){
	if(!canPasswordBeEncrypted){
		return password;
	}

	QString command = "echo \"x"+ base64(password) +"x\" | openssl enc -aes-256-cbc -a -k \""+ base64(encryptionKeyForPassword) +"\"";
	QString s = runCommand(command, 0, false, false, true);
	s = s.replace("\n", "");
	s = s.replace("\r", "");
	return "-aes-" + s;
}
//////////////////////////////////////////////////////////////////////
QString SyncWidget::decryptSMEPassword(QString password){
	if(!canPasswordBeEncrypted){
		return password;
	}

	if(password.indexOf("-aes-")!=0){
		return password;			// password is not encrypted
	}

	password = password.mid(QString("-aes-").length());

	QString command = "echo \""+ password +"\" | openssl enc -d -aes-256-cbc -a -k \""+ base64(encryptionKeyForPassword) +"\"";
	QString s = runCommand(command, 0, false, false, true);
	s = s.replace("\n", "");
	s = s.replace("\r", "");

	if(s.indexOf("x")==0 && s.lastIndexOf("x")==s.length()-1){
		password = decodeBase64(s.mid(1, s.length()-2));
		return password;
	}else{				// Password is incorrect
		return "";
	}
}
//////////////////////////////////////////////////////////////////////
QString SyncWidget::getLoginAndPasswordForCMD(){
	if(canPasswordBeEncrypted){
		return "base64-"+ base64(login) +":base64a-"+ base64(passwordEncrypted) +" base64-"+ base64(providerLogin) +":base64-"+ base64(providerPassword);
	}else{
		return "base64-"+ base64(login) +":base64-"+ base64(password) +" base64-"+ base64(providerLogin) +":base64-"+ base64(providerPassword);
	}
}
//////////////////////////////////////////////////////////////////////

