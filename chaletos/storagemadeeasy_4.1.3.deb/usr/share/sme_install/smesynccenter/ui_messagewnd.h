#ifndef UI_MESSAGEWND_H
#define UI_MESSAGEWND_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
//#include <QtGui/QButtonGroup>
#include <QtGui/QLabel>
//#include <QtGui/QCheckBox>
//#include <QtGui/QRadioButton>
//#include <QtGui/QGroupBox>
//#include <QtGui/QVBoxLayout>
#include <QtGui/QLineEdit>
#include <QtGui/QTextEdit>
#include <QtGui/QPushButton>
//#include <QtGui/QComboBox>
#include <QtGui/QWidget>

//#include <QtGui/QFileDialog>
// #include <QFile>

#include <Qt3Support/Q3MimeSourceFactory>
// #include <QtGui/QDialog>
// #include <QtGui/QMenu>
// #include <QtGui/QMenuBar>
#include <QtGui/QMessageBox>

class Ui_MessageWnd
{
 public:
	QWidget *widget;
	QLabel *textLabel1, *textLabel2, *textLabel3;
	QPushButton *pushButton1, *pushButton2;
	QLineEdit *lineEdit1;
	QTextEdit	*textEdit1;
    void setupUi(QWidget *MessageWnd)
    {
      if(MessageWnd->objectName().isEmpty())
			MessageWnd->setObjectName(QString::fromUtf8("MessageWnd"));
		int windowW=580;
		int windowH=300;
		MessageWnd->resize(windowW, windowH);
		MessageWnd->setWindowIcon(QIcon("/usr/share/pixmaps/sme_synccenter_icon_42.png"));
		MessageWnd->setMinimumSize(200, 200);

      widget=new QWidget(MessageWnd);
      widget->setObjectName(QString::fromUtf8("widget"));
      widget->setGeometry(QRect(0, 0, 900, 700));
/*
QFont wdgfont("Arial", 11);
widget->setFont(wdgfont);
*/
//			checkBox=new QCheckBox(widget);
//			checkBox->setObjectName(QString::fromUtf8("checkBox"));
//			checkBox->setGeometry(QRect(10, 10, 480, 15));

      textLabel1=new QLabel(widget);
      textLabel1->setObjectName(QString::fromUtf8("textLabel1"));
      textLabel1->setGeometry(QRect(15, 10, 280, 18));
      textLabel1->setText("Caption");
/*
      lineEdit1=new QLineEdit(widget);
      lineEdit1->setObjectName(QString::fromUtf8("lineEdit1"));
      lineEdit1->setGeometry(QRect());

      textLabel2=new QLabel(widget);
      textLabel2->setObjectName(QString::fromUtf8("textLabel2"));
      textLabel2->setGeometry(QRect(left, sh, w, h));
*/
      textEdit1=new QTextEdit(widget);
      textEdit1->setObjectName(QString::fromUtf8("textEdit1"));
      textEdit1->setGeometry(QRect(10, 35, windowW-20, windowH-85));
      textEdit1->setText("");

      pushButton1=new QPushButton(widget);
      pushButton1->setObjectName(QString::fromUtf8("pushButton1"));
      pushButton1->setGeometry(QRect(int (windowW/2)-60, windowH-35, 120, 25));
      pushButton1->setText("OK");

      retranslateUi(MessageWnd);

      QMetaObject::connectSlotsByName(MessageWnd);
    } // setupUi

    void retranslateUi(QWidget *MessageWnd)
    {

      MessageWnd->setWindowTitle(QApplication::translate("MessageWnd", "Storage Made Easy Sync Center", 0, QApplication::UnicodeUTF8));

      Q_UNUSED(MessageWnd);
    }// retranslateUi

};

namespace Ui {
    class MessageWnd: public Ui_MessageWnd {};
} // namespace Ui

#endif // UI_MESSAGEWND_H
