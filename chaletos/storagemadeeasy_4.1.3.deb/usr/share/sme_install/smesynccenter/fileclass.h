#ifndef FILECLASS_H
#define FILECLASS_H

#include <QtGui/QWidget>
#include <QDateTime>
#include <QTreeWidget>
#include <QTreeWidgetItem>

namespace Ui
{
    class FileClass;
}

class FileClass{
//   Q_OBJECT

 public:
  FileClass();
  FileClass(QString fname, QString fpath);
  FileClass(QString fname, QString fpath, int fexistsOnServer, int fexistsOnLocal);
  FileClass(QString fname, QString fpath, int fexistsOnServer, int fexistsOnLocal, QDateTime flocaldate, QDateTime fserverdate);
  ~FileClass();

	QString name, servername, path;
	QDateTime localdate, serverdate, realserverdate;
	double id, pid;
	int type;
	qint64 serverSize;
	int existsOnServer;		// 0 - false, 1 - true, -1 - don't know
	int existsOnLocal;		// 0 - false, 1 - true, -1 - don't know
	bool isProcessed, isSyncedUp, isSyncedDown, isOpened;	// isOpened=false - list of files/folders of this folder is not loaded.
	QTreeWidgetItem *node;

};

#endif // FILECLASS_H
