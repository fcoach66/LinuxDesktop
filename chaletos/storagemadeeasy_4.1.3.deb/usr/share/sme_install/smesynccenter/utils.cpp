#include <QFile>

#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <unistd.h>
#include <math.h>


QString boolToQstring(bool b){
   return (b) ? ("true") : ("false");
}

QString intToQstring(int n){
        char buffer[100];
        sprintf(buffer, "%d", n);
        return QString(buffer);
}

QString floatToQstring(double n){
   char buffer[100];
   sprintf(buffer, "%0.5f", n);
   QString s=buffer;
   int p=s.indexOf(".00000");
   if(p==-1) p=s.indexOf(",00000");
   if(p>-1) return s.mid(0, p);
   return s;
}

QString getPartQString(QString s, QString from, QString to){
   int st=s.indexOf(from);
   if(st<0) return "";
   st += from.length();
   int e=s.indexOf(to, st);
	if(to.length()==0) e = s.length();
   if(e-st<=0) return "";
   QString el=s.mid(st, e-st);
   if(el.length()>0 && st>=from.length() && e>-1){
      return el;
   }else{
      return "";
   }
}

void debug(QString s, int level, int DEBUG=0){
        if(level<=DEBUG){
                printf("%s\n", s.toUtf8().data());
        }
}

bool isNumber(QString s){
        if(s=="0" || s=="1" || s=="2" || s=="3" || s=="4" || s=="5" || s=="6" || s=="7" || s=="8" || s=="9") return true;
        return false;
}

int getInt(QString s, int defaultValue=0){
// remove all symbols from string angd try to take number
        if(s=="") return defaultValue;
        bool ok;
        int r = s.toInt(&ok, 10);
        if(!ok){
                while(s.length()>0){						// remove all symbols before numbers
                        if(isNumber(s.at(0)) || (QString(s.at(0))=="-" && isNumber(s.at(1)))) break;
                        s=s.mid(1);
                }

                for(int i=1, sz=s.length(); i<sz; i++){		// remove all symbols after numbers
                        if(!isNumber(s.at(i))){
                                s=s.mid(0, i);
                                break;
                        }
                }
                return getInt(s, defaultValue);
        }

        return r;
}
//////////////////////////////////////////////////////////////////////
QString base64(QString t){
        return QString(t.toUtf8().toBase64());
}
//////////////////////////////////////////////////////////////////////
QString decodeBase64(QString t){
        QByteArray xx="";
        xx.append(t);
        return QString::fromUtf8(xx.fromBase64(xx));
}
//////////////////////////////////////////////////////////////////////
QString getCorrectFilePath(QString s){          // replace // to / and add / on the start
   if(s.indexOf("/")!=0) s="/"+s;
   s.replace("//", "/");
   return s;
}
//////////////////////////////////////////////////////////////////////
QList<QString> getFileInfo(QString s){          // return QList(name, path) from fullname. In the path last symbol is not a "/"
   QList<QString> res;
   s.replace("//", "/");
   int p0=s.indexOf("/");
   if(p0<0){
      res << s << "";
      return res;
   }

   if(p0!=0) s="/"+s;
   if(s.lastIndexOf("/")==s.length()-1) s=s.mid(0, s.length()-1);

   p0=s.lastIndexOf("/");
   res << s.mid(p0+1);
   s=s.mid(0, p0);   // path
   if(s.lastIndexOf("/")==s.length()-1) s=s.mid(0, s.length()-1);
   res << s;
   return res;
}
//////////////////////////////////////////////////////////////////////

