#include <QtGui/QApplication>
#include "syncwidget.h"
#include "utils.cpp"

//#include <stdlib.h>
#include <stdio.h>

#include <unistd.h>
#include <fcntl.h>


int main(int argc, char *argv[])
{
	bool isHidden=false, needCheckforoldversion=false;
	int needSync=0, debug=-1;
	QString com="";
	for(int i=0; i<argc; i++){
		com="";
		com.append(argv[i]);
		if(com=="--hidden")			isHidden=true;
		if(com=="--syncall")			needSync=1;
		if(com=="--syncup")			needSync=2;
		if(com=="--syncdown")		needSync=3;
		if(com=="--cloneup")			needSync=4;
		if(com=="--clonedown")		needSync=5;
		if(com=="--checkforoldversion")	needCheckforoldversion=true;
		if(com=="--debug")			debug=1000;
	}

	QApplication a(argc, argv);

	SyncWidget w;
	if(isHidden){
		w.hide();
	}else{
		w.show();
	}

	w.isHidden=isHidden;
	w.needRunSync=needSync;
	w.needCheckforoldversion=needCheckforoldversion;
	if(debug>-1) w.DEBUG=debug;

	w.start();
	return a.exec();
}
