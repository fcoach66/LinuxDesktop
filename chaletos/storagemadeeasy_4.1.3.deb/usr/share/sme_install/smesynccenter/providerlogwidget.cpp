#include "providerlogwidget.h"
#include "ui_providerlogwidget.h"

ProviderlogWidget::ProviderlogWidget(QWidget *parent) : QWidget(parent), ui(new Ui::ProviderlogWidget){
  ui->setupUi(this);
	plogin="";
	ppass="";
   useAlternativeExit=0;

// Buttons
  QObject::connect(ui->pushButton1, SIGNAL(clicked()), this, SLOT(saveProviderlog()));
  QObject::connect(ui->pushButton2, SIGNAL(clicked()), this, SLOT(hideWindow()));
}
//////////////////////////////////////////////////////////////////////
ProviderlogWidget::~ProviderlogWidget(){
  delete ui;
}
//////////////////////////////////////////////////////////////////////
void ProviderlogWidget::saveProviderlog(){
   QString login = ui->lineEdit1->text();
   QString pass  = ui->lineEdit2->text();
   if( login.length()<1 ){
      QMessageBox::critical(this, tr("Error"), "     Enter login     ");
      return ;
   }

   if(pass.length()<1){
      QMessageBox::critical(this, tr("Error"), "   Enter password   ");
      return ;
   }

   plogin=login;
   ppass=pass;

   if(useAlternativeExit==0){
      emit saveProviderLog();
   }else{
      emit saveProviderLog2();
   }
   this->hide();
}
//////////////////////////////////////////////////////////////////////
void ProviderlogWidget::hideWindow(){
   if(useAlternativeExit==1){
      plogin="";
      ppass="";
      emit saveProviderLog2();
   }
   this->hide();
}
//////////////////////////////////////////////////////////////////////
void ProviderlogWidget::initWnd(){
	ui->lineEdit1->setText(plogin);
	ui->lineEdit2->setText(ppass);
}
//////////////////////////////////////////////////////////////////////

