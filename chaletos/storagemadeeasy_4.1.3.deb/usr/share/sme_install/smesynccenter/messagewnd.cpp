#include "messagewnd.h"
#include "ui_messagewnd.h"

#include "cqthread.h"
#include "fcntl.h"
#include <stdio.h>

MessageWnd::MessageWnd(QWidget *parent) : QWidget(parent), ui(new Ui::MessageWnd){
  ui->setupUi(this);

	DEBUG=-1;
	logs="";
	caption="";

// Buttons
	QObject::connect(ui->pushButton1, SIGNAL(clicked()), this, SLOT(hideWindow()));
}
//////////////////////////////////////////////////////////////////////
MessageWnd::~MessageWnd(){
  delete ui;
}
//////////////////////////////////////////////////////////////////////
void MessageWnd::hideWindow(){
  this->hide();
}
//////////////////////////////////////////////////////////////////////
void MessageWnd::initWnd(){
	ui->textLabel1->setText(caption);
	ui->textEdit1->setText(logs);

}
//////////////////////////////////////////////////////////////////////
QString MessageWnd::getPart(QString q, QString s1, QString s2){
	int s=q.indexOf(s1);
	int e=q.indexOf(s2, s+s1.length());
	if(s>-1 && s>-1 && s<e){
		return q.mid(s+s1.length(), e-s-s1.length());
	}else{
		return "";
	}

}
//////////////////////////////////////////////////////////////////////
void MessageWnd::debug(QString s, int level){
	if(level<=DEBUG){
		QByteArray b = s.toLatin1();
		char *c=b.data();
		printf("%s\n", c);
	}

}
//////////////////////////////////////////////////////////////////////
QString MessageWnd::intToQstring(int n){
	char buffer[100];
	sprintf(buffer, "%d", n);
	QString res;
	res.append(buffer);

	return res;
}
//////////////////////////////////////////////////////////////////////
QString MessageWnd::floatToQstring(double n){
	char buffer[100];
	sprintf(buffer, "%f", n);
	QString res;
	res.append(buffer);

  int s=res.indexOf(",");
  if(s>0){
	  res=res.mid(0, s);
  }else{
	  s=res.indexOf(".");
		if(s>0)	res=res.mid(0, s);
  }

	return res;
}
//////////////////////////////////////////////////////////////////////
void MessageWnd::resizeEvent(QResizeEvent *e){
//	debug("MyWidget::resizeEvent  width "+ intToQstring(width()) + "  height "+ intToQstring(height()) );
	int w=width();
	int h=height();

	ui->textLabel1->setGeometry(QRect(10, 8, 280, 18));
	ui->textEdit1->setGeometry(QRect(3, 30, w-6, h-65));
	ui->pushButton1->setGeometry(QRect(int (w/2)-60, h-28, 120, 25));
	ui->widget->setGeometry(QRect(0, 0, w+1, h+1));

	QWidget::resizeEvent(e);
}






